/**
 *
 */
package com.jh.signator.maintain.producer.agreement.dao;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import com.jh.signator.maintain.producer.agreement.model.data.ContractTypeInfo;
import com.jh.signator.maintain.producer.agreement.model.data.ProducerAgreementResult;
import com.jh.signator.maintain.producer.agreement.model.data.TProducerInfo;
import com.manulife.esb.xsd.distribution.jhfn.maintainproduceragreement.CreateProducerAgreement;
import com.manulife.esb.xsd.distribution.jhfn.maintainproduceragreement.DeleteProducerAgreement.ProducerAgreement;
import com.manulife.esb.xsd.distribution.jhfn.maintainproduceragreement.UpdateProducerAgreement;

/**
 * Provides fake for Endpoint integration test.
 *
 */
public class FakeMaintainProducerAgreementDao implements MaintainProducerAgreementDao {

	public static final String VALID_TPARTY_ICODE = "8001";
	public static final String VALID_TPARTY_IDENTIFIER_ICODE = "8030";
	public static final String VALID_TPARTY_IDENTIFIER_PARTY_ID_NO = "8032";
	public static final String VALID_TPARTY_PARTY_ID_NO = "429";
	public static final String VALID_TPARTY_IDENTIFIER_ID_NO = "171564";

	/*
	 * (non-Javadoc)
	 *
	 * @see com.jh.signator.maintain.identity.dao.MaintainPartyIdentityDao#
	 * selectTCodeDecode(java.lang.String)
	 */
	@Override
	// Cache Candidate
	public List<ContractTypeInfo> selectContractTypeInfo() {
		final List<ContractTypeInfo> contractTypeInfoResults = new ArrayList<>();
		final ContractTypeInfo contractTypeInfo = new ContractTypeInfo();
		contractTypeInfo.setAgentTypeKey("MANAGING-DIRECTOR");
		contractTypeInfo.setContractCode("HV");
		contractTypeInfo.setContractTypeCodeNo(Long.valueOf("31"));
		contractTypeInfoResults.add(contractTypeInfo);
		return contractTypeInfoResults;
	}

	@Override
	public List<TProducerInfo> selectProducerInfoCreate(final String partyIdNo) {
		final List<TProducerInfo> tProducerInfoResult = new ArrayList<>();
		final TProducerInfo tProducerInfo = new TProducerInfo();
		tProducerInfo.setPartyIdNo(Long.valueOf("4948"));
		tProducerInfo.setPrdcrConIdNo(Long.valueOf("36196"));
		tProducerInfo.setPrdcrIdNo(Long.valueOf("4263"));
		tProducerInfoResult.add(tProducerInfo);
		return tProducerInfoResult;
	}

	@Override
	public List<TProducerInfo> selectProducerInfoUpdate(final String partyIdNo) {
		final List<TProducerInfo> tProducerInfoResult = new ArrayList<>();
		final TProducerInfo tProducerInfo = new TProducerInfo();
		tProducerInfo.setPartyIdNo(Long.valueOf("4948"));
		tProducerInfo.setPrdcrConIdNo(Long.valueOf("36196"));
		tProducerInfo.setPrdcrIdNo(Long.valueOf("4263"));
		tProducerInfoResult.add(tProducerInfo);
		return tProducerInfoResult;
	}

	@Override
	public List<TProducerInfo> selectProducerInfoDelete(final String partyIdNo) {
		final List<TProducerInfo> tProducerInfoResult = new ArrayList<>();
		final TProducerInfo tProducerInfo = new TProducerInfo();
		tProducerInfo.setPartyIdNo(Long.valueOf("4948"));
		tProducerInfo.setPrdcrConIdNo(Long.valueOf("36196"));
		tProducerInfo.setPrdcrIdNo(Long.valueOf("4263"));
		tProducerInfoResult.add(tProducerInfo);
		return tProducerInfoResult;
	}

	@Override
	public Long selectFirmInfo(final String agencyCode, final String agencyDetachedCode) {
		final Long retselectFirmInfo = Long.valueOf("143");
		return retselectFirmInfo;
	}

	@Override
	public int insertProducerAgreement(final Long partyIdNo, final CreateProducerAgreement.ProducerAgreement producerAgreement, final String user) {
		return 1;
	}

	@Override
	public int updateProducerAgreement(final Long partyIdNo, final UpdateProducerAgreement.ProducerAgreement producerAgreement, final String user) {
		return 1;

	}

	@Override
	public int deleteProducerAgreement(final ProducerAgreement producerAgreement, final String user) {
		return 1;

	}

	@Override
	public ProducerAgreementResult selectProducerAgreementAfterCreate(final String user, final String producerConIdNo) {

		final ProducerAgreementResult result = new ProducerAgreementResult();
		result.setAgentTypKey("MANAGING-DIRECTOR");
		result.setAgoffstdt(Timestamp.valueOf("2018-06-13 04:00:00.00"));
		result.setCcstdt(Timestamp.valueOf("2018-06-13 04:00:00.00"));
		// result.setCcstopdt(Timestamp.valueOf("1999-04-01T05:00:00.000Z"));
		result.setConCd("HV");
		result.setPrdcrConIdNo(Long.valueOf("188245"));
		result.setPartyIdNo(Long.valueOf("4948"));
		result.setPrdcrIdNo(Long.valueOf("4263"));
		result.setPyrlNo(Long.valueOf("159887"));
		result.setConTypCdNo(Long.valueOf("31"));
		result.setCreatByNm("user1");
		result.setPrimConInd(Long.valueOf("0"));
		result.setLastUpdByNm("user1");
		// result.setCreatDtm(Timestamp.valueOf("2011-09-27T01:13:38.000Z"));
		// result.setLastUpdDtm(Timestamp.valueOf("2018-06-25T12:33:37.990Z"));
		result.setOrgAgencyCd(Long.valueOf("143"));
		result.setOrgDtchCd(Long.valueOf("0"));
		result.setOrgNm("PORTLAND");
		// result.setOrgPartyIdNo(orgPartyIdNo);
		return result;
	}

	@Override
	public List<ProducerAgreementResult> selectProducerAgreementRead(final String partyIdNo, final String producerConIdNo) {
		final List<ProducerAgreementResult> producerAgreementResults = new ArrayList<>();
		final ProducerAgreementResult producerAgreementResult = new ProducerAgreementResult();
		producerAgreementResult.setAgentTypKey("MANAGING-DIRECTOR");
		producerAgreementResult.setAgoffstdt(Timestamp.valueOf("1998-04-01T05:00:00.000Z"));
		producerAgreementResult.setCcstdt(Timestamp.valueOf("1999-04-01T05:00:00.000Z"));
		producerAgreementResult.setCcstopdt(Timestamp.valueOf("1999-04-01T05:00:00.000Z"));
		producerAgreementResult.setConCd("HV");
		producerAgreementResult.setConTypCdNo(Long.valueOf("31"));
		producerAgreementResult.setCreatByNm("JHFFD04_05");
		producerAgreementResult.setLastUpdByNm("user1");
		producerAgreementResult.setCreatDtm(Timestamp.valueOf("2011-09-27T01:13:38.000Z"));
		producerAgreementResult.setLastUpdDtm(Timestamp.valueOf("2018-06-25T12:33:37.990Z"));
		producerAgreementResult.setOrgAgencyCd(Long.valueOf("143"));
		producerAgreementResult.setOrgDtchCd(Long.valueOf("0"));
		producerAgreementResult.setOrgNm("PORTLAND");
		producerAgreementResults.add(producerAgreementResult);
		// result.setOrgPartyIdNo(orgPartyIdNo);
		return producerAgreementResults;
	}

	@Override
	public List<ProducerAgreementResult> selectProducerAgreementAfterUpdateDelete(final String producerConIdNo) {
		final List<ProducerAgreementResult> producerAgreementResults = new ArrayList<>();
		final ProducerAgreementResult producerAgreementResult = new ProducerAgreementResult();
		producerAgreementResult.setAgentTypKey("MANAGING-DIRECTOR");
		producerAgreementResult.setAgoffstdt(Timestamp.valueOf("1998-04-01T05:00:00.000Z"));
		producerAgreementResult.setCcstdt(Timestamp.valueOf("1999-04-01T05:00:00.000Z"));
		producerAgreementResult.setCcstopdt(Timestamp.valueOf("1999-04-01T05:00:00.000Z"));
		producerAgreementResult.setConCd("HV");
		producerAgreementResult.setConTypCdNo(Long.valueOf("31"));
		producerAgreementResult.setCreatByNm("JHFFD04_05");
		producerAgreementResult.setLastUpdByNm("user1");
		producerAgreementResult.setCreatDtm(Timestamp.valueOf("2011-09-27T01:13:38.000Z"));
		producerAgreementResult.setLastUpdDtm(Timestamp.valueOf("2018-06-25T12:33:37.990Z"));
		producerAgreementResult.setOrgAgencyCd(Long.valueOf("143"));
		producerAgreementResult.setOrgDtchCd(Long.valueOf("0"));
		producerAgreementResult.setOrgNm("PORTLAND");
		producerAgreementResults.add(producerAgreementResult);
		// result.setOrgPartyIdNo(orgPartyIdNo);
		return producerAgreementResults;
	}

}
