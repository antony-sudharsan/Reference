/**
 *
 */
package com.jh.signator.maintain.producer.agreement.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.jh.signator.maintain.producer.agreement.dao.MaintainProducerAgreementDao;
import com.jh.signator.maintain.producer.agreement.exception.InvalidInputException;
import com.jh.signator.maintain.producer.agreement.exception.RecordNotFoundException;
import com.jh.signator.maintain.producer.agreement.model.data.ContractTypeInfo;
import com.jh.signator.maintain.producer.agreement.model.data.ProducerAgreementResult;
import com.jh.signator.maintain.producer.agreement.model.data.TProducerInfo;
import com.jh.signator.maintain.producer.agreement.utils.LoggerUtils;
import com.jh.signator.maintain.producer.agreement.utils.MaintainProducerAgreementUtils;
import com.manulife.esb.xsd.common.jh.header.JHHeader;
import com.manulife.esb.xsd.common.jh.header.MessageSource;
import com.manulife.esb.xsd.distribution.jhfn.maintainproduceragreement.CreateProducerAgreement;
import com.manulife.esb.xsd.distribution.jhfn.maintainproduceragreement.CreateProducerAgreementReply;
import com.manulife.esb.xsd.distribution.jhfn.maintainproduceragreement.CreateProducerAgreementRequest;
import com.manulife.esb.xsd.distribution.jhfn.maintainproduceragreement.DeleteProducerAgreement;
import com.manulife.esb.xsd.distribution.jhfn.maintainproduceragreement.DeleteProducerAgreementReply;
import com.manulife.esb.xsd.distribution.jhfn.maintainproduceragreement.DeleteProducerAgreementRequest;
import com.manulife.esb.xsd.distribution.jhfn.maintainproduceragreement.PRODUCER;
import com.manulife.esb.xsd.distribution.jhfn.maintainproduceragreement.PRODUCERAGREEMENT;
import com.manulife.esb.xsd.distribution.jhfn.maintainproduceragreement.ReadProducerAgreement;
import com.manulife.esb.xsd.distribution.jhfn.maintainproduceragreement.ReadProducerAgreementReply;
import com.manulife.esb.xsd.distribution.jhfn.maintainproduceragreement.ReadProducerAgreementRequest;
import com.manulife.esb.xsd.distribution.jhfn.maintainproduceragreement.UpdateProducerAgreement;
import com.manulife.esb.xsd.distribution.jhfn.maintainproduceragreement.UpdateProducerAgreementReply;
import com.manulife.esb.xsd.distribution.jhfn.maintainproduceragreement.UpdateProducerAgreementRequest;

/**
 * Test class for MaintainProducerAgreementService.
 *
 */
public class MaintainProducerAgreementServiceTest {

	private static final String USER = "TEST";
	private static final Long MATCH_PARTY_ID_NO = new Long(4948);
	private static final Long MATCH_PRDCR_ID_NO = new Long(1000);
	private static final Long MATCH_PRDCR_CON_ID_NO = new Long(2000);
	private static final String MATCH_CONTRACT_CODE = "HV";
	private static final Long MATCH_CONTRACT_TYPE_CODE_NO = new Long(63);
	private static final String MATCH_AGENT_TYPE_KEY = "BROKERAGE-SUPERVISORS";
	private static final Long MATCH_AGENCY_CODE = new Long(143);
	private static final Long MATCH_AGENCY_DETACHED_CODE = new Long(0);
	private static final Long MATCH_ORG_PARTY_ID_NO = new Long(143);
	private static final Long MATCH_PAYROLL = new Long(159887);

	@Mock
	MaintainProducerAgreementDao maintainProducerAgreementDao;

	@Mock
	private LoggerUtils loggerUtils;

	@InjectMocks
	private MaintainProducerAgreementService maintainProducerAgreementService;

	@Rule
	public final ExpectedException exception = ExpectedException.none();

	@Before
	public void setup() throws Exception {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void givenValidRequestToCreateThenExpectedDaoMethodsInvoked() {

		when(maintainProducerAgreementDao.selectContractTypeInfo()).thenReturn(createTestContractTypeInfoList());
		when(maintainProducerAgreementDao.selectProducerInfoCreate(MATCH_PARTY_ID_NO.toString()))
				.thenReturn(createTestProducerInfoForCreate());
		when(maintainProducerAgreementDao.selectFirmInfo(MATCH_AGENCY_CODE.toString(),
				MATCH_AGENCY_DETACHED_CODE.toString())).thenReturn(MATCH_ORG_PARTY_ID_NO);
		when(maintainProducerAgreementDao.insertProducerAgreement(any(), any(), any())).thenReturn(1);
		when(maintainProducerAgreementDao.selectProducerAgreementAfterCreate(USER, MATCH_PRDCR_ID_NO.toString()))
				.thenReturn(createProducerAgreementResult(false));

		final CreateProducerAgreementReply reply = maintainProducerAgreementService.create(createTestJHHeader(),
				createTestCreateProducerAgreementRequest());

		Assert.assertNotNull(reply);
		verify(maintainProducerAgreementDao, times(1)).selectContractTypeInfo();
		verify(maintainProducerAgreementDao, times(1)).selectProducerInfoCreate(MATCH_PARTY_ID_NO.toString());
		verify(maintainProducerAgreementDao, times(1)).selectFirmInfo(MATCH_AGENCY_CODE.toString(),
				MATCH_AGENCY_DETACHED_CODE.toString());
		verify(maintainProducerAgreementDao, times(1)).insertProducerAgreement(any(), any(), any());
		verify(maintainProducerAgreementDao, times(1)).selectProducerAgreementAfterCreate(USER,
				MATCH_PRDCR_ID_NO.toString());
		verifyNoMoreInteractions(maintainProducerAgreementDao);
	}

	@Test
	public void givenValidRequestToCreateThenExpectedReplyReturned() {

		when(maintainProducerAgreementDao.selectContractTypeInfo()).thenReturn(createTestContractTypeInfoList());
		when(maintainProducerAgreementDao.selectProducerInfoCreate(MATCH_PARTY_ID_NO.toString()))
				.thenReturn(createTestProducerInfoForCreate());
		when(maintainProducerAgreementDao.selectFirmInfo(MATCH_AGENCY_CODE.toString(),
				MATCH_AGENCY_DETACHED_CODE.toString())).thenReturn(MATCH_ORG_PARTY_ID_NO);
		when(maintainProducerAgreementDao.insertProducerAgreement(any(), any(), any())).thenReturn(1);
		when(maintainProducerAgreementDao.selectProducerAgreementAfterCreate(USER, MATCH_PRDCR_ID_NO.toString()))
				.thenReturn(createProducerAgreementResult(false));

		final CreateProducerAgreementReply reply = maintainProducerAgreementService.create(createTestJHHeader(),
				createTestCreateProducerAgreementRequest());

		assertThat(reply).isEqualToComparingFieldByFieldRecursively(createExpectedCreateProducerAgreementReply());

	}

	@Test
	public void givenNoProducerInfoRowsThenCreateThrowsRecordNotFoundException() {

		when(maintainProducerAgreementDao.selectContractTypeInfo()).thenReturn(createTestContractTypeInfoList());
		when(maintainProducerAgreementDao.selectProducerInfoCreate(MATCH_PARTY_ID_NO.toString()))
				.thenReturn(new ArrayList<TProducerInfo>());
		exception.expect(RecordNotFoundException.class);
		maintainProducerAgreementService.create(createTestJHHeader(), createTestCreateProducerAgreementRequest());

		verify(maintainProducerAgreementDao, times(0)).insertProducerAgreement(any(), any(), any());
	}

	@Test
	public void givenInvalidContractCodeThenCreateThrowsInvalidInputException() {

		when(maintainProducerAgreementDao.selectContractTypeInfo()).thenReturn(createTestContractTypeInfoList());
		when(maintainProducerAgreementDao.selectProducerInfoCreate(MATCH_PARTY_ID_NO.toString()))
				.thenReturn(createTestProducerInfoForCreate());

		final CreateProducerAgreementRequest request = createTestCreateProducerAgreementRequest();
		request.getCreateProducerAgreement().getProducerAgreement().get(0).setProducerAgreementCode("ZZ");

		exception.expect(InvalidInputException.class);
		maintainProducerAgreementService.create(createTestJHHeader(), request);

		verify(maintainProducerAgreementDao, times(0)).insertProducerAgreement(any(), any(), any());
	}

	@Test
	public void givenNoUserThenCreateThrowsInvalidInputException() {

		final JHHeader header = createTestJHHeader();
		header.getMessageSource().setUserID(null);

		exception.expect(InvalidInputException.class);
		maintainProducerAgreementService.create(header, createTestCreateProducerAgreementRequest());

		verify(maintainProducerAgreementDao, times(0)).insertProducerAgreement(any(), any(), any());
	}

	@Test
	public void givenInvalidFirmInfoThenCreateThrowsInvalidInputException() {
		when(maintainProducerAgreementDao.selectContractTypeInfo()).thenReturn(createTestContractTypeInfoList());
		when(maintainProducerAgreementDao.selectProducerInfoCreate(MATCH_PARTY_ID_NO.toString()))
				.thenReturn(createTestProducerInfoForCreate());
		when(maintainProducerAgreementDao.selectFirmInfo(MATCH_AGENCY_CODE.toString(),
				MATCH_AGENCY_DETACHED_CODE.toString())).thenReturn(null);
		exception.expect(InvalidInputException.class);
		maintainProducerAgreementService.create(createTestJHHeader(), createTestCreateProducerAgreementRequest());

		verify(maintainProducerAgreementDao, times(0)).insertProducerAgreement(any(), any(), any());
	}

	@Test
	public void givenSelectAfterInsertReturnsNoRowThenCreateThrowsRecordNotFoundException() {

		when(maintainProducerAgreementDao.selectContractTypeInfo()).thenReturn(createTestContractTypeInfoList());
		when(maintainProducerAgreementDao.selectProducerInfoCreate(MATCH_PARTY_ID_NO.toString()))
				.thenReturn(createTestProducerInfoForCreate());
		when(maintainProducerAgreementDao.selectFirmInfo(MATCH_AGENCY_CODE.toString(),
				MATCH_AGENCY_DETACHED_CODE.toString())).thenReturn(MATCH_ORG_PARTY_ID_NO);
		when(maintainProducerAgreementDao.insertProducerAgreement(any(), any(), any())).thenReturn(1);
		when(maintainProducerAgreementDao.selectProducerAgreementAfterCreate(USER, MATCH_PRDCR_ID_NO.toString()))
				.thenReturn(null);

		exception.expect(RecordNotFoundException.class);
		maintainProducerAgreementService.create(createTestJHHeader(), createTestCreateProducerAgreementRequest());

		verify(maintainProducerAgreementDao, times(0)).insertProducerAgreement(any(), any(), any());
	}

	@Test
	public void givenValidRequestToUpdateThenExpectedDaoMethodsInvoked() {
		when(maintainProducerAgreementDao.selectContractTypeInfo()).thenReturn(createTestContractTypeInfoList());
		when(maintainProducerAgreementDao.selectProducerInfoUpdate(MATCH_PARTY_ID_NO.toString()))
				.thenReturn(createTestProducerInfoForUpdate());
		when(maintainProducerAgreementDao.selectFirmInfo(MATCH_AGENCY_CODE.toString(),
				MATCH_AGENCY_DETACHED_CODE.toString())).thenReturn(MATCH_ORG_PARTY_ID_NO);
		when(maintainProducerAgreementDao.updateProducerAgreement(any(), any(), any())).thenReturn(1);
		when(maintainProducerAgreementDao.selectProducerAgreementAfterUpdateDelete(MATCH_PRDCR_CON_ID_NO.toString()))
				.thenReturn(createProducerAgreementResults(false));

		final UpdateProducerAgreementReply reply = maintainProducerAgreementService.update(createTestJHHeader(),
				createTestUpdateProducerAgreementRequest());

		Assert.assertNotNull(reply);
		verify(maintainProducerAgreementDao, times(1)).selectContractTypeInfo();
		verify(maintainProducerAgreementDao, times(1)).selectProducerInfoUpdate(MATCH_PARTY_ID_NO.toString());
		verify(maintainProducerAgreementDao, times(1)).selectFirmInfo(MATCH_AGENCY_CODE.toString(),
				MATCH_AGENCY_DETACHED_CODE.toString());
		verify(maintainProducerAgreementDao, times(1)).updateProducerAgreement(any(), any(), any());
		verify(maintainProducerAgreementDao, times(1))
				.selectProducerAgreementAfterUpdateDelete(MATCH_PRDCR_CON_ID_NO.toString());
		verifyNoMoreInteractions(maintainProducerAgreementDao);
	}

	@Test
	public void givenValidRequestToUpdateThenExpectedReplyReturned() {
		when(maintainProducerAgreementDao.selectContractTypeInfo()).thenReturn(createTestContractTypeInfoList());
		when(maintainProducerAgreementDao.selectProducerInfoUpdate(MATCH_PARTY_ID_NO.toString()))
				.thenReturn(createTestProducerInfoForUpdate());
		when(maintainProducerAgreementDao.selectFirmInfo(MATCH_AGENCY_CODE.toString(),
				MATCH_AGENCY_DETACHED_CODE.toString())).thenReturn(MATCH_ORG_PARTY_ID_NO);
		when(maintainProducerAgreementDao.updateProducerAgreement(any(), any(), any())).thenReturn(1);
		when(maintainProducerAgreementDao.selectProducerAgreementAfterUpdateDelete(MATCH_PRDCR_CON_ID_NO.toString()))
				.thenReturn(createProducerAgreementResults(false));

		final UpdateProducerAgreementReply reply = maintainProducerAgreementService.update(createTestJHHeader(),
				createTestUpdateProducerAgreementRequest());

		assertThat(reply).isEqualToComparingFieldByFieldRecursively(createExpectedUpdateProducerAgreementReply());
	}

	@Test
	public void givenNoProducerInfoRowsThenUpdateThrowsRecordNotFoundException() {

		when(maintainProducerAgreementDao.selectContractTypeInfo()).thenReturn(createTestContractTypeInfoList());
		when(maintainProducerAgreementDao.selectProducerInfoUpdate(MATCH_PARTY_ID_NO.toString()))
				.thenReturn(new ArrayList<TProducerInfo>());
		exception.expect(RecordNotFoundException.class);
		maintainProducerAgreementService.update(createTestJHHeader(), createTestUpdateProducerAgreementRequest());

		verify(maintainProducerAgreementDao, times(0)).updateProducerAgreement(any(), any(), any());
	}

	@Test
	public void givenInvalidAgreementTypeThenUpdateThrowsInvalidInputException() {

		when(maintainProducerAgreementDao.selectContractTypeInfo()).thenReturn(createTestContractTypeInfoList());
		when(maintainProducerAgreementDao.selectProducerInfoUpdate(MATCH_PARTY_ID_NO.toString()))
				.thenReturn(createTestProducerInfoForUpdate());

		final UpdateProducerAgreementRequest request = createTestUpdateProducerAgreementRequest();
		request.getUpdateProducerAgreement().getProducerAgreement().get(0).setProducerAgreementType("ZZ");
		;

		exception.expect(InvalidInputException.class);
		maintainProducerAgreementService.update(createTestJHHeader(), request);

		verify(maintainProducerAgreementDao, times(0)).updateProducerAgreement(any(), any(), any());
	}

	@Test
	public void givenNoUserThenUpdateThrowsInvalidInputException() {

		final JHHeader header = createTestJHHeader();
		header.getMessageSource().setUserID(null);

		exception.expect(InvalidInputException.class);
		maintainProducerAgreementService.update(header, createTestUpdateProducerAgreementRequest());

		verify(maintainProducerAgreementDao, times(0)).updateProducerAgreement(any(), any(), any());
	}

	@Test
	public void givenInvalidFirmInfoThenUpdateThrowsInvalidInputException() {
		when(maintainProducerAgreementDao.selectContractTypeInfo()).thenReturn(createTestContractTypeInfoList());
		when(maintainProducerAgreementDao.selectProducerInfoUpdate(MATCH_PARTY_ID_NO.toString()))
				.thenReturn(createTestProducerInfoForUpdate());
		when(maintainProducerAgreementDao.selectFirmInfo(MATCH_AGENCY_CODE.toString(),
				MATCH_AGENCY_DETACHED_CODE.toString())).thenReturn(null);
		exception.expect(InvalidInputException.class);
		maintainProducerAgreementService.update(createTestJHHeader(), createTestUpdateProducerAgreementRequest());

		verify(maintainProducerAgreementDao, times(0)).updateProducerAgreement(any(), any(), any());
	}

	@Test
	public void givenSelectAfterUpdateReturnsNoRowThenUpdateThrowsRecordNotFoundException() {

		when(maintainProducerAgreementDao.selectContractTypeInfo()).thenReturn(createTestContractTypeInfoList());
		when(maintainProducerAgreementDao.selectProducerInfoUpdate(MATCH_PARTY_ID_NO.toString()))
				.thenReturn(createTestProducerInfoForUpdate());
		when(maintainProducerAgreementDao.selectFirmInfo(MATCH_AGENCY_CODE.toString(),
				MATCH_AGENCY_DETACHED_CODE.toString())).thenReturn(MATCH_ORG_PARTY_ID_NO);
		when(maintainProducerAgreementDao.updateProducerAgreement(any(), any(), any())).thenReturn(1);
		when(maintainProducerAgreementDao.selectProducerAgreementAfterUpdateDelete(MATCH_PRDCR_CON_ID_NO.toString()))
				.thenReturn(new ArrayList<ProducerAgreementResult>());

		exception.expect(RecordNotFoundException.class);
		maintainProducerAgreementService.update(createTestJHHeader(), createTestUpdateProducerAgreementRequest());

		verify(maintainProducerAgreementDao, times(0)).updateProducerAgreement(any(), any(), any());
		;
	}

	@Test
	public void givenValidRequestToDeleteThenExpectedDaoMethodsInvoked() {
		when(maintainProducerAgreementDao.selectProducerInfoUpdate(MATCH_PARTY_ID_NO.toString()))
				.thenReturn(createTestProducerInfoForUpdate());
		when(maintainProducerAgreementDao.deleteProducerAgreement(any(), any())).thenReturn(1);
		when(maintainProducerAgreementDao.selectProducerAgreementAfterUpdateDelete(MATCH_PRDCR_CON_ID_NO.toString()))
				.thenReturn(createProducerAgreementResults(true));

		final DeleteProducerAgreementReply reply = maintainProducerAgreementService.delete(createTestJHHeader(),
				createTestDeleteProducerAgreementRequest());

		Assert.assertNotNull(reply);

		verify(maintainProducerAgreementDao, times(1)).selectProducerInfoUpdate(MATCH_PARTY_ID_NO.toString());
		verify(maintainProducerAgreementDao, times(1)).deleteProducerAgreement(any(), any());
		verify(maintainProducerAgreementDao, times(1))
				.selectProducerAgreementAfterUpdateDelete(MATCH_PRDCR_CON_ID_NO.toString());
		verifyNoMoreInteractions(maintainProducerAgreementDao);
	}

	@Test
	public void givenValidRequestToDeleteThenExpectedReplyReturned() {
		when(maintainProducerAgreementDao.selectProducerInfoUpdate(MATCH_PARTY_ID_NO.toString()))
				.thenReturn(createTestProducerInfoForUpdate());
		when(maintainProducerAgreementDao.deleteProducerAgreement(any(), any())).thenReturn(1);
		when(maintainProducerAgreementDao.selectProducerAgreementAfterUpdateDelete(MATCH_PRDCR_CON_ID_NO.toString()))
				.thenReturn(createProducerAgreementResults(true));

		final DeleteProducerAgreementReply reply = maintainProducerAgreementService.delete(createTestJHHeader(),
				createTestDeleteProducerAgreementRequest());

		Assert.assertNotNull(reply);

		assertThat(reply).isEqualToComparingFieldByFieldRecursively(createExpectedDeleteProducerAgreementReply());
	}

	@Test
	public void givenNoProducerInfoRowsThenDeleteThrowsRecordNotFoundException() {

		when(maintainProducerAgreementDao.selectContractTypeInfo()).thenReturn(createTestContractTypeInfoList());
		when(maintainProducerAgreementDao.selectProducerInfoUpdate(MATCH_PARTY_ID_NO.toString()))
				.thenReturn(new ArrayList<TProducerInfo>());
		exception.expect(RecordNotFoundException.class);
		maintainProducerAgreementService.delete(createTestJHHeader(), createTestDeleteProducerAgreementRequest());

		verify(maintainProducerAgreementDao, times(0)).deleteProducerAgreement(any(), any());
	}

	@Test
	public void givenPrdrcConIdThenDeleteThrowsInvalidInputException() {

		when(maintainProducerAgreementDao.selectContractTypeInfo()).thenReturn(createTestContractTypeInfoList());
		when(maintainProducerAgreementDao.selectProducerInfoUpdate(MATCH_PARTY_ID_NO.toString()))
				.thenReturn(createTestProducerInfoForUpdate());

		final DeleteProducerAgreementRequest request = createTestDeleteProducerAgreementRequest();
		request.getDeleteProducerAgreement().getProducerAgreement().get(0).setProducerAgreementID("Invalid");
		;

		exception.expect(InvalidInputException.class);
		maintainProducerAgreementService.delete(createTestJHHeader(), request);

		verify(maintainProducerAgreementDao, times(0)).deleteProducerAgreement(any(), any());
	}

	@Test
	public void givenNoUserThenDeleteThrowsInvalidInputException() {

		final JHHeader header = createTestJHHeader();
		header.getMessageSource().setUserID(null);

		exception.expect(InvalidInputException.class);
		maintainProducerAgreementService.delete(header, createTestDeleteProducerAgreementRequest());

		verify(maintainProducerAgreementDao, times(0)).deleteProducerAgreement(any(), any());
	}

	@Test
	public void givenSelectAfterDeleteReturnsNoRowThenDeleteThrowsRecordNotFoundException() {

		when(maintainProducerAgreementDao.selectContractTypeInfo()).thenReturn(createTestContractTypeInfoList());
		when(maintainProducerAgreementDao.selectProducerInfoUpdate(MATCH_PARTY_ID_NO.toString()))
				.thenReturn(createTestProducerInfoForUpdate());
		when(maintainProducerAgreementDao.selectFirmInfo(MATCH_AGENCY_CODE.toString(),
				MATCH_AGENCY_DETACHED_CODE.toString())).thenReturn(MATCH_ORG_PARTY_ID_NO);
		when(maintainProducerAgreementDao.deleteProducerAgreement(any(), any())).thenReturn(1);
		when(maintainProducerAgreementDao.selectProducerAgreementAfterUpdateDelete(MATCH_PRDCR_CON_ID_NO.toString()))
				.thenReturn(new ArrayList<ProducerAgreementResult>());

		exception.expect(RecordNotFoundException.class);
		maintainProducerAgreementService.delete(createTestJHHeader(), createTestDeleteProducerAgreementRequest());

		verify(maintainProducerAgreementDao, times(0)).deleteProducerAgreement(any(), any());
		;
	}

	@Test
	public void givenValidRequestToReadThenExpectedDaoMethodsInvoked() {

		when(maintainProducerAgreementDao.selectProducerAgreementRead(MATCH_PARTY_ID_NO.toString(),
				MATCH_PRDCR_CON_ID_NO.toString())).thenReturn(createProducerAgreementResults(true));

		final ReadProducerAgreementReply reply = maintainProducerAgreementService.read(createTestJHHeader(),
				createTestReadProducerAgreementRequest());

		Assert.assertNotNull(reply);

		verify(maintainProducerAgreementDao, times(1)).selectProducerAgreementRead(MATCH_PARTY_ID_NO.toString(),
				MATCH_PRDCR_CON_ID_NO.toString());
		verifyNoMoreInteractions(maintainProducerAgreementDao);
	}

	@Test
	public void givenNoRecordForProducerAgreementIDThenReadThrowsRecordNotFoundException() {

		when(maintainProducerAgreementDao.selectProducerAgreementRead(MATCH_PARTY_ID_NO.toString(),
				MATCH_PRDCR_CON_ID_NO.toString())).thenReturn(new ArrayList<ProducerAgreementResult>());

		exception.expect(RecordNotFoundException.class);
		maintainProducerAgreementService.read(createTestJHHeader(), createTestReadProducerAgreementRequest());

	}

	@Test
	public void givenValidRequestToReadThenExpectedReplyReturned() {

		when(maintainProducerAgreementDao.selectProducerAgreementRead(MATCH_PARTY_ID_NO.toString(),
				MATCH_PRDCR_CON_ID_NO.toString())).thenReturn(createProducerAgreementResults(true));

		final ReadProducerAgreementReply reply = maintainProducerAgreementService.read(createTestJHHeader(),
				createTestReadProducerAgreementRequest());

		assertThat(reply).isEqualToComparingFieldByFieldRecursively(createExpectedReadProducerAgreementReply());
	}

	private JHHeader createTestJHHeader() {
		final JHHeader header = new JHHeader();
		final MessageSource messageSource = new MessageSource();
		messageSource.setUserID(USER);
		header.setMessageSource(messageSource);

		return header;
	}

	private CreateProducerAgreementRequest createTestCreateProducerAgreementRequest() {
		final CreateProducerAgreementRequest request = new CreateProducerAgreementRequest();
		final CreateProducerAgreement createProducerAgreement = new CreateProducerAgreement();
		createProducerAgreement.setID(MATCH_PARTY_ID_NO.toString());
		createProducerAgreement.setIDRefType(MaintainProducerAgreementService.VALID_IDREF_TYPE);
		request.setCreateProducerAgreement(createProducerAgreement);
		final CreateProducerAgreement.ProducerAgreement producerAgreement = new CreateProducerAgreement.ProducerAgreement();
		createProducerAgreement.getProducerAgreement().add(producerAgreement);
		producerAgreement.setProducerID(MATCH_PRDCR_ID_NO.toString());
		producerAgreement.setEffDate(MaintainProducerAgreementUtils
				.convertTimestampToXmlGregorianCalendar(Timestamp.valueOf("1999-04-01 00:00:00.0")));

		producerAgreement.setPayrollNo(MATCH_PAYROLL.toString());
		producerAgreement.setProducerAgreementCode(MATCH_CONTRACT_CODE);
		producerAgreement.setProducerAgreementType(MATCH_CONTRACT_TYPE_CODE_NO.toString());
		producerAgreement.setProducerAgreementPrimaryIndicator(false);

		producerAgreement.setProducerAgreementDefinition(MATCH_AGENT_TYPE_KEY);
		producerAgreement.setProducerAgreementAgentOfficialStartDate(MaintainProducerAgreementUtils
				.convertTimestampToXmlGregorianCalendar(Timestamp.valueOf("1998-04-01 00:00:00.0")));

		producerAgreement.setProducerAgreementPrimaryIndicator(true);
		producerAgreement.setEndDate(MaintainProducerAgreementUtils
				.convertTimestampToXmlGregorianCalendar(Timestamp.valueOf("2001-07-13 00:00:00.0")));
		producerAgreement.setAgencyCode(MATCH_AGENCY_CODE.toString());
		producerAgreement.setAgencyDetachedCode(MATCH_AGENCY_DETACHED_CODE.toString());

		return request;
	}

	private UpdateProducerAgreementRequest createTestUpdateProducerAgreementRequest() {
		final UpdateProducerAgreementRequest request = new UpdateProducerAgreementRequest();
		final UpdateProducerAgreement updateProducerAgreement = new UpdateProducerAgreement();
		updateProducerAgreement.setID(MATCH_PARTY_ID_NO.toString());
		updateProducerAgreement.setIDRefType(MaintainProducerAgreementService.VALID_IDREF_TYPE);
		request.setUpdateProducerAgreement(updateProducerAgreement);
		final UpdateProducerAgreement.ProducerAgreement producerAgreement = new UpdateProducerAgreement.ProducerAgreement();
		updateProducerAgreement.getProducerAgreement().add(producerAgreement);
		producerAgreement.setProducerAgreementID(MATCH_PRDCR_CON_ID_NO.toString());
		producerAgreement.setProducerID(MATCH_PRDCR_ID_NO.toString());
		producerAgreement.setEffDate(MaintainProducerAgreementUtils
				.convertTimestampToXmlGregorianCalendar(Timestamp.valueOf("1999-04-01 00:00:00.0")));

		producerAgreement.setPayrollNo(MATCH_PAYROLL.toString());
		producerAgreement.setProducerAgreementCode(MATCH_CONTRACT_CODE);
		producerAgreement.setProducerAgreementType(MATCH_CONTRACT_TYPE_CODE_NO.toString());
		producerAgreement.setProducerAgreementPrimaryIndicator(false);

		producerAgreement.setProducerAgreementDefinition(MATCH_AGENT_TYPE_KEY);
		producerAgreement.setProducerAgreementAgentOfficialStartDate(MaintainProducerAgreementUtils
				.convertTimestampToXmlGregorianCalendar(Timestamp.valueOf("1998-04-01 00:00:00.0")));

		producerAgreement.setProducerAgreementPrimaryIndicator(true);
		producerAgreement.setEndDate(MaintainProducerAgreementUtils
				.convertTimestampToXmlGregorianCalendar(Timestamp.valueOf("2001-07-13 00:00:00.0")));
		producerAgreement.setAgencyCode(MATCH_AGENCY_CODE.toString());
		producerAgreement.setAgencyDetachedCode(MATCH_AGENCY_DETACHED_CODE.toString());

		return request;
	}

	private DeleteProducerAgreementRequest createTestDeleteProducerAgreementRequest() {
		final DeleteProducerAgreementRequest request = new DeleteProducerAgreementRequest();
		final DeleteProducerAgreement deleteProducerAgreement = new DeleteProducerAgreement();
		deleteProducerAgreement.setID(MATCH_PARTY_ID_NO.toString());
		deleteProducerAgreement.setIDRefType(MaintainProducerAgreementService.VALID_IDREF_TYPE);
		request.setDeleteProducerAgreement(deleteProducerAgreement);
		final DeleteProducerAgreement.ProducerAgreement producerAgreement = new DeleteProducerAgreement.ProducerAgreement();
		deleteProducerAgreement.getProducerAgreement().add(producerAgreement);
		producerAgreement.setProducerAgreementID(MATCH_PRDCR_CON_ID_NO.toString());
		producerAgreement.setEndDate(MaintainProducerAgreementUtils
				.convertTimestampToXmlGregorianCalendar(Timestamp.valueOf("2001-07-13 00:00:00.0")));

		return request;
	}

	private ReadProducerAgreementRequest createTestReadProducerAgreementRequest() {
		final ReadProducerAgreementRequest request = new ReadProducerAgreementRequest();
		final ReadProducerAgreement readProducerAgreement = new ReadProducerAgreement();
		readProducerAgreement.setID(MATCH_PARTY_ID_NO.toString());
		readProducerAgreement.setIDRefType(MaintainProducerAgreementService.VALID_IDREF_TYPE);
		request.setReadProducerAgreement(readProducerAgreement);
		final ReadProducerAgreement.ProducerAgreement producerAgreement = new ReadProducerAgreement.ProducerAgreement();
		readProducerAgreement.getProducerAgreement().add(producerAgreement);
		producerAgreement.setProducerAgreementID(MATCH_PRDCR_CON_ID_NO.toString());

		return request;
	}

	private List<ContractTypeInfo> createTestContractTypeInfoList() {
		final List<ContractTypeInfo> contractTypes = new ArrayList<>();

		ContractTypeInfo contractType = new ContractTypeInfo();
		contractType.setContractCode("RE");
		contractType.setContractTypeCodeNo(new Long(38));
		contractType.setAgentTypeKey("BROKER");
		contractTypes.add(contractType);
		contractType = new ContractTypeInfo();
		contractType.setContractCode(MATCH_CONTRACT_CODE);
		contractType.setContractTypeCodeNo(MATCH_CONTRACT_TYPE_CODE_NO);
		contractType.setAgentTypeKey(MATCH_AGENT_TYPE_KEY);
		contractTypes.add(contractType);
		contractType = new ContractTypeInfo();
		contractType.setContractCode("HF");
		contractType.setContractTypeCodeNo(new Long(21));
		contractType.setAgentTypeKey("FINANCED");
		contractTypes.add(contractType);

		return contractTypes;
	}

	private List<TProducerInfo> createTestProducerInfoForCreate() {
		final List<TProducerInfo> producers = new ArrayList<>();
		TProducerInfo producer = new TProducerInfo();
		producer.setPartyIdNo(new Long(123));
		producer.setPrdcrIdNo(new Long(999));
		producers.add(producer);
		producer = new TProducerInfo();
		producer.setPartyIdNo(MATCH_PARTY_ID_NO);
		producer.setPrdcrIdNo(MATCH_PRDCR_ID_NO);
		producers.add(producer);
		producer = new TProducerInfo();
		producer.setPartyIdNo(new Long(111));
		producer.setPrdcrIdNo(new Long(888));
		producers.add(producer);
		return producers;
	}

	private List<TProducerInfo> createTestProducerInfoForUpdate() {
		final List<TProducerInfo> producers = new ArrayList<>();
		TProducerInfo producer = new TProducerInfo();
		producer.setPartyIdNo(new Long(123));
		producer.setPrdcrIdNo(new Long(999));
		producers.add(producer);
		producer = new TProducerInfo();
		producer.setPartyIdNo(MATCH_PARTY_ID_NO);
		producer.setPrdcrIdNo(MATCH_PRDCR_ID_NO);
		producer.setPrdcrConIdNo(MATCH_PRDCR_CON_ID_NO);
		producers.add(producer);
		producer = new TProducerInfo();
		producer.setPartyIdNo(new Long(111));
		producer.setPrdcrIdNo(new Long(888));
		producers.add(producer);
		return producers;
	}

	private List<ProducerAgreementResult> createProducerAgreementResults(final boolean includeEndDate) {
		final List<ProducerAgreementResult> results = new ArrayList<>();
		results.add(createProducerAgreementResult(includeEndDate));

		return results;
	}

	private ProducerAgreementResult createProducerAgreementResult(final boolean includeEndDate) {
		final ProducerAgreementResult result = new ProducerAgreementResult();

		result.setPartyIdNo(MATCH_PARTY_ID_NO);
		result.setPrdcrConIdNo(MATCH_PRDCR_CON_ID_NO);
		result.setPrdcrIdNo(MATCH_PRDCR_ID_NO);
		result.setCcstdt(Timestamp.valueOf("1999-04-01 00:00:00.0"));
		result.setPyrlNo(new Long(159887));
		result.setConCd(MATCH_CONTRACT_CODE);
		result.setConTypCdNo(MATCH_CONTRACT_TYPE_CODE_NO);
		result.setAgentTypKey(MATCH_AGENT_TYPE_KEY);
		result.setAgoffstdt(Timestamp.valueOf("1998-04-01 00:00:00.0"));
		result.setOrgPartyIdNo(MATCH_ORG_PARTY_ID_NO);
		result.setPrimConInd(new Long(0));
		result.setOrgAgencyCd(MATCH_AGENCY_CODE);
		result.setOrgDtchCd(MATCH_AGENCY_DETACHED_CODE);
		result.setOrgNm("PORTLAND                 ");
		result.setCreatDtm(Timestamp.valueOf("2018-06-25 12:33:29.597"));
		result.setCreatByNm(USER);
		result.setLastUpdDtm(Timestamp.valueOf("2018-06-25 14:34:53.647"));
		result.setLastUpdByNm(USER);
		if (includeEndDate) {
			result.setCcstopdt(Timestamp.valueOf("2001-07-13 00:00:00.0"));

		}
		return result;
	}

	private CreateProducerAgreementReply createExpectedCreateProducerAgreementReply() {
		final CreateProducerAgreementReply reply = new CreateProducerAgreementReply();
		final PRODUCER producer = new PRODUCER();
		producer.setID(MATCH_PARTY_ID_NO.toString());
		producer.setIDRefType(MaintainProducerAgreementService.VALID_IDREF_TYPE);
		reply.setProducer(producer);

		final PRODUCERAGREEMENT producerAgreement = new PRODUCERAGREEMENT();
		producer.getProducerAgreement().add(producerAgreement);

		producerAgreement.setProducerID(MATCH_PRDCR_ID_NO.toString());
		producerAgreement.setEffDate(MaintainProducerAgreementUtils
				.convertTimestampToXmlGregorianCalendar(Timestamp.valueOf("1999-04-01 00:00:00.0")));

		producerAgreement.setPayrollNo(MATCH_PAYROLL.toString());

		producerAgreement.setProducerAgreementCode(MATCH_CONTRACT_CODE);
		producerAgreement.setProducerAgreementType(MATCH_CONTRACT_TYPE_CODE_NO.toString());
		producerAgreement.setProducerAgreementID(MATCH_PRDCR_CON_ID_NO.toString());
		producerAgreement.setProducerAgreementPrimaryIndicator(false);

		producerAgreement.setProducerAgreementDefinition(MATCH_AGENT_TYPE_KEY);
		producerAgreement.setProducerAgreementAgentOfficialStartDate(MaintainProducerAgreementUtils
				.convertTimestampToXmlGregorianCalendar(Timestamp.valueOf("1998-04-01 00:00:00.0")));

		producerAgreement.setCreatedDate(MaintainProducerAgreementUtils
				.convertTimestampToXmlGregorianCalendar(Timestamp.valueOf("2018-06-25 12:33:29.597")));
		producerAgreement.setCreatedByNm(USER);
		producerAgreement.setUpdatedByNm(USER);
		producerAgreement.setUpdatedDate(MaintainProducerAgreementUtils
				.convertTimestampToXmlGregorianCalendar(Timestamp.valueOf("2018-06-25 14:34:53.647")));

		producerAgreement.setAgencyCode(MATCH_AGENCY_CODE.toString());
		producerAgreement.setAgencyDetachedCode(MATCH_AGENCY_DETACHED_CODE.toString());
		producerAgreement.setAgencyName("PORTLAND");

		return reply;
	}

	private UpdateProducerAgreementReply createExpectedUpdateProducerAgreementReply() {
		final UpdateProducerAgreementReply reply = new UpdateProducerAgreementReply();
		final PRODUCER producer = new PRODUCER();
		producer.setID(MATCH_PARTY_ID_NO.toString());
		producer.setIDRefType(MaintainProducerAgreementService.VALID_IDREF_TYPE);
		reply.setProducer(producer);

		final PRODUCERAGREEMENT producerAgreement = new PRODUCERAGREEMENT();
		producer.getProducerAgreement().add(producerAgreement);

		producerAgreement.setProducerID(MATCH_PRDCR_ID_NO.toString());
		producerAgreement.setProducerAgreementID(MATCH_PRDCR_CON_ID_NO.toString());
		producerAgreement.setEffDate(MaintainProducerAgreementUtils
				.convertTimestampToXmlGregorianCalendar(Timestamp.valueOf("1999-04-01 00:00:00.0")));

		producerAgreement.setPayrollNo(MATCH_PAYROLL.toString());

		producerAgreement.setProducerAgreementCode(MATCH_CONTRACT_CODE);
		producerAgreement.setProducerAgreementType(MATCH_CONTRACT_TYPE_CODE_NO.toString());
		producerAgreement.setProducerAgreementID(MATCH_PRDCR_CON_ID_NO.toString());
		producerAgreement.setProducerAgreementPrimaryIndicator(false);

		producerAgreement.setProducerAgreementDefinition(MATCH_AGENT_TYPE_KEY);
		producerAgreement.setProducerAgreementAgentOfficialStartDate(MaintainProducerAgreementUtils
				.convertTimestampToXmlGregorianCalendar(Timestamp.valueOf("1998-04-01 00:00:00.0")));

		producerAgreement.setCreatedDate(MaintainProducerAgreementUtils
				.convertTimestampToXmlGregorianCalendar(Timestamp.valueOf("2018-06-25 12:33:29.597")));
		producerAgreement.setCreatedByNm(USER);
		producerAgreement.setUpdatedByNm(USER);
		producerAgreement.setUpdatedDate(MaintainProducerAgreementUtils
				.convertTimestampToXmlGregorianCalendar(Timestamp.valueOf("2018-06-25 14:34:53.647")));

		producerAgreement.setAgencyCode(MATCH_AGENCY_CODE.toString());
		producerAgreement.setAgencyDetachedCode(MATCH_AGENCY_DETACHED_CODE.toString());
		producerAgreement.setAgencyName("PORTLAND");

		return reply;
	}

	private DeleteProducerAgreementReply createExpectedDeleteProducerAgreementReply() {
		final DeleteProducerAgreementReply reply = new DeleteProducerAgreementReply();
		final PRODUCER producer = new PRODUCER();
		producer.setID(MATCH_PARTY_ID_NO.toString());
		producer.setIDRefType(MaintainProducerAgreementService.VALID_IDREF_TYPE);
		reply.setProducer(producer);

		final PRODUCERAGREEMENT producerAgreement = new PRODUCERAGREEMENT();
		producer.getProducerAgreement().add(producerAgreement);

		producerAgreement.setProducerID(MATCH_PRDCR_ID_NO.toString());
		producerAgreement.setProducerAgreementID(MATCH_PRDCR_CON_ID_NO.toString());
		producerAgreement.setEffDate(MaintainProducerAgreementUtils
				.convertTimestampToXmlGregorianCalendar(Timestamp.valueOf("1999-04-01 00:00:00.0")));
		producerAgreement.setEndDate(MaintainProducerAgreementUtils
				.convertTimestampToXmlGregorianCalendar(Timestamp.valueOf("2001-07-13 00:00:00.0")));

		producerAgreement.setPayrollNo(MATCH_PAYROLL.toString());

		producerAgreement.setProducerAgreementCode(MATCH_CONTRACT_CODE);
		producerAgreement.setProducerAgreementType(MATCH_CONTRACT_TYPE_CODE_NO.toString());
		producerAgreement.setProducerAgreementID(MATCH_PRDCR_CON_ID_NO.toString());
		producerAgreement.setProducerAgreementPrimaryIndicator(false);

		producerAgreement.setProducerAgreementDefinition(MATCH_AGENT_TYPE_KEY);
		producerAgreement.setProducerAgreementAgentOfficialStartDate(MaintainProducerAgreementUtils
				.convertTimestampToXmlGregorianCalendar(Timestamp.valueOf("1998-04-01 00:00:00.0")));

		producerAgreement.setCreatedDate(MaintainProducerAgreementUtils
				.convertTimestampToXmlGregorianCalendar(Timestamp.valueOf("2018-06-25 12:33:29.597")));
		producerAgreement.setCreatedByNm(USER);
		producerAgreement.setUpdatedByNm(USER);
		producerAgreement.setUpdatedDate(MaintainProducerAgreementUtils
				.convertTimestampToXmlGregorianCalendar(Timestamp.valueOf("2018-06-25 14:34:53.647")));

		producerAgreement.setAgencyCode(MATCH_AGENCY_CODE.toString());
		producerAgreement.setAgencyDetachedCode(MATCH_AGENCY_DETACHED_CODE.toString());
		producerAgreement.setAgencyName("PORTLAND");

		return reply;
	}

	private ReadProducerAgreementReply createExpectedReadProducerAgreementReply() {
		final ReadProducerAgreementReply reply = new ReadProducerAgreementReply();
		final PRODUCER producer = new PRODUCER();
		producer.setID(MATCH_PARTY_ID_NO.toString());
		producer.setIDRefType(MaintainProducerAgreementService.VALID_IDREF_TYPE);
		reply.setProducer(producer);

		final PRODUCERAGREEMENT producerAgreement = new PRODUCERAGREEMENT();
		producer.getProducerAgreement().add(producerAgreement);

		producerAgreement.setProducerID(MATCH_PRDCR_ID_NO.toString());
		producerAgreement.setProducerAgreementID(MATCH_PRDCR_CON_ID_NO.toString());
		producerAgreement.setEffDate(MaintainProducerAgreementUtils
				.convertTimestampToXmlGregorianCalendar(Timestamp.valueOf("1999-04-01 00:00:00.0")));
		producerAgreement.setEndDate(MaintainProducerAgreementUtils
				.convertTimestampToXmlGregorianCalendar(Timestamp.valueOf("2001-07-13 00:00:00.0")));

		producerAgreement.setPayrollNo(MATCH_PAYROLL.toString());

		producerAgreement.setProducerAgreementCode(MATCH_CONTRACT_CODE);
		producerAgreement.setProducerAgreementType(MATCH_CONTRACT_TYPE_CODE_NO.toString());
		producerAgreement.setProducerAgreementID(MATCH_PRDCR_CON_ID_NO.toString());
		producerAgreement.setProducerAgreementPrimaryIndicator(false);

		producerAgreement.setProducerAgreementDefinition(MATCH_AGENT_TYPE_KEY);
		producerAgreement.setProducerAgreementAgentOfficialStartDate(MaintainProducerAgreementUtils
				.convertTimestampToXmlGregorianCalendar(Timestamp.valueOf("1998-04-01 00:00:00.0")));

		producerAgreement.setCreatedDate(MaintainProducerAgreementUtils
				.convertTimestampToXmlGregorianCalendar(Timestamp.valueOf("2018-06-25 12:33:29.597")));
		producerAgreement.setCreatedByNm(USER);
		producerAgreement.setUpdatedByNm(USER);
		producerAgreement.setUpdatedDate(MaintainProducerAgreementUtils
				.convertTimestampToXmlGregorianCalendar(Timestamp.valueOf("2018-06-25 14:34:53.647")));

		producerAgreement.setAgencyCode(MATCH_AGENCY_CODE.toString());
		producerAgreement.setAgencyDetachedCode(MATCH_AGENCY_DETACHED_CODE.toString());
		producerAgreement.setAgencyName("PORTLAND");

		return reply;
	}
}
