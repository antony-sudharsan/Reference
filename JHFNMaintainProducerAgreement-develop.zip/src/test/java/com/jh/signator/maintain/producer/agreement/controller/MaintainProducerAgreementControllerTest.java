/**
 *
 */
package com.jh.signator.maintain.producer.agreement.controller;

import static org.hamcrest.CoreMatchers.is;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.math.BigInteger;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;

import com.jh.signator.maintain.producer.agreement.exception.InvalidInputException;
import com.jh.signator.maintain.producer.agreement.service.MaintainProducerAgreementService;
import com.jh.signator.maintain.producer.agreement.utils.LoggerUtils;
import com.manulife.esb.xsd.common.jh.header.JHHeader;
import com.manulife.esb.xsd.distribution.jhfn.maintainproduceragreement.CreateProducerAgreementReply;
import com.manulife.esb.xsd.distribution.jhfn.maintainproduceragreement.CreateProducerAgreementRequest;
import com.manulife.esb.xsd.distribution.jhfn.maintainproduceragreement.DeleteProducerAgreementReply;
import com.manulife.esb.xsd.distribution.jhfn.maintainproduceragreement.DeleteProducerAgreementRequest;
import com.manulife.esb.xsd.distribution.jhfn.maintainproduceragreement.PRODUCER;
import com.manulife.esb.xsd.distribution.jhfn.maintainproduceragreement.PRODUCERAGREEMENT;
import com.manulife.esb.xsd.distribution.jhfn.maintainproduceragreement.ReadProducerAgreementReply;
import com.manulife.esb.xsd.distribution.jhfn.maintainproduceragreement.ReadProducerAgreementRequest;
import com.manulife.esb.xsd.distribution.jhfn.maintainproduceragreement.UpdateProducerAgreementReply;
import com.manulife.esb.xsd.distribution.jhfn.maintainproduceragreement.UpdateProducerAgreementRequest;

@ActiveProfiles("test")
@RunWith(SpringRunner.class)
/**
 * @WebMvcTest. It will auto-configure the Spring MVC infrastructure for our
 * unit tests. Setting up WebMvc Context for the Controller which is under
 * test("MaintainRelationshipController")
 */
@WebMvcTest(MaintainProducerAgreementController.class)
public class MaintainProducerAgreementControllerTest {

	private final String CREATE_PRODUCER_AGREEMENT_REQUEST = "{\r\n" + "	\"header\": {\r\n" + "		\"conversationUID\": \"ABC_1002\",\r\n"
			+ "		\"currentMessageDateTime\": \"2013-07-30T07:35:55.265+0000\",\r\n" + "		\"environmentID\": \"D1\",\r\n"
			+ "		\"messageSource\": {\r\n" + "			\"applicationName\": \"OEE\",\r\n" + "			\"applicationUserID\": \"SPA\",\r\n"
			+ "			\"hostName\": \"localhost\",\r\n" + "			\"processID\": \"localhost\",\r\n" + "			\"userID\": \"user1\"\r\n"
			+ "		},\r\n" + "		\"messageType\": \"REQUEST\",\r\n" + "		\"messageUID\": \"ABC_1002\",\r\n"
			+ "		\"originalMessageDateTime\": \"2013-07-30T07:35:55.265+0000\",\r\n" + "		\"relatesTo\": \"NA\",\r\n" + "		\"requestTimeOut\": 0,\r\n"
			+ "		\"serviceInfo\": {\r\n" + "			\"serviceName\": \"JHFNMaintainProducerAgreement_Create\",\r\n"
			+ "			\"serviceOperation\": \"Create\",\r\n" + "			\"serviceVersion\": \"1\"\r\n" + "		},\r\n" + "		\"status\": {\r\n"
			+ "			\"statusCode\": 0,\r\n" + "			\"statusDescription\": \"TEST\"\r\n" + "		},\r\n" + "		\"version\": \"1\"\r\n" + "	},\r\n"
			+ "	\"request\": {\r\n" + "		\"createProducerAgreement\": {\r\n" + "			\"id\": \"4948\",\r\n" + "			\"producerAgreement\": [{\r\n"
			+ "				\"producerID\": \"4263\",\r\n" + "				\"effDate\": \"1998-04-01T05:00:00.000+0000\",\r\n"
			+ "				\"payrollNo\": \"159887\",\r\n" + "				\"producerAgreementCode\": \"HV\",\r\n"
			+ "				\"producerAgreementType\": \"31\",\r\n" + "				\"producerAgreementPrimaryIndicator\": false,\r\n"
			+ "				\"producerAgreementDefinition\": \"MANAGING-DIRECTOR\",\r\n"
			+ "				\"producerAgreementAgentOfficialStartDate\": \"1998-04-01T05:00:00.000+0000\",\r\n" + "				\"agencyCode\": \"143\",\r\n"
			+ "				\"agencyDetachedCode\": \"0\",\r\n" + "				\"keyedValue\": []\r\n" + "			}],\r\n"
			+ "			\"idrefType\": 8000\r\n" + "		}\r\n" + "	}\r\n" + "}";

	private final String UPDATE_PRODUCER_AGREEMENT_REQUEST = "{\r\n" + "	\"header\": {\r\n" + "		\"conversationUID\": \"ABC_1002\",\r\n"
			+ "		\"currentMessageDateTime\": \"2013-07-30T07:35:55.265+0000\",\r\n" + "		\"environmentID\": \"D1\",\r\n"
			+ "		\"messageSource\": {\r\n" + "			\"applicationName\": \"OEE\",\r\n" + "			\"applicationUserID\": \"SPA\",\r\n"
			+ "			\"hostName\": \"localhost\",\r\n" + "			\"processID\": \"localhost\",\r\n" + "			\"userID\": \"user1\"\r\n"
			+ "		},\r\n" + "		\"messageType\": \"REQUEST\",\r\n" + "		\"messageUID\": \"ABC_1002\",\r\n"
			+ "		\"originalMessageDateTime\": \"2013-07-30T07:35:55.265+0000\",\r\n" + "		\"relatesTo\": \"NA\",\r\n" + "		\"requestTimeOut\": 0,\r\n"
			+ "		\"serviceInfo\": {\r\n" + "			\"serviceName\": \"JHFNMaintainProducerAgreement_Create\",\r\n"
			+ "			\"serviceOperation\": \"Create\",\r\n" + "			\"serviceVersion\": \"1\"\r\n" + "		},\r\n" + "		\"status\": {\r\n"
			+ "			\"statusCode\": 0,\r\n" + "			\"statusDescription\": \"TEST\"\r\n" + "		},\r\n" + "		\"version\": \"1\"\r\n" + "	},\r\n"
			+ "	\"updateProducerAgreement\": {\r\n" + "		\"id\": \"4948\",\r\n" + "		\"producerAgreement\": [{\r\n"
			+ "			\"producerID\": \"4263\",\r\n" + "			\"effDate\": \"1999-04-01T05:00:00.000+0000\",\r\n"
			+ "			\"payrollNo\": \"159887\",\r\n" + "			\"producerAgreementCode\": \"HV\",\r\n" + "			\"producerAgreementType\": \"31\",\r\n"
			+ "			\"producerAgreementPrimaryIndicator\": false,\r\n" + "			\"producerAgreementDefinition\": \"MANAGING-DIRECTOR\",\r\n"
			+ "			\"producerAgreementAgentOfficialStartDate\": \"1998-04-01T05:00:00.000+0000\",\r\n" + "			\"agencyCode\": \"143\",\r\n"
			+ "			\"agencyDetachedCode\": \"0\",\r\n" + "			\"keyedValue\": [],\r\n" + "			\"producerAgreementID\": \"36196\"\r\n"
			+ "		}],\r\n" + "		\"idrefType\": 8000\r\n" + "	}\r\n" + "}";

	private final String DELETE_PRODUCER_AGREEMENT_REQUEST = "{\r\n" + "	\"header\": {\r\n" + "		\"conversationUID\": \"ABC_1002\",\r\n"
			+ "		\"currentMessageDateTime\": \"2013-07-30T07:35:55.265+0000\",\r\n" + "		\"environmentID\": \"D1\",\r\n"
			+ "		\"messageSource\": {\r\n" + "			\"applicationName\": \"OEE\",\r\n" + "			\"applicationUserID\": \"SPA\",\r\n"
			+ "			\"hostName\": \"localhost\",\r\n" + "			\"processID\": \"localhost\",\r\n" + "			\"userID\": \"user1\"\r\n"
			+ "		},\r\n" + "		\"messageType\": \"REQUEST\",\r\n" + "		\"messageUID\": \"ABC_1002\",\r\n"
			+ "		\"originalMessageDateTime\": \"2013-07-30T07:35:55.265+0000\",\r\n" + "		\"relatesTo\": \"NA\",\r\n" + "		\"requestTimeOut\": 0,\r\n"
			+ "		\"serviceInfo\": {\r\n" + "			\"serviceName\": \"JHFNMaintainProducerAgreement_Create\",\r\n"
			+ "			\"serviceOperation\": \"Create\",\r\n" + "			\"serviceVersion\": \"1\"\r\n" + "		},\r\n" + "		\"status\": {\r\n"
			+ "			\"statusCode\": 0,\r\n" + "			\"statusDescription\": \"TEST\"\r\n" + "		},\r\n" + "		\"version\": \"1\"\r\n" + "	},\r\n"
			+ "	\"deleteProducerAgreement\": {\r\n" + "		\"id\": \"4948\",\r\n" + "		\"producerAgreement\": [{\r\n"
			+ "			\"endDate\": \"2001-07-13T04:00:00.000+0000\",\r\n" + "			\"keyedValue\": [],\r\n"
			+ "			\"producerAgreementID\": \"36196\"\r\n" + "		}],\r\n" + "		\"idrefType\": 8000\r\n" + "	}\r\n" + "}";

	private final String READ_PRODUCER_AGREEMENT_REQUEST = "{\r\n" + "	\"header\": {\r\n" + "		\"conversationUID\": \"ABC_1002\",\r\n"
			+ "		\"currentMessageDateTime\": \"2013-07-30T07:35:55.265+0000\",\r\n" + "		\"environmentID\": \"D1\",\r\n"
			+ "		\"messageSource\": {\r\n" + "			\"applicationName\": \"OEE\",\r\n" + "			\"applicationUserID\": \"SPA\",\r\n"
			+ "			\"hostName\": \"localhost\",\r\n" + "			\"processID\": \"localhost\",\r\n" + "			\"userID\": \"user1\"\r\n"
			+ "		},\r\n" + "		\"messageType\": \"REQUEST\",\r\n" + "		\"messageUID\": \"ABC_1002\",\r\n"
			+ "		\"originalMessageDateTime\": \"2013-07-30T07:35:55.265+0000\",\r\n" + "		\"relatesTo\": \"NA\",\r\n" + "		\"requestTimeOut\": 0,\r\n"
			+ "		\"serviceInfo\": {\r\n" + "			\"serviceName\": \"JHFNMaintainProducerAgreement_Create\",\r\n"
			+ "			\"serviceOperation\": \"Create\",\r\n" + "			\"serviceVersion\": \"1\"\r\n" + "		},\r\n" + "		\"status\": {\r\n"
			+ "			\"statusCode\": 0,\r\n" + "			\"statusDescription\": \"TEST\"\r\n" + "		},\r\n" + "		\"version\": \"1\"\r\n" + "	},\r\n"
			+ "	\"readProducerAgreement\": {\r\n" + "		\"id\": \"4948\",\r\n" + "		\"producerAgreement\": [{\r\n" + "			\"keyedValue\": [{\r\n"
			+ "				\"keyName\": \"\",\r\n" + "				\"vendorCode\": \"\",\r\n" + "				\"keyValue\": \"\"\r\n" + "			}],\r\n"
			+ "			\"producerAgreementID\": \"36196\"\r\n" + "		}],\r\n" + "		\"idrefType\": 8000\r\n" + "	}\r\n" + "}";
	@Autowired
	private MockMvc mvc;

	@MockBean
	private MaintainProducerAgreementService maintainProducerAgreementService;

	@MockBean
	private LoggerUtils loggerUtils;

	@Test
	public void givenValidCreateProducerAgreementRequestThenProperResponseReturned() throws Exception {

		when(maintainProducerAgreementService.create(any(JHHeader.class), any(CreateProducerAgreementRequest.class)))
				.thenReturn(getExpectedValidCreateProducerAgreementReply());

		mvc.perform(post("/jh/signator/maintain/producer/agreement/create").content(CREATE_PRODUCER_AGREEMENT_REQUEST)
				.contentType(MediaType.APPLICATION_JSON_UTF8_VALUE)).andDo(print()).andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
				.andExpect(status().isOk()).andExpect(jsonPath("$.header.messageUID", is("ABC_1002")))
				.andExpect(jsonPath("$.reply.producer.producerAgreement[0].createdByNm", is("user1")))
				.andExpect(jsonPath("$.reply.producer.producerAgreement[0].updatedByNm", is("user1")));

		verify(maintainProducerAgreementService, times(1)).create(any(JHHeader.class), any(CreateProducerAgreementRequest.class));
		verifyNoMoreInteractions(maintainProducerAgreementService);
	}

	@Test
	public void givenValidUpdateProducerAgreementRequestThenProperResponseReturned() throws Exception {

		when(maintainProducerAgreementService.update(any(JHHeader.class), any(UpdateProducerAgreementRequest.class)))
				.thenReturn(getExpectedValidUpdateProducerAgreementReply());

		mvc.perform(post("/jh/signator/maintain/producer/agreement/update").content(UPDATE_PRODUCER_AGREEMENT_REQUEST)
				.contentType(MediaType.APPLICATION_JSON_UTF8_VALUE)).andDo(print()).andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
				.andExpect(status().isOk()).andExpect(jsonPath("$.header.messageUID", is("ABC_1002")))
				.andExpect(jsonPath("$.reply.producer.producerAgreement[0].createdByNm", is("user1")))
				.andExpect(jsonPath("$.reply.producer.producerAgreement[0].updatedByNm", is("user1")));

		verify(maintainProducerAgreementService, times(1)).update(any(JHHeader.class), any(UpdateProducerAgreementRequest.class));
		verifyNoMoreInteractions(maintainProducerAgreementService);
	}

	@Test
	public void givenValidDeleteProducerAgreementRequestThenProperResponseReturned() throws Exception {

		when(maintainProducerAgreementService.delete(any(JHHeader.class), any(DeleteProducerAgreementRequest.class)))
				.thenReturn(getExpectedValidDeleteProducerAgreementReply());

		mvc.perform(post("/jh/signator/maintain/producer/agreement/delete").content(DELETE_PRODUCER_AGREEMENT_REQUEST)
				.contentType(MediaType.APPLICATION_JSON_UTF8_VALUE)).andDo(print()).andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
				.andExpect(status().isOk()).andExpect(jsonPath("$.header.messageUID", is("ABC_1002")))
				.andExpect(jsonPath("$.reply.producer.producerAgreement[0].createdByNm", is("user1")))
				.andExpect(jsonPath("$.reply.producer.producerAgreement[0].updatedByNm", is("user1")));

		verify(maintainProducerAgreementService, times(1)).delete(any(JHHeader.class), any(DeleteProducerAgreementRequest.class));
		verifyNoMoreInteractions(maintainProducerAgreementService);
	}

	@Test
	public void givenValidReadProducerAgreementRequestThenProperResponseReturned() throws Exception {

		when(maintainProducerAgreementService.read(any(JHHeader.class), any(ReadProducerAgreementRequest.class)))
				.thenReturn(getExpectedValidReadProducerAgreementReply());

		mvc.perform(post("/jh/signator/maintain/producer/agreement/read").content(READ_PRODUCER_AGREEMENT_REQUEST)
				.contentType(MediaType.APPLICATION_JSON_UTF8_VALUE)).andDo(print()).andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
				.andExpect(status().isOk()).andExpect(jsonPath("$.header.messageUID", is("ABC_1002")))
				.andExpect(jsonPath("$.reply.producer.producerAgreement[0].createdByNm", is("user1")))
				.andExpect(jsonPath("$.reply.producer.producerAgreement[0].updatedByNm", is("user1")));

		verify(maintainProducerAgreementService, times(1)).read(any(JHHeader.class), any(ReadProducerAgreementRequest.class));
		verifyNoMoreInteractions(maintainProducerAgreementService);
	}

	public CreateProducerAgreementReply getExpectedValidCreateProducerAgreementReply() {
		final CreateProducerAgreementReply createProducerAgreementReply = new CreateProducerAgreementReply();
		final PRODUCER producer = new PRODUCER();
		final PRODUCERAGREEMENT producerAgreement = new PRODUCERAGREEMENT();
		producer.setID("4948");
		producer.setIDRefType(BigInteger.valueOf(8000));
		producerAgreement.setAgencyCode("143");
		producerAgreement.setCreatedByNm("user1");
		producerAgreement.setUpdatedByNm("user1");
		producer.getProducerAgreement().add(producerAgreement);
		createProducerAgreementReply.setProducer(producer);
		return createProducerAgreementReply;
	}

	public UpdateProducerAgreementReply getExpectedValidUpdateProducerAgreementReply() {
		final UpdateProducerAgreementReply updateProducerAgreementReply = new UpdateProducerAgreementReply();
		final PRODUCER producer = new PRODUCER();
		final PRODUCERAGREEMENT producerAgreement = new PRODUCERAGREEMENT();
		producer.setID("4948");
		producer.setIDRefType(BigInteger.valueOf(8000));
		producerAgreement.setAgencyCode("143");
		producerAgreement.setCreatedByNm("user1");
		producerAgreement.setUpdatedByNm("user1");
		producer.getProducerAgreement().add(producerAgreement);
		updateProducerAgreementReply.setProducer(producer);
		return updateProducerAgreementReply;
	}

	public DeleteProducerAgreementReply getExpectedValidDeleteProducerAgreementReply() {
		final DeleteProducerAgreementReply deleteProducerAgreementReply = new DeleteProducerAgreementReply();
		final PRODUCER producer = new PRODUCER();
		final PRODUCERAGREEMENT producerAgreement = new PRODUCERAGREEMENT();
		producer.setID("4948");
		producer.setIDRefType(BigInteger.valueOf(8000));
		producerAgreement.setAgencyCode("143");
		producerAgreement.setCreatedByNm("user1");
		producerAgreement.setUpdatedByNm("user1");
		producer.getProducerAgreement().add(producerAgreement);
		deleteProducerAgreementReply.setProducer(producer);
		return deleteProducerAgreementReply;
	}

	public ReadProducerAgreementReply getExpectedValidReadProducerAgreementReply() {
		final ReadProducerAgreementReply readProducerAgreementReply = new ReadProducerAgreementReply();
		final PRODUCER producer = new PRODUCER();
		final PRODUCERAGREEMENT producerAgreement = new PRODUCERAGREEMENT();
		producer.setID("4948");
		producer.setIDRefType(BigInteger.valueOf(8000));
		producerAgreement.setAgencyCode("143");
		producerAgreement.setCreatedByNm("user1");
		producerAgreement.setUpdatedByNm("user1");
		producer.getProducerAgreement().add(producerAgreement);
		readProducerAgreementReply.setProducer(producer);
		return readProducerAgreementReply;
	}

	@Test
	public void whenInvalidUpdateInputExceptionThrownProperResponseAndStatusReturned() throws Exception {

		when(maintainProducerAgreementService.update(any(JHHeader.class), any(UpdateProducerAgreementRequest.class))).thenThrow(new InvalidInputException());

		mvc.perform(post("/jh/signator/maintain/producer/agreement/update").content(UPDATE_PRODUCER_AGREEMENT_REQUEST)
				.contentType(MediaType.APPLICATION_JSON_UTF8_VALUE)).andDo(print()).andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
				.andExpect(status().isBadRequest()).andExpect(jsonPath("$.code", is("993"))).andExpect(jsonPath("$.message", is("Invalid Input")))
				.andExpect(jsonPath("$.details", is("Invalid information entered for input.")));

		verify(maintainProducerAgreementService, times(1)).update(any(JHHeader.class), any(UpdateProducerAgreementRequest.class));
		verifyNoMoreInteractions(maintainProducerAgreementService);
	}

	@Test
	public void whenInvalidCreateInputExceptionThrownProperResponseAndStatusReturned() throws Exception {

		when(maintainProducerAgreementService.create(any(JHHeader.class), any(CreateProducerAgreementRequest.class))).thenThrow(new InvalidInputException());

		mvc.perform(post("/jh/signator/maintain/producer/agreement/create").content(CREATE_PRODUCER_AGREEMENT_REQUEST)
				.contentType(MediaType.APPLICATION_JSON_UTF8_VALUE)).andDo(print()).andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
				.andExpect(status().isBadRequest()).andExpect(jsonPath("$.code", is("993"))).andExpect(jsonPath("$.message", is("Invalid Input")))
				.andExpect(jsonPath("$.details", is("Invalid information entered for input.")));

		verify(maintainProducerAgreementService, times(1)).create(any(JHHeader.class), any(CreateProducerAgreementRequest.class));
		verifyNoMoreInteractions(maintainProducerAgreementService);
	}

	@Test
	public void whenInvalidDeleteInputExceptionThrownProperResponseAndStatusReturned() throws Exception {

		when(maintainProducerAgreementService.delete(any(JHHeader.class), any(DeleteProducerAgreementRequest.class))).thenThrow(new InvalidInputException());

		mvc.perform(post("/jh/signator/maintain/producer/agreement/delete").content(DELETE_PRODUCER_AGREEMENT_REQUEST)
				.contentType(MediaType.APPLICATION_JSON_UTF8_VALUE)).andDo(print()).andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
				.andExpect(status().isBadRequest()).andExpect(jsonPath("$.code", is("993"))).andExpect(jsonPath("$.message", is("Invalid Input")))
				.andExpect(jsonPath("$.details", is("Invalid information entered for input.")));

		verify(maintainProducerAgreementService, times(1)).delete(any(JHHeader.class), any(DeleteProducerAgreementRequest.class));
		verifyNoMoreInteractions(maintainProducerAgreementService);
	}

	@Test
	public void whenInvalidReadInputExceptionThrownProperResponseAndStatusReturned() throws Exception {

		when(maintainProducerAgreementService.read(any(JHHeader.class), any(ReadProducerAgreementRequest.class))).thenThrow(new InvalidInputException());

		mvc.perform(post("/jh/signator/maintain/producer/agreement/read").content(READ_PRODUCER_AGREEMENT_REQUEST)
				.contentType(MediaType.APPLICATION_JSON_UTF8_VALUE)).andDo(print()).andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
				.andExpect(status().isBadRequest()).andExpect(jsonPath("$.code", is("993"))).andExpect(jsonPath("$.message", is("Invalid Input")))
				.andExpect(jsonPath("$.details", is("Invalid information entered for input.")));

		verify(maintainProducerAgreementService, times(1)).read(any(JHHeader.class), any(ReadProducerAgreementRequest.class));
		verifyNoMoreInteractions(maintainProducerAgreementService);
	}

}
