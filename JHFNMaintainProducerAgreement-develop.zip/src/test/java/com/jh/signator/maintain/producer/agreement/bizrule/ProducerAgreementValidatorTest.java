/**
 *
 */
package com.jh.signator.maintain.producer.agreement.bizrule;

import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Test;

import com.jh.signator.maintain.producer.agreement.model.ProducerAgreementValidationInfo;
import com.jh.signator.maintain.producer.agreement.model.data.ContractTypeInfo;
import com.jh.signator.maintain.producer.agreement.model.data.TProducerInfo;

/**
 * Test class for ProducerAgreementValidator.
 *
 */
public class ProducerAgreementValidatorTest {

	private static final Long MATCH_PARTY_ID_NO = new Long(4296);
	private static final Long MATCH_PRDCR_ID_NO = new Long(1000);
	private static final Long MATCH_PRDCR_CON_ID_NO = new Long(2000);
	private static final String MATCH_CONTRACT_CODE = "RV";
	private static final Long MATCH_CONTRACT_TYPE_CODE_NO = new Long(63);
	private static final String MATCH_AGENT_TYPE_KEY = "BROKERAGE-SUPERVISORS";

	@Test
	public void givenProducerAndContractExistThenIsValidCreateReturnsTrue() {
		final ProducerAgreementValidationInfo validationInfo = new ProducerAgreementValidationInfo();
		validationInfo.setContractTypeInfoList(createTestContractTypeInfoList());
		validationInfo.setProducerInfoList(createTestProducerInfoForCreate());
		validationInfo.setProducerAgreementCode(MATCH_CONTRACT_CODE);
		validationInfo.setProducerAgreementType(MATCH_CONTRACT_TYPE_CODE_NO.toString());
		validationInfo.setProducerAgreementDefinition(MATCH_AGENT_TYPE_KEY);
		validationInfo.setProducerID(MATCH_PRDCR_ID_NO.toString());

		Assert.assertTrue(ProducerAgreementValidator.isValidCreate(validationInfo));
	}

	@Test
	public void givenPrdcrIdNoIsNullThenIsValidCreateReturnsFalse() {
		final ProducerAgreementValidationInfo validationInfo = new ProducerAgreementValidationInfo();
		validationInfo.setContractTypeInfoList(createTestContractTypeInfoList());
		validationInfo.setProducerInfoList(createTestProducerInfoForCreate());
		validationInfo.setProducerAgreementCode(MATCH_CONTRACT_CODE);
		validationInfo.setProducerAgreementType(MATCH_CONTRACT_TYPE_CODE_NO.toString());
		validationInfo.setProducerAgreementDefinition(MATCH_AGENT_TYPE_KEY);
		validationInfo.setProducerID(MATCH_PRDCR_ID_NO.toString());
		// remove matching row
		validationInfo.getProducerInfoList().get(1).setPrdcrIdNo(null);

		Assert.assertFalse(ProducerAgreementValidator.isValidCreate(validationInfo));
	}

	@Test
	public void givenProducerIDDoesNotExistForPartyIDThenIsValidCreateReturnsFalse() {
		final ProducerAgreementValidationInfo validationInfo = new ProducerAgreementValidationInfo();
		validationInfo.setContractTypeInfoList(createTestContractTypeInfoList());
		validationInfo.setProducerInfoList(createTestProducerInfoForCreate());
		validationInfo.setProducerAgreementCode(MATCH_CONTRACT_CODE);
		validationInfo.setProducerAgreementType(MATCH_CONTRACT_TYPE_CODE_NO.toString());
		validationInfo.setProducerAgreementDefinition(MATCH_AGENT_TYPE_KEY);
		validationInfo.setProducerID("INVALID");

		Assert.assertFalse(ProducerAgreementValidator.isValidCreate(validationInfo));
	}

	@Test
	public void givenContractCodeNotInListThenIsValidCreateReturnsFalse() {
		final ProducerAgreementValidationInfo validationInfo = new ProducerAgreementValidationInfo();
		validationInfo.setContractTypeInfoList(createTestContractTypeInfoList());
		validationInfo.setProducerInfoList(createTestProducerInfoForCreate());
		validationInfo.setProducerAgreementCode("ZZ");
		validationInfo.setProducerAgreementType(MATCH_CONTRACT_TYPE_CODE_NO.toString());
		validationInfo.setProducerAgreementDefinition(MATCH_AGENT_TYPE_KEY);
		validationInfo.setProducerID(MATCH_PRDCR_ID_NO.toString());

		Assert.assertFalse(ProducerAgreementValidator.isValidCreate(validationInfo));
	}

	@Test
	public void givenContractTypeCodeNoNotInListThenIsValidCreateReturnsFalse() {
		final ProducerAgreementValidationInfo validationInfo = new ProducerAgreementValidationInfo();
		validationInfo.setContractTypeInfoList(createTestContractTypeInfoList());
		validationInfo.setProducerInfoList(createTestProducerInfoForCreate());
		validationInfo.setProducerAgreementCode(MATCH_CONTRACT_CODE);
		validationInfo.setProducerAgreementType("1234");
		validationInfo.setProducerAgreementDefinition(MATCH_AGENT_TYPE_KEY);
		validationInfo.setProducerID(MATCH_PRDCR_ID_NO.toString());

		Assert.assertFalse(ProducerAgreementValidator.isValidCreate(validationInfo));
	}

	@Test
	public void givenAgentTypeKeyNotInListThenIsValidCreateReturnsFalse() {
		final ProducerAgreementValidationInfo validationInfo = new ProducerAgreementValidationInfo();
		validationInfo.setContractTypeInfoList(createTestContractTypeInfoList());
		validationInfo.setProducerInfoList(createTestProducerInfoForCreate());
		validationInfo.setProducerAgreementCode(MATCH_CONTRACT_CODE);
		validationInfo.setProducerAgreementType(MATCH_CONTRACT_TYPE_CODE_NO.toString());
		validationInfo.setProducerAgreementDefinition("ZZ");
		validationInfo.setProducerID(MATCH_PRDCR_ID_NO.toString());

		Assert.assertFalse(ProducerAgreementValidator.isValidCreate(validationInfo));
	}

	// update tests
	@Test
	public void givenProducerAndContractExistThenIsValidUpdateReturnsTrue() {
		final ProducerAgreementValidationInfo validationInfo = new ProducerAgreementValidationInfo();
		validationInfo.setContractTypeInfoList(createTestContractTypeInfoList());
		validationInfo.setProducerInfoList(createTestProducerInfoForUpdate());
		validationInfo.setProducerAgreementCode(MATCH_CONTRACT_CODE);
		validationInfo.setProducerAgreementType(MATCH_CONTRACT_TYPE_CODE_NO.toString());
		validationInfo.setProducerAgreementDefinition(MATCH_AGENT_TYPE_KEY);
		validationInfo.setProducerAgreementID(MATCH_PRDCR_CON_ID_NO.toString());

		Assert.assertTrue(ProducerAgreementValidator.isValidUpdate(validationInfo));
	}

	@Test
	public void givenPrdcrIdNoIsNullThenIsValidUpdateReturnsFalse() {
		final ProducerAgreementValidationInfo validationInfo = new ProducerAgreementValidationInfo();
		validationInfo.setContractTypeInfoList(createTestContractTypeInfoList());
		validationInfo.setProducerInfoList(createTestProducerInfoForUpdate());
		validationInfo.setProducerAgreementCode(MATCH_CONTRACT_CODE);
		validationInfo.setProducerAgreementType(MATCH_CONTRACT_TYPE_CODE_NO.toString());
		validationInfo.setProducerAgreementDefinition(MATCH_AGENT_TYPE_KEY);
		validationInfo.setProducerAgreementID(MATCH_PRDCR_CON_ID_NO.toString());
		// remove matching row
		validationInfo.getProducerInfoList().get(1).setPrdcrConIdNo(null);

		Assert.assertFalse(ProducerAgreementValidator.isValidUpdate(validationInfo));
	}

	@Test
	public void givenProducerAgreementIDDoesNotExistForPartyIDThenIsValidUpdateReturnsFalse() {
		final ProducerAgreementValidationInfo validationInfo = new ProducerAgreementValidationInfo();
		validationInfo.setContractTypeInfoList(createTestContractTypeInfoList());
		validationInfo.setProducerInfoList(createTestProducerInfoForUpdate());
		validationInfo.setProducerAgreementCode(MATCH_CONTRACT_CODE);
		validationInfo.setProducerAgreementType(MATCH_CONTRACT_TYPE_CODE_NO.toString());
		validationInfo.setProducerAgreementDefinition(MATCH_AGENT_TYPE_KEY);
		validationInfo.setProducerAgreementID("Invalid");

		Assert.assertFalse(ProducerAgreementValidator.isValidUpdate(validationInfo));
	}

	@Test
	public void givenContractCodeNotInListThenIsValidUpdateReturnsFalse() {
		final ProducerAgreementValidationInfo validationInfo = new ProducerAgreementValidationInfo();
		validationInfo.setContractTypeInfoList(createTestContractTypeInfoList());
		validationInfo.setProducerInfoList(createTestProducerInfoForUpdate());
		validationInfo.setProducerAgreementCode("ZZ");
		validationInfo.setProducerAgreementType(MATCH_CONTRACT_TYPE_CODE_NO.toString());
		validationInfo.setProducerAgreementDefinition(MATCH_AGENT_TYPE_KEY);
		validationInfo.setProducerAgreementID(MATCH_PRDCR_CON_ID_NO.toString());

		Assert.assertFalse(ProducerAgreementValidator.isValidUpdate(validationInfo));
	}

	@Test
	public void givenContractTypeCodeNoNotInListThenIsValidUpdateReturnsFalse() {
		final ProducerAgreementValidationInfo validationInfo = new ProducerAgreementValidationInfo();
		validationInfo.setContractTypeInfoList(createTestContractTypeInfoList());
		validationInfo.setProducerInfoList(createTestProducerInfoForUpdate());
		validationInfo.setProducerAgreementCode(MATCH_CONTRACT_CODE);
		validationInfo.setProducerAgreementType("1234");
		validationInfo.setProducerAgreementDefinition(MATCH_AGENT_TYPE_KEY);
		validationInfo.setProducerAgreementID(MATCH_PRDCR_CON_ID_NO.toString());

		Assert.assertFalse(ProducerAgreementValidator.isValidUpdate(validationInfo));
	}

	@Test
	public void givenAgentTypeKeyNotInListThenIsValidUpdateReturnsFalse() {
		final ProducerAgreementValidationInfo validationInfo = new ProducerAgreementValidationInfo();
		validationInfo.setContractTypeInfoList(createTestContractTypeInfoList());
		validationInfo.setProducerInfoList(createTestProducerInfoForUpdate());
		validationInfo.setProducerAgreementCode(MATCH_CONTRACT_CODE);
		validationInfo.setProducerAgreementType(MATCH_CONTRACT_TYPE_CODE_NO.toString());
		validationInfo.setProducerAgreementDefinition("ZZ");
		validationInfo.setProducerAgreementID(MATCH_PRDCR_CON_ID_NO.toString());

		Assert.assertFalse(ProducerAgreementValidator.isValidUpdate(validationInfo));
	}

	// delte tests
	@Test
	public void givenProducerAndContractExistThenIsValidDeleteReturnsTrue() {
		final ProducerAgreementValidationInfo validationInfo = new ProducerAgreementValidationInfo();
		validationInfo.setProducerInfoList(createTestProducerInfoForUpdate());
		validationInfo.setProducerAgreementID(MATCH_PRDCR_CON_ID_NO.toString());

		Assert.assertTrue(ProducerAgreementValidator.isValidDelete(validationInfo));
	}

	@Test
	public void givenPrdcrIdNoIsNullThenIsValidDeleteReturnsFalse() {
		final ProducerAgreementValidationInfo validationInfo = new ProducerAgreementValidationInfo();
		validationInfo.setProducerInfoList(createTestProducerInfoForUpdate());
		validationInfo.setProducerAgreementID(MATCH_PRDCR_CON_ID_NO.toString());
		// remove matching row
		validationInfo.getProducerInfoList().get(1).setPrdcrConIdNo(null);

		Assert.assertFalse(ProducerAgreementValidator.isValidDelete(validationInfo));
	}

	@Test
	public void givenProducerAgreementIDDoesNotExistForPartyIDThenIsValidDeleteReturnsFalse() {
		final ProducerAgreementValidationInfo validationInfo = new ProducerAgreementValidationInfo();
		validationInfo.setProducerInfoList(createTestProducerInfoForUpdate());
		validationInfo.setProducerAgreementID("Invalid");

		Assert.assertFalse(ProducerAgreementValidator.isValidDelete(validationInfo));
	}

	private List<ContractTypeInfo> createTestContractTypeInfoList() {
		final List<ContractTypeInfo> contractTypes = new ArrayList<>();

		ContractTypeInfo contractType = new ContractTypeInfo();
		contractType.setContractCode("RE");
		contractType.setContractTypeCodeNo(new Long(38));
		contractType.setAgentTypeKey("BROKER");
		contractTypes.add(contractType);
		contractType = new ContractTypeInfo();
		contractType.setContractCode(MATCH_CONTRACT_CODE);
		contractType.setContractTypeCodeNo(MATCH_CONTRACT_TYPE_CODE_NO);
		contractType.setAgentTypeKey(MATCH_AGENT_TYPE_KEY);
		contractTypes.add(contractType);
		contractType = new ContractTypeInfo();
		contractType.setContractCode("HF");
		contractType.setContractTypeCodeNo(new Long(21));
		contractType.setAgentTypeKey("FINANCED");
		contractTypes.add(contractType);

		return contractTypes;
	}

	private List<TProducerInfo> createTestProducerInfoForCreate() {
		final List<TProducerInfo> producers = new ArrayList<>();
		TProducerInfo producer = new TProducerInfo();
		producer.setPartyIdNo(new Long(123));
		producer.setPrdcrIdNo(new Long(999));
		producers.add(producer);
		producer = new TProducerInfo();
		producer.setPartyIdNo(MATCH_PARTY_ID_NO);
		producer.setPrdcrIdNo(MATCH_PRDCR_ID_NO);
		producers.add(producer);
		producer = new TProducerInfo();
		producer.setPartyIdNo(new Long(111));
		producer.setPrdcrIdNo(new Long(888));
		producers.add(producer);
		return producers;
	}

	private List<TProducerInfo> createTestProducerInfoForUpdate() {
		final List<TProducerInfo> producers = new ArrayList<>();
		TProducerInfo producer = new TProducerInfo();
		producer.setPartyIdNo(new Long(123));
		producer.setPrdcrIdNo(new Long(999));
		producers.add(producer);
		producer = new TProducerInfo();
		producer.setPartyIdNo(MATCH_PARTY_ID_NO);
		producer.setPrdcrIdNo(MATCH_PRDCR_ID_NO);
		producer.setPrdcrConIdNo(MATCH_PRDCR_CON_ID_NO);
		producers.add(producer);
		producer = new TProducerInfo();
		producer.setPartyIdNo(new Long(111));
		producer.setPrdcrIdNo(new Long(888));
		producers.add(producer);
		return producers;
	}
}
