package com.jh.signator.maintain.producer.agreement.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.context.annotation.Profile;
import org.springframework.transaction.PlatformTransactionManager;

import com.jh.signator.maintain.producer.agreement.dao.FakeMaintainProducerAgreementDao;
import com.jh.signator.maintain.producer.agreement.dao.FakeTransactionManager;

@Profile("test-fake")
@Configuration
public class TestConfig {

	@Bean
	@Primary
	public FakeMaintainProducerAgreementDao getFakeMaintainProducerAgreementDao() {
		return new FakeMaintainProducerAgreementDao();
	}

	@Bean
	@Primary
	public PlatformTransactionManager getTransactionManager() {
		return new FakeTransactionManager();
	}

}
