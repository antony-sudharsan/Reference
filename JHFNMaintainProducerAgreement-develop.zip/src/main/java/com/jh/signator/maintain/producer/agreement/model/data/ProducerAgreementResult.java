package com.jh.signator.maintain.producer.agreement.model.data;

import java.sql.Timestamp;

import org.apache.commons.lang3.builder.ToStringBuilder;

public class ProducerAgreementResult {

	private Long partyIdNo;
	private Long prdcrConIdNo;
	private Long prdcrIdNo;
	private Timestamp ccstdt;
	private Timestamp ccstopdt;
	private Long pyrlNo;
	private String conCd;
	private Long conTypCdNo;
	private Long primConInd;
	private String agentTypKey;
	private Timestamp agoffstdt;
	private Long orgPartyIdNo;
	private Long orgAgencyCd;
	private Long orgDtchCd;
	private String orgNm;
	private Timestamp creatDtm;
	private String creatByNm;
	private Timestamp lastUpdDtm;
	private String lastUpdByNm;

	public Long getPartyIdNo() {
		return partyIdNo;
	}

	public void setPartyIdNo(final Long partyIdNo) {
		this.partyIdNo = partyIdNo;
	}

	public Long getPrdcrConIdNo() {
		return prdcrConIdNo;
	}

	public void setPrdcrConIdNo(final Long prdcrConIdNo) {
		this.prdcrConIdNo = prdcrConIdNo;
	}

	public Long getPrdcrIdNo() {
		return prdcrIdNo;
	}

	public void setPrdcrIdNo(final Long prdcrIdNo) {
		this.prdcrIdNo = prdcrIdNo;
	}

	public Timestamp getCcstdt() {
		return ccstdt;
	}

	public void setCcstdt(final Timestamp ccstdt) {
		this.ccstdt = ccstdt;
	}

	public Timestamp getCcstopdt() {
		return ccstopdt;
	}

	public void setCcstopdt(final Timestamp ccstopdt) {
		this.ccstopdt = ccstopdt;
	}

	public Long getPyrlNo() {
		return pyrlNo;
	}

	public void setPyrlNo(final Long pyrlNo) {
		this.pyrlNo = pyrlNo;
	}

	public String getConCd() {
		return conCd;
	}

	public void setConCd(final String conCd) {
		this.conCd = conCd;
	}

	public Long getConTypCdNo() {
		return conTypCdNo;
	}

	public void setConTypCdNo(final Long conTypCdNo) {
		this.conTypCdNo = conTypCdNo;
	}

	public Long getPrimConInd() {
		return primConInd;
	}

	public void setPrimConInd(final Long primConInd) {
		this.primConInd = primConInd;
	}

	public String getAgentTypKey() {
		return agentTypKey;
	}

	public void setAgentTypKey(final String agentTypKey) {
		this.agentTypKey = agentTypKey;
	}

	public Timestamp getAgoffstdt() {
		return agoffstdt;
	}

	public void setAgoffstdt(final Timestamp agoffstdt) {
		this.agoffstdt = agoffstdt;
	}

	public Long getOrgPartyIdNo() {
		return orgPartyIdNo;
	}

	public void setOrgPartyIdNo(final Long orgPartyIdNo) {
		this.orgPartyIdNo = orgPartyIdNo;
	}

	public Long getOrgAgencyCd() {
		return orgAgencyCd;
	}

	public void setOrgAgencyCd(final Long orgAgencyCd) {
		this.orgAgencyCd = orgAgencyCd;
	}

	public Long getOrgDtchCd() {
		return orgDtchCd;
	}

	public void setOrgDtchCd(final Long orgDtchCd) {
		this.orgDtchCd = orgDtchCd;
	}

	public String getOrgNm() {
		return orgNm;
	}

	public void setOrgNm(final String orgNm) {
		this.orgNm = orgNm;
	}

	public Timestamp getCreatDtm() {
		return creatDtm;
	}

	public void setCreatDtm(final Timestamp creatDtm) {
		this.creatDtm = creatDtm;
	}

	public String getCreatByNm() {
		return creatByNm;
	}

	public void setCreatByNm(final String creatByNm) {
		this.creatByNm = creatByNm;
	}

	public Timestamp getLastUpdDtm() {
		return lastUpdDtm;
	}

	public void setLastUpdDtm(final Timestamp lastUpdDtm) {
		this.lastUpdDtm = lastUpdDtm;
	}

	public String getLastUpdByNm() {
		return lastUpdByNm;
	}

	public void setLastUpdByNm(final String lastUpdByNm) {
		this.lastUpdByNm = lastUpdByNm;
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
}
