package com.jh.signator.maintain.producer.agreement.bizrule;

import java.util.ArrayList;
import java.util.List;

import com.jh.signator.maintain.producer.agreement.model.data.ProducerAgreementResult;
import com.jh.signator.maintain.producer.agreement.utils.MaintainProducerAgreementUtils;
import com.manulife.esb.xsd.distribution.jhfn.maintainproduceragreement.PRODUCERAGREEMENT;

public class MaintainProducerAgreementMapper {

	public List<PRODUCERAGREEMENT> mapProducerAgreement(
			final List<ProducerAgreementResult> producerContractLookUpRows) {
		final List<PRODUCERAGREEMENT> resultsProducerAgreement = new ArrayList<>();
		for (final ProducerAgreementResult producerContractLookup : producerContractLookUpRows) {
			resultsProducerAgreement.add(mapProducerAgreement(producerContractLookup));
		}

		return resultsProducerAgreement;
	}

	public PRODUCERAGREEMENT mapProducerAgreement(final ProducerAgreementResult producerContractLookup) {

		final PRODUCERAGREEMENT producerAgreement = new PRODUCERAGREEMENT();
		producerAgreement.setProducerAgreementID(producerContractLookup.getPrdcrConIdNo().toString());
		producerAgreement.setProducerID(producerContractLookup.getPrdcrIdNo().toString());
		producerAgreement.setEffDate(MaintainProducerAgreementUtils
				.convertTimestampToXmlGregorianCalendar(producerContractLookup.getCcstdt()));
		producerAgreement.setEndDate(MaintainProducerAgreementUtils
				.convertTimestampToXmlGregorianCalendar(producerContractLookup.getCcstopdt()));
		producerAgreement.setPayrollNo(producerContractLookup.getPyrlNo().toString());
		producerAgreement.setProducerAgreementCode(producerContractLookup.getConCd());
		producerAgreement.setProducerAgreementType(producerContractLookup.getConTypCdNo().toString());

		// scalar so false by default
		if ((producerContractLookup.getPrimConInd() != null)
				&& (producerContractLookup.getPrimConInd().longValue() == 1)) {
			producerAgreement.setProducerAgreementPrimaryIndicator(true);

		}
		producerAgreement.setProducerAgreementDefinition(producerContractLookup.getAgentTypKey());
		producerAgreement.setProducerAgreementAgentOfficialStartDate(MaintainProducerAgreementUtils
				.convertTimestampToXmlGregorianCalendar(producerContractLookup.getAgoffstdt()));
		if (producerContractLookup.getOrgAgencyCd() != null) {
			producerAgreement.setAgencyCode(producerContractLookup.getOrgAgencyCd().toString());
		}
		if (producerContractLookup.getOrgDtchCd() != null) {
			producerAgreement.setAgencyDetachedCode(producerContractLookup.getOrgDtchCd().toString());
		}
		String agencyName = producerContractLookup.getOrgNm();
		if (agencyName != null) {
			agencyName = agencyName.trim();
		}
		producerAgreement.setAgencyName(agencyName);
		producerAgreement.setCreatedDate(MaintainProducerAgreementUtils
				.convertTimestampToXmlGregorianCalendar(producerContractLookup.getCreatDtm()));
		producerAgreement.setCreatedByNm(producerContractLookup.getCreatByNm());
		producerAgreement.setUpdatedByNm(producerContractLookup.getLastUpdByNm());
		producerAgreement.setUpdatedDate(MaintainProducerAgreementUtils
				.convertTimestampToXmlGregorianCalendar(producerContractLookup.getLastUpdDtm()));

		return producerAgreement;
	}
}
