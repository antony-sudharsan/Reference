package com.jh.signator.maintain.producer.agreement.utils;

import java.sql.Timestamp;
import java.util.GregorianCalendar;

import javax.xml.bind.JAXBElement;
import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Utility class for MaintainProducerAgreement operations.
 *
 */
public class MaintainProducerAgreementUtils {

	private static final Logger logger = LoggerFactory.getLogger(MaintainProducerAgreementUtils.class);

	private static final String EMPTY_STRING = "";

	/**
	 * Method to convert Timestamp to XMLGregorianCalendar
	 *
	 * @param inputDate
	 * @return
	 */
	public static XMLGregorianCalendar convertTimestampToXmlGregorianCalendar(final Timestamp inputDate) {
		XMLGregorianCalendar xmlGregorianCalendar = null;
		if (inputDate != null) {
			final GregorianCalendar gregorianCalendar = new GregorianCalendar();

			gregorianCalendar.setTime(inputDate);
			try {
				xmlGregorianCalendar = DatatypeFactory.newInstance().newXMLGregorianCalendar(gregorianCalendar);
			} catch (final DatatypeConfigurationException e) {
				logger.error("Failed converting date to XMLGregorianCalendar", e);
			}
		}
		return xmlGregorianCalendar;
	}

	/**
	 * Converts an XMLGregorianCalendar to a Timestamp
	 *
	 * @param xmlGregorianCalendar
	 * @return
	 */
	public static Timestamp convertXmlGregorianCalendarToTimestamp(final XMLGregorianCalendar xmlGregorianCalendar) {
		Timestamp timestamp = null;
		if (xmlGregorianCalendar != null) {
			timestamp = new Timestamp(xmlGregorianCalendar.toGregorianCalendar().getTimeInMillis());
		}

		return timestamp;
	}

	/**
	 * Converts an JAXBElement<XMLGregorianCalendar> to a Timestamp
	 *
	 * @param xmlGregorianCalendar
	 * @return
	 */
	public static Timestamp convertXmlGregorianCalendarToTimestamp(
			final JAXBElement<XMLGregorianCalendar> xmlGregorianCalendar) {
		Timestamp timestamp = null;
		if ((xmlGregorianCalendar != null) && !xmlGregorianCalendar.isNil()) {
			timestamp = new Timestamp(xmlGregorianCalendar.getValue().toGregorianCalendar().getTimeInMillis());
		}

		return timestamp;
	}

	public static String ifNullReturnEmpty(final String value) {
		if (StringUtils.isNotEmpty(value)) {
			return value;
		}

		return EMPTY_STRING;
	}

}
