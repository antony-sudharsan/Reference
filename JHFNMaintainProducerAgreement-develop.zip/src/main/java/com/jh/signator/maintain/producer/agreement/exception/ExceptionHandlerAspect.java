package com.jh.signator.maintain.producer.agreement.exception;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.core.annotation.Order;
import org.springframework.dao.QueryTimeoutException;
import org.springframework.stereotype.Component;

import com.jh.common.logging.LoggerHandler;
import com.jh.signator.maintain.producer.agreement.utils.LoggingContext;
import com.jh.signator.maintain.producer.agreement.utils.LoggingContextHolder;

/**
 * Exception Handler to handle throws and convert to proper fault exceptions.
 *
 */
@Component
@Aspect
@Order(1)
public class ExceptionHandlerAspect {

	@Pointcut("execution(* com.jh.signator.maintain.producer.agreement.service.MaintainProducerAgreementService.*(..))")
	public void serviceHandler() {

	}

	@AfterThrowing(pointcut = "serviceHandler()", throwing = "ex")
	public void handleException(final JoinPoint joinPoint, final Exception ex) {

		if (ex instanceof BaseFaultException) {
			final BaseFaultException bfe = (BaseFaultException) ex;
			throw bfe;
		} else {
			// only log if not one we threw directly as it will be logged in outer layer,
			// either endpoint or controller
			final LoggingContext loggingContext = LoggingContextHolder.getLoggingContext();
			final String className = joinPoint.getSignature().getDeclaringTypeName();
			LoggerHandler.ErrorOut(ex, loggingContext.getMessageUUID(), loggingContext.getSourceSystemName(), className,
					ex.getMessage());

			if (ex instanceof QueryTimeoutException) {
				throw new RequestTimeoutException();
			} else if (ex instanceof Exception) {
				throw new TechnicalErrorException(ex.getMessage(), ex);
			}
		}
	}
}
