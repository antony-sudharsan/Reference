/**
 *
 */
package com.jh.signator.maintain.producer.agreement.model;

import javax.validation.Valid;

import com.manulife.esb.xsd.common.jh.header.JHHeader;
import com.manulife.esb.xsd.distribution.jhfn.maintainproduceragreement.DeleteProducerAgreementRequest;

/**
 * Used to hold request and header.
 *
 */
public class DeleteProducerAgreementRequestWrapper {
	private JHHeader header;
	@Valid
	private DeleteProducerAgreementRequest request;

	public JHHeader getHeader() {
		return header;
	}

	public void setHeader(final JHHeader header) {
		this.header = header;
	}

	public DeleteProducerAgreementRequest getRequest() {
		return request;
	}

	public void setRequest(final DeleteProducerAgreementRequest request) {
		this.request = request;
	}

}
