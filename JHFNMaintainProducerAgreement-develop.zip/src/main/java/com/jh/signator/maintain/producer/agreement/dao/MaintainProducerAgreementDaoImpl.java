package com.jh.signator.maintain.producer.agreement.dao;

import java.util.List;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Profile;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.jh.signator.maintain.producer.agreement.model.data.ContractTypeInfo;
import com.jh.signator.maintain.producer.agreement.model.data.ProducerAgreementResult;
import com.jh.signator.maintain.producer.agreement.model.data.TProducerInfo;
import com.jh.signator.maintain.producer.agreement.utils.MaintainProducerAgreementUtils;
import com.manulife.esb.xsd.distribution.jhfn.maintainproduceragreement.CreateProducerAgreement;
import com.manulife.esb.xsd.distribution.jhfn.maintainproduceragreement.DeleteProducerAgreement.ProducerAgreement;
import com.manulife.esb.xsd.distribution.jhfn.maintainproduceragreement.UpdateProducerAgreement;
import com.microsoft.sqlserver.jdbc.StringUtils;

/**
 * Implementation class for MaintainProducerAgreementDao.
 *
 */
@Repository
@Profile("!test-fake")
public class MaintainProducerAgreementDaoImpl implements MaintainProducerAgreementDao {

	@Value("${RequestTimeoutLimit}")
	private int requestTimeoutLimit;

	private final static String SELECT_PRODUCER_AGREEMENT_READ_SQL = "select \r\n" + "p.party_id_no\r\n"
			+ ",con.prdcr_con_id_no\r\n" + ",con.prdcr_id_no\r\n" + ",con.ccstdt\r\n" + ",con.ccstopdt\r\n"
			+ ",con.pyrl_no\r\n" + ",con.con_cd\r\n" + ",con.con_typ_cd_no\r\n" + ",con.prim_con_ind\r\n"
			+ ",con.agent_typ_key\r\n" + ",con.agoffstdt\r\n" + ",con.org_party_id_no\r\n" + ",firm.org_agency_cd\r\n"
			+ ",firm.org_dtch_cd\r\n" + ",firm.org_nm\r\n" + ",con.creat_dtm\r\n" + ",con.creat_by_nm\r\n"
			+ ",con.last_upd_dtm\r\n" + ",con.last_upd_by_nm \r\n" + "from TPARTY p \r\n"
			+ "left outer join TPRODUCER prdcr on (p.party_id_no = prdcr.party_id_no) \r\n"
			+ "left outer join TPRDCR_CON con on (prdcr.prdcr_id_no = con.prdcr_id_no) \r\n"
			+ "left outer join TPARTY firm on (con.org_party_id_no = firm.party_id_no) \r\n"
			+ "where p.party_id_no = ? \r\n" + "and con.prdcr_con_id_no = ? \r\n"
			+ "order by p.party_id_no,con.prdcr_id_no,con.ccstdt,con.ccstopdt desc";

	private final static String SELECT_CONTRACT_TYPE_INFO_SQL = "select c.contract_code, c.contract_type_code_no, at.agent_type_key\r\n"
			+ "from TCONTRACT_TYPE c (nolock)\r\n" + "INNER JOIN TAGENT_TYPE_CONTRACTS atc (nolock)\r\n"
			+ "ON c.contract_type_id_no = atc.contract_type_id_no\r\n" + "INNER JOIN TAGENT_TYPE at (nolock)\r\n"
			+ "ON at.agent_type_id_no = atc.agent_type_id_no";

	private final static String SELECT_PRODUCER_INFO_CREATE_SQL = "SELECT p.party_id_no, pr.prdcr_id_no \r\n"
			+ "FROM tparty p (NoLock)\r\n" + "  LEFT JOIN tproducer pr (NoLock) ON p.party_id_no = pr.party_id_no \r\n"
			+ "WHERE p.party_id_no = ?";

	private final static String SELECT_PRODUCER_INFO_UPDATE_SQL = "SELECT p.party_id_no, pr.prdcr_id_no, pc.prdcr_con_id_no \r\n"
			+ "FROM tparty p (NoLock) \r\n" + "LEFT JOIN tproducer pr (NoLock) ON p.party_id_no = pr.party_id_no \r\n"
			+ "LEFT JOIN tprdcr_con pc (NoLock) ON pr.prdcr_id_no = pc.prdcr_id_no \r\n" + "WHERE p.party_id_no = ?";

	private final static String INSERT_PRODUCER_AGREEMENT_SQL = "INSERT INTO TPRDCR_CON\r\n"
			+ "           (PRDCR_ID_NO\r\n" + "           ,PYRL_NO\r\n" + "           ,AGENCY_CD\r\n"
			+ "           ,CON_CD\r\n" + "           ,CON_TYP_CD_NO\r\n" + "           ,CCSTDT\r\n"
			+ "           ,CCSTOPDT\r\n" + "           ,AGOFFSTDT\r\n" + "           ,PRIM_CON_IND\r\n"
			+ "           ,AGENT_TYP_KEY\r\n" + "           ,CREAT_DTM\r\n" + "           ,CREAT_BY_NM\r\n"
			+ "           ,CREAT_BY_PRCS_CD\r\n" + "           ,LAST_UPD_DTM\r\n" + "           ,LAST_UPD_BY_NM\r\n"
			+ "           ,LAST_UPD_PRCS_CD\r\n" + "           ,org_party_id_no)\r\n" + "     VALUES\r\n"
			+ "           (?,?,?,?,?,?,?,?,?,?,getdate(),?,8000,getdate(),?,8000,?)";

	private final static String SELECT_PRODUCER_INFO_AFTER_CREATE_SQL = "SELECT TOP 1\r\n"
			+ "      pc.PRDCR_CON_ID_NO\r\n" + "      ,pc.PRDCR_ID_NO\r\n" + "      ,pc.OFFICE_ID_NO\r\n"
			+ "      ,pc.PYRL_NO\r\n" + "      ,pc.AGENCY_CD\r\n" + "      ,pc.CON_CD\r\n"
			+ "      ,pc.CON_TYP_CD_NO\r\n" + "      ,pc.CCSTDT\r\n" + "      ,pc.CCSTOPDT\r\n"
			+ "      ,pc.AGOFFSTDT\r\n" + "      ,pc.PRIM_CON_IND\r\n" + "      ,pc.AGENT_TYP_KEY\r\n"
			+ "      ,pc.CREAT_DTM\r\n" + "      ,pc.CREAT_BY_NM\r\n" + "      ,pc.CREAT_BY_PRCS_CD\r\n"
			+ "      ,pc.LAST_UPD_DTM\r\n" + "      ,pc.LAST_UPD_BY_NM\r\n" + "      ,pc.LAST_UPD_PRCS_CD\r\n"
			+ "      ,pc.org_party_id_no\r\n" + "      ,firm.org_agency_cd\r\n" + "      ,firm.org_dtch_cd\r\n"
			+ "      ,firm.org_nm\r\n" + "  FROM TPRDCR_CON pc (NoLock)\r\n" + "  INNER JOIN TPARTY firm (NoLock)\r\n"
			+ "	On firm.party_id_no = pc.org_party_id_no  \r\n"
			+ "  WHERE pc.CREAT_BY_NM = ? and pc.PRDCR_ID_NO = ?\r\n" + "  ORDER BY pc.CREAT_DTM DESC";

	private final static String SELECT_FIRM_INFO_SQL = "SELECT \r\n" + "   party_id_no\r\n" + "FROM TPARTY \r\n"
			+ "WHERE org_agency_cd = ?\r\n" + "and org_dtch_cd = ?";

	private final static String UPDATE_PRODUCER_AGREEMENT_SQL = "UPDATE TPRDCR_CON\r\n" + "   SET PRDCR_ID_NO = ?\r\n"
			+ "      ,PYRL_NO = ?\r\n" + "      ,AGENCY_CD = ?\r\n" + "      ,CON_CD = ?\r\n"
			+ "      ,CON_TYP_CD_NO = ?\r\n" + "      ,CCSTDT = ?\r\n" + "      ,CCSTOPDT = ?\r\n"
			+ "      ,AGOFFSTDT = ?\r\n" + "      ,PRIM_CON_IND = ?\r\n" + "      ,AGENT_TYP_KEY = ?      \r\n"
			+ "      ,LAST_UPD_DTM = getdate()\r\n" + "      ,LAST_UPD_BY_NM = ?\r\n"
			+ "      ,LAST_UPD_PRCS_CD = 8000\r\n" + "      ,org_party_id_no = ?\r\n" + " WHERE prdcr_con_id_no = ?";

	private final static String SELECT_PRODUCER_AGREEMENT_UPDATE_DELETE_SQL = "SELECT\r\n"
			+ "      pc.PRDCR_CON_ID_NO\r\n" + "      ,pc.PRDCR_ID_NO\r\n" + "      ,pc.OFFICE_ID_NO\r\n"
			+ "      ,pc.PYRL_NO\r\n" + "      ,pc.AGENCY_CD\r\n" + "      ,pc.CON_CD\r\n"
			+ "      ,pc.CON_TYP_CD_NO\r\n" + "      ,pc.CCSTDT\r\n" + "      ,pc.CCSTOPDT\r\n"
			+ "      ,pc.AGOFFSTDT\r\n" + "      ,pc.PRIM_CON_IND\r\n" + "      ,pc.AGENT_TYP_KEY\r\n"
			+ "      ,pc.CREAT_DTM\r\n" + "      ,pc.CREAT_BY_NM\r\n" + "      ,pc.CREAT_BY_PRCS_CD\r\n"
			+ "      ,pc.LAST_UPD_DTM\r\n" + "      ,pc.LAST_UPD_BY_NM\r\n" + "      ,pc.LAST_UPD_PRCS_CD\r\n"
			+ "      ,pc.org_party_id_no\r\n" + "      ,firm.org_agency_cd\r\n" + "      ,firm.org_dtch_cd\r\n"
			+ "      ,firm.org_nm\r\n" + "  FROM TPRDCR_CON pc (NoLock)\r\n" + "  INNER JOIN TPARTY firm (NoLock)\r\n"
			+ "	On firm.party_id_no = pc.org_party_id_no  \r\n" + "  WHERE pc.PRDCR_CON_ID_NO = ? \r\n"
			+ "  ORDER BY pc.CREAT_DTM";

	private final static String DELETE_PRODUCER_AGREEMENT_SQL = "UPDATE tprdcr_con\r\n" + "set\r\n"
			+ "ccstopdt = ?,\r\n" + "last_upd_dtm = getdate(),\r\n" + "last_upd_by_nm = ?\r\n"
			+ "where prdcr_con_id_no = ?";

	private final JdbcTemplate jdbcTemplate;

	@Autowired
	public MaintainProducerAgreementDaoImpl(final JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	@PostConstruct
	public void init() {

		if (requestTimeoutLimit != 0) {
			this.jdbcTemplate.setQueryTimeout(requestTimeoutLimit);
		}
	}

	@Override
	// Cache Candidate
	public List<ContractTypeInfo> selectContractTypeInfo() {
		final RowMapper<ContractTypeInfo> rowMapper = new BeanPropertyRowMapper<>(ContractTypeInfo.class);
		return jdbcTemplate.query(SELECT_CONTRACT_TYPE_INFO_SQL, rowMapper);
	}

	@Override
	public List<TProducerInfo> selectProducerInfoCreate(final String partyIdNo) {
		final RowMapper<TProducerInfo> rowMapper = new BeanPropertyRowMapper<>(TProducerInfo.class);
		return jdbcTemplate.query(SELECT_PRODUCER_INFO_CREATE_SQL, new Object[] { partyIdNo }, rowMapper);
	}

	@Override
	public List<TProducerInfo> selectProducerInfoUpdate(final String partyIdNo) {
		final RowMapper<TProducerInfo> rowMapper = new BeanPropertyRowMapper<>(TProducerInfo.class);
		return jdbcTemplate.query(SELECT_PRODUCER_INFO_UPDATE_SQL, new Object[] { partyIdNo }, rowMapper);
	}

	@Override
	public List<TProducerInfo> selectProducerInfoDelete(final String partyIdNo) {
		final RowMapper<TProducerInfo> rowMapper = new BeanPropertyRowMapper<>(TProducerInfo.class);
		return jdbcTemplate.query(SELECT_PRODUCER_INFO_UPDATE_SQL, new Object[] { partyIdNo }, rowMapper);
	}

	@Override
	public Long selectFirmInfo(final String agencyCode, final String agencyDetachedCode) {
		Long result = null;
		final List<Long> results = jdbcTemplate.queryForList(SELECT_FIRM_INFO_SQL, Long.class,
				new Object[] { agencyCode, agencyDetachedCode });
		if (!results.isEmpty()) {
			result = results.get(0);
		}

		return result;
	}

	@Override
	public int insertProducerAgreement(final Long orgPartyIdNo,
			final CreateProducerAgreement.ProducerAgreement producerAgreement, final String user) {
		Long primConInd = null;
		if (producerAgreement.isProducerAgreementPrimaryIndicator()) {
			primConInd = Long.valueOf(1);
		} else {
			primConInd = Long.valueOf(0);
		}

		return jdbcTemplate.update(INSERT_PRODUCER_AGREEMENT_SQL, new Object[] {
				// prdcr_id_no
				producerAgreement.getProducerID(),
				// pyrl_no
				producerAgreement.getPayrollNo(),
				// agency_cd
				producerAgreement.getAgencyCode(),
				// con_cd
				producerAgreement.getProducerAgreementCode(),
				// con_typ_cd_no
				producerAgreement.getProducerAgreementType(),
				// ccstdt
				MaintainProducerAgreementUtils.convertXmlGregorianCalendarToTimestamp(producerAgreement.getEffDate()),
				// ccstopdt
				MaintainProducerAgreementUtils.convertXmlGregorianCalendarToTimestamp(producerAgreement.getEndDate()),
				// agoffstdt
				MaintainProducerAgreementUtils.convertXmlGregorianCalendarToTimestamp(
						producerAgreement.getProducerAgreementAgentOfficialStartDate()),
				// prim_con_ind
				primConInd,
				// agent_typ_key
				producerAgreement.getProducerAgreementDefinition(),
				// creat_by_nm
				user,
				// last_upd_by_nm
				user,
				// org_party_id_no
				orgPartyIdNo });
	}

	@Override
	public int updateProducerAgreement(final Long orgPartyIdNo,
			final UpdateProducerAgreement.ProducerAgreement producerAgreement, final String user) {

		Long primConInd = null;
		if (producerAgreement.isProducerAgreementPrimaryIndicator()) {
			primConInd = Long.valueOf(1);
		} else {
			primConInd = Long.valueOf(0);
		}

		Long prdcrConIdNo = null;
		if (!StringUtils.isEmpty(producerAgreement.getProducerAgreementID())) {
			prdcrConIdNo = Long.valueOf(producerAgreement.getProducerAgreementID());
		}

		return jdbcTemplate.update(UPDATE_PRODUCER_AGREEMENT_SQL, new Object[] {
				// prdcr_id_no
				producerAgreement.getProducerID(),
				// pyrl_no
				producerAgreement.getPayrollNo(),
				// agency_cd
				producerAgreement.getAgencyCode(),
				// con_cd
				producerAgreement.getProducerAgreementCode(),
				// con_typ_cd_no
				producerAgreement.getProducerAgreementType(),
				// ccstdt
				MaintainProducerAgreementUtils.convertXmlGregorianCalendarToTimestamp(producerAgreement.getEffDate()),
				// ccstopdt
				MaintainProducerAgreementUtils.convertXmlGregorianCalendarToTimestamp(producerAgreement.getEndDate()),
				// agoffstdt
				MaintainProducerAgreementUtils.convertXmlGregorianCalendarToTimestamp(
						producerAgreement.getProducerAgreementAgentOfficialStartDate()),
				// prim_con_ind
				primConInd,
				// agent_typ_key
				producerAgreement.getProducerAgreementDefinition(),
				// last_upd_by_nm
				user,
				// org_party_id_no
				orgPartyIdNo,
				// prdcr_con_id_no
				prdcrConIdNo });
	}

	@Override
	public int deleteProducerAgreement(final ProducerAgreement producerAgreement, final String user) {

		Long prdcrConIdNo = null;
		if (!StringUtils.isEmpty(producerAgreement.getProducerAgreementID())) {
			prdcrConIdNo = Long.valueOf(producerAgreement.getProducerAgreementID());
		}

		return jdbcTemplate.update(DELETE_PRODUCER_AGREEMENT_SQL, new Object[] {
				// ccstopdt
				MaintainProducerAgreementUtils.convertXmlGregorianCalendarToTimestamp(producerAgreement.getEndDate()),
				// last_upd_by_nm
				user,
				// prdcr_con_id_no
				prdcrConIdNo });
	}

	@Override
	public ProducerAgreementResult selectProducerAgreementAfterCreate(final String user, final String producerIdNo) {

		ProducerAgreementResult result = null;

		final RowMapper<ProducerAgreementResult> rowMapper = new BeanPropertyRowMapper<>(ProducerAgreementResult.class);
		final List<ProducerAgreementResult> results = jdbcTemplate.query(SELECT_PRODUCER_INFO_AFTER_CREATE_SQL,
				new Object[] { user, producerIdNo }, rowMapper);
		if (!results.isEmpty()) {
			result = results.get(0);
		}

		return result;
	}

	@Override
	public List<ProducerAgreementResult> selectProducerAgreementRead(final String partyIdNo,
			final String producerConIdNo) {
		String producerConIdNoArg = producerConIdNo;
		if (StringUtils.isEmpty(producerConIdNoArg)) {
			producerConIdNoArg = null;
		}
		final RowMapper<ProducerAgreementResult> rowMapper = new BeanPropertyRowMapper<>(ProducerAgreementResult.class);
		return jdbcTemplate.query(SELECT_PRODUCER_AGREEMENT_READ_SQL, new Object[] { partyIdNo, producerConIdNoArg },
				rowMapper);
	}

	@Override
	public List<ProducerAgreementResult> selectProducerAgreementAfterUpdateDelete(final String producerConIdNo) {
		String producerConIdNoArg = producerConIdNo;
		if (StringUtils.isEmpty(producerConIdNoArg)) {
			producerConIdNoArg = null;
		}
		final RowMapper<ProducerAgreementResult> rowMapper = new BeanPropertyRowMapper<>(ProducerAgreementResult.class);
		return jdbcTemplate.query(SELECT_PRODUCER_AGREEMENT_UPDATE_DELETE_SQL, new Object[] { producerConIdNoArg },
				rowMapper);
	}

}
