package com.jh.life.authentication.controller;

import com.jh.life.authentication.model.AuthenticationRequestWrapper;
import com.jh.life.authentication.model.AuthenticationResponseWrapper;
import com.jh.life.authentication.orchestration.LifeAuthOrchestration;
import com.jh.life.authentication.utils.JHHeaderUtils;
import com.jh.life.authentication.utils.LoggerUtils;
import com.manulife.esb.xsd.checkdisbursementsystem.jh.authentication.AuthenticationRequest;
import com.manulife.esb.xsd.checkdisbursementsystem.jh.authentication.AuthenticationResponse;
import com.manulife.esb.xsd.common.jh.header.JHHeader;
import com.manulife.esb.xsd.common.jh.header.MessageSource;
import com.manulife.esb.xsd.common.jh.header.ServiceInfo;
import com.manulife.esb.xsd.common.jh.header.Status;
import org.codehaus.jackson.map.ObjectMapper;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;

import static org.mockito.Matchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

/**
 * The type Authentication controller test.
 */
@RunWith(SpringRunner.class)
@WebMvcTest(AuthenticationController.class)
public class AuthenticationControllerTest {

    /**
     * Initializing MockMvc
     */
    @Autowired
    private MockMvc mvc;

    /**
     * The Life auth orchestration.
     */
    @MockBean
    LifeAuthOrchestration lifeAuthOrchestration;

    /**
     * The Logger utils.
     */
    @MockBean
    LoggerUtils loggerUtils;

    /**
     * The Header utils.
     */
    @MockBean
    JHHeaderUtils headerUtils;

    /**
     * The Authentication response wrapper.
     */
    AuthenticationResponseWrapper authenticationResponseWrapper = null;
    /**
     * The Authentication request wrapper.
     */
    AuthenticationRequestWrapper authenticationRequestWrapper = null;
    /**
     * The Header.
     */
    JHHeader header = null;
    /**
     * The Authentication request.
     */
    AuthenticationRequest authenticationRequest = null;
    /**
     * The Authentication response.
     */
    AuthenticationResponse authenticationResponse = null;

    /**
     * Sets up.
     *
     * @throws Exception the exception
     */
    @Before
    public void setUp() throws Exception {
        authenticationResponseWrapper = new AuthenticationResponseWrapper();
        authenticationRequestWrapper = new AuthenticationRequestWrapper();
        authenticationRequest = new AuthenticationRequest();
        authenticationRequest.setUserId("svcconecasemgmtdev");
        authenticationRequest.setPassword("8U%-5x4!w");
        MessageSource messageSource = new MessageSource();
        ServiceInfo serviceInfo = new ServiceInfo();
        authenticationResponse = new AuthenticationResponse();
        header = new JHHeader();

        header.setMessageUID("AAAA");
        messageSource.setUserID("CallidusCloud");
        messageSource.setApplicationName("575812");
        messageSource.setApplicationUserID("CallidusCloud");
        messageSource.setHostName("174.129.237.57");
        messageSource.setProcessID("1");

        serviceInfo.setServiceName("Producer");
        serviceInfo.setServiceOperation("CheckLicenseStatus");
        serviceInfo.setServiceVersion("1.0");
        header.setMessageSource(messageSource);
        header.setServiceInfo(serviceInfo);
        authenticationRequestWrapper.setHeader(header);
        authenticationRequestWrapper.setAuthenticationRequest(authenticationRequest);

        AuthenticationResponse.Result result = new AuthenticationResponse.Result();
        Status status = new Status();
        AuthenticationResponse.Result.Success success = new AuthenticationResponse.Result.Success();
        success.setLastName("Alex");
        success.setFirstName("Cruz");
        success.setCode("0");

        status.setStatusCode(0);
        status.setStatusDescription("User details found");
        header.setStatus(status);

        result.setSuccess(success);
        authenticationResponse.setResult(result);
        authenticationResponseWrapper.setHeader(header);
        authenticationResponseWrapper.setAuthenticationResponse(authenticationResponse);
    }

    /**
     * Gets user details.
     *
     * @throws Exception the exception
     */
    @Test
    public void getUserDetails() throws Exception {

        when(lifeAuthOrchestration.passwordAuthn(any(JHHeader.class), any(AuthenticationRequest.class))).thenReturn(authenticationResponseWrapper);
        mvc.perform(post("/jh/ins/security/globalAD/usr/pwd/auth")
                .content(asJsonString(authenticationRequestWrapper))
                .accept(MediaType.APPLICATION_JSON_VALUE)
                .contentType(MediaType.APPLICATION_JSON_VALUE)).andDo(print())
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.authenticationResponse.result.success.firstName").value("Cruz"))
                .andExpect(jsonPath("$.authenticationResponse.result.success.lastName").value("Alex"))
                .andExpect(jsonPath("$.authenticationResponse.result.success.code").value("0"));
    }

    @Test
    public void vallidateHeader() throws Exception {

        when(lifeAuthOrchestration.passwordAuthn(any(JHHeader.class), any(AuthenticationRequest.class))).thenReturn(authenticationResponseWrapper);
        mvc.perform(post("/jh/ins/security/globalAD/usr/pwd/auth")
                .content(asJsonString(authenticationRequestWrapper))
                .accept(MediaType.APPLICATION_JSON_VALUE)
                .contentType(MediaType.APPLICATION_JSON_VALUE)).andDo(print())
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.header.status.statusCode").value(0))
                .andExpect(jsonPath("$.header.status.statusDescription").value("User details found"));
    }

    /**
     * As json string string.
     *
     * @param obj the obj
     *
     * @return the string
     */
    /*
     * converts a Java object into JSON representation
     */
    public static String asJsonString(final Object obj) {
        try {
            String returnStr = new ObjectMapper().writeValueAsString(obj);
            return returnStr;

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}