package com.jh.life.authentication.orchestration;

import com.jh.life.authentication.model.AuthenticationRequestWrapper;
import com.jh.life.authentication.model.AuthenticationResponseWrapper;
import com.jh.life.authentication.service.AuthenticationService;
import com.jh.life.authentication.utils.LoggerUtils;
import com.manulife.esb.xsd.checkdisbursementsystem.jh.authentication.AuthenticationRequest;
import com.manulife.esb.xsd.checkdisbursementsystem.jh.authentication.AuthenticationResponse;
import com.manulife.esb.xsd.common.jh.header.JHHeader;
import com.manulife.esb.xsd.common.jh.header.MessageSource;
import com.manulife.esb.xsd.common.jh.header.ServiceInfo;
import com.manulife.esb.xsd.common.jh.header.Status;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.test.context.junit4.SpringRunner;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

@RunWith(SpringRunner.class)
public class LifeAuthOrchestrationTest {


    @Mock
    AuthenticationService authenticationService;

    @InjectMocks
    LifeAuthOrchestration lifeAuthOrchestration;

    @Mock
    private LoggerUtils loggerUtils;


    /**
     * The Authentication response wrapper.
     */
    AuthenticationResponseWrapper authenticationResponseWrapper = null;
    /**
     * The Authentication request wrapper.
     */
    AuthenticationRequestWrapper authenticationRequestWrapper = null;
    /**
     * The Header.
     */
    JHHeader header = null;
    /**
     * The Authentication request.
     */
    AuthenticationRequest authenticationRequest = null;
    /**
     * The Authentication response.
     */
    AuthenticationResponse authenticationResponse = null;

    /**
     * Sets up.
     *
     * @throws Exception the exception
     */
    @Before
    public void setUp() throws Exception {
        authenticationResponseWrapper = new AuthenticationResponseWrapper();
        authenticationRequestWrapper = new AuthenticationRequestWrapper();
        authenticationRequest = new AuthenticationRequest();
        authenticationRequest.setUserId("svcconecasemgmtdev");
        authenticationRequest.setPassword("8U%-5x4!w");
        MessageSource messageSource = new MessageSource();
        ServiceInfo serviceInfo = new ServiceInfo();
        authenticationResponse = new AuthenticationResponse();
        header = new JHHeader();

        header.setMessageUID("AAAA");
        messageSource.setUserID("CallidusCloud");
        messageSource.setApplicationName("575812");
        messageSource.setApplicationUserID("CallidusCloud");
        messageSource.setHostName("174.129.237.57");
        messageSource.setProcessID("1");

        serviceInfo.setServiceName("Producer");
        serviceInfo.setServiceOperation("CheckLicenseStatus");
        serviceInfo.setServiceVersion("1.0");
        header.setMessageSource(messageSource);
        header.setServiceInfo(serviceInfo);
        authenticationRequestWrapper.setHeader(header);
        authenticationRequestWrapper.setAuthenticationRequest(authenticationRequest);

        AuthenticationResponse.Result result = new AuthenticationResponse.Result();
        Status status = new Status();
        AuthenticationResponse.Result.Success success = new AuthenticationResponse.Result.Success();
        success.setLastName("Alex");
        success.setFirstName("Cruz");
        success.setCode("0");

        status.setStatusCode(0);
        status.setStatusDescription("User details found");
        header.setStatus(status);

        result.setSuccess(success);
        authenticationResponse.setResult(result);
        authenticationResponseWrapper.setHeader(header);
        authenticationResponseWrapper.setAuthenticationResponse(authenticationResponse);
    }

    @Test
    public void passwordAuthnCode() throws Exception {
        when(authenticationService.SendResponseMessage(authenticationRequest, header)).thenReturn(authenticationResponseWrapper);
        assertEquals("0", lifeAuthOrchestration.passwordAuthn(header,authenticationRequest).getAuthenticationResponse().getResult().getSuccess().getCode() );
    }

    @Test
    public void passwordAuthnFirstName() throws Exception {
        when(authenticationService.SendResponseMessage(authenticationRequest, header)).thenReturn(authenticationResponseWrapper);
        assertEquals("Cruz", lifeAuthOrchestration.passwordAuthn(header,authenticationRequest).getAuthenticationResponse().getResult().getSuccess().getFirstName() );
    }

    @Test
    public void passwordAuthnLastName() throws Exception {
        when(authenticationService.SendResponseMessage(authenticationRequest, header)).thenReturn(authenticationResponseWrapper);
        assertEquals("Alex", lifeAuthOrchestration.passwordAuthn(header,authenticationRequest).getAuthenticationResponse().getResult().getSuccess().getLastName() );
    }


    @Test
    public void validateHeaderStatusCode() throws Exception {
        when(authenticationService.SendResponseMessage(authenticationRequest, header)).thenReturn(authenticationResponseWrapper);
        assertEquals(0, lifeAuthOrchestration.passwordAuthn(header,authenticationRequest).getHeader().getStatus().getStatusCode() );
    }

    @Test
    public void validateHeaderStatusDesc() throws Exception {
        when(authenticationService.SendResponseMessage(authenticationRequest, header)).thenReturn(authenticationResponseWrapper);
        assertEquals("User details found", lifeAuthOrchestration.passwordAuthn(header,authenticationRequest).getHeader().getStatus().getStatusDescription() );
    }

}