package com.jh.life;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


/**
 * The type Life user auth application.
 */
@SpringBootApplication
public class LifeUserAuthApplication {

    /**
     * The entry point of application.
     *
     * @param args the input arguments
     */
    public static void main(String[] args) {

        SpringApplication.run(LifeUserAuthApplication.class, args);
    }
}
