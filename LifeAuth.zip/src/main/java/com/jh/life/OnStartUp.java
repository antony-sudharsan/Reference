package com.jh.life;


import com.jh.common.logging.LoggerHandler;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.io.IOException;


/**
 * The type On start up.
 */
@Component
public class OnStartUp {

    @Autowired
    private Environment env;


    /**
     * Init.
     *
     * @throws IOException the io exception
     */
    @PostConstruct
    public void init() throws IOException {

        try {
            LoggerHandler.getInstance(env.getProperty("log.appID"), env.getProperty("log.svcName"), env.getProperty("log.componentName"), env.getProperty("log.svcVersion"));
        }catch (Exception e){
            e.printStackTrace();
            throw e;
        }




    }

}
