package com.jh.life.authentication.service;

import com.jh.common.logging.LoggerHandler;
import org.springframework.stereotype.Component;

import javax.naming.AuthenticationException;
import javax.naming.Context;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.DirContext;
import javax.naming.directory.InitialDirContext;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;

/**
 * The type Password authn search user dn.
 */
@Component
public class PasswordAuthnSearchUserDn {
    /****** START SET/GET METHOD, DO NOT MODIFY */
    protected String InitialContextFactory = "";
    /**
     * The Provider url.
     */
    protected String ProviderURL = "";
    /**
     * The Security authentication.
     */
    protected String SecurityAuthentication = "";
    /**
     * The Security principal.
     */
    protected String SecurityPrincipal = "";
    /**
     * The Security credential.
     */
    protected String SecurityCredential = "";
    /**
     * The Ldap base name.
     */
    protected String LdapBaseName = "";
    /**
     * The User id.
     */
    protected String UserID = "";
    /**
     * The Success code.
     */
    protected String SuccessCode = "";
    /**
     * The Application error code.
     */
    protected String ApplicationErrorCode = "";
    /**
     * The Technical error code.
     */
    protected String TechnicalErrorCode = "";
    /**
     * The Status code.
     */
    protected String StatusCode = "";
    /**
     * The Status description.
     */
    protected String StatusDescription = "";
    /**
     * The Full user dn.
     */
    protected String FullUserDN = "";
    /**
     * The Msg payload.
     */
    protected String msgPayload;
    /**
     * The User det.
     */
    List<String> userDet = new ArrayList<String>();

    /**
     * Gets initial context factory.
     *
     * @return the initial context factory
     */
    public String getInitialContextFactory() {
        return InitialContextFactory;
    }

    /**
     * Sets initial context factory.
     *
     * @param val the val
     */
    public void setInitialContextFactory(String val) {
        InitialContextFactory = val;
    }

    /**
     * Gets provider url.
     *
     * @return the provider url
     */
    public String getProviderURL() {
        return ProviderURL;
    }

    /**
     * Sets provider url.
     *
     * @param val the val
     */
    public void setProviderURL(String val) {
        ProviderURL = val;
    }

    /**
     * Gets security authentication.
     *
     * @return the security authentication
     */
    public String getSecurityAuthentication() {
        return SecurityAuthentication;
    }

    /**
     * Sets security authentication.
     *
     * @param val the val
     */
    public void setSecurityAuthentication(String val) {
        SecurityAuthentication = val;
    }

    /**
     * Gets security principal.
     *
     * @return the security principal
     */
    public String getSecurityPrincipal() {
        return SecurityPrincipal;
    }

    /**
     * Sets security principal.
     *
     * @param val the val
     */
    public void setSecurityPrincipal(String val) {
        SecurityPrincipal = val;
    }

    /**
     * Gets security credential.
     *
     * @return the security credential
     */
    public String getSecurityCredential() {
        return SecurityCredential;
    }

    /**
     * Sets security credential.
     *
     * @param val the val
     */
    public void setSecurityCredential(String val) {
        SecurityCredential = val;
    }

    /**
     * Gets ldap base name.
     *
     * @return the ldap base name
     */
    public String getLdapBaseName() {
        return LdapBaseName;
    }

    /**
     * Sets ldap base name.
     *
     * @param val the val
     */
    public void setLdapBaseName(String val) {
        LdapBaseName = val;
    }

    /**
     * Gets user id.
     *
     * @return the user id
     */
    public String getUserID() {
        return UserID;
    }

    /**
     * Sets user id.
     *
     * @param val the val
     */
    public void setUserID(String val) {
        UserID = val;
    }

    /**
     * Gets success code.
     *
     * @return the success code
     */
    public String getSuccessCode() {
        return SuccessCode;
    }

    /**
     * Sets success code.
     *
     * @param val the val
     */
    public void setSuccessCode(String val) {
        SuccessCode = val;
    }

    /**
     * Gets application error code.
     *
     * @return the application error code
     */
    public String getApplicationErrorCode() {
        return ApplicationErrorCode;
    }

    /**
     * Sets application error code.
     *
     * @param val the val
     */
    public void setApplicationErrorCode(String val) {
        ApplicationErrorCode = val;
    }

    /**
     * Gets technical error code.
     *
     * @return the technical error code
     */
    public String getTechnicalErrorCode() {
        return TechnicalErrorCode;
    }

    /**
     * Sets technical error code.
     *
     * @param val the val
     */
    public void setTechnicalErrorCode(String val) {
        TechnicalErrorCode = val;
    }

    /**
     * Gets status code.
     *
     * @return the status code
     */
    public String getStatusCode() {
        return StatusCode;
    }

    /**
     * Sets status code.
     *
     * @param val the val
     */
    public void setStatusCode(String val) {
        StatusCode = val;
    }

    /**
     * Gets status description.
     *
     * @return the status description
     */
    public String getStatusDescription() {
        return StatusDescription;
    }

    /**
     * Sets status description.
     *
     * @param val the val
     */
    public void setStatusDescription(String val) {
        StatusDescription = val;
    }

    /**
     * Gets full user dn.
     *
     * @return the full user dn
     */
    public String getFullUserDN() {
        return FullUserDN;
    }

    /**
     * Sets full user dn.
     *
     * @param val the val
     */
    public void setFullUserDN(String val) {
        FullUserDN = val;
    }

    /****** END SET/GET METHOD, DO NOT MODIFY  @param transactionId the transaction id
     * @param sourceSystemName the source system name
     * @return the list
     * @throws Exception the exception
     */
    public List<String> invoke(String transactionId, String sourceSystemName) throws Exception {
/* Available Variables: DO NOT MODIFY
	In  : String InitialContextFactory
	In  : String ProviderURL
	In  : String SecurityAuthentication
	In  : String SecurityPrincipal
	In  : String SecurityCredential
	In  : String LdapBaseName
	In  : String UserID
	In  : String SuccessCode
	In  : String ApplicationErrorCode
	In  : String TechnicalErrorCode
	Out : String StatusCode
	Out : String StatusDescription
	Out : String FullUserDN
* Available Variables: DO NOT MODIFY *****/

        String base = getLdapBaseName();

        Hashtable<String, String> env = new Hashtable<String, String>(11);
        env.put(Context.INITIAL_CONTEXT_FACTORY, InitialContextFactory);
        env.put(Context.PROVIDER_URL, ProviderURL);
        env.put(Context.SECURITY_AUTHENTICATION, SecurityAuthentication);
        env.put(Context.SECURITY_PRINCIPAL, SecurityPrincipal);
        env.put(Context.SECURITY_CREDENTIALS, SecurityCredential);
        try {
            DirContext ctx = new InitialDirContext(env);
            SearchControls searchCtrls = new SearchControls();
            searchCtrls.setReturningAttributes(new String[]{});
            searchCtrls.setSearchScope(SearchControls.SUBTREE_SCOPE);
            String filter = ("sAMAccountName" + "=" + UserID);
            NamingEnumeration<SearchResult> answer = ctx.search(LdapBaseName, filter, searchCtrls);
            String fullDN = null;

            if (answer.hasMore()) {
                fullDN = answer.next().getNameInNamespace();
                FullUserDN = fullDN;
                StatusCode = SuccessCode;
                StatusDescription = "Valid User";

            } else if (fullDN == null) {
                StatusCode = ApplicationErrorCode;
                StatusDescription = "No UserDN found for the requested UserID";
            }

            ctx.close();
            ///////******* LOGGING ********** FINAL RESPONSE///////////
            msgPayload = "fullDN " + fullDN + "StatusCode " + StatusCode;
            LoggerHandler.LogOut("INFO", "4", transactionId, sourceSystemName, this.getClass().getName(), msgPayload);
            ///////******* LOGGING **********///////////

        } catch (AuthenticationException ex) {
            // Authentication failed
            StatusCode = ApplicationErrorCode;
            //		StatusDescription="Error in Binding with Proxy User";
            StatusDescription = ex.getMessage();
            ///////******* EXCEPTION HANDLING*******////
            LoggerHandler.ErrorOut(ex, transactionId, sourceSystemName, "AuthenticationController", msgPayload);
        } catch (NamingException ex) {
            StatusCode = ApplicationErrorCode;
            StatusDescription = ex.getMessage();
            ///////******* EXCEPTION HANDLING*******////
            LoggerHandler.ErrorOut(ex, transactionId, sourceSystemName, "AuthenticationController", msgPayload);
        } catch (Exception ex) {
            StatusCode = TechnicalErrorCode;
            StatusDescription = ex.getMessage();
            ///////******* EXCEPTION HANDLING*******////
            LoggerHandler.ErrorOut(ex, transactionId, sourceSystemName, "AuthenticationController", msgPayload);
        }

        userDet.add(StatusDescription);
        userDet.add(FullUserDN);
        return userDet;


    }


}

