package com.jh.life.authentication.orchestration;

import com.jh.common.logging.LoggerHandler;
import com.jh.life.authentication.model.AuthenticationResponseWrapper;
import com.jh.life.authentication.service.AuthenticationService;
import com.jh.life.authentication.utils.LoggerUtils;
import com.jh.life.authentication.utils.LoggingContextHolder;
import com.manulife.esb.xsd.checkdisbursementsystem.jh.authentication.AuthenticationRequest;
import com.manulife.esb.xsd.common.jh.header.JHHeader;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * The type Life auth orchestration.
 */
@Component
public class LifeAuthOrchestration {


    @Autowired
    private LoggerUtils loggerUtils;

    /**
     * The Authentication service.
     */
    @Autowired
    AuthenticationService authenticationService;

    /**
     * Password authn authentication response wrapper.
     *
     * @param header  the header
     * @param request the request
     *
     * @return the authentication response wrapper
     *
     * @throws Exception the exception
     */
    public AuthenticationResponseWrapper passwordAuthn(JHHeader header, AuthenticationRequest request) throws Exception {
        AuthenticationResponseWrapper authenticationResponseWrapper = new AuthenticationResponseWrapper();

        final String messageUUID = LoggingContextHolder.getLoggingContext().getMessageUUID();
        final String sourceSystemName = LoggingContextHolder.getLoggingContext().getSourceSystemName();
        LoggerHandler.LogOut("INFO", "2", messageUUID, sourceSystemName, this.getClass().getName(),
                "Entering passwordAuthn " + loggerUtils.writeAsJson(request));


        authenticationResponseWrapper = authenticationService.SendResponseMessage(request,header);

        LoggerHandler.LogOut("INFO", "5", messageUUID, sourceSystemName, this.getClass().getName(),
                "After passwordAuthn " + loggerUtils.writeAsJson(authenticationResponseWrapper));

        return authenticationResponseWrapper;
    }
}
