package com.jh.life.authentication.constants;

public class LifeAuthConstants {

    public static String SUCCESS_MSG =  "User details found";

    public static String NOT_FOUND_MSG = "No UserDN found for the requested UserID";

    public static String RESPONSE = "Response";
    public static String VALID_USER = "Valid User";


    public LifeAuthConstants() {
    }
}
