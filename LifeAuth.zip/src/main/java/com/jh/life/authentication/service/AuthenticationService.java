package com.jh.life.authentication.service;

import com.jh.common.logging.LoggerHandler;
import com.jh.life.authentication.config.LDAPConfigurationProp;
import com.jh.life.authentication.constants.LifeAuthConstants;
import com.jh.life.authentication.model.AuthenticationResponseWrapper;
import com.jh.life.authentication.utils.LoggerUtils;
import com.jh.life.authentication.utils.LoggingContextHolder;
import com.manulife.esb.xsd.checkdisbursementsystem.jh.authentication.AuthenticationRequest;
import com.manulife.esb.xsd.checkdisbursementsystem.jh.authentication.AuthenticationResponse;
import com.manulife.esb.xsd.checkdisbursementsystem.jh.authentication.SendAuthenticationResponse;
import com.manulife.esb.xsd.common.jh.header.JHHeader;
import com.manulife.esb.xsd.common.jh.header.Status;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;



/**
 * The type Authentication service.
 */
@Service
public class AuthenticationService {

    @Autowired
    private LoggerUtils loggerUtils;


    private String fullUserDn = null;
    /**
     * The Ldap prop.
     */
    @Autowired
    LDAPConfigurationProp ldapProp;
    /**
     * The Passwd auth.
     */
    @Autowired
    PasswordAuthnSearchUserDn passwdAuth;
    /**
     * The Passwd rtrv det.
     */
    @Autowired
    PasswordAuthnRetrieveUserDetails passwdRtrvDet;

    /**
     * The Send response.
     */
    SendAuthenticationResponse sendResponse = new SendAuthenticationResponse();

    /**
     * The Retrv user det.
     */
    List<String> retrvUserDet = new ArrayList<String>();

    /**
     * Get request mesage list.
     *
     * @param globalADPwdAuthRequet the global ad pwd auth requet
     * @param transactionId         the transaction id
     * @param sourceSystemName      the source system name
     *
     * @return the list
     *
     * @throws Exception the exception
     */
    public List<String> GetRequestMesage(AuthenticationRequest globalADPwdAuthRequet, String transactionId, String sourceSystemName) throws Exception {

        List<String> userDet = new ArrayList<String>();

        passwdAuth.setInitialContextFactory(ldapProp.getInitialContextFactory());
        passwdAuth.setProviderURL(ldapProp.getProviderUrl());
        passwdAuth.setSecurityAuthentication(ldapProp.getSecurityAuth());
        passwdAuth.setSecurityPrincipal(ldapProp.getSecurityPrincipal());
        passwdAuth.setSecurityCredential(ldapProp.getSecurityCredentials());
        passwdAuth.setLdapBaseName(ldapProp.getBaseDN());
        passwdAuth.setUserID(globalADPwdAuthRequet.getUserId());
        passwdAuth.setSuccessCode(ldapProp.getSuccessCode());
        passwdAuth.setApplicationErrorCode(ldapProp.getApplicationErrorCode());
        passwdAuth.setTechnicalErrorCode(ldapProp.getTechnicalErrorCode());

        LoggerHandler.LogOut("INFO", "3a", transactionId, sourceSystemName, this.getClass().getName(), passwdAuth.toString());
        userDet = passwdAuth.invoke(transactionId, sourceSystemName);

        return userDet;

    }

    /**
     * Send response message authentication response wrapper.
     *
     * @param globalADPwdAuthRequet the global ad pwd auth requet
     * @param header                the header
     *
     * @return the authentication response wrapper
     *
     * @throws Exception the exception
     */
    public AuthenticationResponseWrapper SendResponseMessage(AuthenticationRequest globalADPwdAuthRequet,JHHeader header ) throws Exception {

        final String transactionId = LoggingContextHolder.getLoggingContext().getMessageUUID();
        final String sourceSystemName = LoggingContextHolder.getLoggingContext().getSourceSystemName();
        LoggerHandler.LogOut("INFO", "3", transactionId, sourceSystemName, this.getClass().getName(),
                "Entering SendResponseMessage   " + loggerUtils.writeAsJson(globalADPwdAuthRequet));

        AuthenticationResponseWrapper authenticationResponseWrapper = new AuthenticationResponseWrapper();
        AuthenticationResponse   authenticationResponse = new AuthenticationResponse();
        AuthenticationResponse.Result result = new AuthenticationResponse.Result();
        Status status = new Status();

        // Invoking LDAP
        List<String> userDet  = GetRequestMesage(globalADPwdAuthRequet, transactionId, sourceSystemName);

        passwdRtrvDet.setInitialContextFactory(ldapProp.getInitialContextFactory());
        passwdRtrvDet.setProviderURL(ldapProp.getProviderUrl());
        passwdRtrvDet.setSecurityAuthentication(ldapProp.getSecurityAuth());

        LoggerHandler.LogOut("INFO", "3", transactionId, sourceSystemName, this.getClass().getName(), passwdAuth.toString());

        passwdRtrvDet.setSecurityCredential(globalADPwdAuthRequet.getPassword());

        passwdRtrvDet.setLdapUserDN(userDet.get(1));
        passwdRtrvDet.setUserID(globalADPwdAuthRequet.getUserId());
        passwdRtrvDet.setApplicationErrorCode(ldapProp.getApplicationErrorCode());
        passwdRtrvDet.setTechnicalErrorCode(ldapProp.getTechnicalErrorCode());
        passwdRtrvDet.setSuccessCode(ldapProp.getSuccessCode());

        // Invoking LDAP
        retrvUserDet = passwdRtrvDet.invoke(transactionId, sourceSystemName);

       /* System.out.println("The value of the user details >>>>>"+userDet.get(0));
        System.out.println("The value of the passwdRtrvDet.getStatusCode() >>>>>>"+passwdRtrvDet.getStatusCode());
        System.out.println("The value of the passwdRtrvDet. statuc desc() >>>>>>"+passwdRtrvDet.getStatusDescription());*/

            if (userDet.get(0) == LifeAuthConstants.VALID_USER) {
                if(passwdRtrvDet.getStatusCode().equals("1") || passwdRtrvDet.getStatusCode().equals("2") ){

                    AuthenticationResponse.Result.Failure failure = new AuthenticationResponse.Result.Failure();
                    failure.setCode(ldapProp.getApplicationErrorCode());
                    status.setStatusCode(1);
                    status.setStatusDescription(passwdRtrvDet.getStatusDescription());
                    header.setStatus(status);
                    header.setMessageType(LifeAuthConstants.RESPONSE);

                    result.setFailure(failure);
                }else {

                    AuthenticationResponse.Result.Success success = new AuthenticationResponse.Result.Success();
                    success.setFirstName(retrvUserDet.get(0));
                    success.setLastName(retrvUserDet.get(1));
                    success.setCode(retrvUserDet.get(2));

                    status.setStatusCode(0);
                    status.setStatusDescription(LifeAuthConstants.SUCCESS_MSG);
                    header.setStatus(status);
                    header.setMessageType(LifeAuthConstants.RESPONSE);
                    result.setSuccess(success);
                }
            } else {
                AuthenticationResponse.Result.Failure failure = new AuthenticationResponse.Result.Failure();
                failure.setCode(ldapProp.getApplicationErrorCode());
                status.setStatusCode(1);
                status.setStatusDescription(LifeAuthConstants.NOT_FOUND_MSG);
                header.setStatus(status);
                header.setMessageType(LifeAuthConstants.RESPONSE);

                result.setFailure(failure);

            }
        authenticationResponse.setResult(result);
        authenticationResponseWrapper.setHeader(header);
        authenticationResponseWrapper.setAuthenticationResponse(authenticationResponse);
        userDet.clear();
        retrvUserDet.clear();

        LoggerHandler.LogOut("INFO", "4", transactionId, sourceSystemName, this.getClass().getName(),
                "Exiting SendResponseMessage " + loggerUtils.writeAsJson(authenticationResponseWrapper));

        return authenticationResponseWrapper;
    }


}
