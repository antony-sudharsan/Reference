package com.jh.life.authentication.model;

import com.manulife.esb.xsd.checkdisbursementsystem.jh.authentication.AuthenticationRequest;
import com.manulife.esb.xsd.common.jh.header.JHHeader;

public class AuthenticationRequestWrapper {
    private JHHeader header;

    private AuthenticationRequest authenticationRequest;

    public JHHeader getHeader() {
        return header;
    }

    public void setHeader(JHHeader header) {
        this.header = header;
    }

    public AuthenticationRequest getAuthenticationRequest() {
        return authenticationRequest;
    }

    public void setAuthenticationRequest(AuthenticationRequest authenticationRequest) {
        this.authenticationRequest = authenticationRequest;
    }
}
