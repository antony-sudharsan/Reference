package com.jh.life.authentication.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;


@ResponseStatus(HttpStatus.NOT_FOUND)
public class NotFoundException  extends BaseFaultException {
	/**
	 *
	 */
	private static final long serialVersionUID = 1L;
	private static final String DEFAULT_CODE = "99999";
	private static final String DEFAULT_REASON = "Service Timed Out";
	private static final String DEFAULT_DETAILS = "Service Timed Out";
	private static final String FAULT_STRING = "Internal Error";

	public NotFoundException() {
		super(DEFAULT_CODE, DEFAULT_REASON, DEFAULT_DETAILS, FAULT_STRING);
	}

}


