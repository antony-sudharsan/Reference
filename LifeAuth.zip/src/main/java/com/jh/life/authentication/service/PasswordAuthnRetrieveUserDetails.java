package com.jh.life.authentication.service;

import com.jh.common.logging.LoggerHandler;
import org.springframework.stereotype.Component;

import javax.naming.AuthenticationException;
import javax.naming.Context;
import javax.naming.NamingException;
import javax.naming.directory.Attributes;
import javax.naming.directory.DirContext;
import javax.naming.directory.InitialDirContext;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;

/**
 * The type Password authn retrieve user details.
 */
@Component
public class PasswordAuthnRetrieveUserDetails {

    /****** START SET/GET METHOD, DO NOT MODIFY */
    protected String InitialContextFactory = "";
    /**
     * The Provider url.
     */
    protected String ProviderURL = "";
    /**
     * The Security authentication.
     */
    protected String SecurityAuthentication = "";
    /**
     * The Security credential.
     */
    protected String SecurityCredential = "";
    /**
     * The Ldap user dn.
     */
    protected String LdapUserDN = "";
    /**
     * The User id.
     */
    protected String UserID = "";
    /**
     * The Application error code.
     */
    protected String ApplicationErrorCode = "";
    /**
     * The Technical error code.
     */
    protected String TechnicalErrorCode = "";
    /**
     * The Success code.
     */
    protected String SuccessCode = "";
    /**
     * The First name.
     */
    protected String FirstName = "";
    /**
     * The Last name.
     */
    protected String LastName = "";
    /**
     * The Status code.
     */
    protected String StatusCode = "";
    /**
     * The Status description.
     */
    protected String StatusDescription = "";
    /**
     * The Msg payload.
     */
    protected String msgPayload;
    /**
     * The Retrv user det.
     */
    List<String> retrvUserDet = new ArrayList<String>();

    /**
     * Gets initial context factory.
     *
     * @return the initial context factory
     */
    public String getInitialContextFactory() {
        return InitialContextFactory;
    }

    /**
     * Sets initial context factory.
     *
     * @param val the val
     */
    public void setInitialContextFactory(String val) {
        InitialContextFactory = val;
    }

    /**
     * Gets provider url.
     *
     * @return the provider url
     */
    public String getProviderURL() {
        return ProviderURL;
    }

    /**
     * Sets provider url.
     *
     * @param val the val
     */
    public void setProviderURL(String val) {
        ProviderURL = val;
    }

    /**
     * Gets security authentication.
     *
     * @return the security authentication
     */
    public String getSecurityAuthentication() {
        return SecurityAuthentication;
    }

    /**
     * Sets security authentication.
     *
     * @param val the val
     */
    public void setSecurityAuthentication(String val) {
        SecurityAuthentication = val;
    }

    /**
     * Gets security credential.
     *
     * @return the security credential
     */
    public String getSecurityCredential() {
        return SecurityCredential;
    }

    /**
     * Sets security credential.
     *
     * @param val the val
     */
    public void setSecurityCredential(String val) {
        SecurityCredential = val;
    }

    /**
     * Gets ldap user dn.
     *
     * @return the ldap user dn
     */
    public String getLdapUserDN() {
        return LdapUserDN;
    }

    /**
     * Sets ldap user dn.
     *
     * @param val the val
     */
    public void setLdapUserDN(String val) {
        LdapUserDN = val;
    }

    /**
     * Gets user id.
     *
     * @return the user id
     */
    public String getUserID() {
        return UserID;
    }

    /**
     * Sets user id.
     *
     * @param val the val
     */
    public void setUserID(String val) {
        UserID = val;
    }

    /**
     * Gets application error code.
     *
     * @return the application error code
     */
    public String getApplicationErrorCode() {
        return ApplicationErrorCode;
    }

    /**
     * Sets application error code.
     *
     * @param val the val
     */
    public void setApplicationErrorCode(String val) {
        ApplicationErrorCode = val;
    }

    /**
     * Gets technical error code.
     *
     * @return the technical error code
     */
    public String getTechnicalErrorCode() {
        return TechnicalErrorCode;
    }

    /**
     * Sets technical error code.
     *
     * @param val the val
     */
    public void setTechnicalErrorCode(String val) {
        TechnicalErrorCode = val;
    }

    /**
     * Gets success code.
     *
     * @return the success code
     */
    public String getSuccessCode() {
        return SuccessCode;
    }

    /**
     * Sets success code.
     *
     * @param val the val
     */
    public void setSuccessCode(String val) {
        SuccessCode = val;
    }

    /**
     * Gets first name.
     *
     * @return the first name
     */
    public String getFirstName() {
        return FirstName;
    }

    /**
     * Sets first name.
     *
     * @param val the val
     */
    public void setFirstName(String val) {
        FirstName = val;
    }

    /**
     * Gets last name.
     *
     * @return the last name
     */
    public String getLastName() {
        return LastName;
    }

    /**
     * Sets last name.
     *
     * @param val the val
     */
    public void setLastName(String val) {
        LastName = val;
    }

    /**
     * Gets status code.
     *
     * @return the status code
     */
    public String getStatusCode() {
        return StatusCode;
    }

    /**
     * Sets status code.
     *
     * @param val the val
     */
    public void setStatusCode(String val) {
        StatusCode = val;
    }

    /**
     * Gets status description.
     *
     * @return the status description
     */
    public String getStatusDescription() {
        return StatusDescription;
    }

    /**
     * Sets status description.
     *
     * @param val the val
     */
    public void setStatusDescription(String val) {
        StatusDescription = val;
    }

    /****** END SET/GET METHOD, DO NOT MODIFY  @param transactionId the transaction id
     * @param sourceSystemName the source system name
     * @return the list
     * @throws Exception the exception
     */
    public List<String> invoke(String transactionId, String sourceSystemName) throws Exception {

        Hashtable<String, String> env = new Hashtable<String, String>(11);
        env.put(Context.INITIAL_CONTEXT_FACTORY, InitialContextFactory);
        env.put(Context.PROVIDER_URL, ProviderURL);
        env.put(Context.SECURITY_AUTHENTICATION, SecurityAuthentication);
        env.put(Context.SECURITY_PRINCIPAL, LdapUserDN);
        env.put(Context.SECURITY_CREDENTIALS, SecurityCredential);


        try {

            DirContext ctx = new InitialDirContext(env);
            Attributes attrs = ctx.getAttributes(LdapUserDN);


            FirstName = (String) attrs.get("givenName").get();
            LastName = (String) attrs.get("sn").get();
            StatusCode = SuccessCode;
            StatusDescription = "User details found";
            ///////******* LOGGING ********** FINAL RESPONSE///////////
            msgPayload = "FirstName " + FirstName + "LastName " + LastName;
            LoggerHandler.LogOut("INFO", "4", transactionId, sourceSystemName, "AuthenticationService", msgPayload);
            ///////******* LOGGING **********///////////
            if (FirstName == null && LastName == null) {
                StatusCode = ApplicationErrorCode;
                StatusDescription = "No details found for the requested UserID";
            }
            ctx.close();
        } catch (AuthenticationException ex) {
            // Authentication failed
            ex.printStackTrace();
            StatusCode = ApplicationErrorCode;
            StatusDescription = ex.getMessage();
            ///////******* EXCEPTION HANDLING*******////
            LoggerHandler.ErrorOut(ex, transactionId, sourceSystemName, "AuthenticationController", msgPayload);
        } catch (NamingException ex) {
            ex.printStackTrace();
            StatusCode = ApplicationErrorCode;
            StatusDescription = ex.getMessage();
            ///////******* EXCEPTION HANDLING*******////
            LoggerHandler.ErrorOut(ex, transactionId, sourceSystemName, "AuthenticationController", msgPayload);
        } catch (Exception ex) {
            ex.printStackTrace();
            StatusCode = TechnicalErrorCode;
            StatusDescription = ex.getMessage();
            ///////******* EXCEPTION HANDLING*******////
            LoggerHandler.ErrorOut(ex, transactionId, sourceSystemName, "AuthenticationController", msgPayload);
        }
        retrvUserDet.add(FirstName);
        retrvUserDet.add(LastName);
        retrvUserDet.add(StatusCode);
        retrvUserDet.add(StatusDescription);
        return retrvUserDet;

    }
}
