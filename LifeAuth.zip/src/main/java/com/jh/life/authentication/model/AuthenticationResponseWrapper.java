package com.jh.life.authentication.model;

import com.manulife.esb.xsd.checkdisbursementsystem.jh.authentication.AuthenticationResponse;
import com.manulife.esb.xsd.common.jh.header.JHHeader;

public class AuthenticationResponseWrapper {

    private JHHeader header;
    private AuthenticationResponse authenticationResponse;

    public JHHeader getHeader() {
        return header;
    }

    public void setHeader(JHHeader header) {
        this.header = header;
    }

    public AuthenticationResponse getAuthenticationResponse() {
        return authenticationResponse;
    }

    public void setAuthenticationResponse(AuthenticationResponse authenticationResponse) {
        this.authenticationResponse = authenticationResponse;
    }
}
