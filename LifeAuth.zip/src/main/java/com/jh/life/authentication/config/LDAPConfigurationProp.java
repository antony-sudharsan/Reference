package com.jh.life.authentication.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * The type Ldap configuration prop.
 */
@Component
public class LDAPConfigurationProp {
	@Value("${ldap.baseDN}")
	private String baseDN;
	@Value("${ldap.initialContextFactory}")
    private String initialContextFactory;
	@Value("${ldap.providerUrl}")
	private String providerUrl;
	@Value("${ldap.securityAuth}")
	private String securityAuth;
	@Value("${ldap.securityCredentials}")
	private String securityCredentials;
	@Value("${ldap.securityPrincipal}")
	private String securityPrincipal;
	@Value("${ldap.successCode}")
	private String successCode;
	@Value("${ldap.applicationErrorCode}")
	private String applicationErrorCode;
	@Value("${ldap.technicalErrorCode}")
	private String technicalErrorCode;
	@Value("${ldap.passwordUser}")
    private String passwordUser;

    /**
     * Gets password user.
     *
     * @return the password user
     */
    public String getPasswordUser() {
		return passwordUser;
	}

    /**
     * Sets password user.
     *
     * @param passwordUser the password user
     */
    public void setPasswordUser(String passwordUser) {
		this.passwordUser = passwordUser;
	}

    /**
     * Gets success code.
     *
     * @return the success code
     */
    public String getSuccessCode() {
		return successCode;
	}

    /**
     * Sets success code.
     *
     * @param successCode the success code
     */
    public void setSuccessCode(String successCode) {
		this.successCode = successCode;
	}

    /**
     * Gets application error code.
     *
     * @return the application error code
     */
    public String getApplicationErrorCode() {
		return applicationErrorCode;
	}

    /**
     * Sets application error code.
     *
     * @param applicationErrorCode the application error code
     */
    public void setApplicationErrorCode(String applicationErrorCode) {
		this.applicationErrorCode = applicationErrorCode;
	}

    /**
     * Gets technical error code.
     *
     * @return the technical error code
     */
    public String getTechnicalErrorCode() {
		return technicalErrorCode;
	}

    /**
     * Sets technical error code.
     *
     * @param technicalErrorCode the technical error code
     */
    public void setTechnicalErrorCode(String technicalErrorCode) {
		this.technicalErrorCode = technicalErrorCode;
	}

    /**
     * Gets base dn.
     *
     * @return the base dn
     */
    public String getBaseDN() {
		return baseDN;
	}

    /**
     * Sets base dn.
     *
     * @param baseDN the base dn
     */
    public void setBaseDN(String baseDN) {
		this.baseDN = baseDN;
	}

    /**
     * Gets initial context factory.
     *
     * @return the initial context factory
     */
    public String getInitialContextFactory() {
		return initialContextFactory;
	}

    /**
     * Sets initial context factory.
     *
     * @param initialContextFactory the initial context factory
     */
    public void setInitialContextFactory(String initialContextFactory) {
		this.initialContextFactory = initialContextFactory;
	}

    /**
     * Gets provider url.
     *
     * @return the provider url
     */
    public String getProviderUrl() {
		return providerUrl;
	}

    /**
     * Sets provider url.
     *
     * @param providerUrl the provider url
     */
    public void setProviderUrl(String providerUrl) {
		this.providerUrl = providerUrl;
	}

    /**
     * Gets security auth.
     *
     * @return the security auth
     */
    public String getSecurityAuth() {
		return securityAuth;
	}

    /**
     * Sets security auth.
     *
     * @param securityAuth the security auth
     */
    public void setSecurityAuth(String securityAuth) {
		this.securityAuth = securityAuth;
	}

    /**
     * Gets security credentials.
     *
     * @return the security credentials
     */
    public String getSecurityCredentials() {
		return securityCredentials;
	}

    /**
     * Sets security credentials.
     *
     * @param securityCredentials the security credentials
     */
    public void setSecurityCredentials(String securityCredentials) {
		this.securityCredentials = securityCredentials;
	}

    /**
     * Gets security principal.
     *
     * @return the security principal
     */
    public String getSecurityPrincipal() {
		return securityPrincipal;
	}

    /**
     * Sets security principal.
     *
     * @param securityPrincipal the security principal
     */
    public void setSecurityPrincipal(String securityPrincipal) {
		this.securityPrincipal = securityPrincipal;
	}
	
	
	
}
