package com.jh.life.authentication.endpoint;

import com.jh.common.logging.LoggerHandler;
import com.jh.life.authentication.exception.BadRequestException;
import com.jh.life.authentication.orchestration.LifeAuthOrchestration;
import com.jh.life.authentication.utils.*;
import com.manulife.esb.xsd.checkdisbursementsystem.jh.authentication.AuthenticationRequest;
import com.manulife.esb.xsd.checkdisbursementsystem.jh.authentication.AuthenticationResponse;
import com.manulife.esb.xsd.common.jh.header.JHHeader;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ws.context.MessageContext;
import org.springframework.ws.server.endpoint.annotation.Endpoint;
import org.springframework.ws.server.endpoint.annotation.PayloadRoot;
import org.springframework.ws.server.endpoint.annotation.RequestPayload;
import org.springframework.ws.server.endpoint.annotation.ResponsePayload;
import org.springframework.ws.soap.SoapHeaderElement;
import org.springframework.ws.soap.server.endpoint.annotation.SoapHeader;

/**
 * Exposes  Operations via SOAP.
 */
@Endpoint
public class LifeAuthEndpoint {
    private static final String NAMESPACE_URI = "http://www.esb.manulife.com/xsd/checkdisbursementsystem/jh/authentication";

    private static final String JH_HEADER_NS = "http://www.esb.manulife.com/xsd/common/jh/header";

    private final JHHeaderJaxbUtils jhHeaderJaxbUtils;
    private final LoggerUtils loggerUtils;

    LifeAuthOrchestration lifeAuthOrchestration;

    /**
     * Instantiates a new Producer endpoint.
     *
     * @param lifeAuthOrchestration the lifeAuthOrchestration
     * @param jhHeaderJaxbUtils     the jh header jaxb utils
     * @param loggerUtils           the logger utils
     */
    @Autowired
    public LifeAuthEndpoint(final LifeAuthOrchestration lifeAuthOrchestration,
                            final JHHeaderJaxbUtils jhHeaderJaxbUtils, final LoggerUtils loggerUtils) {
        this.lifeAuthOrchestration = lifeAuthOrchestration;
        this.jhHeaderJaxbUtils = jhHeaderJaxbUtils;
        this.loggerUtils = loggerUtils;
    }


    @PayloadRoot(namespace = NAMESPACE_URI, localPart = "Authentication_request")
    @ResponsePayload
    public AuthenticationResponse passwordAuthn(final @RequestPayload AuthenticationRequest request,
                                                final @SoapHeader("{" + JH_HEADER_NS + "}JHHeader") SoapHeaderElement jhHeaderElement,
                                                final MessageContext messageContext) throws Exception {
        AuthenticationResponse reply = null;
        JHHeader header = parseHeader(jhHeaderElement);
        JHHeaderUtils.validateHeader(header);

        final String messageUUID = JHHeaderUtils.retrieveOrDefaultMessageUID(header, "CheckLicenseStatus");
        final String sourceSystemName = JHHeaderUtils.retrieveOrDefaultSourceSystemName(header);

        try {
            LoggingContextHolder.getLoggingContext().setContext(messageUUID, sourceSystemName);
            LoggerHandler.LogOut("INFO", "1", messageUUID, sourceSystemName, this.getClass().getName(),
                    "Entering passwordAuthn EndPoint " + loggerUtils.writeAsJson(request));

            reply = lifeAuthOrchestration.passwordAuthn(header, request).getAuthenticationResponse();

            LoggerHandler.LogOut("INFO", "6", messageUUID, sourceSystemName, this.getClass().getName(),
                    "Exiting passwordAuthn EndPoint " + loggerUtils.writeAsJson(reply));

        } catch (final Exception e) {
            LoggerHandler.ErrorOut(e, messageUUID, sourceSystemName, this.getClass().getName(), e.getMessage());
            throw e;
        }

        // add response header as a property to be used by EndpointInterceptor
        // Current service does not modify header on response
        messageContext.setProperty(HeaderKey.JH_HEADER_KEY.getValue(), header);
        LoggingContextHolder.getLoggingContext().clear();

        return reply;
    }

    /**
     *
     * @param jhHeaderElement
     * @return
     */
    private JHHeader parseHeader(final SoapHeaderElement jhHeaderElement) {
        // parse JH Header if present
        JHHeader header = null;
        if (null != jhHeaderElement) {
            header = jhHeaderJaxbUtils.unmarshallJHHeader(jhHeaderElement);
        } else {
            throw new BadRequestException("Missing Header");
        }

        return header;
    }

}