package com.jh.life.authentication.controller;

import com.jh.life.authentication.exception.BaseFaultException;
import com.jh.life.authentication.exception.ExceptionResponse;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;


/**
 * The type Auth controller exception.
 */
@ControllerAdvice
public class AuthControllerException extends ResponseEntityExceptionHandler{

    /**
     * Handle exception response entity.
     *
     * @param ex      the ex
     * @param request the request
     *
     * @return the response entity
     */
    @ExceptionHandler(BaseFaultException.class)
    public final ResponseEntity<Object> handleException(BaseFaultException ex, WebRequest request) {

        ExceptionResponse resp = new ExceptionResponse(ex.getCode(), ex.getReason(), ex.getReason());

        if (ex.getCode().equals("TECHNICAL_ERROR_CODE")) {
            return new ResponseEntity(resp, HttpStatus.INTERNAL_SERVER_ERROR);
        } else if (ex.getCode().equals("TIMEOUT_ERROR_CODE")) {
            return new ResponseEntity(resp, HttpStatus.REQUEST_TIMEOUT);
        } else {
            return new ResponseEntity(resp, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
	
	
}

