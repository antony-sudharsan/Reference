package com.jh.life.authentication.controller;

import com.jh.common.logging.LoggerHandler;
import com.jh.life.authentication.model.AuthenticationRequestWrapper;
import com.jh.life.authentication.model.AuthenticationResponseWrapper;
import com.jh.life.authentication.orchestration.LifeAuthOrchestration;
import com.jh.life.authentication.utils.JHHeaderUtils;
import com.jh.life.authentication.utils.LoggingContextHolder;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

@RestController
@EnableSwagger2
public class AuthenticationController {

    @Autowired
    LifeAuthOrchestration lifeAuthOrchestration;


    @ApiOperation(
            value = "Check password Authn",
            notes = "Service will check Password Auth",
            response = AuthenticationResponseWrapper.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Success"),
            @ApiResponse(code = 406, message = "Service Processing Error"),
            @ApiResponse(code = 408, message = "Request Timeout"),
            @ApiResponse(code = 500, message = "LDAP Server Backend returned an error"),
            @ApiResponse(code = 400, message = "Validation Failed"),
            @ApiResponse(code = 404, message = "Record not found "),
            @ApiResponse(code = 401, message = "Unauthorized to perform operation")
    })
    @RequestMapping(value = "/jh/ins/security/globalAD/usr/pwd/auth", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)

    public ResponseEntity<AuthenticationResponseWrapper> passwordAuthn(@RequestBody AuthenticationRequestWrapper request) throws Exception {

        final String messageUUID = JHHeaderUtils.retrieveOrDefaultMessageUID(request.getHeader(),
                "getUserDetails");
        final String sourceSystemName = JHHeaderUtils.retrieveOrDefaultSourceSystemName(request.getHeader());
        AuthenticationResponseWrapper authenticationResponseWrapper = new AuthenticationResponseWrapper();
        try {
            LoggingContextHolder.getLoggingContext().setContext(messageUUID, sourceSystemName);

            JHHeaderUtils.validateHeader(request.getHeader());
            LoggerHandler.LogOut("INFO", "1", messageUUID, sourceSystemName, this.getClass().getName(), "Entering getUserDetails Controller");


            authenticationResponseWrapper = lifeAuthOrchestration.passwordAuthn(request.getHeader(), request.getAuthenticationRequest());

            LoggerHandler.LogOut("INFO", "6", messageUUID, sourceSystemName, this.getClass().getName(), "Exiting getUserDetails Controller");
            LoggerHandler.LogOut("DEBUG", "6", messageUUID, sourceSystemName, this.getClass().getName(), "Controller getUserDetails Success");

        } catch (final Exception e) {
            LoggerHandler.ErrorOut(e, messageUUID, sourceSystemName, this.getClass().getName(), e.getMessage());
            throw e;
        }
		
	/*if( (globalADPwdAuthResponse.getFirstName().length() == 0) || (globalADPwdAuthResponse.getLastName().length() == 0))
	{
		throw new NotFoundException("User ID Not Found: ");
	}*/

        return new ResponseEntity(authenticationResponseWrapper, new HttpHeaders(), HttpStatus.OK);

    }
}
