package com.jh.life.authentication.exception;

/**
 * Represents SoapFault for Record Not Found.
 */
public class RecordNotFoundException extends BaseFaultException {
    private static final long serialVersionUID = -6016805724195451879L;

    private static final String DEFAULT_CODE = "999";
    private static final String DEFAULT_REASON = "No Data Found";
    private static final String DEFAULT_DETAILS = "No Data Found based on criteria";
    private static final String FAULT_STRING = "Internal Error";

    public RecordNotFoundException() {
        super(DEFAULT_CODE, DEFAULT_REASON, DEFAULT_DETAILS, FAULT_STRING);
    }

    public RecordNotFoundException(final String message) {
        super(DEFAULT_CODE, DEFAULT_REASON, DEFAULT_DETAILS, message);
    }
}
