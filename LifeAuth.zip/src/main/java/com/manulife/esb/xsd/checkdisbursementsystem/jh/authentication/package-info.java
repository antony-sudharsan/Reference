@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.esb.manulife.com/xsd/checkdisbursementsystem/jh/authentication", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.manulife.esb.xsd.checkdisbursementsystem.jh.authentication;
