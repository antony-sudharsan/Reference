
package com.manulife.esb.xsd.checkdisbursementsystem.jh.authentication;

import javax.xml.bind.annotation.XmlRegistry;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.manulife.esb.xsd.checkdisbursementsystem.jh.authentication package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {


    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.manulife.esb.xsd.checkdisbursementsystem.jh.authentication
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link AuthenticationResponse }
     * 
     */
    public AuthenticationResponse createAuthenticationResponse() {
        return new AuthenticationResponse();
    }

    /**
     * Create an instance of {@link AuthenticationResponse.Result }
     * 
     */
    public AuthenticationResponse.Result createAuthenticationResponseResult() {
        return new AuthenticationResponse.Result();
    }

    /**
     * Create an instance of {@link AuthenticationRequest }
     * 
     */
    public AuthenticationRequest createAuthenticationRequest() {
        return new AuthenticationRequest();
    }

    /**
     * Create an instance of {@link AuthenticationResponse.Result.Failure }
     * 
     */
    public AuthenticationResponse.Result.Failure createAuthenticationResponseResultFailure() {
        return new AuthenticationResponse.Result.Failure();
    }

    /**
     * Create an instance of {@link AuthenticationResponse.Result.Success }
     * 
     */
    public AuthenticationResponse.Result.Success createAuthenticationResponseResultSuccess() {
        return new AuthenticationResponse.Result.Success();
    }

}
