
package com.manulife.esb.xsd.common.jh.header;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ServiceInfo complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ServiceInfo">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/common/jh/header}ServiceName"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/common/jh/header}ServiceVersion"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/common/jh/header}ServiceOperation"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ServiceInfo", propOrder = {
    "serviceName",
    "serviceVersion",
    "serviceOperation"
})
public class ServiceInfo {

    @XmlElement(name = "ServiceName", required = true)
    protected String serviceName;
    @XmlElement(name = "ServiceVersion", required = true)
    protected String serviceVersion;
    @XmlElement(name = "ServiceOperation", required = true)
    protected String serviceOperation;

    /**
     * Used to identify the service that is being 
     *                                                                        requested.
     *                                       
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getServiceName() {
        return serviceName;
    }

    /**
     * Sets the value of the serviceName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setServiceName(String value) {
        this.serviceName = value;
    }

    /**
     * Used to identify the version of the service being 
     *                                                                        invoked.
     *                                        
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getServiceVersion() {
        return serviceVersion;
    }

    /**
     * Sets the value of the serviceVersion property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setServiceVersion(String value) {
        this.serviceVersion = value;
    }

    /**
     * Service Function.  Describes the type of service 
     *                                                                        requested like Policy Inquiry.
     *                                       
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getServiceOperation() {
        return serviceOperation;
    }

    /**
     * Sets the value of the serviceOperation property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setServiceOperation(String value) {
        this.serviceOperation = value;
    }

}
