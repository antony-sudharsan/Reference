package com.manulife.esb.xsd.checkdisbursementsystem.jh.authentication;

import javax.xml.bind.annotation.XmlElement;

import org.springframework.stereotype.Component;
@Component
public class SendAuthenticationResponse {

	 
     private String statusCode;    
     private String firstName;     
     private String lastName;
     private String statusMsg;
	public String getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getStatusMsg() {
		return statusMsg;
	}
	public void setStatusMsg(String statusMsg) {
		this.statusMsg = statusMsg;
	}
     
}
