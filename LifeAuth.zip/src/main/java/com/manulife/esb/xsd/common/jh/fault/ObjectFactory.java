
package com.manulife.esb.xsd.common.jh.fault;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.manulife.esb.xsd.common.jh.fault package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _Faultcode_QNAME = new QName("http://www.esb.manulife.com/xsd/common/jh/fault", "faultcode");
    private final static QName _Faultactor_QNAME = new QName("http://www.esb.manulife.com/xsd/common/jh/fault", "faultactor");
    private final static QName _Faultstring_QNAME = new QName("http://www.esb.manulife.com/xsd/common/jh/fault", "faultstring");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.manulife.esb.xsd.common.jh.fault
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link SoapFault }
     * 
     */
    public SoapFault createSoapFault() {
        return new SoapFault();
    }

    /**
     * Create an instance of {@link DefaultFaultElement }
     * 
     */
    public DefaultFaultElement createDefaultFaultElement() {
        return new DefaultFaultElement();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/common/jh/fault", name = "faultcode")
    public JAXBElement<String> createFaultcode(String value) {
        return new JAXBElement<String>(_Faultcode_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/common/jh/fault", name = "faultactor")
    public JAXBElement<String> createFaultactor(String value) {
        return new JAXBElement<String>(_Faultactor_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/common/jh/fault", name = "faultstring")
    public JAXBElement<String> createFaultstring(String value) {
        return new JAXBElement<String>(_Faultstring_QNAME, String.class, null, value);
    }

}
