# Global AD Pwd Auth  Design Document
## Introduction
    This document defines the service specification for SOA components making up the Global AD Pwd Auth service for John Hancock LTC.
    This service supports operations related to Global AD Pwd Auth . The operations currently specified are:  

1. passwordAuthn

## REST Operations
|Operation|URI|Method|
|---|:---:|---:|
|passwordAuthn|/jh/ins/security/globalAD/usr/pwd/auth|POST|

# SOAP Endpoint URL
Operation|URI|Local Part|
---|---|---|
passwordAuthn|https://globaladpwdauth.apps.cac.preview.pcf.manulife.com//|AuthenticationRequest|

## Swagger URL
https://https://globaladpwdauth.apps.cac.preview.pcf.manulife.com//swagger-ui.html

## Audit Point
No|Reference Interpretation
---|---
1|Data received From Input
2|Data Sent to End System
3|Data Output received from End System
4|Data sent back to Output

## HTTP Error Codes
# For REST Service
Error Code|Error Description
---|---
200|Success
408|Request Timeout 
417|Max Records (Search only)       
500|Technical Error
400|Invalid Input, Bad Request of Validation Failed.
404|Record not found 

# For SOAP Service
Code|Reason|Detail
---|---|---
999|No Data Found|No Data Found based on criteria
993|Invalid Input|Invalid information entered for input.
998|[] records found, refine search criteria|[] records found, it is greater than user maximum input of []
9999|Technical Error|Stacktrace Message
99999|Service Timed Out|Service Timed Out

