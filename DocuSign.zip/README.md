# DocuSign Design Document
## Introduction
    This document defines the service specification for SOA components making up the Docu Sign service for John Hancock LTC.
    This service supports operations related to Docu Sign. The operations currently specified are:  

1. Get Envelope Docs
2. Get Envelope Docs Combined
3. Get Envelope Docs All

## REST Operations
|Operation|URI|Method|
|---|:---:|---:|
|getEnvelopeDocsCombined|/jh/common/docusign/envelope/getdocscombine|POST|
|getEnvelopeDocs|/jh/common/docusign/envelope/getdoc|POST|
|getEnvelopeDocsAll|/jh/common/docusign/envelope/getalldocs|POST|

# SOAP Endpoint URL
Operation|URI|Local Part|
---|---|---|
getEnvelopeDocsCombined|https://docusignenvelope-dev.apps.cac.preview.pcf.manulife.com/|GetEnvelopeDocsCombinedRequest|
getEnvelopeDocs|https://docusignenvelope-dev.apps.cac.preview.pcf.manulife.com/|GetEnvelopeDocsRequest|
getEnvelopeDocsAll|https://docusignenvelope-dev.apps.cac.preview.pcf.manulife.com/|GetEnvelopeDocsAllRequest|

## Swagger URL
https://docusignenvelope-dev.apps.cac.preview.pcf.manulife.com/swagger-ui.html

## Audit Point
No|Reference Interpretation
---|---
1|Data received From Input
2|Data Sent to End System
3|Data Output received from End System
4|Data sent back to Output

## HTTP Error Codes
# For REST Service
Error Code|Error Description
---|---
200|Success
408|Request Timeout 
417|Max Records (Search only)       
500|Technical Error
400|Invalid Input, Bad Request of Validation Failed.
404|Record not found 

# For SOAP Service
Code|Reason|Detail
---|---|---
999|No Data Found|No Data Found based on criteria
993|Invalid Input|Invalid information entered for input.
998|[] records found, refine search criteria|[] records found, it is greater than user maximum input of []
9999|Technical Error|Stacktrace Message
99999|Service Timed Out|Service Timed Out


