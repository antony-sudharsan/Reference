package com.jh.rpc.docusign.utils;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class DocuSignEnvelopeUtilsTest {

    @Before
    public void setUp() throws Exception {
    }

    @After
    public void tearDown() throws Exception {
    }

    @Test
    public void convertTimestampToXmlGregorianCalendar() {
    }

    @Test
    public void convertUtilDateToGregoerianCalendar() {
    }

    @Test
    public void convertXmlGregorianCalendarToTimestamp() {
    }

    @Test
    public void convertXmlGregorianCalendarToTimestamp1() {
    }

    @Test
    public void ifNullReturnEmpty() {
    }

    @Test
    public void getStringShortValue() {
    }

    @Test
    public void checkIsEqual() {
    }

    @Test
    public void checkLenghtIsZero() {
    }

    @Test
    public void getLARSProducerStatus() {
    }
}