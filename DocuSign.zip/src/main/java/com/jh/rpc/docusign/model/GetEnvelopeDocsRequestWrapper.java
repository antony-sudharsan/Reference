package com.jh.rpc.docusign.model;

import com.manulife.esb.xsd.common.jh.header.JHHeader;
import com.manulife.esb.xsd.pfs.jh.docusignenvelopeservice.GetEnvelopeDocsRequest;

/**
 * The type Get envelope docs request wrapper.
 */
public class GetEnvelopeDocsRequestWrapper {

    private GetEnvelopeDocsRequest getEnvelopeDocsRequest;

    private JHHeader jhHeader;

    /**
     * Gets get envelope docs request.
     *
     * @return the get envelope docs request
     */
    public GetEnvelopeDocsRequest getGetEnvelopeDocsRequest() {
        return getEnvelopeDocsRequest;
    }

    /**
     * Sets get envelope docs request.
     *
     * @param getEnvelopeDocsRequest the get envelope docs request
     */
    public void setGetEnvelopeDocsRequest(GetEnvelopeDocsRequest getEnvelopeDocsRequest) {
        this.getEnvelopeDocsRequest = getEnvelopeDocsRequest;
    }

    /**
     * Gets jh header.
     *
     * @return the jh header
     */
    public JHHeader getJhHeader() {
        return jhHeader;
    }

    /**
     * Sets jh header.
     *
     * @param jhHeader the jh header
     */
    public void setJhHeader(JHHeader jhHeader) {
        this.jhHeader = jhHeader;
    }
}
