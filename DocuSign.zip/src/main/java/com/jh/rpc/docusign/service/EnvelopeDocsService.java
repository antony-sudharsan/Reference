package com.jh.rpc.docusign.service;

import com.jh.common.logging.LoggerHandler;
import com.jh.rpc.docusign.config.DocuSignConfigProp;
import com.jh.rpc.docusign.exception.DocumentNotFoundException;
import com.jh.rpc.docusign.utils.LoggerUtils;
import com.manulife.esb.xsd.pfs.jh.docusignenvelopeservice.Document;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.net.ssl.*;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;
import java.security.cert.X509Certificate;

/**
 * The type Envelope docs service.
 */
@Component
public class EnvelopeDocsService {

    @Autowired
    private LoggerUtils loggerUtils;

    /**
     * The Docu prop.
     */
    @Autowired
    DocuSignConfigProp docuProp;


    /**
     * Gets doc details.
     *
     * @param docSignUrl       the doc sign url
     * @param transactionId    the transaction id
     * @param sourceSystemName the source system name
     * @param document         the document
     *
     * @return the doc details
     *
     * @throws Exception the exception
     */
    public Document getDocDetails(String docSignUrl, String transactionId, String sourceSystemName, Document document) throws Exception {

    	   StringBuffer response = new StringBuffer();
    	   String strMsg=null;
           String password = docuProp.getSslpassword();
          // String xDocusign="<DocuSignCredentials><Username>SAS-WMD-TIBCO-Support@jhancock.com</Username><Password>Jh1@2017</Password><IntegratorKey>906d7d50-b512-42cf-8ede-8183d3153cca</IntegratorKey></DocuSignCredentials>";
           String xDocusign="<DocuSignCredentials><Username>" + docuProp.getDocuuser()+ "</Username>" + "<Password>" + docuProp.getPswd()+ "</Password>" + "<IntegratorKey>" + docuProp.getIntegretorkey()+ "</IntegratorKey></DocuSignCredentials>";  
               TrustManager[] trustAllCerts = new TrustManager[] {new X509TrustManager() {
  	                public X509Certificate[] getAcceptedIssuers() {
  	                    return null;
  	                }
  	                public void checkClientTrusted(X509Certificate[] certs, String authType) {
  	                }
  	                public void checkServerTrusted(X509Certificate[] certs, String authType) {
  	                }
  				}
  			};	
  			   
  			   SSLContext sslContext = SSLContext.getInstance("SSL");
  			   sslContext.init(null, trustAllCerts, new java.security.SecureRandom());
  		       HttpsURLConnection.setDefaultSSLSocketFactory(sslContext.getSocketFactory());    		
  			   
  		       HostnameVerifier allHostsValid = new HostnameVerifier() {
  		           public boolean verify(String hostname, SSLSession session) {
  		               return true;
  		           }
  		       };
           
                     
                     HttpsURLConnection connection = null;
                     HttpsURLConnection.setDefaultSSLSocketFactory(sslContext.getSocketFactory());  
                     connection = (HttpsURLConnection) new URL(docSignUrl).openConnection();
                     connection.setRequestMethod(docuProp.getMethod());
                     connection.setReadTimeout(Integer.parseInt(docuProp.getReadtimeout()));
                     connection.setConnectTimeout(Integer.parseInt(docuProp.getConnectiontimeout()));
                     xDocusign="<DocuSignCredentials><Username>SAS-WMD-TIBCO-Support@jhancock.com</Username><Password>Jh1@2017</Password><IntegratorKey>906d7d50-b512-42cf-8ede-8183d3153cca</IntegratorKey></DocuSignCredentials>";
                     connection.setRequestProperty("X-DocuSign-Authentication", xDocusign);                                      
                     connection.setDoInput(true);                   
                     int responseCode = connection.getResponseCode(); 
                     if(responseCode==400)
       				{
                        document.setContent("");
                    	 throw new DocumentNotFoundException("No documents found for below URI=  " + docSignUrl);
       					
       				}
                     if(responseCode==204)
        				{
                            document.setContent("");
                     	 throw new DocumentNotFoundException("No content found for below URI=  " + docSignUrl);
        					
        				}
                     if(responseCode==404)
        				{
                            document.setContent("");
                     	 throw new DocumentNotFoundException("No documents found for below URI=  " + docSignUrl);
        					
        				}
                     else if (responseCode==200)
                     {
                    	 BufferedReader in = new BufferedReader(
                                 new InputStreamReader(connection.getInputStream()));
                                 String inputLine;                   
                               
                                 while ((inputLine = in.readLine()) != null) {
                                                   	 
                                	 response.append(inputLine);
                                	 
                                 }
                                 ////************RESTRICTING TO FIRST 5000 CHARACTER ONLY INCASE OF LARGE CONTENT***************////
                                 //docModel.setDocContent( response.toString().substring(0, 5000));
                                 ////////**********RESETTING BUFFER TO ZERO**********/////////
                         document.setContent( response.toString());
                                 response.setLength(0);
                                 in.close();
                     }

           LoggerHandler.LogOut("INFO", "7", transactionId, sourceSystemName, this.getClass().getName(),
                   "Exiting checkLicenseStatus " + loggerUtils.writeAsJson(document));
                                
             
              
              return document;

       }

     
}