package com.jh.rpc.docusign.model;

import com.manulife.esb.xsd.common.jh.header.JHHeader;
import com.manulife.esb.xsd.pfs.jh.docusignenvelopeservice.GetEnvelopeDocsAllResponse;

/**
 * The type Get envelope docs all response wrapper.
 */
public class GetEnvelopeDocsAllResponseWrapper {

    private GetEnvelopeDocsAllResponse getEnvelopeDocsAllResponse;
    private JHHeader jhHeader;

    /**
     * Gets get envelope docs all response.
     *
     * @return the get envelope docs all response
     */
    public GetEnvelopeDocsAllResponse getGetEnvelopeDocsAllResponse() {
        return getEnvelopeDocsAllResponse;
    }

    /**
     * Sets get envelope docs all response.
     *
     * @param getEnvelopeDocsAllResponse the get envelope docs all response
     */
    public void setGetEnvelopeDocsAllResponse(GetEnvelopeDocsAllResponse getEnvelopeDocsAllResponse) {
        this.getEnvelopeDocsAllResponse = getEnvelopeDocsAllResponse;
    }

    /**
     * Gets jh header.
     *
     * @return the jh header
     */
    public JHHeader getJhHeader() {
        return jhHeader;
    }

    /**
     * Sets jh header.
     *
     * @param jhHeader the jh header
     */
    public void setJhHeader(JHHeader jhHeader) {
        this.jhHeader = jhHeader;
    }
}
