package com.jh.rpc.docusign.model;

import com.manulife.esb.xsd.common.jh.header.JHHeader;
import com.manulife.esb.xsd.pfs.jh.docusignenvelopeservice.GetEnvelopeDocsCombinedRequest;

/**
 * The type Get envelope docs combined request wrapper.
 */
public class GetEnvelopeDocsCombinedRequestWrapper {

    private GetEnvelopeDocsCombinedRequest getEnvelopeDocsCombinedRequest;

    private JHHeader jhHeader;

    /**
     * Gets get envelope docs combined request.
     *
     * @return the get envelope docs combined request
     */
    public GetEnvelopeDocsCombinedRequest getGetEnvelopeDocsCombinedRequest() {
        return getEnvelopeDocsCombinedRequest;
    }

    /**
     * Sets get envelope docs combined request.
     *
     * @param getEnvelopeDocsCombinedRequest the get envelope docs combined request
     */
    public void setGetEnvelopeDocsCombinedRequest(GetEnvelopeDocsCombinedRequest getEnvelopeDocsCombinedRequest) {
        this.getEnvelopeDocsCombinedRequest = getEnvelopeDocsCombinedRequest;
    }

    /**
     * Gets jh header.
     *
     * @return the jh header
     */
    public JHHeader getJhHeader() {
        return jhHeader;
    }

    /**
     * Sets jh header.
     *
     * @param jhHeader the jh header
     */
    public void setJhHeader(JHHeader jhHeader) {
        this.jhHeader = jhHeader;
    }
}
