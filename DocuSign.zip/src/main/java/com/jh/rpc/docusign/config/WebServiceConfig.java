package com.jh.rpc.docusign.config;

import com.jh.rpc.docusign.endpoint.DocusignEnvelopeEndpointInterceptor;
import com.jh.rpc.docusign.exception.BaseFaultException;
import com.jh.rpc.docusign.exception.DetailSoapFaultDefinitionExceptionResolver;
import com.jh.rpc.docusign.utils.JHHeaderJaxbUtils;
import org.springframework.boot.web.servlet.ServletRegistrationBean;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;
import org.springframework.ws.config.annotation.EnableWs;
import org.springframework.ws.config.annotation.WsConfigurerAdapter;
import org.springframework.ws.server.EndpointInterceptor;
import org.springframework.ws.soap.server.endpoint.SoapFaultDefinition;
import org.springframework.ws.soap.server.endpoint.SoapFaultMappingExceptionResolver;
import org.springframework.ws.transport.http.MessageDispatcherServlet;
import org.springframework.ws.wsdl.wsdl11.SimpleWsdl11Definition;
import org.springframework.xml.xsd.SimpleXsdSchema;
import org.springframework.xml.xsd.XsdSchema;

import java.util.List;
import java.util.Properties;

/**
 * Configures Web Service Endpoint for DocuSignEnvelopeApplication Operations.
 */
@EnableWs
@Configuration
public class WebServiceConfig extends WsConfigurerAdapter {

    /**
     * Message dispatcher servlet servlet registration bean.
     *
     * @param applicationContext the application context
     *
     * @return the servlet registration bean
     */
    @Bean
    public ServletRegistrationBean messageDispatcherServlet(final ApplicationContext applicationContext) {
        final MessageDispatcherServlet servlet = new MessageDispatcherServlet();
        servlet.setApplicationContext(applicationContext);
        servlet.setTransformWsdlLocations(true);
        servlet.setTransformSchemaLocations(true);
        return new ServletRegistrationBean(servlet, "/wealth/pfs/DocusignEnvelope/*");
    }

    /**
     * Producer wsdl 11 definition simple wsdl 11 definition.
     *
     * @return the simple wsdl 11 definition
     */
// Note: Could use wsdl from TIBCO but it has embedded tibco namespaces
    // To retrieve wsdl
    // http://localhost:8080/wealth/pfs/DocusignEnvelope/DocusignEnvelope.wsdl
    @Bean(name = "DocusignEnvelope")
    public SimpleWsdl11Definition docusignEnvelopeWsdl11Definition() {
        final SimpleWsdl11Definition wsdl = new SimpleWsdl11Definition(
                new ClassPathResource("DocusignEnvelope.wsdl"));

        return wsdl;
    }

    /**
     * Jh header jaxb utils jh header jaxb utils.
     *
     * @return the jh header jaxb utils
     */
    @Bean
    public JHHeaderJaxbUtils jhHeaderJaxbUtils() {
        return new JHHeaderJaxbUtils();
    }

    /**
     * DocuSignEnvelope agreement schema xsd schema.
     *
     * @return the xsd schema
     */
// will expose imported schema
    // http://localhost:8080/MaintainProducerAgreement_1.0/JHFNMaintainProducerAgreement.xsd
    @Bean(name = "Docusign")
    public XsdSchema docuSignEnvelopeSchema() {

        return  new SimpleXsdSchema(new ClassPathResource("DocusignEnvelope.xsd"));
    }

    /**
     * Header schema xsd schema.
     *
     * @return the xsd schema
     */
// will expose imported schema
    // http://localhost:8080/MaintainProducerAgreement_1.0/JHHeader_0.5.0.xsd
    @Bean(name = "JHHeader_0.5.0")
    public XsdSchema headerSchema() {
        return new SimpleXsdSchema(new ClassPathResource("JHHeader_0.5.0.xsd"));
    }



    /**
     * Exception resolver soap fault mapping exception resolver.
     *
     * @return the soap fault mapping exception resolver
     */
    @Bean
    public SoapFaultMappingExceptionResolver exceptionResolver() {
        final SoapFaultMappingExceptionResolver exceptionResolver = new DetailSoapFaultDefinitionExceptionResolver();

        final SoapFaultDefinition faultDefinition = new SoapFaultDefinition();
        faultDefinition.setFaultCode(SoapFaultDefinition.SERVER);
        faultDefinition.setFaultStringOrReason("Internal Error");
        exceptionResolver.setDefaultFault(faultDefinition);

        final Properties errorMappings = new Properties();
        errorMappings.setProperty(Exception.class.getName(), SoapFaultDefinition.SERVER.toString());
        errorMappings.setProperty(BaseFaultException.class.getName(), SoapFaultDefinition.SERVER.toString());
        exceptionResolver.setExceptionMappings(errorMappings);
        exceptionResolver.setOrder(1);
        return exceptionResolver;
    }

    @Override
    public void addInterceptors(final List<EndpointInterceptor> interceptors) {

        final CustomValidatingInterceptor validatingInterceptor = new CustomValidatingInterceptor();
        validatingInterceptor.setValidateRequest(true);
        validatingInterceptor.setValidateResponse(true);
        validatingInterceptor.setXsdSchema(docuSignEnvelopeSchema());
        interceptors.add(validatingInterceptor);

        // will handle adding soap response header
        interceptors.add(new DocusignEnvelopeEndpointInterceptor(jhHeaderJaxbUtils()));
    }

}
