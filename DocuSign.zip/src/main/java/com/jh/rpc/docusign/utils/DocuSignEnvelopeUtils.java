package com.jh.rpc.docusign.utils;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import javax.xml.bind.JAXBElement;
import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;
import java.sql.Date;
import java.sql.Timestamp;
import java.util.GregorianCalendar;

/**
 * Utility class for DocuSignEnvelopeApplication operations.
 */
@Component
public class DocuSignEnvelopeUtils {

    private static final Logger logger = LoggerFactory.getLogger(DocuSignEnvelopeUtils.class);

    private static final String EMPTY_STRING = "";

    /**
     * Method to convert Timestamp to XMLGregorianCalendar
     *
     * @param inputDate the input date
     *
     * @return xml gregorian calendar
     */
    public static XMLGregorianCalendar convertTimestampToXmlGregorianCalendar(final Timestamp inputDate) {
        XMLGregorianCalendar xmlGregorianCalendar = null;
        if (inputDate != null) {
            final GregorianCalendar gregorianCalendar = new GregorianCalendar();

            gregorianCalendar.setTime(inputDate);
            try {
                xmlGregorianCalendar = DatatypeFactory.newInstance().newXMLGregorianCalendar(gregorianCalendar);
            } catch (final DatatypeConfigurationException e) {
                logger.error("Failed converting date to XMLGregorianCalendar", e);
            }
        }
        return xmlGregorianCalendar;
    }

    /**
     * Convert util date to gregoerian calendar xml gregorian calendar.
     *
     * @param inputDate the input date
     *
     * @return the xml gregorian calendar
     */
    public XMLGregorianCalendar convertUtilDateToGregoerianCalendar(Date inputDate) {
        GregorianCalendar gregorianCalContactEffDate = new GregorianCalendar();
        gregorianCalContactEffDate.setTime(inputDate);
        XMLGregorianCalendar date2 = null;
        try {
            date2 = DatatypeFactory.newInstance().newXMLGregorianCalendar(gregorianCalContactEffDate);
        } catch (Exception e) {

        }
        return date2;
    }


    /**
     * Converts an XMLGregorianCalendar to a Timestamp
     *
     * @param xmlGregorianCalendar the xml gregorian calendar
     *
     * @return timestamp
     */
    public static Timestamp convertXmlGregorianCalendarToTimestamp(final XMLGregorianCalendar xmlGregorianCalendar) {
        Timestamp timestamp = null;
        if (xmlGregorianCalendar != null) {
            timestamp = new Timestamp(xmlGregorianCalendar.toGregorianCalendar().getTimeInMillis());
        }

        return timestamp;
    }

    /**
     * Converts an JAXBElement<XMLGregorianCalendar> to a Timestamp
     *
     * @param xmlGregorianCalendar the xml gregorian calendar
     *
     * @return timestamp
     */
    public static Timestamp convertXmlGregorianCalendarToTimestamp(
            final JAXBElement<XMLGregorianCalendar> xmlGregorianCalendar) {
        Timestamp timestamp = null;
        if ((xmlGregorianCalendar != null) && !xmlGregorianCalendar.isNil()) {
            timestamp = new Timestamp(xmlGregorianCalendar.getValue().toGregorianCalendar().getTimeInMillis());
        }

        return timestamp;
    }

    /**
     * If null return empty string.
     *
     * @param value the value
     *
     * @return the string
     */
    public static String ifNullReturnEmpty(final String value) {
        if (StringUtils.isNotEmpty(value)) {
            return value;
        }

        return EMPTY_STRING;
    }

    /**
     * Gets string short value.
     *
     * @param value the value
     *
     * @return the string short value
     */
    public String getStringShortValue(Object value) {

        if (value != null) {
            return String.valueOf(((short) value));
        } else {
            return EMPTY_STRING;
        }

    }

    /**
     * Check is equal boolean.
     *
     * @param source the source
     * @param target the target
     *
     * @return the boolean
     */
    public boolean checkIsEqual(String source,String target) {
        return source.equalsIgnoreCase(target);
    }

    /**
     * Check lenght is zero boolean.
     *
     * @param source the source
     *
     * @return the boolean
     */
    public boolean checkLenghtIsZero(String source) {
        return (null == source || source.length() == 0);
    }

    /**
     * Gets lars producer status.
     *
     * @param status the status
     *
     * @return the lars producer status
     */
    public int getLARSProducerStatus(String status) {
        int statusOut = 0;
        switch (status) {
            case "Unknown":
                statusOut= 0;
                break;
            case "Active":
                statusOut= 1;
                break;
            case "Inactive":
                statusOut= 2;
                break;
            case "Pending":
                statusOut= 3;
                break;
            case "DocuSignEnvelopeApplication Ineligibal for rehire":
                statusOut= 1000000000;
                break;
        }

        return statusOut;
    }
}
