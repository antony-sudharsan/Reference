package com.jh.rpc.docusign.model;

import com.manulife.esb.xsd.common.jh.header.JHHeader;
import com.manulife.esb.xsd.pfs.jh.docusignenvelopeservice.GetEnvelopeDocsAllRequest;

/**
 * The type Get envelope docs all request wrapper.
 */
public class GetEnvelopeDocsAllRequestWrapper {

    private GetEnvelopeDocsAllRequest getEnvelopeDocsAllRequest;
    private JHHeader jhHeader;

    /**
     * Gets get envelope docs all request.
     *
     * @return the get envelope docs all request
     */
    public GetEnvelopeDocsAllRequest getGetEnvelopeDocsAllRequest() {
        return getEnvelopeDocsAllRequest;
    }

    /**
     * Sets get envelope docs all request.
     *
     * @param getEnvelopeDocsAllRequest the get envelope docs all request
     */
    public void setGetEnvelopeDocsAllRequest(GetEnvelopeDocsAllRequest getEnvelopeDocsAllRequest) {
        this.getEnvelopeDocsAllRequest = getEnvelopeDocsAllRequest;
    }

    /**
     * Gets jh header.
     *
     * @return the jh header
     */
    public JHHeader getJhHeader() {
        return jhHeader;
    }

    /**
     * Sets jh header.
     *
     * @param jhHeader the jh header
     */
    public void setJhHeader(JHHeader jhHeader) {
        this.jhHeader = jhHeader;
    }
}
