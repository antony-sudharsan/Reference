package com.jh.rpc.docusign;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


/**
 * The type Docu sign envelope application.
 */
@SpringBootApplication
public class DocuSignEnvelopeApplication {


    /**
     * The entry point of application.
     *
     * @param args the input arguments
     */
    public static void main(String[] args) {
        SpringApplication.run(DocuSignEnvelopeApplication.class, args);
    }


}
