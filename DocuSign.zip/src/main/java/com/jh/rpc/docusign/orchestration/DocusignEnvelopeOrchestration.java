package com.jh.rpc.docusign.orchestration;

import com.google.gson.Gson;
import com.jh.common.logging.LoggerHandler;
import com.jh.rpc.docusign.config.DocuSignConfigProp;
import com.jh.rpc.docusign.exception.InvalidInputException;
import com.jh.rpc.docusign.model.GetEnvelopeDocsAllResponseWrapper;
import com.jh.rpc.docusign.model.GetEnvelopeDocsCombinedResponseWrapper;
import com.jh.rpc.docusign.model.GetEnvelopeDocsResponseWrapper;
import com.jh.rpc.docusign.service.EnvelopeDocsService;
import com.jh.rpc.docusign.utils.DocuSignEnvelopeUtils;
import com.jh.rpc.docusign.utils.LoggerUtils;
import com.jh.rpc.docusign.utils.LoggingContextHolder;
import com.manulife.esb.xsd.common.jh.header.JHHeader;
import com.manulife.esb.xsd.pfs.jh.docusignenvelopeservice.*;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.sql.SQLException;
import java.util.List;


/**
 * The type Docusign envelope orchestration.
 */
@Component
public class DocusignEnvelopeOrchestration {

    @Autowired
    private LoggerUtils loggerUtils;

    @Autowired
    private DocuSignEnvelopeUtils docuSignEnvelopeUtils;

    @Autowired
    private EnvelopeDocsService envelopeDocsService;

    /**
     * The Docu prop.
     */
    @Autowired
    DocuSignConfigProp docuProp;

    /**
     * The Req uri.
     */
    String reqURI = null;

    /**
     * Gets envelope docs.
     *
     * @param header  the header
     * @param request the request
     *
     * @return the envelope docs
     *
     * @throws Exception the exception
     */
    public GetEnvelopeDocsResponseWrapper getEnvelopeDocs(JHHeader header, final GetEnvelopeDocsRequest request) throws Exception {

        final String messageUUID = LoggingContextHolder.getLoggingContext().getMessageUUID();
        final String sourceSystemName = LoggingContextHolder.getLoggingContext().getSourceSystemName();
        GetEnvelopeDocsResponseWrapper reply = new GetEnvelopeDocsResponseWrapper();

        GetEnvelopeDocsResponse getEnvelopeDocsResponse  = reply.getGetEnvelopeDocsResponse();
        Envelope envelope = new Envelope();
        Documents documents = new Documents();


        List<Document> documentList = request.getEnvelope().getDocuments().getDocument();
        String enveLopeID = request.getEnvelope().getID();
        String envRegion = request.getInstance().getRegion();


        LoggerHandler.LogOut("INFO", "2a", messageUUID, sourceSystemName, this.getClass().getName(),
                "getEnvelopeDocs " + loggerUtils.writeAsJson(request));

        documents.setDocument(getDocuments(documentList, enveLopeID, envRegion, messageUUID, sourceSystemName));
        envelope.setDocuments(documents);
        getEnvelopeDocsResponse.setEnvelope(envelope);
        reply.setGetEnvelopeDocsResponse(getEnvelopeDocsResponse);

        LoggerHandler.LogOut("INFO", "7", messageUUID, sourceSystemName, this.getClass().getName(),
                "Exiting getEnvelopeDocs " + loggerUtils.writeAsJson(reply));

        return reply;
    }

    private List<Document> getDocuments(List<Document> documentList, String enveLopeID, String envRegion, String messageUUID, String sourceSystemName) throws Exception {
        Document document = null;
        for (int i = 0; i < documentList.size(); i++) {
            document = (Document) documentList.get(i);
            String docID = document.getID();
            String docName = document.getName();
            String docType = document.getType();

            ////Form the URI////
            if (((enveLopeID).length() > 0) && (docID.length() > 0) && (envRegion.length() > 0)) {
                //reqURI=concat($_globalVariables/ns:GlobalVariables/DocusignEnvelope/DocusignEnvelope/CLE/DocusignProvider/RequestURI,$account_id,$envelopes,$Env_ID,$documents,$Doc_ID)
                reqURI = docuProp.getHost() + ":" + docuProp.getPort() + docuProp.getRequri() + "/" + docuProp.getAccountid() + "/" + docuProp.getEnvelopes() + "/" + enveLopeID + "/" + docuProp.getDocid() + "/" + docID;
            } else if (((enveLopeID).length() > 0) && (docID.length() == 0)) {
                reqURI = docuProp.getRequri() + docuProp.getAccountid() + docuProp.getEnvelopes() + enveLopeID + docuProp.getDocid();
            }


            LoggerHandler.LogOut("INFO", "2", messageUUID, sourceSystemName, this.getClass().getName(),
                    "Formatted reqURI" + reqURI);


            document = envelopeDocsService.getDocDetails(reqURI, messageUUID, sourceSystemName, document);

        }

        return documentList;
    }

    /**
     * Gets envelope docs combined.
     *
     * @param header  the header
     * @param request the request
     *
     * @return the envelope docs combined
     *
     * @throws SQLException the sql exception
     */
    public GetEnvelopeDocsCombinedResponseWrapper getEnvelopeDocsCombined(JHHeader header, GetEnvelopeDocsCombinedRequest request) throws Exception {

        final String messageUUID = LoggingContextHolder.getLoggingContext().getMessageUUID();
        final String sourceSystemName = LoggingContextHolder.getLoggingContext().getSourceSystemName();
        GetEnvelopeDocsCombinedResponseWrapper reply = new GetEnvelopeDocsCombinedResponseWrapper();
        GetEnvelopeDocsCombinedResponse getEnvelopeDocsCombinedResponse = new GetEnvelopeDocsCombinedResponse();
        List<Document> documentList = request.getEnvelope().getDocuments().getDocument();
        Envelope envelope = new Envelope();
        Documents documents = new Documents();


        String enveLopeID = request.getEnvelope().getID();
        String envRegion = request.getInstance().getRegion();

        LoggerHandler.LogOut("INFO", "2a", messageUUID, sourceSystemName, this.getClass().getName(),
                "GetEnvelopeDocsCombinedResponseWrapper " + loggerUtils.writeAsJson(request));

        documents.setDocument(getDocuments(documentList, enveLopeID, envRegion, messageUUID, sourceSystemName));
        envelope.setDocuments(documents);
        getEnvelopeDocsCombinedResponse.setEnvelope(envelope);
        reply.setGetEnvelopeDocsCombinedResponse(getEnvelopeDocsCombinedResponse);
        /*documentList.forEach((document) -> {

            String docID = document.getID();
            String docName = document.getName();
            String docType = document.getType();

            ////Form the URI////
            if (((enveLopeID).length() > 0) && (docID.length() > 0) && (envRegion.length() > 0)) {
                //reqURI=concat($_globalVariables/ns:GlobalVariables/DocusignEnvelope/DocusignEnvelope/CLE/DocusignProvider/RequestURI,$account_id,$envelopes,$Env_ID,$documents,$Doc_ID)
                reqURI = docuProp.getHost() + ":" + docuProp.getPort() + docuProp.getRequri() + "/" + docuProp.getAccountid() + "/" + docuProp.getEnvelopes() + "/" + enveLopeID + "/" + docuProp.getDocid() + "/" + docID;
            } else if (((enveLopeID).length() > 0) && (docID.length() == 0)) {
                reqURI = docuProp.getRequri() + docuProp.getAccountid() + docuProp.getEnvelopes() + enveLopeID + docuProp.getDocid();
            }


            LoggerHandler.LogOut("INFO", "2", messageUUID, sourceSystemName, this.getClass().getName(),
                    "Formatted reqURI" + reqURI);

            try {
                document = envelopeDocsService.getDocDetails(reqURI, messageUUID, sourceSystemName, document);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });*/

        LoggerHandler.LogOut("INFO", "7", messageUUID, sourceSystemName, this.getClass().getName(),
                "Exiting GetEnvelopeDocsCombinedResponseWrapper " + loggerUtils.writeAsJson(reply));

        return reply;
    }


    /**
     * Gets envelope docs all.
     *
     * @param header  the header
     * @param request the request
     *
     * @return the envelope docs all
     *
     * @throws SQLException the sql exception
     */
    public GetEnvelopeDocsAllResponseWrapper getEnvelopeDocsAll(JHHeader header, GetEnvelopeDocsAllRequest request) throws Exception {

        final String messageUUID = LoggingContextHolder.getLoggingContext().getMessageUUID();
        final String sourceSystemName = LoggingContextHolder.getLoggingContext().getSourceSystemName();


        GetEnvelopeDocsAllResponseWrapper getProducerResponseWrapper = new GetEnvelopeDocsAllResponseWrapper();

        GetEnvelopeDocsAllResponse getEnvelopeDocsAllResponse = new GetEnvelopeDocsAllResponse();
        Envelope envelope = new Envelope();
        Documents documents = new Documents();
        LoggerHandler.LogOut("INFO", "2", messageUUID, sourceSystemName, this.getClass().getName(),
                "Entering getEnvelopeDocsAll " + loggerUtils.writeAsJson(request));

        //final String user = retrieveAndValidateUser(header);


        final Gson returnDocList;
        String jsonStr = null;
        String enveLopeID = request.getEnvelope().getID();
        String envRegion = request.getInstance().getRegion();

        reqURI = docuProp.getHost() + ":" + docuProp.getPort() + docuProp.getRequri() + "/" + docuProp.getAccountid() + "/" + docuProp.getEnvelopes() + "/"
                + enveLopeID + "/" + docuProp.getDocid();

        LoggerHandler.LogOut("INFO", "2", messageUUID, sourceSystemName, this.getClass().getName(), reqURI);
        List<Document> documentList = request.getEnvelope().getDocuments().getDocument();


        documents.setDocument(getDocuments(documentList, enveLopeID, envRegion, messageUUID, sourceSystemName));
        envelope.setDocuments(documents);
        getEnvelopeDocsAllResponse.setEnvelope(envelope);
        getProducerResponseWrapper.setGetEnvelopeDocsAllResponse(getEnvelopeDocsAllResponse);

        LoggerHandler.LogOut("INFO", "4", messageUUID, sourceSystemName, this.getClass().getName(),
                "Exiting getEnvelopeDocsAll " + loggerUtils.writeAsJson(getProducerResponseWrapper));

        return getProducerResponseWrapper;
    }


    /**
     * Retrieve user from header, and if not found throw proper exception.
     *
     * @param header
     *
     * @return
     */
    private String retrieveAndValidateUser(final JHHeader header) {
        final String user = header.getMessageSource().getUserID();
        if (StringUtils.isEmpty(user)) {
            throw new InvalidInputException();
        }
        return user;
    }


}
