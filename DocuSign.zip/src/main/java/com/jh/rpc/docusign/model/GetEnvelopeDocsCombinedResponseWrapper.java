package com.jh.rpc.docusign.model;

import com.manulife.esb.xsd.common.jh.header.JHHeader;
import com.manulife.esb.xsd.pfs.jh.docusignenvelopeservice.GetEnvelopeDocsCombinedResponse;

/**
 * The type Get envelope docs combined response wrapper.
 */
public class GetEnvelopeDocsCombinedResponseWrapper {

    private GetEnvelopeDocsCombinedResponse getEnvelopeDocsCombinedResponse;
    private JHHeader header;

    /**
     * Gets get envelope docs combined response.
     *
     * @return the get envelope docs combined response
     */
    public GetEnvelopeDocsCombinedResponse getGetEnvelopeDocsCombinedResponse() {
        return getEnvelopeDocsCombinedResponse;
    }

    /**
     * Sets get envelope docs combined response.
     *
     * @param getEnvelopeDocsCombinedResponse the get envelope docs combined response
     */
    public void setGetEnvelopeDocsCombinedResponse(GetEnvelopeDocsCombinedResponse getEnvelopeDocsCombinedResponse) {
        this.getEnvelopeDocsCombinedResponse = getEnvelopeDocsCombinedResponse;
    }

    /**
     * Gets header.
     *
     * @return the header
     */
    public JHHeader getHeader() {
        return header;
    }

    /**
     * Sets header.
     *
     * @param header the header
     */
    public void setHeader(JHHeader header) {
        this.header = header;
    }
}
