package com.jh.rpc.docusign.exception;

/**
 * Represents SoapFault for Record Not Found.
 */
public class DocumentNotFoundException extends BaseFaultException {
    private static final long serialVersionUID = -6016805724195451879L;

    private static final String DEFAULT_CODE = "BIZ-DATA-E5000";
    private static final String DEFAULT_REASON = "Invalid Service Request: The envelope specified either does not exist or you have no rights to it.";
    private static final String DEFAULT_DETAILS = "No Data Found based on criteria";
    private static final String FAULT_STRING = "Internal Error";

    /**
     * Instantiates a new Document not found exception.
     */
    public DocumentNotFoundException() {
        super(DEFAULT_CODE, DEFAULT_REASON, DEFAULT_DETAILS, FAULT_STRING);
    }

    /**
     * Instantiates a new Document not found exception.
     *
     * @param message the message
     */
    public DocumentNotFoundException(final String message) {
        super(DEFAULT_CODE, DEFAULT_REASON, message, FAULT_STRING);
    }
}
