package com.jh.rpc.docusign.controller;

import com.jh.common.logging.LoggerHandler;
import com.jh.rpc.docusign.model.*;
import com.jh.rpc.docusign.orchestration.DocusignEnvelopeOrchestration;
import com.jh.rpc.docusign.utils.JHHeaderUtils;
import com.jh.rpc.docusign.utils.LoggerUtils;
import com.jh.rpc.docusign.utils.LoggingContextHolder;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.DataBinder;
import org.springframework.web.bind.annotation.*;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

/**
 * The type Producer controller.
 */
@RestController
@EnableSwagger2
public class DocusignEnvelopeController {


    /**
     * The Producer orchestration.
     */
    @Autowired
    DocusignEnvelopeOrchestration docusignEnvelopeOrchestration;

    private LoggerUtils loggerUtils;

    /**
     * Activate direct field access.
     *
     * @param dataBinder the data binder
     */
    @InitBinder
    public void activateDirectFieldAccess(final DataBinder dataBinder) {
        dataBinder.initDirectFieldAccess();
    }

    /**
     * Instantiates a new Producer controller.
     *
     * @param docusignEnvelopeOrchestration the producer orchestration
     * @param loggerUtils                   the logger utils
     */
    public DocusignEnvelopeController(DocusignEnvelopeOrchestration docusignEnvelopeOrchestration, LoggerUtils loggerUtils) {
        this.docusignEnvelopeOrchestration = docusignEnvelopeOrchestration;
        this.loggerUtils = loggerUtils;
    }

    /**
     * Check license status response entity.
     *
     * @param request the request
     *
     * @return the response entity
     *
     * @throws Exception the exception
     */
    @ApiOperation(
            value = "getEnvelopeDocs",
            notes = "Service will retrive the Envelope Documents",
            response = GetEnvelopeDocsResponseWrapper.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Success"),
            @ApiResponse(code = 406, message = "Service Processing Error"),
            @ApiResponse(code = 408, message = "Request Timeout"),
            @ApiResponse(code = 500, message = "SQL Server Backend returned an error"),
            @ApiResponse(code = 400, message = "Validation Failed"),
            @ApiResponse(code = 404, message = "Auth data Record not found "),
            @ApiResponse(code = 401, message = "Unauthorized to perform operation")
    })
    @RequestMapping(value = "/jh/common/docusign/envelope/getdoc", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<GetEnvelopeDocsResponseWrapper> getEnvelopeDocs(@RequestBody GetEnvelopeDocsRequestWrapper request) throws Exception {

        final String messageUUID = JHHeaderUtils.retrieveOrDefaultMessageUID(request.getJhHeader(),
                "checkLicenseStatus");
        final String sourceSystemName = JHHeaderUtils.retrieveOrDefaultSourceSystemName(request.getJhHeader());
        GetEnvelopeDocsResponseWrapper envelopeDocsResponseWrapper;

        try {
            LoggingContextHolder.getLoggingContext().setContext(messageUUID, sourceSystemName);

            JHHeaderUtils.validateHeader(request.getJhHeader());
            LoggerHandler.LogOut("INFO", "1", messageUUID, sourceSystemName, this.getClass().getName(), "Entering getEnvelopeDocs Controller");
            envelopeDocsResponseWrapper = docusignEnvelopeOrchestration.getEnvelopeDocs(request.getJhHeader(), request.getGetEnvelopeDocsRequest());

            LoggerHandler.LogOut("INFO", "6", messageUUID, sourceSystemName, this.getClass().getName(), "Exiting getEnvelopeDocs Controller");
            LoggerHandler.LogOut("DEBUG", "6", messageUUID, sourceSystemName, this.getClass().getName(), "Controller Create Success");


        } catch (final Exception e) {
            LoggerHandler.ErrorOut(e, messageUUID, sourceSystemName, this.getClass().getName(), e.getMessage());
            throw e;
        }

        return new ResponseEntity(envelopeDocsResponseWrapper, new HttpHeaders(), HttpStatus.OK);
    }

    /**
     * Gets envelope docs combined.
     *
     * @param request the request
     *
     * @return the envelope docs combined
     *
     * @throws Exception the exception
     */
    @ApiOperation(
            value = "Get Envelope Docs Combined Response",
            notes = "Service will retrieve the  Envelope Docs Combined Response Details",
            response = GetEnvelopeDocsCombinedResponseWrapper.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Success"),
            @ApiResponse(code = 500, message = "Internal Server Error"),
            @ApiResponse(code = 400, message = "Bad Request"),
            @ApiResponse(code = 404, message = "Not Found"),
            @ApiResponse(code = 401, message = "Unauthorized"),
            @ApiResponse(code = 408, message = "Request Timeout")
    })
    @RequestMapping(value = "/jh/common/docusign/envelope/getdocscombine", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<GetEnvelopeDocsCombinedResponseWrapper> getEnvelopeDocsCombined(@RequestBody GetEnvelopeDocsCombinedRequestWrapper request) throws Exception {

        final String messageUUID = JHHeaderUtils.retrieveOrDefaultMessageUID(request.getJhHeader(),
                "checkLicenseStatus");
        final String sourceSystemName = JHHeaderUtils.retrieveOrDefaultSourceSystemName(request.getJhHeader());
        GetEnvelopeDocsCombinedResponseWrapper getProducerResponseWrapper;

        try {
            LoggingContextHolder.getLoggingContext().setContext(messageUUID, sourceSystemName);

            JHHeaderUtils.validateHeader(request.getJhHeader());
            LoggerHandler.LogOut("INFO", "1", messageUUID, sourceSystemName, this.getClass().getName(), "Entering getEnvelopeDocsCombined Controller");
            getProducerResponseWrapper = docusignEnvelopeOrchestration.getEnvelopeDocsCombined(request.getJhHeader(), request.getGetEnvelopeDocsCombinedRequest());

            LoggerHandler.LogOut("INFO", "6", messageUUID, sourceSystemName, this.getClass().getName(), "Exiting getEnvelopeDocsCombined Controller");
            LoggerHandler.LogOut("DEBUG", "6", messageUUID, sourceSystemName, this.getClass().getName(), "Controller Create Success");


        } catch (final Exception e) {
            LoggerHandler.ErrorOut(e, messageUUID, sourceSystemName, this.getClass().getName(), e.getMessage());
            throw e;
        }

        return new ResponseEntity(getProducerResponseWrapper, new HttpHeaders(), HttpStatus.OK);

    }

    /**
     * Gets envelope docs all.
     *
     * @param request the request
     *
     * @return the envelope docs all
     *
     * @throws Exception the exception
     */
    @ApiOperation(
            value = "Get All Envelope Docs",
            notes = "Service will fetch all the envelope docs",
            response = GetEnvelopeDocsCombinedResponseWrapper.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Success"),
            @ApiResponse(code = 500, message = "Internal Server Error"),
            @ApiResponse(code = 400, message = "Bad Request"),
            @ApiResponse(code = 404, message = "Not Found"),
            @ApiResponse(code = 401, message = "Unauthorized"),
            @ApiResponse(code = 408, message = "Request Timeout")
    })
    @RequestMapping(value = "/jh/common/docusign/envelope/getalldocs", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<GetEnvelopeDocsAllResponseWrapper> getEnvelopeDocsAll(@RequestBody GetEnvelopeDocsAllRequestWrapper request) throws Exception {

        final String messageUUID = JHHeaderUtils.retrieveOrDefaultMessageUID(request.getJhHeader(),
                "checkLicenseStatus");
        final String sourceSystemName = JHHeaderUtils.retrieveOrDefaultSourceSystemName(request.getJhHeader());
        GetEnvelopeDocsAllResponseWrapper getProducerResponseWrapper;

        try {
            LoggingContextHolder.getLoggingContext().setContext(messageUUID, sourceSystemName);

            JHHeaderUtils.validateHeader(request.getJhHeader());
            LoggerHandler.LogOut("INFO", "1", messageUUID, sourceSystemName, this.getClass().getName(), "Entering getEnvelopeDocsAll Controller");
            getProducerResponseWrapper = docusignEnvelopeOrchestration.getEnvelopeDocsAll(request.getJhHeader(), request.getGetEnvelopeDocsAllRequest());

            LoggerHandler.LogOut("INFO", "6", messageUUID, sourceSystemName, this.getClass().getName(), "Exiting getEnvelopeDocsAll Controller");
            LoggerHandler.LogOut("DEBUG", "6", messageUUID, sourceSystemName, this.getClass().getName(), "Controller Create Success");


        } catch (final Exception e) {
            LoggerHandler.ErrorOut(e, messageUUID, sourceSystemName, this.getClass().getName(), e.getMessage());
            throw e;
        }

        return new ResponseEntity(getProducerResponseWrapper, new HttpHeaders(), HttpStatus.OK);

    }
}
