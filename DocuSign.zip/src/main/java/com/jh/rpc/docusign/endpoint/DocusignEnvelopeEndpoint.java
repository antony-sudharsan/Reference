package com.jh.rpc.docusign.endpoint;

import com.jh.common.logging.LoggerHandler;
import com.jh.rpc.docusign.exception.BadRequestException;
import com.jh.rpc.docusign.model.GetEnvelopeDocsAllResponseWrapper;
import com.jh.rpc.docusign.model.GetEnvelopeDocsCombinedResponseWrapper;
import com.jh.rpc.docusign.model.GetEnvelopeDocsResponseWrapper;
import com.jh.rpc.docusign.orchestration.DocusignEnvelopeOrchestration;
import com.jh.rpc.docusign.utils.*;
import com.manulife.esb.wsdl.pfs.jh.docusignenvelopeservice.GetEnvelopeDocsAllFault;
import com.manulife.esb.wsdl.pfs.jh.docusignenvelopeservice.GetEnvelopeDocsCombinedFault;
import com.manulife.esb.xsd.common.jh.header.JHHeader;
import com.manulife.esb.xsd.pfs.jh.docusignenvelopeservice.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ws.context.MessageContext;
import org.springframework.ws.server.endpoint.annotation.Endpoint;
import org.springframework.ws.server.endpoint.annotation.PayloadRoot;
import org.springframework.ws.server.endpoint.annotation.RequestPayload;
import org.springframework.ws.server.endpoint.annotation.ResponsePayload;
import org.springframework.ws.soap.SoapHeaderElement;
import org.springframework.ws.soap.server.endpoint.annotation.SoapHeader;

/**
 * Exposes DocuSignEnvelopeApplication Operations via SOAP.
 */
@Endpoint
public class DocusignEnvelopeEndpoint {
    private static final String NAMESPACE_URI = "http://www.esb.manulife.com/xsd/pfs/jh/DocusignEnvelopeService";

    private static final String JH_HEADER_NS = "http://www.esb.manulife.com/xsd/common/jh/header";

    private final JHHeaderJaxbUtils jhHeaderJaxbUtils;
    private final LoggerUtils loggerUtils;
    /**
     * The Producer orchestration.
     */
    final DocusignEnvelopeOrchestration docusignEnvelopeOrchestration;


    /**
     * Instantiates a new Docusign envelope endpoint.
     *
     * @param docusignEnvelopeOrchestration the docusign envelope orchestration
     * @param jhHeaderJaxbUtils             the jh header jaxb utils
     * @param loggerUtils                   the logger utils
     */
    @Autowired
    public DocusignEnvelopeEndpoint(final DocusignEnvelopeOrchestration docusignEnvelopeOrchestration,
                                    final JHHeaderJaxbUtils jhHeaderJaxbUtils, final LoggerUtils loggerUtils) {
        this.docusignEnvelopeOrchestration = docusignEnvelopeOrchestration;
        this.jhHeaderJaxbUtils = jhHeaderJaxbUtils;
        this.loggerUtils = loggerUtils;
    }


    /**
     * Gets envelope docs.
     *
     * @param request         the request
     * @param jhHeaderElement the jh header element
     * @param messageContext  the message context
     *
     * @return the envelope docs
     *
     * @throws Exception the exception
     */
    @PayloadRoot(namespace = NAMESPACE_URI, localPart = "GetEnvelopeDocs_request")
    @ResponsePayload
    public GetEnvelopeDocsResponse getEnvelopeDocs(final @RequestPayload GetEnvelopeDocsRequest request,
                                                   final @SoapHeader("{" + JH_HEADER_NS + "}JHHeader") SoapHeaderElement jhHeaderElement,
                                                   final MessageContext messageContext) throws Exception {
        GetEnvelopeDocsResponse reply = null;
        JHHeader header = parseHeader(jhHeaderElement);
        JHHeaderUtils.validateHeader(header);

        final String messageUUID = JHHeaderUtils.retrieveOrDefaultMessageUID(header, "CheckLicenseStatus");
        final String sourceSystemName = JHHeaderUtils.retrieveOrDefaultSourceSystemName(header);

        try {
            LoggingContextHolder.getLoggingContext().setContext(messageUUID, sourceSystemName);
            LoggerHandler.LogOut("INFO", "1", messageUUID, sourceSystemName, this.getClass().getName(),
                    "Entering checkLicenseStatus EndPoint " + loggerUtils.writeAsJson(request));

            GetEnvelopeDocsResponseWrapper getEnvelopeDocsResponseWrapper = docusignEnvelopeOrchestration.getEnvelopeDocs(header, request);

            reply = getEnvelopeDocsResponseWrapper.getGetEnvelopeDocsResponse();
            header = getEnvelopeDocsResponseWrapper.getJhHeader();
            LoggerHandler.LogOut("INFO", "8", messageUUID, sourceSystemName, this.getClass().getName(),
                    "Exiting checkLicenseStatus EndPoint " + loggerUtils.writeAsJson(reply));

        } catch (final Exception e) {
            LoggerHandler.ErrorOut(e, messageUUID, sourceSystemName, this.getClass().getName(), e.getMessage());
            throw e;
        }

        // add response header as a property to be used by EndpointInterceptor
        // Current service does not modify header on response
        messageContext.setProperty(HeaderKey.JH_HEADER_KEY.getValue(), header);
        LoggingContextHolder.getLoggingContext().clear();

        return reply;
    }


    /**
     * Gets envelope docs combined.
     *
     * @param request         the request
     * @param jhHeaderElement the jh header element
     * @param messageContext  the message context
     *
     * @return the envelope docs combined
     *
     * @throws GetEnvelopeDocsCombinedFault the get envelope docs combined fault
     * @throws Exception                    the exception
     */
    @PayloadRoot(namespace = NAMESPACE_URI, localPart = "GetEnvelopeDocsCombined_request")
    @ResponsePayload
    public GetEnvelopeDocsCombinedResponse getEnvelopeDocsCombined(final @RequestPayload GetEnvelopeDocsCombinedRequest request,
                                                                   final @SoapHeader("{" + JH_HEADER_NS + "}JHHeader") SoapHeaderElement jhHeaderElement,
                                                                   final MessageContext messageContext) throws GetEnvelopeDocsCombinedFault, Exception {

        GetEnvelopeDocsCombinedResponse reply = null;
        JHHeader header = parseHeader(jhHeaderElement);
        JHHeaderUtils.validateHeader(header);

        final String messageUUID = JHHeaderUtils.retrieveOrDefaultMessageUID(header, "GetProducer");
        final String sourceSystemName = JHHeaderUtils.retrieveOrDefaultSourceSystemName(header);

        try {
            LoggingContextHolder.getLoggingContext().setContext(messageUUID, sourceSystemName);
            LoggerHandler.LogOut("INFO", "1", messageUUID, sourceSystemName, this.getClass().getName(),
                    "Entering getProducer EndPoint " + loggerUtils.writeAsJson(request));

            GetEnvelopeDocsCombinedResponseWrapper getEnvelopeDocsCombinedResponseWrapper = docusignEnvelopeOrchestration.getEnvelopeDocsCombined(header, request);

            reply = getEnvelopeDocsCombinedResponseWrapper.getGetEnvelopeDocsCombinedResponse();

            header = getEnvelopeDocsCombinedResponseWrapper.getHeader();

            LoggerHandler.LogOut("INFO", "5", messageUUID, sourceSystemName, this.getClass().getName(),
                    "Exiting getProducer EndPoint " + loggerUtils.writeAsJson(reply));
        } catch (Exception e) {
            LoggerHandler.ErrorOut(e, messageUUID, sourceSystemName, this.getClass().getName(), e.getMessage());
            throw e;
        }

        // add response header as a property to be used by EndpointInterceptor
        // Current service does not modify header on response
        messageContext.setProperty(HeaderKey.JH_HEADER_KEY.getValue(), header);
        LoggingContextHolder.getLoggingContext().clear();

        return reply;
    }

    /**
     * Gets envelope docs all.
     *
     * @param request         the request
     * @param jhHeaderElement the jh header element
     * @param messageContext  the message context
     *
     * @return the envelope docs all
     *
     * @throws GetEnvelopeDocsAllFault the get envelope docs all fault
     * @throws Exception               the exception
     */
    @PayloadRoot(namespace = NAMESPACE_URI, localPart = "GetEnvelopeDocsAll_request")
    @ResponsePayload
    public GetEnvelopeDocsAllResponse getEnvelopeDocsAll(final @RequestPayload GetEnvelopeDocsAllRequest request,
                                                         final @SoapHeader("{" + JH_HEADER_NS + "}JHHeader") SoapHeaderElement jhHeaderElement,
                                                         final MessageContext messageContext) throws GetEnvelopeDocsAllFault, Exception {

        GetEnvelopeDocsAllResponse reply = null;
        JHHeader header = parseHeader(jhHeaderElement);
        JHHeaderUtils.validateHeader(header);

        final String messageUUID = JHHeaderUtils.retrieveOrDefaultMessageUID(header, "GetProducer");
        final String sourceSystemName = JHHeaderUtils.retrieveOrDefaultSourceSystemName(header);

        try {
            LoggingContextHolder.getLoggingContext().setContext(messageUUID, sourceSystemName);
            LoggerHandler.LogOut("INFO", "1", messageUUID, sourceSystemName, this.getClass().getName(),
                    "Entering getProducer EndPoint " + loggerUtils.writeAsJson(request));

            GetEnvelopeDocsAllResponseWrapper getEnvelopeDocsAllResponseWrapper = docusignEnvelopeOrchestration.getEnvelopeDocsAll(header, request);

            reply = getEnvelopeDocsAllResponseWrapper.getGetEnvelopeDocsAllResponse();

            header = getEnvelopeDocsAllResponseWrapper.getJhHeader();

            LoggerHandler.LogOut("INFO", "5", messageUUID, sourceSystemName, this.getClass().getName(),
                    "Exiting getProducer EndPoint " + loggerUtils.writeAsJson(reply));
        } catch (Exception e) {
            LoggerHandler.ErrorOut(e, messageUUID, sourceSystemName, this.getClass().getName(), e.getMessage());
            throw e;
        }

        // add response header as a property to be used by EndpointInterceptor
        // Current service does not modify header on response
        messageContext.setProperty(HeaderKey.JH_HEADER_KEY.getValue(), header);
        LoggingContextHolder.getLoggingContext().clear();

        return reply;
    }


    private JHHeader parseHeader(final SoapHeaderElement jhHeaderElement) {
        // parse JH Header if present
        JHHeader header = null;
        if (null != jhHeaderElement) {
            header = jhHeaderJaxbUtils.unmarshallJHHeader(jhHeaderElement);
        } else {
            throw new BadRequestException("Missing Header");
        }

        return header;
    }

}