package com.jh.rpc.docusign.utils;

import java.io.PrintWriter;
import java.io.StringWriter;

/**
 * The type Utility.
 */
public class Utility {

    /**
     * Gets stack trace.
     *
     * @param t the t
     *
     * @return the stack trace
     */
    public static String getStackTrace(final Throwable t) {
        final StringWriter sw = new StringWriter();
        t.printStackTrace(new PrintWriter(sw));
        return sw.toString();
    }

}
