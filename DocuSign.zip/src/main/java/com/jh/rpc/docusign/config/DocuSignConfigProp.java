package com.jh.rpc.docusign.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Configuration;

/**
 * The type Docu sign config prop.
 */
@Configuration
//@PropertySource("classpath:custom.properties")
@EnableConfigurationProperties
@ConfigurationProperties(prefix = "docusign")


public class DocuSignConfigProp {

    /**
     * The Accountid.
     */
    String accountid;
    /**
     * The Host.
     */
    String host;
    /**
     * The Port.
     */
    String port;
    /**
     * The Method.
     */
    String method;
    /**
     * The Headeraccept.
     */
    String headeraccept;
    /**
     * The Xdocusignauthentication.
     */
    String xdocusignauthentication;
    /**
     * The Requri.
     */
    String requri;
    /**
     * The Envelopes.
     */
    String envelopes;
    /**
     * The Docid.
     */
    String docid;
    /**
     * The Instanceid.
     */
    String instanceid;
    /**
     * The Subdivisionid.
     */
    String subdivisionid;
    /**
     * The Uridocid.
     */
    String uridocid;
    /**
     * The Allowsoap.
     */
    String allowsoap;
    /**
     * The Auth.
     */
    String auth;
    /**
     * The Sslpassword.
     */
    String sslpassword;
    /**
     * The Connectiontimeout.
     */
    String connectiontimeout;
    /**
     * The Readtimeout.
     */
    String readtimeout;
    /**
     * The Doctype.
     */
    String doctype;
    /**
     * The Docuuser.
     */
    String docuuser;
    /**
     * The Pswd.
     */
    String pswd;
    /**
     * The Integretorkey.
     */
    String integretorkey;

    /**
     * Gets doctype.
     *
     * @return the doctype
     */
    public String getDoctype() {
		return doctype;
	}

    /**
     * Gets docuuser.
     *
     * @return the docuuser
     */
    public String getDocuuser() {
		return docuuser;
	}

    /**
     * Sets docuuser.
     *
     * @param docuuser the docuuser
     */
    public void setDocuuser(String docuuser) {
		this.docuuser = docuuser;
	}

    /**
     * Gets pswd.
     *
     * @return the pswd
     */
    public String getPswd() {
		return pswd;
	}

    /**
     * Sets pswd.
     *
     * @param pswd the pswd
     */
    public void setPswd(String pswd) {
		this.pswd = pswd;
	}

    /**
     * Gets integretorkey.
     *
     * @return the integretorkey
     */
    public String getIntegretorkey() {
		return integretorkey;
	}

    /**
     * Sets integretorkey.
     *
     * @param integretorkey the integretorkey
     */
    public void setIntegretorkey(String integretorkey) {
		this.integretorkey = integretorkey;
	}

    /**
     * Sets doctype.
     *
     * @param doctype the doctype
     */
    public void setDoctype(String doctype) {
		this.doctype = doctype;
	}

    /**
     * Gets connectiontimeout.
     *
     * @return the connectiontimeout
     */
    public String getConnectiontimeout() {
		return connectiontimeout;
	}

    /**
     * Sets connectiontimeout.
     *
     * @param connectiontimeout the connectiontimeout
     */
    public void setConnectiontimeout(String connectiontimeout) {
		this.connectiontimeout = connectiontimeout;
	}

    /**
     * Gets readtimeout.
     *
     * @return the readtimeout
     */
    public String getReadtimeout() {
		return readtimeout;
	}

    /**
     * Sets readtimeout.
     *
     * @param readtimeout the readtimeout
     */
    public void setReadtimeout(String readtimeout) {
		this.readtimeout = readtimeout;
	}

    /**
     * Gets sslpassword.
     *
     * @return the sslpassword
     */
    public String getSslpassword() {
		return sslpassword;
	}

    /**
     * Sets sslpassword.
     *
     * @param sslpassword the sslpassword
     */
    public void setSslpassword(String sslpassword) {
		this.sslpassword = sslpassword;
	}

    /**
     * Gets accountid.
     *
     * @return the accountid
     */
    public String getAccountid() {
		return accountid;
	}

    /**
     * Sets accountid.
     *
     * @param accountid the accountid
     */
    public void setAccountid(String accountid) {
		this.accountid = accountid;
	}

    /**
     * Gets host.
     *
     * @return the host
     */
    public String getHost() {
		return host;
	}

    /**
     * Sets host.
     *
     * @param host the host
     */
    public void setHost(String host) {
		this.host = host;
	}

    /**
     * Gets port.
     *
     * @return the port
     */
    public String getPort() {
		return port;
	}

    /**
     * Sets port.
     *
     * @param port the port
     */
    public void setPort(String port) {
		this.port = port;
	}

    /**
     * Gets method.
     *
     * @return the method
     */
    public String getMethod() {
		return method;
	}

    /**
     * Sets method.
     *
     * @param method the method
     */
    public void setMethod(String method) {
		this.method = method;
	}

    /**
     * Gets headeraccept.
     *
     * @return the headeraccept
     */
    public String getHeaderaccept() {
		return headeraccept;
	}

    /**
     * Sets headeraccept.
     *
     * @param headeraccept the headeraccept
     */
    public void setHeaderaccept(String headeraccept) {
		this.headeraccept = headeraccept;
	}

    /**
     * Gets xdocusignauthentication.
     *
     * @return the xdocusignauthentication
     */
    public String getXdocusignauthentication() {
		return xdocusignauthentication;
	}

    /**
     * Sets xdocusignauthentication.
     *
     * @param xdocusignauthentication the xdocusignauthentication
     */
    public void setXdocusignauthentication(String xdocusignauthentication) {
		this.xdocusignauthentication = xdocusignauthentication;
	}

    /**
     * Gets requri.
     *
     * @return the requri
     */
    public String getRequri() {
		return requri;
	}

    /**
     * Sets requri.
     *
     * @param requri the requri
     */
    public void setRequri(String requri) {
		this.requri = requri;
	}

    /**
     * Gets envelopes.
     *
     * @return the envelopes
     */
    public String getEnvelopes() {
		return envelopes;
	}

    /**
     * Sets envelopes.
     *
     * @param envelopes the envelopes
     */
    public void setEnvelopes(String envelopes) {
		this.envelopes = envelopes;
	}

    /**
     * Gets docid.
     *
     * @return the docid
     */
    public String getDocid() {
		return docid;
	}

    /**
     * Sets docid.
     *
     * @param docid the docid
     */
    public void setDocid(String docid) {
		this.docid = docid;
	}

    /**
     * Gets instanceid.
     *
     * @return the instanceid
     */
    public String getInstanceid() {
		return instanceid;
	}

    /**
     * Sets instanceid.
     *
     * @param instanceid the instanceid
     */
    public void setInstanceid(String instanceid) {
		this.instanceid = instanceid;
	}

    /**
     * Gets subdivisionid.
     *
     * @return the subdivisionid
     */
    public String getSubdivisionid() {
		return subdivisionid;
	}

    /**
     * Sets subdivisionid.
     *
     * @param subdivisionid the subdivisionid
     */
    public void setSubdivisionid(String subdivisionid) {
		this.subdivisionid = subdivisionid;
	}

    /**
     * Gets uridocid.
     *
     * @return the uridocid
     */
    public String getUridocid() {
		return uridocid;
	}

    /**
     * Sets uridocid.
     *
     * @param uridocid the uridocid
     */
    public void setUridocid(String uridocid) {
		this.uridocid = uridocid;
	}

    /**
     * Gets allowsoap.
     *
     * @return the allowsoap
     */
    public String getAllowsoap() {
		return allowsoap;
	}

    /**
     * Sets allowsoap.
     *
     * @param allowsoap the allowsoap
     */
    public void setAllowsoap(String allowsoap) {
		this.allowsoap = allowsoap;
	}

    /**
     * Gets auth.
     *
     * @return the auth
     */
    public String getAuth() {
		return auth;
	}

    /**
     * Sets auth.
     *
     * @param auth the auth
     */
    public void setAuth(String auth) {
		this.auth = auth;
	}

	
}
