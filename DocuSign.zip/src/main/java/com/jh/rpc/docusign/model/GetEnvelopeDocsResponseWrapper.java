package com.jh.rpc.docusign.model;

import com.manulife.esb.xsd.common.jh.header.JHHeader;
import com.manulife.esb.xsd.pfs.jh.docusignenvelopeservice.GetEnvelopeDocsResponse;

/**
 * The type Get envelope docs response wrapper.
 */
public class GetEnvelopeDocsResponseWrapper {

    private GetEnvelopeDocsResponse getEnvelopeDocsResponse;
    private JHHeader jhHeader;

    /**
     * Gets get envelope docs response.
     *
     * @return the get envelope docs response
     */
    public GetEnvelopeDocsResponse getGetEnvelopeDocsResponse() {
        return getEnvelopeDocsResponse;
    }

    /**
     * Sets get envelope docs response.
     *
     * @param getEnvelopeDocsResponse the get envelope docs response
     */
    public void setGetEnvelopeDocsResponse(GetEnvelopeDocsResponse getEnvelopeDocsResponse) {
        this.getEnvelopeDocsResponse = getEnvelopeDocsResponse;
    }

    /**
     * Gets jh header.
     *
     * @return the jh header
     */
    public JHHeader getJhHeader() {
        return jhHeader;
    }

    /**
     * Sets jh header.
     *
     * @param jhHeader the jh header
     */
    public void setJhHeader(JHHeader jhHeader) {
        this.jhHeader = jhHeader;
    }
}
