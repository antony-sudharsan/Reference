
package com.manulife.esb.xsd.pfs.jh.docusignenvelopeservice;

import javax.xml.bind.annotation.*;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/pfs/jh/DocusignEnvelopeService}SubDivisionID" minOccurs="0"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/pfs/jh/DocusignEnvelopeService}Instance" minOccurs="0"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/pfs/jh/DocusignEnvelopeService}Envelope" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "subDivisionID",
    "instance",
    "envelope"
})
@XmlRootElement(name = "GetEnvelopeDocsAll_response")
public class GetEnvelopeDocsAllResponse {

    @XmlElement(name = "SubDivisionID")
    protected String subDivisionID;
    @XmlElement(name = "Instance")
    protected Instance instance;
    @XmlElement(name = "Envelope")
    protected Envelope envelope;

    /**
     * Gets the value of the subDivisionID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSubDivisionID() {
        return subDivisionID;
    }

    /**
     * Sets the value of the subDivisionID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSubDivisionID(String value) {
        this.subDivisionID = value;
    }

    /**
     * Gets the value of the instance property.
     * 
     * @return
     *     possible object is
     *     {@link Instance }
     *     
     */
    public Instance getInstance() {
        return instance;
    }

    /**
     * Sets the value of the instance property.
     * 
     * @param value
     *     allowed object is
     *     {@link Instance }
     *     
     */
    public void setInstance(Instance value) {
        this.instance = value;
    }

    /**
     * Gets the value of the envelope property.
     * 
     * @return
     *     possible object is
     *     {@link Envelope }
     *     
     */
    public Envelope getEnvelope() {
        return envelope;
    }

    /**
     * Sets the value of the envelope property.
     * 
     * @param value
     *     allowed object is
     *     {@link Envelope }
     *     
     */
    public void setEnvelope(Envelope value) {
        this.envelope = value;
    }

}
