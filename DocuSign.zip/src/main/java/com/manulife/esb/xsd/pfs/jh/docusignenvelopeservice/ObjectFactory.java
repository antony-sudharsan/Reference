
package com.manulife.esb.xsd.pfs.jh.docusignenvelopeservice;

import com.manulife.esb.xsd.common.jh.commonmessage.FaultType;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.manulife.esb.xsd.pfs.jh.docusignenvelopeservice package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _Region_QNAME = new QName("http://www.esb.manulife.com/xsd/pfs/jh/DocusignEnvelopeService", "Region");
    private final static QName _Type_QNAME = new QName("http://www.esb.manulife.com/xsd/pfs/jh/DocusignEnvelopeService", "Type");
    private final static QName _Content_QNAME = new QName("http://www.esb.manulife.com/xsd/pfs/jh/DocusignEnvelopeService", "Content");
    private final static QName _SubDivisionID_QNAME = new QName("http://www.esb.manulife.com/xsd/pfs/jh/DocusignEnvelopeService", "SubDivisionID");
    private final static QName _GetContent_QNAME = new QName("http://www.esb.manulife.com/xsd/pfs/jh/DocusignEnvelopeService", "GetContent");
    private final static QName _ID_QNAME = new QName("http://www.esb.manulife.com/xsd/pfs/jh/DocusignEnvelopeService", "ID");
    private final static QName _Fault_QNAME = new QName("http://www.esb.manulife.com/xsd/pfs/jh/DocusignEnvelopeService", "Fault");
    private final static QName _Name_QNAME = new QName("http://www.esb.manulife.com/xsd/pfs/jh/DocusignEnvelopeService", "Name");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.manulife.esb.xsd.pfs.jh.docusignenvelopeservice
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link GetEnvelopeDocsAllResponse }
     * 
     */
    public GetEnvelopeDocsAllResponse createGetEnvelopeDocsAllResponse() {
        return new GetEnvelopeDocsAllResponse();
    }

    /**
     * Create an instance of {@link Instance }
     * 
     */
    public Instance createInstance() {
        return new Instance();
    }

    /**
     * Create an instance of {@link Envelope }
     * 
     */
    public Envelope createEnvelope() {
        return new Envelope();
    }

    /**
     * Create an instance of {@link Documents }
     * 
     */
    public Documents createDocuments() {
        return new Documents();
    }

    /**
     * Create an instance of {@link Document }
     * 
     */
    public Document createDocument() {
        return new Document();
    }

    /**
     * Create an instance of {@link GetEnvelopeDocsResponse }
     * 
     */
    public GetEnvelopeDocsResponse createGetEnvelopeDocsResponse() {
        return new GetEnvelopeDocsResponse();
    }

    /**
     * Create an instance of {@link Request }
     * 
     */
    public Request createRequest() {
        return new Request();
    }

    /**
     * Create an instance of {@link Response }
     * 
     */
    public Response createResponse() {
        return new Response();
    }

    /**
     * Create an instance of {@link GetEnvelopeDocsCombinedResponse }
     * 
     */
    public GetEnvelopeDocsCombinedResponse createGetEnvelopeDocsCombinedResponse() {
        return new GetEnvelopeDocsCombinedResponse();
    }

    /**
     * Create an instance of {@link GetEnvelopeDocsCombinedRequest }
     * 
     */
    public GetEnvelopeDocsCombinedRequest createGetEnvelopeDocsCombinedRequest() {
        return new GetEnvelopeDocsCombinedRequest();
    }

    /**
     * Create an instance of {@link GetEnvelopeDocsFault }
     * 
     */
    public GetEnvelopeDocsFault createGetEnvelopeDocsFault() {
        return new GetEnvelopeDocsFault();
    }

    /**
     * Create an instance of {@link GetEnvelopeDocsAllRequest }
     * 
     */
    public GetEnvelopeDocsAllRequest createGetEnvelopeDocsAllRequest() {
        return new GetEnvelopeDocsAllRequest();
    }

    /**
     * Create an instance of {@link GetEnvelopeDocsRequest }
     * 
     */
    public GetEnvelopeDocsRequest createGetEnvelopeDocsRequest() {
        return new GetEnvelopeDocsRequest();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/pfs/jh/DocusignEnvelopeService", name = "Region")
    public JAXBElement<String> createRegion(String value) {
        return new JAXBElement<String>(_Region_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/pfs/jh/DocusignEnvelopeService", name = "Type")
    public JAXBElement<String> createType(String value) {
        return new JAXBElement<String>(_Type_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/pfs/jh/DocusignEnvelopeService", name = "Content")
    public JAXBElement<String> createContent(String value) {
        return new JAXBElement<String>(_Content_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/pfs/jh/DocusignEnvelopeService", name = "SubDivisionID")
    public JAXBElement<String> createSubDivisionID(String value) {
        return new JAXBElement<String>(_SubDivisionID_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/pfs/jh/DocusignEnvelopeService", name = "GetContent")
    public JAXBElement<String> createGetContent(String value) {
        return new JAXBElement<String>(_GetContent_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/pfs/jh/DocusignEnvelopeService", name = "ID")
    public JAXBElement<String> createID(String value) {
        return new JAXBElement<String>(_ID_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link FaultType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/pfs/jh/DocusignEnvelopeService", name = "Fault")
    public JAXBElement<FaultType> createFault(FaultType value) {
        return new JAXBElement<FaultType>(_Fault_QNAME, FaultType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/pfs/jh/DocusignEnvelopeService", name = "Name")
    public JAXBElement<String> createName(String value) {
        return new JAXBElement<String>(_Name_QNAME, String.class, null, value);
    }

}
