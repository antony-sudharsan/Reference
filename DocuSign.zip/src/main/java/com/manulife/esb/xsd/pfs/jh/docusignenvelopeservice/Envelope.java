
package com.manulife.esb.xsd.pfs.jh.docusignenvelopeservice;

import javax.xml.bind.annotation.*;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/pfs/jh/DocusignEnvelopeService}ID" minOccurs="0"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/pfs/jh/DocusignEnvelopeService}GetContent" minOccurs="0"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/pfs/jh/DocusignEnvelopeService}Documents" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "id",
    "getContent",
    "documents"
})
@XmlRootElement(name = "Envelope")
public class Envelope {

    @XmlElement(name = "ID")
    protected String id;
    @XmlElement(name = "GetContent")
    protected String getContent;
    @XmlElement(name = "Documents")
    protected Documents documents;

    /**
     * Gets the value of the id property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getID() {
        return id;
    }

    /**
     * Sets the value of the id property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setID(String value) {
        this.id = value;
    }

    /**
     * Gets the value of the getContent property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGetContent() {
        return getContent;
    }

    /**
     * Sets the value of the getContent property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGetContent(String value) {
        this.getContent = value;
    }

    /**
     * Gets the value of the documents property.
     * 
     * @return
     *     possible object is
     *     {@link Documents }
     *     
     */
    public Documents getDocuments() {
        return documents;
    }

    /**
     * Sets the value of the documents property.
     * 
     * @param value
     *     allowed object is
     *     {@link Documents }
     *     
     */
    public void setDocuments(Documents value) {
        this.documents = value;
    }

}
