# Email Notification Design Document
## Introduction
    The service enables to send Email Notification.
    
## Operation
Operation|URI|Method
---|---|---
SendEmail|/jh/rps/notification/dst/email/sendemail|POST


## Swagger URL
https://dstemailnotification-dev.apps.cac.preview.pcf.manulife.com/swagger-ui.html

## Audit Point
No|Reference Interpretation
---|---
1|Data received From LTC
2|Data Sent to Promise DB
3|Data Output received from Promise DB
4|Data sent back to LTC

## HTTP Error Codes

Error Code|Error Description
---|---
200|Success
400|Validation Error: Invalid Request
404|Downstream System not reachable
204|Claim record could not be created
500|Internal Service Error
