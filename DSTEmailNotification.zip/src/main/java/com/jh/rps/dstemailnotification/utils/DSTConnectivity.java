package com.jh.rps.dstemailnotification.utils;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;


import javax.net.ssl.HttpsURLConnection;

import org.apache.http.ssl.SSLContextBuilder;
import javax.net.ssl.SSLContext;

import org.springframework.util.ResourceUtils;

/**
 * The type Dst connectivity.
 */
public class DSTConnectivity {

    /**
     * The entry point of application.
     *
     * @param args the input arguments
     */
    public static void main(String[] args) {
		// TODO Auto-generated method stub
				
        try {
        	   String password = "changeit";
               SSLContext sslContext = SSLContextBuilder
                       .create()
                       .loadKeyMaterial(ResourceUtils.getFile("C:\\Users\\deepain\\OneDrive - Manulife\\Attachments\\Certificates\\EmailService\\CACerts.jks"), password.toCharArray(), password.toCharArray())
                       .loadTrustMaterial(ResourceUtils.getFile("C:\\Users\\deepain\\OneDrive - Manulife\\Attachments\\Certificates\\EmailService\\CACerts.jks"), password.toCharArray())
                       .build();
                        
               String URI = "https://www.epriority.com/TransactionMailer?version=1&cid=22315&authDate=2018-02-24T09%3A18%3A05&authMd5=cb4b52e2b3a40c22650cb2e91484dd41&instructions=%3Cbatch%3E%20%09%3Ctemplate%3E%20%09%09%3Ccontent%20charset%20%3D%20%22ISO-8859-1%22%20display%20%3D%20%22body%22%20mfile%20%3D%20%22Label%22%20parse%20%3D%20%22n%22%20type%20%3D%20%22text%2Fhtml%22%3EBody%3C%2Fcontent%3E%20%09%09%3Cheader%3E%20%09%09%09%3Csubject%3ESubject%3C%2Fsubject%3E%20%09%09%09%3Cfrom%20address%20%3D%20%22From%40jhancock.com%22%20name%20%3D%20%22FromFirst%20FromLast%22%2F%3E%20%09%09%09%3Creply%20address%20%3D%20%22replyto%40jhancock.com%22%2F%3E%20%09%09%3C%2Fheader%3E%20%09%09%3Clist%3E%20%09%09%09%3Cemail%20id%20%3D%20%22ToLast%22%20id2%20%3D%20%22123456%22%20id3%20%3D%20%22123456%22%3E%20%09%09%09%09%3Crcpt%20address%20%3D%20%22IDeepak%40jhanock.com%22%20name%20%3D%20%22ToFirst%20ToLast%22%2F%3E%20%09%09%09%3C%2Femail%3E%20%09%09%3C%2Flist%3E%20%09%3C%2Ftemplate%3E%20%3C%2Fbatch%3E";
               //String URI1 = "https://www.epriority.com/TransactionMailer?version=1&cid=22315&authDate=2018-02-24T09%3A18%3A05&authMd5=cb4b52e2b3a40c22650cb2e91484dd41&instructions=<batch> 	<template> 		<content charset = "ISO-8859-1" display = "body" mfile = "Label" parse = "n" type = "text/html">Body</content> 		<header> 			<subject>Subject</subject> 			<from address = "From@jhancock.com" name = "FromFirst FromLast"/> 			<reply address = "replyto@jhancock.com"/> 		</header> 		<list> 			<email id = "ToLast" id2 = "123456" id3 = "123456"> 				<rcpt address = "IDeepak@jhanock.com" name = "ToFirst ToLast"/> 			</email> 		</list> 	</template> </batch>";
               //String postData = "version=1&amp;cid=22315&amp;authDate=2018-02-22T10%3A25%3A14&amp;authMd5=7e9d99560fffc647bf8c3081c8530070&amp;instructions=%3C%3Fxml+version%3D%221.0%22+encoding%3D%22UTF-8%22%3F%3E%0A%3Cbatch%3E%3Ctemplate%3E%3Ccontent+mfile%3D%22Label%22+charset%3D%22ISO-8859-1%22+type%3D%22text%2Fhtml%22+parse%3D%22n%22+display%3D%22body%22%3EBody%3C%2Fcontent%3E%3Cheader%3E%3Csubject%3ESubject%3C%2Fsubject%3E%3Cfrom+address%3D%22From%40jhancock.com%22+name%3D%22FromFirst+FromLast%22%2F%3E%3Creply+address%3D%22replyto%40jhancock.com%22%2F%3E%3C%2Fheader%3E%3Clist%3E%3Cemail+id%3D%22ToLast%22+id2%3D%22123456%22+id3%3D%22123456%22%3E%3Crcpt+address%3D%22pbajpai%40jhanock.com%22+name%3D%22ToFirst+ToLast%22%2F%3E%3C%2Femail%3E%3C%2Flist%3E%3C%2Ftemplate%3E%3C%2Fbatch%3E";
               //int postDataLength = postData.length();
               
               HttpsURLConnection connection = null;
               HttpsURLConnection.setDefaultSSLSocketFactory(sslContext.getSocketFactory());              
               connection = (HttpsURLConnection) new URL(URI).openConnection();                        
               connection.setRequestProperty("Accept", "image/gif, image/x-xbitmap, image/jpeg, image/pjpeg, image/png, */*");
               connection.setRequestProperty("Accept-Charset", "iso-8859-1,*,utf-8");
               connection.setRequestProperty("Accept-Encoding", "gzip");
               connection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded;charset=UTF-8");
               //connection.setRequestProperty("Content-Length", Integer.toString(postDataLength));
               connection.setRequestMethod("GET");
               connection.setDoInput(true);
               connection.setDoOutput(true);            
               DataOutputStream wr = new DataOutputStream(connection.getOutputStream());
               
               //wr.writeBytes(postData);
               wr.flush();
               wr.close();
               
               int responseCode = connection.getResponseCode();
               InputStream response1 = connection.getErrorStream();
               
               System.out.println("\n"+connection.getHeaderFields());
               System.out.println("\n"+connection.getHeaderField("Header"));
               
               System.out.println("\nSending 'POST' request to URL : " + URI);
               //System.out.println("Post Data : " + postData);
               System.out.println("Response Code : " + responseCode);
               System.out.println("Response Message : " + response1);
               
               if(responseCode == 200) { 
	               BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
	               String inputLine;
	               StringBuffer response = new StringBuffer();
	
	               while ((inputLine = in.readLine()) != null) {
	                     response.append(inputLine);
	               }
	               in.close();
	               System.out.println(response.toString());
               }else {
            	   BufferedReader in = new BufferedReader(new InputStreamReader(connection.getErrorStream()));
                   String inputLine;
                   StringBuffer response = new StringBuffer();

                   while ((inputLine = in.readLine()) != null) {
                         response.append(inputLine);
                   }
                   in.close();
                   System.out.println(response.toString());
               }                          
        
        } catch (Exception e) {
               // TODO Auto-generated catch block
               e.printStackTrace();
               
               
               
        }
			

	}

}
