package com.jh.rps.dstemailnotification.constants;

/**
 * The type Email notification constants.
 */
public class EmailNotificationConstants {

    // ####### Error Messages #####################

    /**
     * The constant TECHNICAL_ERROR_REASON.
     */
    public static String TECHNICAL_ERROR_REASON = "Technical Error";
    /**
     * The constant INVALID_INPUT_ERROR_REASON.
     */
    public static String INVALID_INPUT_ERROR_REASON = "Invalid Input";
    /**
     * The constant TIMEOUT_ERROR_REASON.
     */
    public static String TIMEOUT_ERROR_REASON = "Service Timedout";
    /**
     * The constant NO_RECORD_FOUND_ERROR_REASON.
     */
    public static String NO_RECORD_FOUND_ERROR_REASON = "No Data Found";
    /**
     * The constant MAX_RECORD_ERROR_REASON.
     */
    public static String MAX_RECORD_ERROR_REASON = "Max Result Limit Encountered";

    /**
     * The constant LICENSE_SUCESS_MSG.
     */
    public static String LICENSE_SUCESS_MSG = "Success - DocuSignEnvelopeApplication Licensed to Sell";
    /**
     * The constant LICENSE_NOT_FOUND.
     */
    public static String LICENSE_NOT_FOUND = "DocuSignEnvelopeApplication not found in LARS";
    /**
     * The constant LICENSE_ORG_NOT_FOUND.
     */
    public static String LICENSE_ORG_NOT_FOUND = "Organization ID not found in LARS";
    /**
     * The constant LICENSE_ERROR.
     */
    public static String LICENSE_ERROR = "LARS System error occurred";
    /**
     * The constant LICENSE_INVALID_SYS.
     */
    public static String LICENSE_INVALID_SYS = "Invalid Source System";
    /**
     * The constant LICENSE_INVALID_REQ.
     */
    public static String LICENSE_INVALID_REQ = "Invalid Request";
    /**
     * The constant LICENSE_DISPUTE.
     */
    public static String LICENSE_DISPUTE = "DocuSignEnvelopeApplication licence dispute";
    /**
     * The constant PROD_NO_MATCH_FOUND.
     */
    public static String PROD_NO_MATCH_FOUND = "No Match Found for Specific Identifier";
    /**
     * The constant PROD_ORG_MULTIPLE_AGENCY.
     */
    public static String PROD_ORG_MULTIPLE_AGENCY = "Organization has multiple Agency codes";
    /**
     * The constant PROD_ORG_NO_AGENCY.
     */
    public static String PROD_ORG_NO_AGENCY = "Organization has no Agency code";
    /**
     * The constant PROD_NO_AFILLATION.
     */
    public static String PROD_NO_AFILLATION = "No Affiliation found";
    /**
     * The constant PROD_PAYROLL_NOT_ACTIVE.
     */
    public static String PROD_PAYROLL_NOT_ACTIVE = "Payroll number or Contract not active";
    /**
     * The constant PROD_SUCCESS.
     */
    public static String PROD_SUCCESS = "Success";
    // ####### Error Codes #####################

    /**
     * The constant TECHNICAL_ERROR_CODE.
     */
    public static String TECHNICAL_ERROR_CODE = "9999";
    /**
     * The constant INVALID_INPUT_ERROR_CODE.
     */
    public static String INVALID_INPUT_ERROR_CODE = "993";
    /**
     * The constant TIMEOUT_ERROR_CODE.
     */
    public static String TIMEOUT_ERROR_CODE = "99999";
    /**
     * The constant NO_RECORD_FOUND_ERROR_CODE.
     */
    public static String NO_RECORD_FOUND_ERROR_CODE = "999";
    /**
     * The constant MAX_RECORD_ERROR_CODE.
     */
    public static String MAX_RECORD_ERROR_CODE = "998";

    public static String EPRIORITY_URL = "https://www.epriority.com/TransactionMailer";
    public static String KEY_STORE_FILE_NAME = "CACerts.jks";
    public static String KEY_STORE_PASS = "changeit";

    /**
     * Instantiates a new Email notification constants.
     */
    public EmailNotificationConstants() {
    }
}
