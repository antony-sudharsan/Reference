package com.jh.rps.dstemailnotification.model;

import com.manulife.esb.xsd.common.jh.header.JHHeader;
import com.manulife.esb.xsd.rps.jh.sendemail.SendEMailRequest;

/**
 * The type Send e mail request wrapper.
 */
public class SendEMailRequestWrapper {
    private JHHeader jhHeader;

    private SendEMailRequest sendEMailRequest;

    /**
     * Gets jh header.
     *
     * @return the jh header
     */
    public JHHeader getJhHeader() {
        return jhHeader;
    }

    /**
     * Sets jh header.
     *
     * @param jhHeader the jh header
     */
    public void setJhHeader(JHHeader jhHeader) {
        this.jhHeader = jhHeader;
    }

    /**
     * Gets send e mail request.
     *
     * @return the send e mail request
     */
    public SendEMailRequest getSendEMailRequest() {
        return sendEMailRequest;
    }

    /**
     * Sets send e mail request.
     *
     * @param sendEMailRequest the send e mail request
     */
    public void setSendEMailRequest(SendEMailRequest sendEMailRequest) {
        this.sendEMailRequest = sendEMailRequest;
    }
}
