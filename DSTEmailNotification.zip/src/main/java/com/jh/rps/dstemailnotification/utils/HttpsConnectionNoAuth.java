/**
 * 
 */
package com.jh.rps.dstemailnotification.utils;

import com.jh.common.logging.LoggerHandler;
import com.jh.rps.dstemailnotification.constants.EmailNotificationConstants;
import org.apache.http.ssl.SSLContextBuilder;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Component;

import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import java.net.URL;


/**
 * The type Https connection no auth.
 */
@Component
public class HttpsConnectionNoAuth {

    /**
     * Instantiates a new Https connection no auth.
     */
    public HttpsConnectionNoAuth() {
		super();
	}

    /**
     * Gets https connection with no auth.
     *
     * @param queryString the query string
     *
     * @return the https connection with no auth
     */
    public HttpsURLConnection getHttpsConnectionWithNoAuth(String queryString) {
        HttpsURLConnection connection = null;
		try {

             String url = EmailNotificationConstants.EPRIORITY_URL;
              String keystoreFile = EmailNotificationConstants.KEY_STORE_FILE_NAME;
              String keystorePassword = EmailNotificationConstants.KEY_STORE_PASS;

		    System.out.println("The value of tjhe keystoreFile>>"+keystoreFile);
		SSLContext sslContext = SSLContextBuilder.create()
				.loadKeyMaterial(new ClassPathResource(keystoreFile).getFile(), keystorePassword.toCharArray(), keystorePassword.toCharArray())
                .loadTrustMaterial(new ClassPathResource(keystoreFile).getFile(), keystorePassword.toCharArray())
                .build();
		if(queryString.length() > 0) {			
            LoggerHandler.LogOut("INFO", "1", "", "", this.getClass().getName(),
                    "URL: "+ url+"?"+queryString);
		}
		

        HttpsURLConnection.setDefaultSSLSocketFactory(sslContext.getSocketFactory());               
        connection = (HttpsURLConnection) new URL(url+"?"+queryString).openConnection();         
        connection.setRequestProperty("Accept", "image/gif, image/x-xbitmap, image/jpeg, image/pjpeg, image/png, */*");
        connection.setRequestProperty("Accept-Charset", "iso-8859-1,*,utf-8");
        connection.setRequestProperty("Accept-Encoding", "gzip");
        connection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded;charset=UTF-8");
        connection.setRequestMethod("GET");
        connection.setDoInput(true);
        connection.setDoOutput(true);

		}catch(Exception e) {
            LoggerHandler.LogOut("INFO", "1", "", "", this.getClass().getName(),
                    "getHttpsConnectionWithNoAuth " + e.getMessage());
		}
        return connection;
    }
}
