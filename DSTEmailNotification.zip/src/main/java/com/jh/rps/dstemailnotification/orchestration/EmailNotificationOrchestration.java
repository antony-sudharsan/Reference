package com.jh.rps.dstemailnotification.orchestration;

import com.jh.common.logging.LoggerHandler;
import com.jh.rps.dstemailnotification.exception.InvalidInputException;
import com.jh.rps.dstemailnotification.exception.TechnicalErrorException;
import com.jh.rps.dstemailnotification.model.SendEMailReplyWrapper;
import com.jh.rps.dstemailnotification.service.SendEmailService;
import com.jh.rps.dstemailnotification.utils.LoggerUtils;
import com.jh.rps.dstemailnotification.utils.LoggingContextHolder;
import com.manulife.esb.xsd.common.jh.header.JHHeader;
import com.manulife.esb.xsd.rps.jh.sendemail.SendEMailReply;
import com.manulife.esb.xsd.rps.jh.sendemail.SendEMailRequest;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;


/**
 * The type Email notification orchestration.
 */
@Component
public class EmailNotificationOrchestration {

    @Autowired
    private LoggerUtils loggerUtils;


    @Autowired
    private SendEmailService sendEmailService;


    /**
     * Send e mail send e mail reply wrapper.
     *
     * @param header  the header
     * @param request the request
     *
     * @return the send e mail reply wrapper
     *
     * @throws Exception the exception
     */
    public SendEMailReplyWrapper sendEMail(JHHeader header, final SendEMailRequest request) throws Exception {

        final String messageUUID = LoggingContextHolder.getLoggingContext().getMessageUUID();
        final String sourceSystemName = LoggingContextHolder.getLoggingContext().getSourceSystemName();
        SendEMailReplyWrapper reply = new SendEMailReplyWrapper();

        try {
            LoggerHandler.LogOut("INFO", "2", messageUUID, sourceSystemName, this.getClass().getName(),
                    "Entering sendEMail " + loggerUtils.writeAsJson(request));
            SendEMailReply.Status status = sendEmailService.sendEmailMessage(messageUUID, sourceSystemName, request);

            SendEMailReply sendEMailReply = new SendEMailReply();
            sendEMailReply.setStatus(status);
            reply.setSendEMailReply(sendEMailReply);

            reply.setJhHeader(header);
            LoggerHandler.LogOut("INFO", "5", messageUUID, sourceSystemName, this.getClass().getName(),
                    "Exiting getEnvelopeDocs " + loggerUtils.writeAsJson(reply));
        } catch (TechnicalErrorException e) {
            throw e;
        } catch (Exception e) {
            throw new TechnicalErrorException(e.getMessage());
        }
        return reply;
    }


    private String retrieveAndValidateUser(final JHHeader header) {
        final String user = header.getMessageSource().getUserID();
        if (StringUtils.isEmpty(user)) {
            throw new InvalidInputException();
        }
        return user;
    }


}
