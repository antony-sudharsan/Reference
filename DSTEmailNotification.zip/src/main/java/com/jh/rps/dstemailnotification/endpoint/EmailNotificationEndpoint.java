package com.jh.rps.dstemailnotification.endpoint;

import com.jh.common.logging.LoggerHandler;
import com.jh.rps.dstemailnotification.exception.BadRequestException;
import com.jh.rps.dstemailnotification.model.SendEMailReplyWrapper;
import com.jh.rps.dstemailnotification.orchestration.EmailNotificationOrchestration;
import com.jh.rps.dstemailnotification.utils.*;
import com.manulife.esb.xsd.common.jh.header.JHHeader;
import com.manulife.esb.xsd.rps.jh.sendemail.SendEMailReply;
import com.manulife.esb.xsd.rps.jh.sendemail.SendEMailRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ws.context.MessageContext;
import org.springframework.ws.server.endpoint.annotation.Endpoint;
import org.springframework.ws.server.endpoint.annotation.PayloadRoot;
import org.springframework.ws.server.endpoint.annotation.RequestPayload;
import org.springframework.ws.server.endpoint.annotation.ResponsePayload;
import org.springframework.ws.soap.SoapHeaderElement;
import org.springframework.ws.soap.server.endpoint.annotation.SoapHeader;

/**
 * The type Email notification endpoint.
 */
@Endpoint
public class EmailNotificationEndpoint {
    private static final String NAMESPACE_URI = "http://www.esb.manulife.com/xsd/RPS/jh/SendEmail";

    private static final String JH_HEADER_NS = "http://www.esb.manulife.com/xsd/common/jh/header";

    private final JHHeaderJaxbUtils jhHeaderJaxbUtils;
    private final LoggerUtils loggerUtils;

    /**
     * The Email notification orchestration.
     */
    EmailNotificationOrchestration emailNotificationOrchestration;


    /**
     * Instantiates a new Email notification endpoint.
     *
     * @param emailNotificationOrchestration the email notification orchestration
     * @param jhHeaderJaxbUtils              the jh header jaxb utils
     * @param loggerUtils                    the logger utils
     */
    @Autowired
    public EmailNotificationEndpoint(final EmailNotificationOrchestration emailNotificationOrchestration,
                                     final JHHeaderJaxbUtils jhHeaderJaxbUtils, final LoggerUtils loggerUtils) {
        this.emailNotificationOrchestration = emailNotificationOrchestration;
        this.jhHeaderJaxbUtils = jhHeaderJaxbUtils;
        this.loggerUtils = loggerUtils;
    }


    /**
     * Send e mail send e mail reply.
     *
     * @param request         the request
     * @param jhHeaderElement the jh header element
     * @param messageContext  the message context
     *
     * @return the send e mail reply
     *
     * @throws Exception the exception
     */
    @PayloadRoot(namespace = NAMESPACE_URI, localPart = "SendEMail_request")
    @ResponsePayload
    public SendEMailReply sendEMail(final @RequestPayload SendEMailRequest request,
                                          final @SoapHeader("{" + JH_HEADER_NS + "}JHHeader") SoapHeaderElement jhHeaderElement,
                                          final MessageContext messageContext) throws Exception {
        SendEMailReply reply = null;
        JHHeader header = parseHeader(jhHeaderElement);
        JHHeaderUtils.validateHeader(header);

        final String messageUUID = JHHeaderUtils.retrieveOrDefaultMessageUID(header, "CheckLicenseStatus");
        final String sourceSystemName = JHHeaderUtils.retrieveOrDefaultSourceSystemName(header);

        try {
            LoggingContextHolder.getLoggingContext().setContext(messageUUID, sourceSystemName);
            LoggerHandler.LogOut("INFO", "1", messageUUID, sourceSystemName, this.getClass().getName(),
                    "Entering checkLicenseStatus EndPoint " + loggerUtils.writeAsJson(request));

            SendEMailReplyWrapper sendEMailReplyWrapper = emailNotificationOrchestration.sendEMail(header, request);

            reply = sendEMailReplyWrapper.getSendEMailReply();
            header = sendEMailReplyWrapper.getJhHeader();
            LoggerHandler.LogOut("INFO", "6", messageUUID, sourceSystemName, this.getClass().getName(),
                    "Exiting checkLicenseStatus EndPoint " + loggerUtils.writeAsJson(reply));

        } catch (final Exception e) {
            LoggerHandler.ErrorOut(e, messageUUID, sourceSystemName, this.getClass().getName(), e.getMessage());
            throw e;
        }

        // add response header as a property to be used by EndpointInterceptor
        // Current service does not modify header on response
        messageContext.setProperty(HeaderKey.JH_HEADER_KEY.getValue(), header);
        LoggingContextHolder.getLoggingContext().clear();

        return reply;
    }




    private JHHeader parseHeader(final SoapHeaderElement jhHeaderElement) {
        // parse JH Header if present
        JHHeader header = null;
        if (null != jhHeaderElement) {
            header = jhHeaderJaxbUtils.unmarshallJHHeader(jhHeaderElement);
        } else {
            throw new BadRequestException("Missing Header");
        }

        return header;
    }

}