package com.jh.rps.dstemailnotification.exception;

/**
 * The type Exception response.
 */
public class ExceptionResponse {


    private String code;

    private String message;

    private String details;

    /**
     * Instantiates a new Exception response.
     *
     * @param code    the code
     * @param message the message
     * @param details the details
     */
    public ExceptionResponse(String code, String message, String details) {
        super();
        this.code = code;
        this.message = message;
        this.details = details;
    }

    @Override
    public String toString() {
        return "ExceptionResponse [code=" + code + ", message=" + message + ", details=" + details + "]";
    }

    /**
     * Gets code.
     *
     * @return the code
     */
    public String getCode() {
        return code;
    }

    /**
     * Sets code.
     *
     * @param code the code
     */
    public void setCode(String code) {
        this.code = code;
    }

    /**
     * Gets message.
     *
     * @return the message
     */
    public String getMessage() {
        return message;
    }

    /**
     * Sets message.
     *
     * @param message the message
     */
    public void setMessage(String message) {
        this.message = message;
    }

    /**
     * Gets details.
     *
     * @return the details
     */
    public String getDetails() {
        return details;
    }

    /**
     * Sets details.
     *
     * @param details the details
     */
    public void setDetails(String details) {
        this.details = details;
    }


}
