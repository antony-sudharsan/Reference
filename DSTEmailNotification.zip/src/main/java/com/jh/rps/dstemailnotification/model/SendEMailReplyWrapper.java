package com.jh.rps.dstemailnotification.model;

import com.manulife.esb.xsd.common.jh.header.JHHeader;
import com.manulife.esb.xsd.rps.jh.sendemail.SendEMailReply;

/**
 * The type Send e mail reply wrapper.
 */
public class SendEMailReplyWrapper {

    private JHHeader jhHeader;

    private SendEMailReply sendEMailReply;

    /**
     * Gets jh header.
     *
     * @return the jh header
     */
    public JHHeader getJhHeader() {
        return jhHeader;
    }

    /**
     * Sets jh header.
     *
     * @param jhHeader the jh header
     */
    public void setJhHeader(JHHeader jhHeader) {
        this.jhHeader = jhHeader;
    }

    /**
     * Gets send e mail reply.
     *
     * @return the send e mail reply
     */
    public SendEMailReply getSendEMailReply() {
        return sendEMailReply;
    }

    /**
     * Sets send e mail reply.
     *
     * @param sendEMailReply the send e mail reply
     */
    public void setSendEMailReply(SendEMailReply sendEMailReply) {
        this.sendEMailReply = sendEMailReply;
    }
}
