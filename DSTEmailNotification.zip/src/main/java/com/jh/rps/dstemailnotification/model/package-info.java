/**
 * 
 */
/**
 * @author deepain
 *
 */
package com.jh.rps.dstemailnotification.model;