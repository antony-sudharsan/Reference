package com.jh.rps.dstemailnotification.exception;

/**
 * The type Connectivity exception.
 */
public class ConnectivityException extends BaseFaultException {
    private static final long serialVersionUID = -6016805724195451879L;

    private static final String DEFAULT_CODE = "993";
    private static final String DEFAULT_REASON = "Invalid Input";
    private static final String DEFAULT_DETAILS = "Invalid information entered for input.";
    private static final String FAULT_STRING = "Internal Error";

    /**
     * Instantiates a new Connectivity exception.
     */
    public ConnectivityException() {
        super(DEFAULT_CODE, DEFAULT_REASON, DEFAULT_DETAILS, FAULT_STRING);
    }

}
