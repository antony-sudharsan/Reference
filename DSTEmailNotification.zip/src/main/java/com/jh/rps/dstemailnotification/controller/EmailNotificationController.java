package com.jh.rps.dstemailnotification.controller;

import com.jh.common.logging.LoggerHandler;
import com.jh.rps.dstemailnotification.model.SendEMailReplyWrapper;
import com.jh.rps.dstemailnotification.model.SendEMailRequestWrapper;
import com.jh.rps.dstemailnotification.orchestration.EmailNotificationOrchestration;
import com.jh.rps.dstemailnotification.utils.JHHeaderUtils;
import com.jh.rps.dstemailnotification.utils.LoggingContextHolder;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

/**
 * The type Email notification controller.
 */
@RestController
@EnableSwagger2
public class EmailNotificationController {
	
	@Autowired
	private EmailNotificationOrchestration emailNotificationOrchestration;

    /**
     * Send e mail response entity.
     *
     * @param request the request
     *
     * @return the response entity
     *
     * @throws Exception the exception
     */
    @ApiOperation(
			value = "Send Email",
			notes = "Service will Send Email",
			response = SendEMailReplyWrapper.class)
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Success"),
			@ApiResponse(code = 406, message = "Service Processing Error"),
			@ApiResponse(code = 408, message = "Request Timeout"),
			@ApiResponse(code = 500, message = "SQL Server Backend returned an error"),
			@ApiResponse(code = 400, message = "Validation Failed"),
			@ApiResponse(code = 404, message = "Auth data Record not found "),
			@ApiResponse(code = 401, message = "Unauthorized to perform operation")
	})
	@RequestMapping(value = "/jh/rps/notification/dst/email/sendemail", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<SendEMailReplyWrapper> sendEMail(@RequestBody SendEMailRequestWrapper request) throws Exception {

		final String messageUUID = JHHeaderUtils.retrieveOrDefaultMessageUID(request.getJhHeader(),
				"sendEMail");
		final String sourceSystemName = JHHeaderUtils.retrieveOrDefaultSourceSystemName(request.getJhHeader());
		SendEMailReplyWrapper sendEMailReplyWrapper;

		try {
			LoggingContextHolder.getLoggingContext().setContext(messageUUID, sourceSystemName);

			JHHeaderUtils.validateHeader(request.getJhHeader());
			LoggerHandler.LogOut("INFO", "1", messageUUID, sourceSystemName, this.getClass().getName(), "Entering sendEMail Controller");
			sendEMailReplyWrapper = emailNotificationOrchestration.sendEMail(request.getJhHeader(), request.getSendEMailRequest());

			LoggerHandler.LogOut("INFO", "6", messageUUID, sourceSystemName, this.getClass().getName(), "Exiting sendEMail Controller");
			LoggerHandler.LogOut("DEBUG", "6", messageUUID, sourceSystemName, this.getClass().getName(), "Controller Create Success");


		} catch (final Exception e) {
			LoggerHandler.ErrorOut(e, messageUUID, sourceSystemName, this.getClass().getName(), e.getMessage());
			throw e;
		}

		return new ResponseEntity(sendEMailReplyWrapper, new HttpHeaders(), HttpStatus.OK);
	}


}