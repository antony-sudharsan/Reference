/**
 * 
 */
package com.jh.rps.dstemailnotification.model;

import lombok.AllArgsConstructor;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


/**
 * The type Error response.
 */
public class ErrorResponse {
		
	private String Code;
	private String message;
	private String details;

    /**
     * Instantiates a new Error response.
     *
     * @param code    the code
     * @param message the message
     * @param details the details
     */
    public ErrorResponse(String code, String message, String details) {
        Code = code;
        this.message = message;
        this.details = details;
    }

    /**
     * Gets code.
     *
     * @return the code
     */
    public String getCode() {
		return Code;
	}

    /**
     * Sets code.
     *
     * @param code the code
     */
    public void setCode(String code) {
		Code = code;
	}

    /**
     * Gets message.
     *
     * @return the message
     */
    public String getMessage() {
		return message;
	}

    /**
     * Sets message.
     *
     * @param message the message
     */
    public void setMessage(String message) {
		this.message = message;
	}

    /**
     * Gets details.
     *
     * @return the details
     */
    public String getDetails() {
		return details;
	}

    /**
     * Sets details.
     *
     * @param details the details
     */
    public void setDetails(String details) {
		this.details = details;
	}
}
