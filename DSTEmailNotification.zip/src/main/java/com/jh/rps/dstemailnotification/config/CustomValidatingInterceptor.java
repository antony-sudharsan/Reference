package com.jh.rps.dstemailnotification.config;

import com.jh.rps.dstemailnotification.exception.InvalidInputException;
import org.springframework.core.io.ClassPathResource;
import org.springframework.ws.WebServiceMessage;
import org.springframework.ws.soap.server.endpoint.interceptor.PayloadValidatingInterceptor;
import org.xml.sax.SAXException;

import javax.xml.transform.Source;
import javax.xml.transform.dom.DOMResult;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import javax.xml.validation.Validator;
import java.io.IOException;

/**
 * The type Custom validating interceptor.
 */
public class CustomValidatingInterceptor extends PayloadValidatingInterceptor {

    protected Source getValidationRequestSource(WebServiceMessage request) {
        Source source = request.getPayloadSource();
        try {
            validateSchema(source);
        } catch (Exception e){
            throw new InvalidInputException();
        }
        return source;
    }

    private void validateSchema(Source source) throws SAXException, IOException {
        SchemaFactory schemaFactory = SchemaFactory.newInstance(getSchemaLanguage());
        try {
            Schema schema = schemaFactory.newSchema(new ClassPathResource("EmailService.xsd").getFile());
            Validator validator = schema.newValidator();
            DOMResult result = new DOMResult();
            validator.validate(source, result);


        } catch (SAXException ex) {
           throw ex;
        } catch (Exception ex) {
            throw ex;
        }
    }
}