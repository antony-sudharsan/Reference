/**
 *
 */
package com.jh.rps.dstemailnotification.service;

import com.jh.common.logging.LoggerHandler;
import com.jh.rps.dstemailnotification.exception.TechnicalErrorException;
import com.jh.rps.dstemailnotification.model.Batch;
import com.jh.rps.dstemailnotification.model.Batch.Template.List.Email;
import com.jh.rps.dstemailnotification.utils.HttpsConnectionNoAuth;
import com.jh.rps.dstemailnotification.utils.LoggerUtils;
import com.manulife.esb.xsd.rps.jh.sendemail.SendEMailReply;
import com.manulife.esb.xsd.rps.jh.sendemail.SendEMailRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.net.ssl.HttpsURLConnection;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;
import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.InputStreamReader;
import java.io.StringWriter;
import java.security.MessageDigest;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;


/**
 * The type Send email service.
 */
@Component
public class SendEmailService {

    @Autowired
    private LoggerUtils loggerUtils;

    /**
     * Send email message send e mail reply . status.
     *
     * @param messageUUID      the message uuid
     * @param sourceSystemName the source system name
     * @param email            the email
     *
     * @return the send e mail reply . status
     */
    public SendEMailReply.Status sendEmailMessage(String messageUUID, String sourceSystemName, SendEMailRequest email)  {

        SendEMailReply.Status status;
        try {

            LoggerHandler.LogOut("INFO", "3", messageUUID, sourceSystemName, this.getClass().getName(),
                    "Entering sendEmailMessage " + loggerUtils.writeAsJson(email));

            String queryString = generateDstInputQueryString(messageUUID, sourceSystemName, email);

            status = invokeDST(messageUUID, sourceSystemName, queryString);

            LoggerHandler.LogOut("INFO", "4", messageUUID, sourceSystemName, this.getClass().getName(),
                    "Entering invokeDST " + loggerUtils.writeAsJson(status));
            return status;

        } catch (TechnicalErrorException implEx) {
            throw implEx;
        } catch (Exception e) {

            LoggerHandler.ErrorOut(e, messageUUID, sourceSystemName, this.getClass().getName(), email.toString());
            throw new TechnicalErrorException("Error Occured While Sending Email", e);
        }
    }

    /**
     *
     * @param messageUUID
     * @param sourceSystemName
     * @param queryString
     * @return
     */

    public SendEMailReply.Status invokeDST(String messageUUID, String sourceSystemName, String queryString) {
        try {
            LoggerHandler.LogOut("INFO", "3c", messageUUID, sourceSystemName, this.getClass().getName(),
                    "Entering invokeDST " + queryString);
            SendEMailReply.Status status = new SendEMailReply.Status();
            String inputLine;
            StringBuffer response = new StringBuffer();
            HttpsURLConnection connection = new HttpsConnectionNoAuth().getHttpsConnectionWithNoAuth(queryString);
            DataOutputStream wr = new DataOutputStream(connection.getOutputStream());
            wr.flush();
            wr.close();

            int responseCode = connection.getResponseCode();

            if (responseCode == 200) {
                BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                while ((inputLine = in.readLine()) != null) {
                    response.append(inputLine);
                }
                in.close();
                status.setCode("0");
                status.setMessage("Email Send Success");
            } else {
                BufferedReader in = new BufferedReader(new InputStreamReader(connection.getErrorStream()));
                while ((inputLine = in.readLine()) != null) {
                    response.append(inputLine);
                }
                in.close();
                throw new TechnicalErrorException("DST Service Error -Service not available Response Code from DST" + responseCode);
            }
            LoggerHandler.LogOut("INFO", "3d", messageUUID, sourceSystemName, this.getClass().getName(),
                    "Entering invokeDST " + loggerUtils.writeAsJson(status));
            return status;
        } catch (TechnicalErrorException implEx) {
            throw implEx;
        } catch (Exception e) {
            /**
             * Exception while Invoking DST service
             */
            e.printStackTrace();
            LoggerHandler.ErrorOut(e, messageUUID, sourceSystemName, this.getClass().getName(), "DST Invocation failed : " + e.toString());
            throw new TechnicalErrorException("DST Service Error -Service not available", e);
        }
    }

    /**
     *
     * @param messageUUID
     * @param sourceSystemName
     * @param authDate
     * @param webApiPassword
     * @return
     */

    private String generateMD5DigestToken(String messageUUID, String sourceSystemName, String authDate, String webApiPassword) {
        try {
            LoggerHandler.LogOut("DEBUG", "1e", messageUUID, sourceSystemName, this.getClass().getName(), "AuthenticationDate: " + authDate + " , webApiPassword: " + webApiPassword);

            String strDigestString = authDate + webApiPassword;
            MessageDigest md = MessageDigest.getInstance("MD5");
            byte[] hash = md.digest(strDigestString.getBytes());
            StringBuffer buf = new StringBuffer(hash.length * 2);
            for (int i = 0; i < hash.length; i++) {
                //don't forget the second hex digit
                if (((int) hash[i] & 0xff) < 0x10) {
                    buf.append("0");
                }
                buf.append(Long.toString((int) hash[i] & 0xff, 16));
            }
            /**
             * MD5DigestToken generation completed
             */
            LoggerHandler.LogOut("DEBUG", "1f", messageUUID, sourceSystemName, this.getClass().getName(), "***MD5Digesttoken: " + buf.toString() + " :***");
            return buf.toString();

        } catch (Exception e) {
            /**
             * Exception while MD5DigestToken generation
             */
            LoggerHandler.ErrorOut(e, messageUUID, sourceSystemName, this.getClass().getName(), "AuthenticationDate: " + authDate + " , webApiPassword: " + webApiPassword);
            throw new TechnicalErrorException("MD5 Digest token generation failed", e);
        }
    }

    /**
     *
     * @param messageUUID
     * @param sourceSystemName
     * @param email
     * @return
     */
    public String generateDstInputQueryString(String messageUUID, String sourceSystemName, SendEMailRequest email)  {

        LoggerHandler.LogOut("INFO", "3a", messageUUID, sourceSystemName, this.getClass().getName(),
                "Entering generateDstInputQueryString " + loggerUtils.writeAsJson(email));

        String queryString = "";
        try {
            /**
             * Starting HTTPRequest queryString generation
             */
            LoggerHandler.LogOut("DEBUG", "1b", messageUUID, sourceSystemName, this.getClass().getName(), email.toString());
            String authDate = LocalDateTime.now().toString().substring(0, 19);

            JAXBContext jaxbContext = JAXBContext.newInstance(Batch.class);
            Marshaller jaxbMarshaller = jaxbContext.createMarshaller();
            StringWriter sw = new StringWriter();
            jaxbMarshaller.marshal(generateBatchObject(messageUUID, sourceSystemName, email), sw);
            String instructions = sw.toString();

            /**
             * Replacing Special Characters
             */
            instructions = instructions.replaceAll("<", "%3C").replace("?", "%3F").replaceAll(" ", "%20").replaceAll("=", "%3D").replaceAll(">", "%3E").replaceAll("/", "%2F").replaceAll("@", "%40").replaceAll("\"", "%22");

            String Version = "version=1";
            String CID = "cid=22315";
            String AuthDate = "authDate=" + authDate;
            String AuthMd5 = "authMd5=" + generateMD5DigestToken(messageUUID, sourceSystemName, authDate, "Daje-277buqd");
            String Instructions = "instructions=" + instructions;
            queryString = Version + "&" + CID + "&" + AuthDate + "&" + AuthMd5 + "&" + Instructions;

            /**
             * HTTPRequest queryString generation completed
             */
            LoggerHandler.LogOut("INFO", "3b", messageUUID, sourceSystemName, this.getClass().getName(),
                    "GenerateDstInputQueryString >" + queryString);

            return queryString;

        } catch (Exception e) {
            /**
             * Exception while HTTP Request QueryString generation
             */
            LoggerHandler.ErrorOut(e, messageUUID, sourceSystemName, this.getClass().getName(), "Query String generation failed : " + e);

            throw new TechnicalErrorException("Query String generation failed", e);
        }

    }

    /**
     *
     * @param messageUUID
     * @param sourceSystemName
     * @param email
     * @return
     */

    private Batch generateBatchObject(String messageUUID, String sourceSystemName, SendEMailRequest email)  {

        try {
            /**
             * Starting Batch XML generation
             */
            LoggerHandler.LogOut("DEBUG", "1c", messageUUID, sourceSystemName, this.getClass().getName(), email.toString());

            Batch batch = new Batch();

            //Creating Template.Content object
            Batch.Template.Content content = new Batch.Template.Content();
            System.out.println("Email-->Message-->Body: " + email.getMessage().getBody());
            content.setValue(email.getMessage().getBody());
            content.setMfile(email.getMessage().getLabel());
            content.setCharset("ISO-8859-1");
            content.setType("text/html");
            content.setParse("n");
            content.setDisplay("body");
            List<Batch.Template.Content> contentList = new ArrayList<Batch.Template.Content>();
            contentList.add(content);

            //Creating Template.Header.From object
            Batch.Template.Header.From headerFrom = new Batch.Template.Header.From();
            headerFrom.setName(email.getSender().getFromFirstName() + " " + email.getSender().getFromLastName());
            headerFrom.setAddress(email.getSender().getFrom());

            //Creating template.Header.Reply object
            Batch.Template.Header.Reply headerReply = new Batch.Template.Header.Reply();
            headerReply.setAddress(email.getSender().getReplyTo());

            //Creating Template.Header object
            Batch.Template.Header header = new Batch.Template.Header();
            header.setSubject(email.getMessage().getSubject());
            header.setFrom(headerFrom);
            header.setReply(headerReply);

            //Creating template.list.email.receipt object
            Batch.Template.List.Email.Rcpt receipt = new Batch.Template.List.Email.Rcpt();
            receipt.setAddress(email.getRecipient().getTo());
            receipt.setName(email.getRecipient().getToFirstName() + " " + email.getRecipient().getToLastName());

            //Creating template.list.email.receipt object
            Email eml = new Email();
            String filteredLastName = email.getRecipient().getToLastName().replace(email.getRecipient().getToLastName().replace("${lastnameformat}", ""), "");
            eml.setId(filteredLastName);
            eml.setId2(email.getRequestor().getContractNumber());
            eml.setId3(email.getRecipient().getPersonId());
            eml.setRcpt(receipt);

            List<Email> emlList = new ArrayList<Email>();
            emlList.add(eml);
            Batch.Template.List list = new Batch.Template.List();
            list.setEmail(emlList);

            //Collating Batch.Template object

            Batch.Template template = new Batch.Template();
            template.setHeader(header);
            template.setList(list);
            template.setContent(contentList);
            List<Object> templateList = new ArrayList<Object>();
            templateList.add(template);
            batch.setTemplateOrSmstemplate(templateList);

            /**
             * Batch XML generation completed
             */
            LoggerHandler.LogOut("DEBUG", "1d", messageUUID, sourceSystemName, this.getClass().getName(), "Batch XML generation completed: " + batch);
            return batch;
        } catch (Exception e) {
            /**
             * Exception while generating Batch xml
             */
            LoggerHandler.ErrorOut(e, messageUUID, sourceSystemName, this.getClass().getName(), "Query Xml generation failed : " + e.toString());
            throw new TechnicalErrorException("Query Xml generation failed", e);

        }
    }

}
