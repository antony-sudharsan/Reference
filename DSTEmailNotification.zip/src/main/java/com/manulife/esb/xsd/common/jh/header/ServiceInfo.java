
package com.manulife.esb.xsd.common.jh.header;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * The type Service info.
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ServiceInfo", propOrder = {
    "serviceName",
    "serviceVersion",
    "serviceOperation"
})
public class ServiceInfo {

    /**
     * The Service name.
     */
    @XmlElement(name = "ServiceName", required = true)
    protected String serviceName;
    /**
     * The Service version.
     */
    @XmlElement(name = "ServiceVersion", required = true)
    protected String serviceVersion;
    /**
     * The Service operation.
     */
    @XmlElement(name = "ServiceOperation", required = true)
    protected String serviceOperation;

    /**
     * Gets service name.
     *
     * @return the service name
     */
    public String getServiceName() {
        return serviceName;
    }

    /**
     * Sets service name.
     *
     * @param value the value
     */
    public void setServiceName(String value) {
        this.serviceName = value;
    }

    /**
     * Gets service version.
     *
     * @return the service version
     */
    public String getServiceVersion() {
        return serviceVersion;
    }

    /**
     * Sets service version.
     *
     * @param value the value
     */
    public void setServiceVersion(String value) {
        this.serviceVersion = value;
    }

    /**
     * Gets service operation.
     *
     * @return the service operation
     */
    public String getServiceOperation() {
        return serviceOperation;
    }

    /**
     * Sets service operation.
     *
     * @param value the value
     */
    public void setServiceOperation(String value) {
        this.serviceOperation = value;
    }

}
