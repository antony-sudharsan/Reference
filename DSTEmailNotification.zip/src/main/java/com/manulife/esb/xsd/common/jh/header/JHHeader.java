
package com.manulife.esb.xsd.common.jh.header;

import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * The type Jh header.
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "version",
    "conversationUID",
    "messageUID",
    "relatesTo",
    "messageType",
    "originalMessageDateTime",
    "currentMessageDateTime",
    "messageSource",
    "serviceInfo",
    "status",
    "environmentID",
    "requestTimeOut"
})
@XmlRootElement(name = "JHHeader")
public class JHHeader {

    /**
     * The Version.
     */
    @XmlElement(name = "Version", required = true)
    protected String version;
    /**
     * The Conversation uid.
     */
    @XmlElement(name = "ConversationUID", required = true)
    protected String conversationUID;
    /**
     * The Message uid.
     */
    @XmlElement(name = "MessageUID", required = true)
    protected String messageUID;
    /**
     * The Relates to.
     */
    @XmlElement(name = "RelatesTo", required = true)
    protected String relatesTo;
    /**
     * The Message type.
     */
    @XmlElement(name = "MessageType", required = true)
    protected String messageType;
    /**
     * The Original message date time.
     */
    @XmlElement(name = "OriginalMessageDateTime", required = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar originalMessageDateTime;
    /**
     * The Current message date time.
     */
    @XmlElement(name = "CurrentMessageDateTime", required = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar currentMessageDateTime;
    /**
     * The Message source.
     */
    @XmlElement(name = "MessageSource", required = true)
    protected MessageSource messageSource;
    /**
     * The Service info.
     */
    @XmlElement(name = "ServiceInfo", required = true)
    protected ServiceInfo serviceInfo;
    /**
     * The Status.
     */
    @XmlElement(name = "Status")
    protected Status status;
    /**
     * The Environment id.
     */
    @XmlElement(name = "EnvironmentID", nillable = true)
    protected String environmentID;
    /**
     * The Request time out.
     */
    @XmlElement(name = "RequestTimeOut")
    protected BigDecimal requestTimeOut;

    /**
     * Gets version.
     *
     * @return the version
     */
    public String getVersion() {
        return version;
    }

    /**
     * Sets version.
     *
     * @param value the value
     */
    public void setVersion(String value) {
        this.version = value;
    }

    /**
     * Gets conversation uid.
     *
     * @return the conversation uid
     */
    public String getConversationUID() {
        return conversationUID;
    }

    /**
     * Sets conversation uid.
     *
     * @param value the value
     */
    public void setConversationUID(String value) {
        this.conversationUID = value;
    }

    /**
     * Gets message uid.
     *
     * @return the message uid
     */
    public String getMessageUID() {
        return messageUID;
    }

    /**
     * Sets message uid.
     *
     * @param value the value
     */
    public void setMessageUID(String value) {
        this.messageUID = value;
    }

    /**
     * Gets relates to.
     *
     * @return the relates to
     */
    public String getRelatesTo() {
        return relatesTo;
    }

    /**
     * Sets relates to.
     *
     * @param value the value
     */
    public void setRelatesTo(String value) {
        this.relatesTo = value;
    }

    /**
     * Gets message type.
     *
     * @return the message type
     */
    public String getMessageType() {
        return messageType;
    }

    /**
     * Sets message type.
     *
     * @param value the value
     */
    public void setMessageType(String value) {
        this.messageType = value;
    }

    /**
     * Gets original message date time.
     *
     * @return the original message date time
     */
    public XMLGregorianCalendar getOriginalMessageDateTime() {
        return originalMessageDateTime;
    }

    /**
     * Sets original message date time.
     *
     * @param value the value
     */
    public void setOriginalMessageDateTime(XMLGregorianCalendar value) {
        this.originalMessageDateTime = value;
    }

    /**
     * Gets current message date time.
     *
     * @return the current message date time
     */
    public XMLGregorianCalendar getCurrentMessageDateTime() {
        return currentMessageDateTime;
    }

    /**
     * Sets current message date time.
     *
     * @param value the value
     */
    public void setCurrentMessageDateTime(XMLGregorianCalendar value) {
        this.currentMessageDateTime = value;
    }

    /**
     * Gets message source.
     *
     * @return the message source
     */
    public MessageSource getMessageSource() {
        return messageSource;
    }

    /**
     * Sets message source.
     *
     * @param value the value
     */
    public void setMessageSource(MessageSource value) {
        this.messageSource = value;
    }

    /**
     * Gets service info.
     *
     * @return the service info
     */
    public ServiceInfo getServiceInfo() {
        return serviceInfo;
    }

    /**
     * Sets service info.
     *
     * @param value the value
     */
    public void setServiceInfo(ServiceInfo value) {
        this.serviceInfo = value;
    }

    /**
     * Gets status.
     *
     * @return the status
     */
    public Status getStatus() {
        return status;
    }

    /**
     * Sets status.
     *
     * @param value the value
     */
    public void setStatus(Status value) {
        this.status = value;
    }

    /**
     * Gets environment id.
     *
     * @return the environment id
     */
    public String getEnvironmentID() {
        return environmentID;
    }

    /**
     * Sets environment id.
     *
     * @param value the value
     */
    public void setEnvironmentID(String value) {
        this.environmentID = value;
    }

    /**
     * Gets request time out.
     *
     * @return the request time out
     */
    public BigDecimal getRequestTimeOut() {
        return requestTimeOut;
    }

    /**
     * Sets request time out.
     *
     * @param value the value
     */
    public void setRequestTimeOut(BigDecimal value) {
        this.requestTimeOut = value;
    }

}
