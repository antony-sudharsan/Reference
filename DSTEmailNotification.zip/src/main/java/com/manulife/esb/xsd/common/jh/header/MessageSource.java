
package com.manulife.esb.xsd.common.jh.header;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * The type Message source.
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "MessageSource", propOrder = {
    "applicationName",
    "hostName",
    "applicationUserID",
    "userID",
    "processID"
})
public class MessageSource {

    /**
     * The Application name.
     */
    @XmlElement(name = "ApplicationName", required = true)
    protected String applicationName;
    /**
     * The Host name.
     */
    @XmlElement(name = "HostName", required = true)
    protected String hostName;
    /**
     * The Application user id.
     */
    @XmlElement(name = "ApplicationUserID")
    protected String applicationUserID;
    /**
     * The User id.
     */
    @XmlElement(name = "UserID")
    protected String userID;
    /**
     * The Process id.
     */
    @XmlElement(name = "ProcessID")
    protected String processID;

    /**
     * Gets application name.
     *
     * @return the application name
     */
    public String getApplicationName() {
        return applicationName;
    }

    /**
     * Sets application name.
     *
     * @param value the value
     */
    public void setApplicationName(String value) {
        this.applicationName = value;
    }

    /**
     * Gets host name.
     *
     * @return the host name
     */
    public String getHostName() {
        return hostName;
    }

    /**
     * Sets host name.
     *
     * @param value the value
     */
    public void setHostName(String value) {
        this.hostName = value;
    }

    /**
     * Gets application user id.
     *
     * @return the application user id
     */
    public String getApplicationUserID() {
        return applicationUserID;
    }

    /**
     * Sets application user id.
     *
     * @param value the value
     */
    public void setApplicationUserID(String value) {
        this.applicationUserID = value;
    }

    /**
     * Gets user id.
     *
     * @return the user id
     */
    public String getUserID() {
        return userID;
    }

    /**
     * Sets user id.
     *
     * @param value the value
     */
    public void setUserID(String value) {
        this.userID = value;
    }

    /**
     * Gets process id.
     *
     * @return the process id
     */
    public String getProcessID() {
        return processID;
    }

    /**
     * Sets process id.
     *
     * @param value the value
     */
    public void setProcessID(String value) {
        this.processID = value;
    }

}
