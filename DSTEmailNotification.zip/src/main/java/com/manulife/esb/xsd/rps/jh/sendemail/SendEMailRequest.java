
package com.manulife.esb.xsd.rps.jh.sendemail;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * The type Send e mail request.
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "requestor",
    "recipient",
    "sender",
    "message"
})
@XmlRootElement(name = "SendEMail_request")
public class SendEMailRequest {

    /**
     * The Requestor.
     */
    @XmlElement(name = "Requestor", required = true)
    protected SendEMailRequest.Requestor requestor;
    /**
     * The Recipient.
     */
    @XmlElement(name = "Recipient", required = true)
    protected SendEMailRequest.Recipient recipient;
    /**
     * The Sender.
     */
    @XmlElement(name = "Sender", required = true)
    protected SendEMailRequest.Sender sender;
    /**
     * The Message.
     */
    @XmlElement(name = "Message", required = true)
    protected SendEMailRequest.Message message;

    /**
     * Gets requestor.
     *
     * @return the requestor
     */
    public SendEMailRequest.Requestor getRequestor() {
        return requestor;
    }

    /**
     * Sets requestor.
     *
     * @param value the value
     */
    public void setRequestor(SendEMailRequest.Requestor value) {
        this.requestor = value;
    }

    /**
     * Gets recipient.
     *
     * @return the recipient
     */
    public SendEMailRequest.Recipient getRecipient() {
        return recipient;
    }

    /**
     * Sets recipient.
     *
     * @param value the value
     */
    public void setRecipient(SendEMailRequest.Recipient value) {
        this.recipient = value;
    }

    /**
     * Gets sender.
     *
     * @return the sender
     */
    public SendEMailRequest.Sender getSender() {
        return sender;
    }

    /**
     * Sets sender.
     *
     * @param value the value
     */
    public void setSender(SendEMailRequest.Sender value) {
        this.sender = value;
    }

    /**
     * Gets message.
     *
     * @return the message
     */
    public SendEMailRequest.Message getMessage() {
        return message;
    }

    /**
     * Sets message.
     *
     * @param value the value
     */
    public void setMessage(SendEMailRequest.Message value) {
        this.message = value;
    }


    /**
     * The type Message.
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "messageId",
        "subject",
        "body",
        "label",
        "templateName"
    })
    public static class Message {

        /**
         * The Message id.
         */
        @XmlElement(name = "MessageId", required = true)
        protected String messageId;
        /**
         * The Subject.
         */
        @XmlElement(name = "Subject", required = true)
        protected String subject;
        /**
         * The Body.
         */
        @XmlElement(name = "Body", required = true)
        protected String body;
        /**
         * The Label.
         */
        @XmlElement(name = "Label", required = true)
        protected String label;
        /**
         * The Template name.
         */
        @XmlElement(name = "TemplateName", required = true)
        protected String templateName;

        /**
         * Gets message id.
         *
         * @return the message id
         */
        public String getMessageId() {
            return messageId;
        }

        /**
         * Sets message id.
         *
         * @param value the value
         */
        public void setMessageId(String value) {
            this.messageId = value;
        }

        /**
         * Gets subject.
         *
         * @return the subject
         */
        public String getSubject() {
            return subject;
        }

        /**
         * Sets subject.
         *
         * @param value the value
         */
        public void setSubject(String value) {
            this.subject = value;
        }

        /**
         * Gets body.
         *
         * @return the body
         */
        public String getBody() {
            return body;
        }

        /**
         * Sets body.
         *
         * @param value the value
         */
        public void setBody(String value) {
            this.body = value;
        }

        /**
         * Gets label.
         *
         * @return the label
         */
        public String getLabel() {
            return label;
        }

        /**
         * Sets label.
         *
         * @param value the value
         */
        public void setLabel(String value) {
            this.label = value;
        }

        /**
         * Gets template name.
         *
         * @return the template name
         */
        public String getTemplateName() {
            return templateName;
        }

        /**
         * Sets template name.
         *
         * @param value the value
         */
        public void setTemplateName(String value) {
            this.templateName = value;
        }

    }


    /**
     * The type Recipient.
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "personId",
        "toFirstName",
        "toLastName",
        "to"
    })
    public static class Recipient {

        /**
         * The Person id.
         */
        @XmlElement(name = "PersonId", required = true)
        protected String personId;
        /**
         * The To first name.
         */
        @XmlElement(name = "To_FirstName", required = true)
        protected String toFirstName;
        /**
         * The To last name.
         */
        @XmlElement(name = "To_LastName", required = true)
        protected String toLastName;
        /**
         * The To.
         */
        @XmlElement(name = "To", required = true)
        protected String to;

        /**
         * Gets person id.
         *
         * @return the person id
         */
        public String getPersonId() {
            return personId;
        }

        /**
         * Sets person id.
         *
         * @param value the value
         */
        public void setPersonId(String value) {
            this.personId = value;
        }

        /**
         * Gets to first name.
         *
         * @return the to first name
         */
        public String getToFirstName() {
            return toFirstName;
        }

        /**
         * Sets to first name.
         *
         * @param value the value
         */
        public void setToFirstName(String value) {
            this.toFirstName = value;
        }

        /**
         * Gets to last name.
         *
         * @return the to last name
         */
        public String getToLastName() {
            return toLastName;
        }

        /**
         * Sets to last name.
         *
         * @param value the value
         */
        public void setToLastName(String value) {
            this.toLastName = value;
        }

        /**
         * Gets to.
         *
         * @return the to
         */
        public String getTo() {
            return to;
        }

        /**
         * Sets to.
         *
         * @param value the value
         */
        public void setTo(String value) {
            this.to = value;
        }

    }


    /**
     * The type Requestor.
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "division",
        "contractNumber"
    })
    public static class Requestor {

        /**
         * The Division.
         */
        @XmlElement(name = "Division", required = true)
        protected String division;
        /**
         * The Contract number.
         */
        @XmlElement(name = "ContractNumber", required = true)
        protected String contractNumber;

        /**
         * Gets division.
         *
         * @return the division
         */
        public String getDivision() {
            return division;
        }

        /**
         * Sets division.
         *
         * @param value the value
         */
        public void setDivision(String value) {
            this.division = value;
        }

        /**
         * Gets contract number.
         *
         * @return the contract number
         */
        public String getContractNumber() {
            return contractNumber;
        }

        /**
         * Sets contract number.
         *
         * @param value the value
         */
        public void setContractNumber(String value) {
            this.contractNumber = value;
        }

    }


    /**
     * The type Sender.
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "fromFirstName",
        "fromLastName",
        "from",
        "replyTo"
    })
    public static class Sender {

        /**
         * The From first name.
         */
        @XmlElement(name = "From_FirstName", required = true)
        protected String fromFirstName;
        /**
         * The From last name.
         */
        @XmlElement(name = "From_LastName", required = true)
        protected String fromLastName;
        /**
         * The From.
         */
        @XmlElement(name = "From", required = true)
        protected String from;
        /**
         * The Reply to.
         */
        @XmlElement(name = "ReplyTo")
        protected String replyTo;

        /**
         * Gets from first name.
         *
         * @return the from first name
         */
        public String getFromFirstName() {
            return fromFirstName;
        }

        /**
         * Sets from first name.
         *
         * @param value the value
         */
        public void setFromFirstName(String value) {
            this.fromFirstName = value;
        }

        /**
         * Gets from last name.
         *
         * @return the from last name
         */
        public String getFromLastName() {
            return fromLastName;
        }

        /**
         * Sets from last name.
         *
         * @param value the value
         */
        public void setFromLastName(String value) {
            this.fromLastName = value;
        }

        /**
         * Gets from.
         *
         * @return the from
         */
        public String getFrom() {
            return from;
        }

        /**
         * Sets from.
         *
         * @param value the value
         */
        public void setFrom(String value) {
            this.from = value;
        }

        /**
         * Gets reply to.
         *
         * @return the reply to
         */
        public String getReplyTo() {
            return replyTo;
        }

        /**
         * Sets reply to.
         *
         * @param value the value
         */
        public void setReplyTo(String value) {
            this.replyTo = value;
        }

    }

}
