
package com.manulife.esb.xsd.common.jh.commonmessage;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * The type Object factory.
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _Fault_QNAME = new QName("http://www.esb.manulife.com/xsd/common/jh/CommonMessage", "Fault");
    private final static QName _RequestHeader_QNAME = new QName("http://www.esb.manulife.com/xsd/common/jh/CommonMessage", "RequestHeader");
    private final static QName _ResponseHeader_QNAME = new QName("http://www.esb.manulife.com/xsd/common/jh/CommonMessage", "ResponseHeader");

    /**
     * Instantiates a new Object factory.
     */
    public ObjectFactory() {
    }

    /**
     * Create response header response header.
     *
     * @return the response header
     */
    public ResponseHeader createResponseHeader() {
        return new ResponseHeader();
    }

    /**
     * Create request header request header.
     *
     * @return the request header
     */
    public RequestHeader createRequestHeader() {
        return new RequestHeader();
    }

    /**
     * Create fault type fault type.
     *
     * @return the fault type
     */
    public FaultType createFaultType() {
        return new FaultType();
    }

    /**
     * Create response common info response common info.
     *
     * @return the response common info
     */
    public ResponseCommonInfo createResponseCommonInfo() {
        return new ResponseCommonInfo();
    }

    /**
     * Create request parameter request parameter.
     *
     * @return the request parameter
     */
    public RequestParameter createRequestParameter() {
        return new RequestParameter();
    }

    /**
     * Create request common info request common info.
     *
     * @return the request common info
     */
    public RequestCommonInfo createRequestCommonInfo() {
        return new RequestCommonInfo();
    }

    /**
     * Create request parameters request parameters.
     *
     * @return the request parameters
     */
    public RequestParameters createRequestParameters() {
        return new RequestParameters();
    }

    /**
     * Create fault jaxb element.
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/common/jh/CommonMessage", name = "Fault")
    public JAXBElement<FaultType> createFault(FaultType value) {
        return new JAXBElement<FaultType>(_Fault_QNAME, FaultType.class, null, value);
    }

    /**
     * Create request header jaxb element.
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/common/jh/CommonMessage", name = "RequestHeader")
    public JAXBElement<RequestHeader> createRequestHeader(RequestHeader value) {
        return new JAXBElement<RequestHeader>(_RequestHeader_QNAME, RequestHeader.class, null, value);
    }

    /**
     * Create response header jaxb element.
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/common/jh/CommonMessage", name = "ResponseHeader")
    public JAXBElement<ResponseHeader> createResponseHeader(ResponseHeader value) {
        return new JAXBElement<ResponseHeader>(_ResponseHeader_QNAME, ResponseHeader.class, null, value);
    }

}
