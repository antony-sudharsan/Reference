
package com.manulife.esb.xsd.rps.jh.sendemail;

import javax.xml.bind.annotation.XmlRegistry;


/**
 * The type Object factory.
 */
@XmlRegistry
public class ObjectFactory {


    /**
     * Instantiates a new Object factory.
     */
    public ObjectFactory() {
    }

    /**
     * Create send e mail reply send e mail reply.
     *
     * @return the send e mail reply
     */
    public SendEMailReply createSendEMailReply() {
        return new SendEMailReply();
    }

    /**
     * Create send e mail request send e mail request.
     *
     * @return the send e mail request
     */
    public SendEMailRequest createSendEMailRequest() {
        return new SendEMailRequest();
    }

    /**
     * Create send e mail reply status send e mail reply . status.
     *
     * @return the send e mail reply . status
     */
    public SendEMailReply.Status createSendEMailReplyStatus() {
        return new SendEMailReply.Status();
    }

    /**
     * Create send e mail request requestor send e mail request . requestor.
     *
     * @return the send e mail request . requestor
     */
    public SendEMailRequest.Requestor createSendEMailRequestRequestor() {
        return new SendEMailRequest.Requestor();
    }

    /**
     * Create send e mail request recipient send e mail request . recipient.
     *
     * @return the send e mail request . recipient
     */
    public SendEMailRequest.Recipient createSendEMailRequestRecipient() {
        return new SendEMailRequest.Recipient();
    }

    /**
     * Create send e mail request sender send e mail request . sender.
     *
     * @return the send e mail request . sender
     */
    public SendEMailRequest.Sender createSendEMailRequestSender() {
        return new SendEMailRequest.Sender();
    }

    /**
     * Create send e mail request message send e mail request . message.
     *
     * @return the send e mail request . message
     */
    public SendEMailRequest.Message createSendEMailRequestMessage() {
        return new SendEMailRequest.Message();
    }

}
