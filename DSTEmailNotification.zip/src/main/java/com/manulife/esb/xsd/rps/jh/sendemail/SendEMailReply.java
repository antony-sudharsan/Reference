
package com.manulife.esb.xsd.rps.jh.sendemail;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * The type Send e mail reply.
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "status"
})
@XmlRootElement(name = "SendEMail_reply")
public class SendEMailReply {

    /**
     * The Status.
     */
    @XmlElement(name = "Status", required = true)
    protected SendEMailReply.Status status;

    /**
     * Gets status.
     *
     * @return the status
     */
    public SendEMailReply.Status getStatus() {
        return status;
    }

    /**
     * Sets status.
     *
     * @param value the value
     */
    public void setStatus(SendEMailReply.Status value) {
        this.status = value;
    }


    /**
     * The type Status.
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "code",
        "message"
    })
    public static class Status {

        /**
         * The Code.
         */
        @XmlElement(name = "Code", required = true)
        protected String code;
        /**
         * The Message.
         */
        @XmlElement(name = "Message", required = true)
        protected String message;

        /**
         * Gets code.
         *
         * @return the code
         */
        public String getCode() {
            return code;
        }

        /**
         * Sets code.
         *
         * @param value the value
         */
        public void setCode(String value) {
            this.code = value;
        }

        /**
         * Gets message.
         *
         * @return the message
         */
        public String getMessage() {
            return message;
        }

        /**
         * Sets message.
         *
         * @param value the value
         */
        public void setMessage(String value) {
            this.message = value;
        }

    }

}
