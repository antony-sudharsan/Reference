
package com.manulife.esb.xsd.common.jh.commonmessage;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * The type Request parameter.
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "RequestParameter", propOrder = {
    "parmName",
    "parmValue",
    "parmDesc"
})
public class RequestParameter {

    /**
     * The Parm name.
     */
    @XmlElement(name = "ParmName", required = true)
    protected String parmName;
    /**
     * The Parm value.
     */
    @XmlElement(name = "ParmValue", required = true)
    protected String parmValue;
    /**
     * The Parm desc.
     */
    @XmlElement(name = "ParmDesc")
    protected String parmDesc;

    /**
     * Gets parm name.
     *
     * @return the parm name
     */
    public String getParmName() {
        return parmName;
    }

    /**
     * Sets parm name.
     *
     * @param value the value
     */
    public void setParmName(String value) {
        this.parmName = value;
    }

    /**
     * Gets parm value.
     *
     * @return the parm value
     */
    public String getParmValue() {
        return parmValue;
    }

    /**
     * Sets parm value.
     *
     * @param value the value
     */
    public void setParmValue(String value) {
        this.parmValue = value;
    }

    /**
     * Gets parm desc.
     *
     * @return the parm desc
     */
    public String getParmDesc() {
        return parmDesc;
    }

    /**
     * Sets parm desc.
     *
     * @param value the value
     */
    public void setParmDesc(String value) {
        this.parmDesc = value;
    }

}
