
package com.manulife.esb.xsd.common.jh.commonmessage;

import javax.xml.bind.annotation.*;


/**
 * The type Fault type.
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "FaultType", propOrder = {
    "errorCode",
    "errorDescription"
})
@XmlRootElement(name = "Fault")
public class FaultType {

    /**
     * The Error code.
     */
    @XmlElement(name = "ErrorCode", required = true)
    protected String errorCode;
    /**
     * The Error description.
     */
    @XmlElement(name = "ErrorDescription", required = true)
    protected String errorDescription;

    /**
     * Gets error code.
     *
     * @return the error code
     */
    public String getErrorCode() {
        return errorCode;
    }

    /**
     * Sets error code.
     *
     * @param value the value
     */
    public void setErrorCode(String value) {
        this.errorCode = value;
    }

    /**
     * Gets error description.
     *
     * @return the error description
     */
    public String getErrorDescription() {
        return errorDescription;
    }

    /**
     * Sets error description.
     *
     * @param value the value
     */
    public void setErrorDescription(String value) {
        this.errorDescription = value;
    }

}
