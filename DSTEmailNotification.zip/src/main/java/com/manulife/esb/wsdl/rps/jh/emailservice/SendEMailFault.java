
package com.manulife.esb.wsdl.rps.jh.emailservice;

import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.ws.WebFault;
import com.manulife.esb.xsd.common.jh.commonmessage.FaultType;


/**
 * The type Send e mail fault.
 */
@WebFault(name = "Fault", targetNamespace = "http://www.esb.manulife.com/xsd/common/jh/CommonMessage")
@XmlRootElement(name = "SendEMail_fault")
public class SendEMailFault
    extends Exception
{

    /**
     * Instantiates a new Send e mail fault.
     */
    public SendEMailFault() {
    }

    /**
     * Instantiates a new Send e mail fault.
     *
     * @param faultInfo the fault info
     */
    public SendEMailFault(FaultType faultInfo) {
        this.faultInfo = faultInfo;
    }

    private FaultType faultInfo;

    /**
     * Instantiates a new Send e mail fault.
     *
     * @param message   the message
     * @param faultInfo the fault info
     */
    public SendEMailFault(String message, FaultType faultInfo) {
        super(message);
        this.faultInfo = faultInfo;
    }

    /**
     * Instantiates a new Send e mail fault.
     *
     * @param message   the message
     * @param faultInfo the fault info
     * @param cause     the cause
     */
    public SendEMailFault(String message, FaultType faultInfo, Throwable cause) {
        super(message, cause);
        this.faultInfo = faultInfo;
    }

    /**
     * Gets fault info.
     *
     * @return the fault info
     */
    public FaultType getFaultInfo() {
        return faultInfo;
    }

}
