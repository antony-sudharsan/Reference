
package com.manulife.esb.wsdl.rps.jh.emailservice;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;
import javax.xml.bind.annotation.XmlSeeAlso;
import com.manulife.esb.xsd.rps.jh.sendemail.SendEMailReply;
import com.manulife.esb.xsd.rps.jh.sendemail.SendEMailRequest;


/**
 * The interface E mail service.
 */
@WebService(name = "EMailService", targetNamespace = "http://www.esb.manulife.com/wsdl/RPS/jh/EMailService")
@SOAPBinding(parameterStyle = SOAPBinding.ParameterStyle.BARE)
@XmlSeeAlso({
    com.manulife.esb.xsd.rps.jh.sendemail.ObjectFactory.class,
    com.manulife.esb.xsd.common.jh.commonmessage.ObjectFactory.class,
    com.manulife.esb.xsd.common.jh.header.ObjectFactory.class
})
public interface EMailService {


    /**
     * Send e mail send e mail reply.
     *
     * @param sendEMailRequest the send e mail request
     *
     * @return the send e mail reply
     *
     * @throws SendEMailFault the send e mail fault
     */
    @WebMethod(operationName = "SendEMail", action = "SendEMail")
    @WebResult(name = "SendEMail_reply", targetNamespace = "http://www.esb.manulife.com/xsd/RPS/jh/SendEmail", partName = "SendEMail_reply")
    public SendEMailReply sendEMail(
        @WebParam(name = "SendEMail_request", targetNamespace = "http://www.esb.manulife.com/xsd/RPS/jh/SendEmail", partName = "SendEMail_request")
        SendEMailRequest sendEMailRequest)
        throws SendEMailFault
    ;

}
