
package com.manulife.esb.wsdl.rps.jh.emailservice;

import java.net.MalformedURLException;
import java.net.URL;
import javax.xml.namespace.QName;
import javax.xml.ws.Service;
import javax.xml.ws.WebEndpoint;
import javax.xml.ws.WebServiceClient;
import javax.xml.ws.WebServiceException;
import javax.xml.ws.WebServiceFeature;


/**
 * The type E mail service service.
 */
@WebServiceClient(name = "EMailService", targetNamespace = "http://www.esb.manulife.com/wsdl/RPS/jh/EMailService", wsdlLocation = "file:/C:/Tibco2MS/Wave1WSDLs/Email/EMailService_WSDL.wsdl")
public class EMailService_Service
    extends Service
{

    private final static URL EMAILSERVICE_WSDL_LOCATION;
    private final static WebServiceException EMAILSERVICE_EXCEPTION;
    private final static QName EMAILSERVICE_QNAME = new QName("http://www.esb.manulife.com/wsdl/RPS/jh/EMailService", "EMailService");

    static {
        URL url = null;
        WebServiceException e = null;
        try {
            url = new URL("file:/C:/Tibco2MS/Wave1WSDLs/Email/EMailService_WSDL.wsdl");
        } catch (MalformedURLException ex) {
            e = new WebServiceException(ex);
        }
        EMAILSERVICE_WSDL_LOCATION = url;
        EMAILSERVICE_EXCEPTION = e;
    }

    /**
     * Instantiates a new E mail service service.
     */
    public EMailService_Service() {
        super(__getWsdlLocation(), EMAILSERVICE_QNAME);
    }

    /**
     * Instantiates a new E mail service service.
     *
     * @param features the features
     */
    public EMailService_Service(WebServiceFeature... features) {
        super(__getWsdlLocation(), EMAILSERVICE_QNAME, features);
    }

    /**
     * Instantiates a new E mail service service.
     *
     * @param wsdlLocation the wsdl location
     */
    public EMailService_Service(URL wsdlLocation) {
        super(wsdlLocation, EMAILSERVICE_QNAME);
    }

    /**
     * Instantiates a new E mail service service.
     *
     * @param wsdlLocation the wsdl location
     * @param features     the features
     */
    public EMailService_Service(URL wsdlLocation, WebServiceFeature... features) {
        super(wsdlLocation, EMAILSERVICE_QNAME, features);
    }

    /**
     * Instantiates a new E mail service service.
     *
     * @param wsdlLocation the wsdl location
     * @param serviceName  the service name
     */
    public EMailService_Service(URL wsdlLocation, QName serviceName) {
        super(wsdlLocation, serviceName);
    }

    /**
     * Instantiates a new E mail service service.
     *
     * @param wsdlLocation the wsdl location
     * @param serviceName  the service name
     * @param features     the features
     */
    public EMailService_Service(URL wsdlLocation, QName serviceName, WebServiceFeature... features) {
        super(wsdlLocation, serviceName, features);
    }

    /**
     * Gets e mail service soap binding.
     *
     * @return the e mail service soap binding
     */
    @WebEndpoint(name = "EMailService_SOAPBinding")
    public EMailService getEMailServiceSOAPBinding() {
        return super.getPort(new QName("http://www.esb.manulife.com/wsdl/RPS/jh/EMailService", "EMailService_SOAPBinding"), EMailService.class);
    }

    /**
     * Gets e mail service soap binding.
     *
     * @param features the features
     *
     * @return the e mail service soap binding
     */
    @WebEndpoint(name = "EMailService_SOAPBinding")
    public EMailService getEMailServiceSOAPBinding(WebServiceFeature... features) {
        return super.getPort(new QName("http://www.esb.manulife.com/wsdl/RPS/jh/EMailService", "EMailService_SOAPBinding"), EMailService.class, features);
    }

    private static URL __getWsdlLocation() {
        if (EMAILSERVICE_EXCEPTION!= null) {
            throw EMAILSERVICE_EXCEPTION;
        }
        return EMAILSERVICE_WSDL_LOCATION;
    }

}
