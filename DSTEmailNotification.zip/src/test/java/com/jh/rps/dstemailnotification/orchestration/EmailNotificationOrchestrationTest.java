package com.jh.rps.dstemailnotification.orchestration;

import com.jh.rps.dstemailnotification.model.SendEMailReplyWrapper;
import com.jh.rps.dstemailnotification.model.SendEMailRequestWrapper;
import com.jh.rps.dstemailnotification.service.SendEmailService;
import com.jh.rps.dstemailnotification.utils.LoggerUtils;
import com.manulife.esb.xsd.common.jh.header.JHHeader;
import com.manulife.esb.xsd.common.jh.header.MessageSource;
import com.manulife.esb.xsd.common.jh.header.ServiceInfo;
import com.manulife.esb.xsd.rps.jh.sendemail.SendEMailReply;
import com.manulife.esb.xsd.rps.jh.sendemail.SendEMailRequest;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.test.context.junit4.SpringRunner;

import static org.junit.Assert.*;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.when;

/**
 * The type EmailNotificationOrchestrationTest  test.
 */
@RunWith(SpringRunner.class)
public class EmailNotificationOrchestrationTest {


    @InjectMocks
    EmailNotificationOrchestration emailNotificationOrchestration;

    @Mock
    private LoggerUtils loggerUtils;

    @Mock
    private SendEmailService sendEmailService;

    SendEMailReplyWrapper sendEMailReplyWrapper = null;
    SendEMailReply sendEMailReply = null;
    SendEMailRequestWrapper sendEMailRequestWrapper = null;
    SendEMailRequest sendEMailRequest = null;
    JHHeader header = null;
    SendEMailReply.Status status = null;

    @Before
    public void setUp() {
        sendEMailReplyWrapper = new SendEMailReplyWrapper();
        sendEMailRequestWrapper = new SendEMailRequestWrapper();
        sendEMailReply = new SendEMailReply();
        sendEMailRequest = new SendEMailRequest();
        MessageSource messageSource = new MessageSource();
        ServiceInfo serviceInfo = new ServiceInfo();
        header = new JHHeader();
        header.setMessageSource(messageSource);
        header.setServiceInfo(serviceInfo);
        header.setMessageUID("AAAA");

        messageSource.setUserID("CallidusCloud");
        messageSource.setApplicationName("575812");
        messageSource.setApplicationUserID("CallidusCloud");
        messageSource.setHostName("174.129.237.57");
        messageSource.setProcessID("1");

        serviceInfo.setServiceName("Producer");
        serviceInfo.setServiceOperation("CheckLicenseStatus");
        serviceInfo.setServiceVersion("1.0");
        status = new SendEMailReply.Status();
        status.setMessage("Email Send Success");
        status.setCode("0");
        sendEMailReply.setStatus(status);
        sendEMailReplyWrapper.setSendEMailReply(sendEMailReply);
        sendEMailRequestWrapper.setSendEMailRequest(sendEMailRequest);
        sendEMailRequestWrapper.setJhHeader(header);
    }


    @Test
    public void sendEMailSuccess() throws Exception {

        when(sendEmailService.sendEmailMessage("ABC", "WER", sendEMailRequest)).thenReturn(status);
        emailNotificationOrchestration.sendEMail(header,sendEMailRequest);
        assertEquals("0",sendEMailReplyWrapper.getSendEMailReply().getStatus().getCode());
        assertEquals("Email Send Success",sendEMailReplyWrapper.getSendEMailReply().getStatus().getMessage());
    }

    @Test
    public void sendEMailFailure() throws Exception {
        status = new SendEMailReply.Status();
        status.setMessage("Email Send Failure");
        status.setCode("1");
        sendEMailReply.setStatus(status);
        when(sendEmailService.sendEmailMessage("ABC", "WER", sendEMailRequest)).thenReturn(status);
        emailNotificationOrchestration.sendEMail(header,sendEMailRequest);
        assertEquals("1",sendEMailReplyWrapper.getSendEMailReply().getStatus().getCode());
        assertEquals("Email Send Failure",sendEMailReplyWrapper.getSendEMailReply().getStatus().getMessage());

    }

    @After
    public void tearDown() throws Exception {
    }
}