package com.jh.rps.dstemailnotification.controller;

import com.jh.rps.dstemailnotification.model.SendEMailReplyWrapper;
import com.jh.rps.dstemailnotification.model.SendEMailRequestWrapper;
import com.jh.rps.dstemailnotification.orchestration.EmailNotificationOrchestration;
import com.jh.rps.dstemailnotification.utils.JHHeaderUtils;
import com.jh.rps.dstemailnotification.utils.LoggerUtils;
import com.manulife.esb.xsd.common.jh.header.JHHeader;
import com.manulife.esb.xsd.common.jh.header.MessageSource;
import com.manulife.esb.xsd.common.jh.header.ServiceInfo;
import com.manulife.esb.xsd.rps.jh.sendemail.SendEMailReply;
import com.manulife.esb.xsd.rps.jh.sendemail.SendEMailRequest;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;

import static org.mockito.Matchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;


/**
 * The type Producer controller test.
 */
@RunWith(SpringRunner.class)
/**
 * @WebMvcTest.
 * It will auto-configure the Spring MVC infrastructure for our unit tests.
 * Setting up WebMvc Context for the Controller which is under test("AnnuityController")
 */
@WebMvcTest(EmailNotificationController.class)
public class EmailNotificationControllerTest {

    /**
     * Initializing MockMvc
     */
    @Autowired
    private MockMvc mvc;
    /**
     * The Producer orchestration.
     *
     * @MockBean The class is included in the spring-boot-test library. It allows to add Mockito mocks in a Spring ApplicationContext. If a bean, compatible with the declared class exists in the context, it replaces it by the mock. If it is not the case, it adds the mock in the context as a bean.
     */
    @MockBean
    EmailNotificationOrchestration emailNotificationOrchestration;

    /**
     * The Logger utils.
     */
    @MockBean
    LoggerUtils loggerUtils;

    /**
     * The Header utils.
     */
    @MockBean
    JHHeaderUtils headerUtils;

    SendEMailReplyWrapper sendEMailReplyWrapper = null;
    SendEMailReply sendEMailReply = null;
    SendEMailRequestWrapper sendEMailRequestWrapper = null;
    SendEMailRequest sendEMailRequest = null;
    JHHeader header = null;
    @Before
    public void setUp() {
        sendEMailReplyWrapper = new SendEMailReplyWrapper();
        sendEMailRequestWrapper = new SendEMailRequestWrapper();
        sendEMailReply = new SendEMailReply();
        sendEMailRequest = new SendEMailRequest();
        MessageSource messageSource = new MessageSource();
        ServiceInfo serviceInfo = new ServiceInfo();
        header = new JHHeader();
        header.setMessageSource(messageSource);
        header.setServiceInfo(serviceInfo);
        header.setMessageUID("AAAA");

        messageSource.setUserID("CallidusCloud");
        messageSource.setApplicationName("575812");
        messageSource.setApplicationUserID("CallidusCloud");
        messageSource.setHostName("174.129.237.57");
        messageSource.setProcessID("1");

        serviceInfo.setServiceName("Producer");
        serviceInfo.setServiceOperation("CheckLicenseStatus");
        serviceInfo.setServiceVersion("1.0");
        SendEMailReply.Status status = new SendEMailReply.Status();
        status.setMessage("Email Send Success");
        status.setCode("0");
        sendEMailReply.setStatus(status);
        sendEMailReplyWrapper.setSendEMailReply(sendEMailReply);
        sendEMailRequestWrapper.setSendEMailRequest(sendEMailRequest);
        sendEMailRequestWrapper.setJhHeader(header);
    }

    @Test
    public void sendEMailSuccess() throws Exception {

        when(emailNotificationOrchestration.sendEMail(any(JHHeader.class), any(SendEMailRequest.class))).thenReturn(sendEMailReplyWrapper);

        mvc.perform(post("/jh/rps/notification/dst/email/sendemail")
                .content(asJsonString(sendEMailRequestWrapper))
                .accept(MediaType.APPLICATION_JSON_VALUE)
                .contentType(MediaType.APPLICATION_JSON_VALUE)).andDo(print())
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.sendEMailReply.status.code").value("0"))
                .andExpect(jsonPath("$.sendEMailReply.status.message").value("Email Send Success"));
    }


    @Test
    public void sendEMailFailure() throws Exception {

        SendEMailReply.Status status = new SendEMailReply.Status();
        status.setMessage("Email Send Failure");
        status.setCode("1");
        sendEMailReply.setStatus(status);
        sendEMailReplyWrapper.setSendEMailReply(sendEMailReply);

        when(emailNotificationOrchestration.sendEMail(any(JHHeader.class), any(SendEMailRequest.class))).thenReturn(sendEMailReplyWrapper);

        mvc.perform(post("/jh/rps/notification/dst/email/sendemail")
                .content(asJsonString(sendEMailRequestWrapper))
                .accept(MediaType.APPLICATION_JSON_VALUE)
                .contentType(MediaType.APPLICATION_JSON_VALUE)).andDo(print())
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.sendEMailReply.status.code").value("1"))
                .andExpect(jsonPath("$.sendEMailReply.status.message").value("Email Send Failure"));
    }
    /**
     * As json string string.
     *
     * @param obj the obj
     *
     * @return the string
     */
    /*
     * converts a Java object into JSON representation
     */
    public static String asJsonString(final Object obj) {
        try {
            String returnStr = new ObjectMapper().writeValueAsString(obj);
            return returnStr;

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}