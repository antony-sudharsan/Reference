/**
 *
 */
package com.jh.signator.maintain.producer.agreement.model;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import com.manulife.esb.xsd.common.jh.header.JHHeader;
import com.manulife.esb.xsd.distribution.jhfn.maintainproduceragreement.SearchProducerAgreementRequest;

/**
 * Used to hold request and header.
 *
 */
public class SearchProducerAgreementRequestWrapper {

	@NotNull
	private JHHeader header;

	@NotNull
	@Valid
	private SearchProducerAgreementRequest request;

	public JHHeader getHeader() {
		return header;
	}

	public void setHeader(final JHHeader header) {
		this.header = header;
	}

	public SearchProducerAgreementRequest getRequest() {
		return request;
	}

	public void setRequest(final SearchProducerAgreementRequest request) {
		this.request = request;
	}

}
