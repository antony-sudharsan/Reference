package com.jh.signator.maintain.producer.agreement.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.DataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.jh.common.logging.LoggerHandler;
import com.jh.signator.maintain.producer.agreement.model.CreateProducerAgreementReplyWrapper;
import com.jh.signator.maintain.producer.agreement.model.CreateProducerAgreementRequestWrapper;
import com.jh.signator.maintain.producer.agreement.model.DeleteProducerAgreementReplyWrapper;
import com.jh.signator.maintain.producer.agreement.model.DeleteProducerAgreementRequestWrapper;
import com.jh.signator.maintain.producer.agreement.model.ReadProducerAgreementReplyWrapper;
import com.jh.signator.maintain.producer.agreement.model.ReadProducerAgreementRequestWrapper;
import com.jh.signator.maintain.producer.agreement.model.SearchProducerAgreementReplyWrapper;
import com.jh.signator.maintain.producer.agreement.model.SearchProducerAgreementRequestWrapper;
import com.jh.signator.maintain.producer.agreement.model.UpdateProducerAgreementReplyWrapper;
import com.jh.signator.maintain.producer.agreement.model.UpdateProducerAgreementRequestWrapper;
import com.jh.signator.maintain.producer.agreement.service.MaintainProducerAgreementService;
import com.jh.signator.maintain.producer.agreement.utils.JHHeaderUtils;
import com.jh.signator.maintain.producer.agreement.utils.LoggerUtils;
import com.jh.signator.maintain.producer.agreement.utils.LoggingContextHolder;
import com.manulife.esb.xsd.distribution.jhfn.maintainproduceragreement.CreateProducerAgreementReply;
import com.manulife.esb.xsd.distribution.jhfn.maintainproduceragreement.DeleteProducerAgreementReply;
import com.manulife.esb.xsd.distribution.jhfn.maintainproduceragreement.ReadProducerAgreementReply;
import com.manulife.esb.xsd.distribution.jhfn.maintainproduceragreement.SearchProducerAgreementReply;
import com.manulife.esb.xsd.distribution.jhfn.maintainproduceragreement.UpdateProducerAgreementReply;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

/**
 * Exposes REST operations for MaintainPartyIdentity.
 *
 */
@RestController
@EnableSwagger2
@RequestMapping("/jh/signator/maintain/producer/agreement")
public class MaintainProducerAgreementController {

	private final LoggerUtils loggerUtils;
	private final MaintainProducerAgreementService maintainProducerAgreementService;

	@InitBinder
	public void activateDirectFieldAccess(final DataBinder dataBinder) {
		dataBinder.initDirectFieldAccess();
	}

	@Autowired
	public MaintainProducerAgreementController(final MaintainProducerAgreementService maintainProducerAgreementService,
			final LoggerUtils loggerUtils) {
		this.loggerUtils = loggerUtils;
		this.maintainProducerAgreementService = maintainProducerAgreementService;
	}

	@ApiOperation(value = "create", notes = "Service to create producer agreement", response = CreateProducerAgreementReplyWrapper.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Success"),
			@ApiResponse(code = 408, message = "Request Timeout"),
			@ApiResponse(code = 500, message = "Technical Error"), @ApiResponse(code = 400, message = "Invalid Input"),
			@ApiResponse(code = 404, message = "Record not found ") })

	@RequestMapping(value = "/create producer agreement", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CreateProducerAgreementReplyWrapper> create(
			@Valid @RequestBody final CreateProducerAgreementRequestWrapper request) {

		JHHeaderUtils.validateHeader(request.getHeader());

		final CreateProducerAgreementReplyWrapper replyWrapper = new CreateProducerAgreementReplyWrapper();
		// Currently no changes to header on response in TIBCO
		replyWrapper.setHeader(request.getHeader());
		final String messageUUID = JHHeaderUtils.retrieveOrDefaultMessageUID(request.getHeader(),
				"CreateProducerAgreement");
		final String sourceSystemName = JHHeaderUtils.retrieveOrDefaultSourceSystemName(request.getHeader());

		try {
			LoggingContextHolder.getLoggingContext().setContext(messageUUID, sourceSystemName);
			LoggerHandler.LogOut("INFO", "1", messageUUID, sourceSystemName, this.getClass().getName(),
					"Entering create Controller " + loggerUtils.writeAsJson(request));

			final CreateProducerAgreementReply reply = maintainProducerAgreementService.create(request.getHeader(),
					request.getRequest());
			replyWrapper.setReply(reply);

			LoggerHandler.LogOut("INFO", "4", messageUUID, sourceSystemName, this.getClass().getName(),
					"Exiting create Controller " + loggerUtils.writeAsJson(reply));
			LoggingContextHolder.getLoggingContext().clear();

		} catch (final Exception e) {
			LoggerHandler.ErrorOut(e, messageUUID, sourceSystemName, this.getClass().getName(), e.getMessage());
			throw e;
		}

		return new ResponseEntity<>(replyWrapper, new HttpHeaders(), HttpStatus.OK);
	}

	@ApiOperation(value = "update producer agreement", notes = "Service to update producer agreement", response = UpdateProducerAgreementReplyWrapper.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Success"),
			@ApiResponse(code = 408, message = "Request Timeout"),
			@ApiResponse(code = 500, message = "Technical Error"), @ApiResponse(code = 400, message = "Invalid Input"),
			@ApiResponse(code = 404, message = "Record not found ") })

	@RequestMapping(value = "/update", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<UpdateProducerAgreementReplyWrapper> update(
			@Valid @RequestBody final UpdateProducerAgreementRequestWrapper request) {

		JHHeaderUtils.validateHeader(request.getHeader());

		final UpdateProducerAgreementReplyWrapper replyWrapper = new UpdateProducerAgreementReplyWrapper();
		// Currently no changes to header on response in TIBCO
		replyWrapper.setHeader(request.getHeader());
		final String messageUUID = JHHeaderUtils.retrieveOrDefaultMessageUID(request.getHeader(),
				"UpdateProducerAgreement");
		final String sourceSystemName = JHHeaderUtils.retrieveOrDefaultSourceSystemName(request.getHeader());

		try {
			LoggingContextHolder.getLoggingContext().setContext(messageUUID, sourceSystemName);
			LoggerHandler.LogOut("INFO", "1", messageUUID, sourceSystemName, this.getClass().getName(),
					"Entering update Controller " + loggerUtils.writeAsJson(request));

			final UpdateProducerAgreementReply reply = maintainProducerAgreementService.update(request.getHeader(),
					request.getRequest());
			replyWrapper.setReply(reply);

			LoggerHandler.LogOut("INFO", "4", messageUUID, sourceSystemName, this.getClass().getName(),
					"Exiting update Controller " + loggerUtils.writeAsJson(reply));
			LoggingContextHolder.getLoggingContext().clear();

		} catch (final Exception e) {
			LoggerHandler.ErrorOut(e, messageUUID, sourceSystemName, this.getClass().getName(), e.getMessage());
			throw e;
		}

		return new ResponseEntity<>(replyWrapper, new HttpHeaders(), HttpStatus.OK);
	}

	@ApiOperation(value = "delete producer agreement", notes = "Service to delete producer agreement", response = DeleteProducerAgreementReplyWrapper.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Success"),
			@ApiResponse(code = 408, message = "Request Timeout"),
			@ApiResponse(code = 500, message = "Technical Error"), @ApiResponse(code = 400, message = "Invalid Input"),
			@ApiResponse(code = 404, message = "Record not found ") })

	@RequestMapping(value = "/delete", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<DeleteProducerAgreementReplyWrapper> delete(
			@Valid @RequestBody final DeleteProducerAgreementRequestWrapper request) {

		JHHeaderUtils.validateHeader(request.getHeader());

		final DeleteProducerAgreementReplyWrapper replyWrapper = new DeleteProducerAgreementReplyWrapper();
		// Currently no changes to header on response in TIBCO
		replyWrapper.setHeader(request.getHeader());
		final String messageUUID = JHHeaderUtils.retrieveOrDefaultMessageUID(request.getHeader(),
				"DeleteProducerAgreement");
		final String sourceSystemName = JHHeaderUtils.retrieveOrDefaultSourceSystemName(request.getHeader());

		try {
			LoggingContextHolder.getLoggingContext().setContext(messageUUID, sourceSystemName);
			LoggerHandler.LogOut("INFO", "1", messageUUID, sourceSystemName, this.getClass().getName(),
					"Entering delete Controller " + loggerUtils.writeAsJson(request));

			final DeleteProducerAgreementReply reply = maintainProducerAgreementService.delete(request.getHeader(),
					request.getRequest());
			replyWrapper.setReply(reply);

			LoggerHandler.LogOut("INFO", "4", messageUUID, sourceSystemName, this.getClass().getName(),
					"Exiting delete Controller " + loggerUtils.writeAsJson(reply));
			LoggingContextHolder.getLoggingContext().clear();

		} catch (final Exception e) {
			LoggerHandler.ErrorOut(e, messageUUID, sourceSystemName, this.getClass().getName(), e.getMessage());
			throw e;
		}

		return new ResponseEntity<>(replyWrapper, new HttpHeaders(), HttpStatus.OK);
	}

	@ApiOperation(value = "read producer agreement", notes = "Service to read producer agreement", response = ReadProducerAgreementReplyWrapper.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Success"),
			@ApiResponse(code = 408, message = "Request Timeout"), @ApiResponse(code = 417, message = "Max Records"),
			@ApiResponse(code = 500, message = "Technical Error"), @ApiResponse(code = 400, message = "Invalid Input"),
			@ApiResponse(code = 404, message = "Record not found ") })

	@RequestMapping(value = "/read", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ReadProducerAgreementReplyWrapper> read(
			@Valid @RequestBody final ReadProducerAgreementRequestWrapper request) {

		JHHeaderUtils.validateHeader(request.getHeader());

		final ReadProducerAgreementReplyWrapper replyWrapper = new ReadProducerAgreementReplyWrapper();
		// Currently no changes to header on response in TIBCO
		replyWrapper.setHeader(request.getHeader());
		final String messageUUID = JHHeaderUtils.retrieveOrDefaultMessageUID(request.getHeader(),
				"ReadProducerAgreement");
		final String sourceSystemName = JHHeaderUtils.retrieveOrDefaultSourceSystemName(request.getHeader());

		try {
			LoggingContextHolder.getLoggingContext().setContext(messageUUID, sourceSystemName);
			LoggerHandler.LogOut("INFO", "1", messageUUID, sourceSystemName, this.getClass().getName(),
					"Entering read Controller " + loggerUtils.writeAsJson(request));

			final ReadProducerAgreementReply reply = maintainProducerAgreementService.read(request.getHeader(),
					request.getRequest());
			replyWrapper.setReply(reply);

			LoggerHandler.LogOut("INFO", "4", messageUUID, sourceSystemName, this.getClass().getName(),
					"Exiting read Controller " + loggerUtils.writeAsJson(reply));
			LoggingContextHolder.getLoggingContext().clear();

		} catch (final Exception e) {
			LoggerHandler.ErrorOut(e, messageUUID, sourceSystemName, this.getClass().getName(), e.getMessage());
			throw e;
		}

		return new ResponseEntity<>(replyWrapper, new HttpHeaders(), HttpStatus.OK);
	}

	@ApiOperation(value = "search producer agreements", notes = "Service to search producer agreement", response = SearchProducerAgreementReplyWrapper.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Success"),
			@ApiResponse(code = 408, message = "Request Timeout"),
			@ApiResponse(code = 500, message = "Technical Error"), @ApiResponse(code = 400, message = "Invalid Input"),
			@ApiResponse(code = 404, message = "Record not found ") })

	@RequestMapping(value = "/search", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<SearchProducerAgreementReplyWrapper> search(
			@Valid @RequestBody final SearchProducerAgreementRequestWrapper request) {

		JHHeaderUtils.validateHeader(request.getHeader());

		final SearchProducerAgreementReplyWrapper replyWrapper = new SearchProducerAgreementReplyWrapper();
		// Currently no changes to header on response in TIBCO
		replyWrapper.setHeader(request.getHeader());
		final String messageUUID = JHHeaderUtils.retrieveOrDefaultMessageUID(request.getHeader(),
				"SearchProducerAgreement");
		final String sourceSystemName = JHHeaderUtils.retrieveOrDefaultSourceSystemName(request.getHeader());

		try {
			LoggingContextHolder.getLoggingContext().setContext(messageUUID, sourceSystemName);
			LoggerHandler.LogOut("INFO", "1", messageUUID, sourceSystemName, this.getClass().getName(),
					"Entering search Controller " + loggerUtils.writeAsJson(request));

			final SearchProducerAgreementReply reply = maintainProducerAgreementService.search(request.getHeader(),
					request.getRequest());
			replyWrapper.setReply(reply);

			LoggerHandler.LogOut("INFO", "4", messageUUID, sourceSystemName, this.getClass().getName(),
					"Exiting search Controller " + loggerUtils.writeAsJson(reply));
			LoggingContextHolder.getLoggingContext().clear();

		} catch (final Exception e) {
			LoggerHandler.ErrorOut(e, messageUUID, sourceSystemName, this.getClass().getName(), e.getMessage());
			throw e;
		}

		return new ResponseEntity<>(replyWrapper, new HttpHeaders(), HttpStatus.OK);
	}
}
