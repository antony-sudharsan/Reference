/**
 *
 */
package com.jh.signator.maintain.producer.agreement.model;

import com.manulife.esb.xsd.common.jh.header.JHHeader;
import com.manulife.esb.xsd.distribution.jhfn.maintainproduceragreement.DeleteProducerAgreementReply;

/**
 * Used to hold reply with response header.
 *
 */
public class DeleteProducerAgreementReplyWrapper {
	private JHHeader header;
	private DeleteProducerAgreementReply reply;

	public JHHeader getHeader() {
		return header;
	}

	public void setHeader(final JHHeader header) {
		this.header = header;
	}

	public DeleteProducerAgreementReply getReply() {
		return reply;
	}

	public void setReply(final DeleteProducerAgreementReply reply) {
		this.reply = reply;
	}

}
