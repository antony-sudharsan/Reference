package com.jh.signator.maintain.producer.agreement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MaintainProducerAgreement {
	

	public static void main(String[] args) {
		SpringApplication.run(MaintainProducerAgreement.class, args);
	}
	

}
