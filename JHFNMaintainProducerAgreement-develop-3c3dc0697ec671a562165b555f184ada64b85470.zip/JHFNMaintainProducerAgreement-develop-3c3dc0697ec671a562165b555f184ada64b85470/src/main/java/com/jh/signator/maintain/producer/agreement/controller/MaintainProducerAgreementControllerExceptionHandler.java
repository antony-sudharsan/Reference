package com.jh.signator.maintain.producer.agreement.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.validation.FieldError;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.jh.signator.maintain.producer.agreement.exception.BadRequestException;
import com.jh.signator.maintain.producer.agreement.exception.ExceptionResponse;
import com.jh.signator.maintain.producer.agreement.exception.InvalidInputException;
import com.jh.signator.maintain.producer.agreement.exception.MaxRecordsException;
import com.jh.signator.maintain.producer.agreement.exception.RecordNotFoundException;
import com.jh.signator.maintain.producer.agreement.exception.RequestTimeoutException;
import com.jh.signator.maintain.producer.agreement.exception.TechnicalErrorException;
import com.jh.signator.maintain.producer.agreement.utils.Utility;

/**
 * Controller advice to handle exceptions escaping
 * MaintainPartyIdentityController.
 *
 */
@ControllerAdvice
public class MaintainProducerAgreementControllerExceptionHandler extends ResponseEntityExceptionHandler {

	@Override
	protected ResponseEntity<Object> handleMethodArgumentNotValid(final MethodArgumentNotValidException ex,
			final HttpHeaders headers, final HttpStatus status, final WebRequest request) {

		final List<String> errors = new ArrayList<>();
		for (final FieldError error : ex.getBindingResult().getFieldErrors()) {
			errors.add(error.getField() + ": " + error.getDefaultMessage());
		}
		for (final ObjectError error : ex.getBindingResult().getGlobalErrors()) {
			errors.add(error.getObjectName() + ": " + error.getDefaultMessage());
		}
		final ExceptionResponse exceptionResponse = new ExceptionResponse("400", "Request Validation Failed",
				errors.toString());
		return new ResponseEntity<>(exceptionResponse, HttpStatus.BAD_REQUEST);
	}

	// 500
	@ExceptionHandler(Exception.class)
	public final ResponseEntity<Object> handleAllExceptions(final Exception ex, final WebRequest request) {
		final TechnicalErrorException techError = new TechnicalErrorException(ex.getMessage(), ex);
		return new ResponseEntity<>(techError.getExceptionResponse(), HttpStatus.NOT_ACCEPTABLE);

	}

	// 408
	@ExceptionHandler(RequestTimeoutException.class)
	public final ResponseEntity<ExceptionResponse> handleException(final RequestTimeoutException ex,
			final WebRequest request) {

		return new ResponseEntity<>(ex.getExceptionResponse(), HttpStatus.REQUEST_TIMEOUT);
	}

	// 417
	@ExceptionHandler(MaxRecordsException.class)
	public final ResponseEntity<ExceptionResponse> handleException(final MaxRecordsException ex,
			final WebRequest request) {

		return new ResponseEntity<>(ex.getExceptionResponse(), HttpStatus.EXPECTATION_FAILED);
	}

	// 404
	@ExceptionHandler(RecordNotFoundException.class)
	public final ResponseEntity<ExceptionResponse> handleException(final RecordNotFoundException ex,
			final WebRequest request) {
		return new ResponseEntity<>(ex.getExceptionResponse(), HttpStatus.NOT_FOUND);
	}

	@Override
	protected ResponseEntity<Object> handleHttpMessageNotReadable(final HttpMessageNotReadableException ex,
			final HttpHeaders headers, final HttpStatus status, final WebRequest request) {
		final ExceptionResponse exceptionResponse = new ExceptionResponse("400", ex.getMessage(),
				Utility.getStackTrace(ex));
		return new ResponseEntity<>(exceptionResponse, HttpStatus.BAD_REQUEST);
	}

	// 400
	@ExceptionHandler(BadRequestException.class)
	public final ResponseEntity<Object> handleException(final BadRequestException ex, final WebRequest request) {

		return new ResponseEntity<>(ex.getExceptionResponse(), HttpStatus.BAD_REQUEST);
	}

	// 400
	@ExceptionHandler(InvalidInputException.class)
	public final ResponseEntity<Object> handleException(final InvalidInputException ex, final WebRequest request) {

		return new ResponseEntity<>(ex.getExceptionResponse(), HttpStatus.BAD_REQUEST);
	}

	// 500
	@ExceptionHandler(TechnicalErrorException.class)
	public final ResponseEntity<Object> handleException(final TechnicalErrorException ex, final WebRequest request) {
		return new ResponseEntity<>(ex.getExceptionResponse(), HttpStatus.INTERNAL_SERVER_ERROR);
	}

}
