package com.jh.signator.maintain.producer.agreement.endpoint;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ws.context.MessageContext;
import org.springframework.ws.server.endpoint.annotation.Endpoint;
import org.springframework.ws.server.endpoint.annotation.PayloadRoot;
import org.springframework.ws.server.endpoint.annotation.RequestPayload;
import org.springframework.ws.server.endpoint.annotation.ResponsePayload;
import org.springframework.ws.soap.SoapHeaderElement;
import org.springframework.ws.soap.server.endpoint.annotation.SoapHeader;

import com.jh.common.logging.LoggerHandler;
import com.jh.signator.maintain.producer.agreement.exception.BadRequestException;
import com.jh.signator.maintain.producer.agreement.service.MaintainProducerAgreementService;
import com.jh.signator.maintain.producer.agreement.utils.HeaderKey;
import com.jh.signator.maintain.producer.agreement.utils.JHHeaderJaxbUtils;
import com.jh.signator.maintain.producer.agreement.utils.JHHeaderUtils;
import com.jh.signator.maintain.producer.agreement.utils.LoggerUtils;
import com.jh.signator.maintain.producer.agreement.utils.LoggingContextHolder;
import com.manulife.esb.xsd.common.jh.header.JHHeader;
import com.manulife.esb.xsd.distribution.jhfn.maintainproduceragreement.CreateProducerAgreementReply;
import com.manulife.esb.xsd.distribution.jhfn.maintainproduceragreement.CreateProducerAgreementRequest;
import com.manulife.esb.xsd.distribution.jhfn.maintainproduceragreement.DeleteProducerAgreementReply;
import com.manulife.esb.xsd.distribution.jhfn.maintainproduceragreement.DeleteProducerAgreementRequest;
import com.manulife.esb.xsd.distribution.jhfn.maintainproduceragreement.ReadProducerAgreementReply;
import com.manulife.esb.xsd.distribution.jhfn.maintainproduceragreement.ReadProducerAgreementRequest;
import com.manulife.esb.xsd.distribution.jhfn.maintainproduceragreement.SearchProducerAgreementReply;
import com.manulife.esb.xsd.distribution.jhfn.maintainproduceragreement.SearchProducerAgreementRequest;
import com.manulife.esb.xsd.distribution.jhfn.maintainproduceragreement.UpdateProducerAgreementReply;
import com.manulife.esb.xsd.distribution.jhfn.maintainproduceragreement.UpdateProducerAgreementRequest;

/**
 * Exposes MaintainProducerAgreement Operations via SOAP.
 *
 */
@Endpoint
public class MaintainProducerAgreementEndpoint {
	private static final String NAMESPACE_URI = "http://www.esb.manulife.com/xsd/distribution/jhfn/maintainproduceragreement";

	private static final String JH_HEADER_NS = "http://www.esb.manulife.com/xsd/common/jh/header";

	private final JHHeaderJaxbUtils jhHeaderJaxbUtils;
	private final LoggerUtils loggerUtils;
	final MaintainProducerAgreementService maintainProducerAgreementService;

	@Autowired
	public MaintainProducerAgreementEndpoint(final MaintainProducerAgreementService maintainProducerAgreementService,
			final JHHeaderJaxbUtils jhHeaderJaxbUtils, final LoggerUtils loggerUtils) {
		this.maintainProducerAgreementService = maintainProducerAgreementService;
		this.jhHeaderJaxbUtils = jhHeaderJaxbUtils;
		this.loggerUtils = loggerUtils;
	}

	@PayloadRoot(namespace = NAMESPACE_URI, localPart = "CreateProducerAgreement_request")
	@ResponsePayload
	public CreateProducerAgreementReply create(final @RequestPayload CreateProducerAgreementRequest request,
			final @SoapHeader("{" + JH_HEADER_NS + "}JHHeader") SoapHeaderElement jhHeaderElement,
			final MessageContext messageContext) {

		CreateProducerAgreementReply reply = null;
		final JHHeader header = parseHeader(jhHeaderElement);
		JHHeaderUtils.validateHeader(header);

		final String messageUUID = JHHeaderUtils.retrieveOrDefaultMessageUID(header, "CreateProducerAgreement");
		final String sourceSystemName = JHHeaderUtils.retrieveOrDefaultSourceSystemName(header);
		try {
			LoggingContextHolder.getLoggingContext().setContext(messageUUID, sourceSystemName);
			LoggerHandler.LogOut("INFO", "1", messageUUID, sourceSystemName, this.getClass().getName(),
					"Entering create EndPoint " + loggerUtils.writeAsJson(request));
			reply = maintainProducerAgreementService.create(header, request);
			LoggerHandler.LogOut("INFO", "4", messageUUID, sourceSystemName, this.getClass().getName(),
					"Exiting create EndPoint " + loggerUtils.writeAsJson(reply));
		} catch (final Exception e) {
			LoggerHandler.ErrorOut(e, messageUUID, sourceSystemName, this.getClass().getName(), e.getMessage());
			throw e;
		}

		// add response header as a property to be used by EndpointInterceptor
		// Current service does not modify header on response
		messageContext.setProperty(HeaderKey.JH_HEADER_KEY.getValue(), header);
		LoggingContextHolder.getLoggingContext().clear();

		return reply;
	}

	@PayloadRoot(namespace = NAMESPACE_URI, localPart = "UpdateProducerAgreement_request")
	@ResponsePayload
	public UpdateProducerAgreementReply update(final @RequestPayload UpdateProducerAgreementRequest request,
			final @SoapHeader("{" + JH_HEADER_NS + "}JHHeader") SoapHeaderElement jhHeaderElement,
			final MessageContext messageContext) {

		UpdateProducerAgreementReply reply = null;
		final JHHeader header = parseHeader(jhHeaderElement);
		JHHeaderUtils.validateHeader(header);

		final String messageUUID = JHHeaderUtils.retrieveOrDefaultMessageUID(header, "UpdateProducerAgreement");
		final String sourceSystemName = JHHeaderUtils.retrieveOrDefaultSourceSystemName(header);

		try {
			LoggingContextHolder.getLoggingContext().setContext(messageUUID, sourceSystemName);
			LoggerHandler.LogOut("INFO", "1", messageUUID, sourceSystemName, this.getClass().getName(),
					"Entering update EndPoint " + loggerUtils.writeAsJson(request));
			reply = maintainProducerAgreementService.update(header, request);
			LoggerHandler.LogOut("INFO", "4", messageUUID, sourceSystemName, this.getClass().getName(),
					"Exiting update EndPoint " + loggerUtils.writeAsJson(reply));
		} catch (final Exception e) {
			LoggerHandler.ErrorOut(e, messageUUID, sourceSystemName, this.getClass().getName(), e.getMessage());
			throw e;
		}

		// add response header as a property to be used by EndpointInterceptor
		// Current service does not modify header on response
		messageContext.setProperty(HeaderKey.JH_HEADER_KEY.getValue(), header);
		LoggingContextHolder.getLoggingContext().clear();

		return reply;
	}

	@PayloadRoot(namespace = NAMESPACE_URI, localPart = "DeleteProducerAgreement_request")
	@ResponsePayload
	public DeleteProducerAgreementReply delete(final @RequestPayload DeleteProducerAgreementRequest request,
			final @SoapHeader("{" + JH_HEADER_NS + "}JHHeader") SoapHeaderElement jhHeaderElement,
			final MessageContext messageContext) {

		DeleteProducerAgreementReply reply = null;
		final JHHeader header = parseHeader(jhHeaderElement);
		JHHeaderUtils.validateHeader(header);

		final String messageUUID = JHHeaderUtils.retrieveOrDefaultMessageUID(header, "DeleteProducerAgreement");
		final String sourceSystemName = JHHeaderUtils.retrieveOrDefaultSourceSystemName(header);

		try {
			LoggingContextHolder.getLoggingContext().setContext(messageUUID, sourceSystemName);
			LoggerHandler.LogOut("INFO", "1", messageUUID, sourceSystemName, this.getClass().getName(),
					"Entering delete EndPoint " + loggerUtils.writeAsJson(request));
			reply = maintainProducerAgreementService.delete(header, request);
			LoggerHandler.LogOut("INFO", "4", messageUUID, sourceSystemName, this.getClass().getName(),
					"Exiting delete EndPoint " + loggerUtils.writeAsJson(reply));
		} catch (final Exception e) {
			LoggerHandler.ErrorOut(e, messageUUID, sourceSystemName, this.getClass().getName(), e.getMessage());
			throw e;
		}

		// add response header as a property to be used by EndpointInterceptor
		// Current service does not modify header on response
		messageContext.setProperty(HeaderKey.JH_HEADER_KEY.getValue(), header);
		LoggingContextHolder.getLoggingContext().clear();

		return reply;
	}

	@PayloadRoot(namespace = NAMESPACE_URI, localPart = "ReadProducerAgreement_request")
	@ResponsePayload
	public ReadProducerAgreementReply read(final @RequestPayload ReadProducerAgreementRequest request,
			final @SoapHeader("{" + JH_HEADER_NS + "}JHHeader") SoapHeaderElement jhHeaderElement,
			final MessageContext messageContext) {

		ReadProducerAgreementReply reply = null;
		final JHHeader header = parseHeader(jhHeaderElement);
		JHHeaderUtils.validateHeader(header);

		final String messageUUID = JHHeaderUtils.retrieveOrDefaultMessageUID(header, "ReadProducerAgreement");
		final String sourceSystemName = JHHeaderUtils.retrieveOrDefaultSourceSystemName(header);

		try {
			LoggingContextHolder.getLoggingContext().setContext(messageUUID, sourceSystemName);
			LoggerHandler.LogOut("INFO", "1", messageUUID, sourceSystemName, this.getClass().getName(),
					"Entering read EndPoint " + loggerUtils.writeAsJson(request));
			reply = maintainProducerAgreementService.read(header, request);
			LoggerHandler.LogOut("INFO", "4", messageUUID, sourceSystemName, this.getClass().getName(),
					"Exiting read EndPoint " + loggerUtils.writeAsJson(reply));
		} catch (final Exception e) {
			LoggerHandler.ErrorOut(e, messageUUID, sourceSystemName, this.getClass().getName(), e.getMessage());
			throw e;
		}

		// add response header as a property to be used by EndpointInterceptor
		// Current service does not modify header on response
		messageContext.setProperty(HeaderKey.JH_HEADER_KEY.getValue(), header);
		LoggingContextHolder.getLoggingContext().clear();

		return reply;
	}

	@PayloadRoot(namespace = NAMESPACE_URI, localPart = "SearchProducerAgreement_request")
	@ResponsePayload
	public SearchProducerAgreementReply search(final @RequestPayload SearchProducerAgreementRequest request,
			final @SoapHeader("{" + JH_HEADER_NS + "}JHHeader") SoapHeaderElement jhHeaderElement,
			final MessageContext messageContext) {

		SearchProducerAgreementReply reply = null;
		final JHHeader header = parseHeader(jhHeaderElement);
		JHHeaderUtils.validateHeader(header);

		final String messageUUID = JHHeaderUtils.retrieveOrDefaultMessageUID(header, "SearchProducerAgreement");
		final String sourceSystemName = JHHeaderUtils.retrieveOrDefaultSourceSystemName(header);

		try {
			LoggingContextHolder.getLoggingContext().setContext(messageUUID, sourceSystemName);
			LoggerHandler.LogOut("INFO", "1", messageUUID, sourceSystemName, this.getClass().getName(),
					"Entering search EndPoint " + loggerUtils.writeAsJson(request));
			reply = maintainProducerAgreementService.search(header, request);
			LoggerHandler.LogOut("INFO", "4", messageUUID, sourceSystemName, this.getClass().getName(),
					"Exiting search EndPoint " + loggerUtils.writeAsJson(reply));
		} catch (final Exception e) {
			LoggerHandler.ErrorOut(e, messageUUID, sourceSystemName, this.getClass().getName(), e.getMessage());
			throw e;
		}

		// add response header as a property to be used by EndpointInterceptor
		// Current service does not modify header on response
		messageContext.setProperty(HeaderKey.JH_HEADER_KEY.getValue(), header);
		LoggingContextHolder.getLoggingContext().clear();

		return reply;
	}

	private JHHeader parseHeader(final SoapHeaderElement jhHeaderElement) {
		// parse JH Header if present
		JHHeader header = null;
		if (null != jhHeaderElement) {
			header = jhHeaderJaxbUtils.unmarshallJHHeader(jhHeaderElement);
		} else {
			throw new BadRequestException("Missing Header");
		}

		return header;
	}

}