/**
 *
 */
package com.jh.signator.maintain.producer.agreement.model;

import java.util.List;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.jh.signator.maintain.producer.agreement.model.data.ContractTypeInfo;
import com.jh.signator.maintain.producer.agreement.model.data.TProducerInfo;

/**
 * Holds information needed to validate ProducerAgreement for create/update.
 *
 */
public class ProducerAgreementValidationInfo {
	private String producerID;
	private String producerAgreementID;
	private String producerAgreementCode;
	private String producerAgreementType;
	private String producerAgreementDefinition;
	private List<ContractTypeInfo> contractTypeInfoList;
	private List<TProducerInfo> producerInfoList;

	public String getProducerID() {
		return producerID;
	}

	public void setProducerID(final String producerID) {
		this.producerID = producerID;
	}

	public String getProducerAgreementID() {
		return producerAgreementID;
	}

	public void setProducerAgreementID(final String producerAgreementID) {
		this.producerAgreementID = producerAgreementID;
	}

	public String getProducerAgreementCode() {
		return producerAgreementCode;
	}

	public void setProducerAgreementCode(final String producerAgreementCode) {
		this.producerAgreementCode = producerAgreementCode;
	}

	public String getProducerAgreementType() {
		return producerAgreementType;
	}

	public void setProducerAgreementType(final String producerAgreementType) {
		this.producerAgreementType = producerAgreementType;
	}

	public String getProducerAgreementDefinition() {
		return producerAgreementDefinition;
	}

	public void setProducerAgreementDefinition(final String producerAgreementDefinition) {
		this.producerAgreementDefinition = producerAgreementDefinition;
	}

	public List<ContractTypeInfo> getContractTypeInfoList() {
		return contractTypeInfoList;
	}

	public void setContractTypeInfoList(final List<ContractTypeInfo> contractTypeInfoList) {
		this.contractTypeInfoList = contractTypeInfoList;
	}

	public List<TProducerInfo> getProducerInfoList() {
		return producerInfoList;
	}

	public void setProducerInfoList(final List<TProducerInfo> producerInfoList) {
		this.producerInfoList = producerInfoList;
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
}
