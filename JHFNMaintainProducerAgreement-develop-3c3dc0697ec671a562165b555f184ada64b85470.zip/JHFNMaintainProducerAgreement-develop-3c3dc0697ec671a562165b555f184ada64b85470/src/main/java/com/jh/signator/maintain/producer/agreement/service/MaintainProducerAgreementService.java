package com.jh.signator.maintain.producer.agreement.service;

import java.math.BigInteger;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.jh.common.logging.LoggerHandler;
import com.jh.signator.maintain.producer.agreement.bizrule.MaintainProducerAgreementMapper;
import com.jh.signator.maintain.producer.agreement.bizrule.ProducerAgreementValidator;
import com.jh.signator.maintain.producer.agreement.dao.MaintainProducerAgreementDao;
import com.jh.signator.maintain.producer.agreement.dao.SearchFilterCriteriaUtils;
import com.jh.signator.maintain.producer.agreement.exception.InvalidInputException;
import com.jh.signator.maintain.producer.agreement.exception.MaxRecordsException;
import com.jh.signator.maintain.producer.agreement.exception.RecordNotFoundException;
import com.jh.signator.maintain.producer.agreement.model.ProducerAgreementValidationInfo;
import com.jh.signator.maintain.producer.agreement.model.data.ContractTypeInfo;
import com.jh.signator.maintain.producer.agreement.model.data.ProducerAgreementResult;
import com.jh.signator.maintain.producer.agreement.model.data.TProducerInfo;
import com.jh.signator.maintain.producer.agreement.utils.LoggerUtils;
import com.jh.signator.maintain.producer.agreement.utils.LoggingContextHolder;
import com.manulife.esb.xsd.common.jh.header.JHHeader;
import com.manulife.esb.xsd.distribution.jhfn.maintainproduceragreement.CreateProducerAgreement;
import com.manulife.esb.xsd.distribution.jhfn.maintainproduceragreement.CreateProducerAgreementReply;
import com.manulife.esb.xsd.distribution.jhfn.maintainproduceragreement.CreateProducerAgreementRequest;
import com.manulife.esb.xsd.distribution.jhfn.maintainproduceragreement.DeleteProducerAgreement;
import com.manulife.esb.xsd.distribution.jhfn.maintainproduceragreement.DeleteProducerAgreementReply;
import com.manulife.esb.xsd.distribution.jhfn.maintainproduceragreement.DeleteProducerAgreementRequest;
import com.manulife.esb.xsd.distribution.jhfn.maintainproduceragreement.PRODUCER;
import com.manulife.esb.xsd.distribution.jhfn.maintainproduceragreement.ReadProducerAgreement;
import com.manulife.esb.xsd.distribution.jhfn.maintainproduceragreement.ReadProducerAgreementReply;
import com.manulife.esb.xsd.distribution.jhfn.maintainproduceragreement.ReadProducerAgreementRequest;
import com.manulife.esb.xsd.distribution.jhfn.maintainproduceragreement.SearchProducerAgreementReply;
import com.manulife.esb.xsd.distribution.jhfn.maintainproduceragreement.SearchProducerAgreementRequest;
import com.manulife.esb.xsd.distribution.jhfn.maintainproduceragreement.UpdateProducerAgreement;
import com.manulife.esb.xsd.distribution.jhfn.maintainproduceragreement.UpdateProducerAgreementReply;
import com.manulife.esb.xsd.distribution.jhfn.maintainproduceragreement.UpdateProducerAgreementRequest;

/**
 * Handles orchestrating business logic associated with
 * MaintainProducerAgreement CRUD operations.
 *
 */
@Service
public class MaintainProducerAgreementService {

	@Value("${MaxRecords}")
	private int maxRecords;

	protected static final BigInteger VALID_IDREF_TYPE = BigInteger.valueOf(8000);
	@Autowired
	private LoggerUtils loggerUtils;

	@Autowired
	private MaintainProducerAgreementDao maintainProducerAgreementDao;

	@Transactional
	@Order(0)
	public CreateProducerAgreementReply create(final JHHeader header, final CreateProducerAgreementRequest request) {
		final CreateProducerAgreementReply reply = new CreateProducerAgreementReply();
		final String messageUUID = LoggingContextHolder.getLoggingContext().getMessageUUID();
		final String sourceSystemName = LoggingContextHolder.getLoggingContext().getSourceSystemName();

		LoggerHandler.LogOut("INFO", "2", messageUUID, sourceSystemName, this.getClass().getName(),
				"Entering create " + loggerUtils.writeAsJson(request));

		final String user = retrieveAndValidateUser(header);
		validateRequest(request.getCreateProducerAgreement().getIDRefType());

		reply.setProducer(createProducer(request.getCreateProducerAgreement().getID()));
		final MaintainProducerAgreementMapper mapper = new MaintainProducerAgreementMapper();

		final List<ContractTypeInfo> contractTypeInfoList = maintainProducerAgreementDao.selectContractTypeInfo();
		LoggerHandler.LogOut("INFO", "2a", messageUUID, sourceSystemName, this.getClass().getName(),
				"Results from selectContractTypeInfo " + contractTypeInfoList);
		final List<TProducerInfo> producerInfoList = maintainProducerAgreementDao
				.selectProducerInfoCreate(request.getCreateProducerAgreement().getID());
		LoggerHandler.LogOut("INFO", "2b", messageUUID, sourceSystemName, this.getClass().getName(),
				"Results from selectProducerInfoCreate " + producerInfoList);
		if (producerInfoList.isEmpty()) {
			throw new RecordNotFoundException();
		}
		final ProducerAgreementValidationInfo validationInfo = new ProducerAgreementValidationInfo();
		validationInfo.setContractTypeInfoList(contractTypeInfoList);
		validationInfo.setProducerInfoList(producerInfoList);

		final List<CreateProducerAgreement.ProducerAgreement> producerAgreements = request.getCreateProducerAgreement()
				.getProducerAgreement();
		for (final CreateProducerAgreement.ProducerAgreement producerAgreement : producerAgreements) {
			LoggerHandler.LogOut("INFO", "2c", messageUUID, sourceSystemName, this.getClass().getName(),
					"Starting createproduceragreement  " + loggerUtils.writeAsJson(producerAgreement));
			validationInfo.setProducerID(producerAgreement.getProducerID());
			validationInfo.setProducerAgreementCode(producerAgreement.getProducerAgreementCode());
			validationInfo.setProducerAgreementType(producerAgreement.getProducerAgreementType());
			validationInfo.setProducerAgreementDefinition(producerAgreement.getProducerAgreementDefinition());

			if (ProducerAgreementValidator.isValidCreate(validationInfo)) {
				final Long orgPartyIdNo = maintainProducerAgreementDao.selectFirmInfo(producerAgreement.getAgencyCode(),
						producerAgreement.getAgencyDetachedCode());
				LoggerHandler.LogOut("INFO", "2d", messageUUID, sourceSystemName, this.getClass().getName(),
						"Result from  selectFirmInfo " + orgPartyIdNo);
				if (orgPartyIdNo == null) {
					throw new InvalidInputException();
				}
				LoggerHandler.LogOut("INFO", "2e", messageUUID, sourceSystemName, this.getClass().getName(),
						"inserting ProducerAgreement ");
				maintainProducerAgreementDao.insertProducerAgreement(orgPartyIdNo, producerAgreement, user);
				final ProducerAgreementResult createdRecord = maintainProducerAgreementDao
						.selectProducerAgreementAfterCreate(user, producerAgreement.getProducerID());
				LoggerHandler.LogOut("INFO", "2f", messageUUID, sourceSystemName, this.getClass().getName(),
						"Result from selectProducerAgreementAfterCreate " + createdRecord);
				if (createdRecord == null) {
					// unhandled in TIBCO
					throw new RecordNotFoundException();
				}
				reply.getProducer().getProducerAgreement().add(mapper.mapProducerAgreement(createdRecord));
			} else {
				throw new InvalidInputException();
			}
		}

		LoggerHandler.LogOut("INFO", "3", messageUUID, sourceSystemName, this.getClass().getName(),
				"Exiting create " + loggerUtils.writeAsJson(reply));

		return reply;
	}

	@Transactional
	@Order(0)
	public UpdateProducerAgreementReply update(final JHHeader header, final UpdateProducerAgreementRequest request) {
		final UpdateProducerAgreementReply reply = new UpdateProducerAgreementReply();
		final String messageUUID = LoggingContextHolder.getLoggingContext().getMessageUUID();
		final String sourceSystemName = LoggingContextHolder.getLoggingContext().getSourceSystemName();

		LoggerHandler.LogOut("INFO", "2", messageUUID, sourceSystemName, this.getClass().getName(),
				"Entering update " + loggerUtils.writeAsJson(request));

		final String user = retrieveAndValidateUser(header);
		validateRequest(request.getUpdateProducerAgreement().getIDRefType());

		reply.setProducer(createProducer(request.getUpdateProducerAgreement().getID()));
		final MaintainProducerAgreementMapper mapper = new MaintainProducerAgreementMapper();

		final List<ContractTypeInfo> contractTypeInfoList = maintainProducerAgreementDao.selectContractTypeInfo();
		LoggerHandler.LogOut("INFO", "2a", messageUUID, sourceSystemName, this.getClass().getName(),
				"Results from selectContractTypeInfo " + contractTypeInfoList);
		final List<TProducerInfo> producerInfoList = maintainProducerAgreementDao
				.selectProducerInfoUpdate(request.getUpdateProducerAgreement().getID());
		LoggerHandler.LogOut("INFO", "2b", messageUUID, sourceSystemName, this.getClass().getName(),
				"Results from selectProducerInfoUpdate " + producerInfoList);
		if (producerInfoList.isEmpty()) {
			throw new RecordNotFoundException();
		}
		final ProducerAgreementValidationInfo validationInfo = new ProducerAgreementValidationInfo();
		validationInfo.setContractTypeInfoList(contractTypeInfoList);
		validationInfo.setProducerInfoList(producerInfoList);

		final List<UpdateProducerAgreement.ProducerAgreement> producerAgreements = request.getUpdateProducerAgreement()
				.getProducerAgreement();
		for (final UpdateProducerAgreement.ProducerAgreement producerAgreement : producerAgreements) {
			LoggerHandler.LogOut("INFO", "2c", messageUUID, sourceSystemName, this.getClass().getName(),
					"Starting updateproduceragreement  " + loggerUtils.writeAsJson(producerAgreement));
			validationInfo.setProducerAgreementID(producerAgreement.getProducerAgreementID());
			validationInfo.setProducerAgreementCode(producerAgreement.getProducerAgreementCode());
			validationInfo.setProducerAgreementType(producerAgreement.getProducerAgreementType());
			validationInfo.setProducerAgreementDefinition(producerAgreement.getProducerAgreementDefinition());

			if (ProducerAgreementValidator.isValidUpdate(validationInfo)) {
				final Long orgPartyIdNo = maintainProducerAgreementDao.selectFirmInfo(producerAgreement.getAgencyCode(),
						producerAgreement.getAgencyDetachedCode());
				LoggerHandler.LogOut("INFO", "2d", messageUUID, sourceSystemName, this.getClass().getName(),
						"Result from  selectFirmInfo " + orgPartyIdNo);
				if (orgPartyIdNo == null) {
					throw new InvalidInputException();
				}
				LoggerHandler.LogOut("INFO", "2e", messageUUID, sourceSystemName, this.getClass().getName(),
						"updating ProducerAgreement ");
				if ((maintainProducerAgreementDao.updateProducerAgreement(orgPartyIdNo, producerAgreement, user) > 0)) {
					final List<ProducerAgreementResult> producerAgreementResults = maintainProducerAgreementDao
							.selectProducerAgreementAfterUpdateDelete(producerAgreement.getProducerAgreementID());
					LoggerHandler.LogOut("INFO", "2f", messageUUID, sourceSystemName, this.getClass().getName(),
							"Result from selectProducerAgreementAfterUpdateDelete " + producerAgreementResults);
					if (producerAgreementResults.isEmpty()) {
						// unhandled in TIBCO
						throw new RecordNotFoundException();
					}
					reply.getProducer().getProducerAgreement()
							.addAll(mapper.mapProducerAgreement(producerAgreementResults));
				} else {
					throw new InvalidInputException();
				}
			} else {
				throw new InvalidInputException();
			}
		}

		LoggerHandler.LogOut("INFO", "3", messageUUID, sourceSystemName, this.getClass().getName(),
				"Exiting update " + loggerUtils.writeAsJson(reply));

		return reply;
	}

	@Transactional
	@Order(0)
	public DeleteProducerAgreementReply delete(final JHHeader header, final DeleteProducerAgreementRequest request) {
		final DeleteProducerAgreementReply reply = new DeleteProducerAgreementReply();
		final String messageUUID = LoggingContextHolder.getLoggingContext().getMessageUUID();
		final String sourceSystemName = LoggingContextHolder.getLoggingContext().getSourceSystemName();

		LoggerHandler.LogOut("INFO", "2", messageUUID, sourceSystemName, this.getClass().getName(),
				"Entering delete " + loggerUtils.writeAsJson(request));

		final String user = retrieveAndValidateUser(header);
		validateRequest(request.getDeleteProducerAgreement().getIDRefType());

		reply.setProducer(createProducer(request.getDeleteProducerAgreement().getID()));
		final MaintainProducerAgreementMapper mapper = new MaintainProducerAgreementMapper();

		final List<TProducerInfo> producerInfoList = maintainProducerAgreementDao
				.selectProducerInfoDelete(request.getDeleteProducerAgreement().getID());
		LoggerHandler.LogOut("INFO", "2a", messageUUID, sourceSystemName, this.getClass().getName(),
				"Results from selectProducerInfoDelete " + producerInfoList);

		if (producerInfoList.isEmpty()) {
			throw new RecordNotFoundException();
		}
		final ProducerAgreementValidationInfo validationInfo = new ProducerAgreementValidationInfo();
		validationInfo.setProducerInfoList(producerInfoList);

		final List<DeleteProducerAgreement.ProducerAgreement> producerAgreements = request.getDeleteProducerAgreement()
				.getProducerAgreement();
		for (final DeleteProducerAgreement.ProducerAgreement producerAgreement : producerAgreements) {
			validationInfo.setProducerAgreementID(producerAgreement.getProducerAgreementID());
			LoggerHandler.LogOut("INFO", "2b", messageUUID, sourceSystemName, this.getClass().getName(),
					"Starting deleteproduceragreement  " + loggerUtils.writeAsJson(producerAgreement));
			if (ProducerAgreementValidator.isValidDelete(validationInfo)) {
				LoggerHandler.LogOut("INFO", "2c", messageUUID, sourceSystemName, this.getClass().getName(),
						"deleting ProducerAgreement ");
				if ((maintainProducerAgreementDao.deleteProducerAgreement(producerAgreement, user) > 0)) {
					final List<ProducerAgreementResult> producerAgreementResults = maintainProducerAgreementDao
							.selectProducerAgreementAfterUpdateDelete(producerAgreement.getProducerAgreementID());
					LoggerHandler.LogOut("INFO", "2d", messageUUID, sourceSystemName, this.getClass().getName(),
							"Result from selectProducerAgreementAfterUpdateDelete " + producerAgreementResults);
					if (producerAgreementResults.isEmpty()) {

						throw new RecordNotFoundException();
					}
					reply.getProducer().getProducerAgreement()
							.addAll(mapper.mapProducerAgreement(producerAgreementResults));
				} else {
					throw new InvalidInputException();
				}
			} else {
				throw new InvalidInputException();
			}
		}

		LoggerHandler.LogOut("INFO", "3", messageUUID, sourceSystemName, this.getClass().getName(),
				"Exiting delete " + loggerUtils.writeAsJson(reply));

		return reply;
	}

	public SearchProducerAgreementReply search(final JHHeader header, final SearchProducerAgreementRequest request) {
		final SearchProducerAgreementReply reply = new SearchProducerAgreementReply();
		final String messageUUID = LoggingContextHolder.getLoggingContext().getMessageUUID();
		final String sourceSystemName = LoggingContextHolder.getLoggingContext().getSourceSystemName();
		LoggerHandler.LogOut("INFO", "2", messageUUID, sourceSystemName, this.getClass().getName(),
				"Entering search " + loggerUtils.writeAsJson(request));

		final MaintainProducerAgreementMapper mapper = new MaintainProducerAgreementMapper();

		if (!SearchFilterCriteriaUtils
				.isSearchCriteriaValid(request.getSearchProducerAgreement().getSearchCriteria())) {
			throw new InvalidInputException();
		}
		final long requestMaxRecords = request.getSearchProducerAgreement().getMaxRecords();
		if (requestMaxRecords > maxRecords) {
			throw new MaxRecordsException(request.getSearchProducerAgreement().getMaxRecords(), maxRecords, false);
		}

		final int countProducerAgreementInfo = maintainProducerAgreementDao
				.searchProducerAgreementCount(request.getSearchProducerAgreement());
		LoggerHandler.LogOut("INFO", "2b", messageUUID, sourceSystemName, this.getClass().getName(),
				"Results from  searchProducerAgreementCount " + countProducerAgreementInfo);
		if (countProducerAgreementInfo > requestMaxRecords) {
			throw new MaxRecordsException(countProducerAgreementInfo, requestMaxRecords, true);
		}

		final List<ProducerAgreementResult> results = maintainProducerAgreementDao
				.searchProducerAgreement(request.getSearchProducerAgreement());

		LoggerHandler.LogOut("INFO", "2c", messageUUID, sourceSystemName, this.getClass().getName(),
				"Results from  searchProducerAgreement " + results);
		reply.getProducer().addAll(mapper.mapProducer(results));

		LoggerHandler.LogOut("INFO", "3", messageUUID, sourceSystemName, this.getClass().getName(),
				"Exiting search " + loggerUtils.writeAsJson(reply));

		return reply;
	}

	public ReadProducerAgreementReply read(final JHHeader header, final ReadProducerAgreementRequest request) {
		final ReadProducerAgreementReply reply = new ReadProducerAgreementReply();
		final String messageUUID = LoggingContextHolder.getLoggingContext().getMessageUUID();
		final String sourceSystemName = LoggingContextHolder.getLoggingContext().getSourceSystemName();

		LoggerHandler.LogOut("INFO", "2", messageUUID, sourceSystemName, this.getClass().getName(),
				"Entering read " + loggerUtils.writeAsJson(request));

		validateRequest(request.getReadProducerAgreement().getIDRefType());

		reply.setProducer(createProducer(request.getReadProducerAgreement().getID()));
		final MaintainProducerAgreementMapper mapper = new MaintainProducerAgreementMapper();

		final List<ReadProducerAgreement.ProducerAgreement> producerAgreements = request.getReadProducerAgreement()
				.getProducerAgreement();
		for (final ReadProducerAgreement.ProducerAgreement producerAgreement : producerAgreements) {
			LoggerHandler.LogOut("INFO", "2a", messageUUID, sourceSystemName, this.getClass().getName(),
					"Starting readproduceragreement  " + loggerUtils.writeAsJson(producerAgreement));

			final List<ProducerAgreementResult> producerAgreementResults = maintainProducerAgreementDao
					.selectProducerAgreementRead(request.getReadProducerAgreement().getID(),
							producerAgreement.getProducerAgreementID());
			LoggerHandler.LogOut("INFO", "2b", messageUUID, sourceSystemName, this.getClass().getName(),
					"Results from  selectProducerAgreementRead " + producerAgreementResults);
			if (producerAgreementResults.size() > 0) {
				reply.getProducer().getProducerAgreement()
						.addAll(mapper.mapProducerAgreement(producerAgreementResults));
			} else {
				throw new RecordNotFoundException();
			}
		}

		LoggerHandler.LogOut("INFO", "3", messageUUID, sourceSystemName, this.getClass().getName(),
				"Exiting read " + loggerUtils.writeAsJson(reply));

		return reply;
	}

	// used for testing only
	protected void setMaxRecords(final int maxRecords) {
		this.maxRecords = maxRecords;
	}

	private void validateRequest(final BigInteger idRefType) {
		if (!VALID_IDREF_TYPE.equals(idRefType)) {
			throw new InvalidInputException();
		}
	}

	/**
	 * Retrieve user from header, and if not found throw proper exception.
	 *
	 * @param header
	 * @return
	 */
	private String retrieveAndValidateUser(final JHHeader header) {
		final String user = header.getMessageSource().getUserID();
		if (StringUtils.isEmpty(user)) {
			throw new InvalidInputException();
		}
		return user;
	}

	private PRODUCER createProducer(final String id) {
		final PRODUCER producer = new PRODUCER();
		producer.setID(id);
		producer.setIDRefType(VALID_IDREF_TYPE);

		return producer;
	}

}
