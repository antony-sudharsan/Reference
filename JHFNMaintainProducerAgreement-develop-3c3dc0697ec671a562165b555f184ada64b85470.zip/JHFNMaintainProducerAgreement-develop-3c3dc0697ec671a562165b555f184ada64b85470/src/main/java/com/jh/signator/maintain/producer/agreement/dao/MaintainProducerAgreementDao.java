package com.jh.signator.maintain.producer.agreement.dao;

import java.util.List;

import com.jh.signator.maintain.producer.agreement.model.data.ContractTypeInfo;
import com.jh.signator.maintain.producer.agreement.model.data.ProducerAgreementResult;
import com.jh.signator.maintain.producer.agreement.model.data.TProducerInfo;
import com.manulife.esb.xsd.distribution.jhfn.maintainproduceragreement.CreateProducerAgreement.ProducerAgreement;
import com.manulife.esb.xsd.distribution.jhfn.maintainproduceragreement.DeleteProducerAgreement;
import com.manulife.esb.xsd.distribution.jhfn.maintainproduceragreement.SearchProducerAgreement;
import com.manulife.esb.xsd.distribution.jhfn.maintainproduceragreement.UpdateProducerAgreement;

/**
 * Interface for create, update, delete, read and search operations related to
 * MaintainProducerAgreement.
 *
 */
public interface MaintainProducerAgreementDao {

	List<ContractTypeInfo> selectContractTypeInfo();

	List<TProducerInfo> selectProducerInfoCreate(final String partyIdNo);

	List<TProducerInfo> selectProducerInfoUpdate(final String partyIdNo);

	List<TProducerInfo> selectProducerInfoDelete(final String partyIdNo);

	Long selectFirmInfo(final String agencyCode, final String agencyDetachedCode);

	int insertProducerAgreement(final Long orgPartyIdNo, final ProducerAgreement producerAgreement, final String user);

	int updateProducerAgreement(final Long orgPartyIdNo,
			final UpdateProducerAgreement.ProducerAgreement producerAgreement, final String user);

	int deleteProducerAgreement(final DeleteProducerAgreement.ProducerAgreement producerAgreement, final String user);

	ProducerAgreementResult selectProducerAgreementAfterCreate(final String user, final String producerIdNo);

	List<ProducerAgreementResult> selectProducerAgreementRead(final String partyIdNo, final String producerConIdNo);

	List<ProducerAgreementResult> selectProducerAgreementAfterUpdateDelete(final String producerConIdNo);

	int searchProducerAgreementCount(SearchProducerAgreement searchProducerAgreement);

	List<ProducerAgreementResult> searchProducerAgreement(SearchProducerAgreement searchProducerAgreement);

}
