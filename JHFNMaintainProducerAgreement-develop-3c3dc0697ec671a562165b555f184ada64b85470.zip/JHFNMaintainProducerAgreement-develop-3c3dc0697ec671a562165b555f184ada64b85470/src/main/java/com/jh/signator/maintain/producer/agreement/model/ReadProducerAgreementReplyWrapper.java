/**
 *
 */
package com.jh.signator.maintain.producer.agreement.model;

import com.manulife.esb.xsd.common.jh.header.JHHeader;
import com.manulife.esb.xsd.distribution.jhfn.maintainproduceragreement.ReadProducerAgreementReply;

/**
 * Used to hold reply with response header.
 *
 */
public class ReadProducerAgreementReplyWrapper {
	private JHHeader header;
	private ReadProducerAgreementReply reply;

	public JHHeader getHeader() {
		return header;
	}

	public void setHeader(final JHHeader header) {
		this.header = header;
	}

	public ReadProducerAgreementReply getReply() {
		return reply;
	}

	public void setReply(final ReadProducerAgreementReply reply) {
		this.reply = reply;
	}

}
