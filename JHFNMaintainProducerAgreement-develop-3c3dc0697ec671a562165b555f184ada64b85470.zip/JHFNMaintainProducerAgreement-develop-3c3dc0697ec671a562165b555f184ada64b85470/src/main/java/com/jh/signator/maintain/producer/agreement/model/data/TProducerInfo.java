/**
 *
 */
package com.jh.signator.maintain.producer.agreement.model.data;

import org.apache.commons.lang3.builder.ToStringBuilder;

/**
 * Represents result set from Select Producer Info.
 *
 */
public class TProducerInfo {

	private Long partyIdNo;
	private Long prdcrIdNo;
	private Long prdcrConIdNo;

	public Long getPartyIdNo() {
		return partyIdNo;
	}

	public void setPartyIdNo(final Long partyIdNo) {
		this.partyIdNo = partyIdNo;
	}

	public Long getPrdcrIdNo() {
		return prdcrIdNo;
	}

	public void setPrdcrIdNo(final Long prdcrIdNo) {
		this.prdcrIdNo = prdcrIdNo;
	}

	public Long getPrdcrConIdNo() {
		return prdcrConIdNo;
	}

	public void setPrdcrConIdNo(final Long prdcrConIdNo) {
		this.prdcrConIdNo = prdcrConIdNo;
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
}
