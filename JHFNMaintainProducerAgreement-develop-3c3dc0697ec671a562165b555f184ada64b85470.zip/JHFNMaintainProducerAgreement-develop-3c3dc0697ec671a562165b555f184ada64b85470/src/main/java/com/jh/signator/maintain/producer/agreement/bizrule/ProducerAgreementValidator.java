/**
 *
 */
package com.jh.signator.maintain.producer.agreement.bizrule;

import org.apache.commons.lang3.StringUtils;

import com.jh.signator.maintain.producer.agreement.model.ProducerAgreementValidationInfo;

/**
 * Validates ProducerAgreement request info for create/update against contract
 * and producer info.
 *
 */
public class ProducerAgreementValidator {

	public static boolean isValidCreate(final ProducerAgreementValidationInfo validationInfo) {
		boolean isValid = true;
		if (!validationInfo.getProducerInfoList().stream().anyMatch(p -> {
			return ((p.getPrdcrIdNo() != null) && p.getPrdcrIdNo().toString().equals(validationInfo.getProducerID()));
		})) {
			isValid = false;
			// Note: contractCode and ContractTypeCodeNo can not be null in db
		} else if (!validationInfo.getContractTypeInfoList().stream().anyMatch(c -> {
			return (c.getContractCode().equals(validationInfo.getProducerAgreementCode())
					&& c.getContractTypeCodeNo().toString().equals(validationInfo.getProducerAgreementType())
					&& StringUtils.equals(c.getAgentTypeKey(), validationInfo.getProducerAgreementDefinition()));
		})) {
			isValid = false;
		}

		return isValid;

	}

	public static boolean isValidUpdate(final ProducerAgreementValidationInfo validationInfo) {
		boolean isValid = true;
		if (!validationInfo.getProducerInfoList().stream().anyMatch(p -> {
			return ((p.getPrdcrConIdNo() != null)
					&& p.getPrdcrConIdNo().toString().equals(validationInfo.getProducerAgreementID()));
		})) {
			isValid = false;
			// Note: contractCode and ContractTypeCodeNo can not be null in db
		} else if (!validationInfo.getContractTypeInfoList().stream().anyMatch(c -> {
			return (c.getContractCode().equals(validationInfo.getProducerAgreementCode())
					&& c.getContractTypeCodeNo().toString().equals(validationInfo.getProducerAgreementType())
					&& StringUtils.equals(c.getAgentTypeKey(), validationInfo.getProducerAgreementDefinition()));
		})) {
			isValid = false;
		}

		return isValid;

	}

	public static boolean isValidDelete(final ProducerAgreementValidationInfo validationInfo) {
		boolean isValid = true;
		if (!validationInfo.getProducerInfoList().stream().anyMatch(p -> {
			return ((p.getPrdcrConIdNo() != null)
					&& p.getPrdcrConIdNo().toString().equals(validationInfo.getProducerAgreementID()));
		})) {
			isValid = false;
		}

		return isValid;

	}
}
