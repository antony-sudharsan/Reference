/**
 *
 */
package com.jh.signator.maintain.producer.agreement.model;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import com.manulife.esb.xsd.common.jh.header.JHHeader;
import com.manulife.esb.xsd.distribution.jhfn.maintainproduceragreement.CreateProducerAgreementRequest;

/**
 * Used to hold request and header.
 *
 */
public class CreateProducerAgreementRequestWrapper {

	@NotNull
	private JHHeader header;

	@NotNull
	@Valid
	private CreateProducerAgreementRequest request;

	public JHHeader getHeader() {
		return header;
	}

	public void setHeader(final JHHeader header) {
		this.header = header;
	}

	public CreateProducerAgreementRequest getRequest() {
		return request;
	}

	public void setRequest(final CreateProducerAgreementRequest request) {
		this.request = request;
	}

}
