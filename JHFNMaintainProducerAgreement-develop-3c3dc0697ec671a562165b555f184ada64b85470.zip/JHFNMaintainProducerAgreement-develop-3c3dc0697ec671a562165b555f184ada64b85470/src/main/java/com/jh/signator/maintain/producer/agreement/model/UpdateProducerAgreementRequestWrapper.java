/**
 *
 */
package com.jh.signator.maintain.producer.agreement.model;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import com.manulife.esb.xsd.common.jh.header.JHHeader;
import com.manulife.esb.xsd.distribution.jhfn.maintainproduceragreement.UpdateProducerAgreementRequest;

/**
 * Used to hold request and header.
 *
 */
public class UpdateProducerAgreementRequestWrapper {

	@NotNull
	private JHHeader header;

	@NotNull
	@Valid
	private UpdateProducerAgreementRequest request;

	public JHHeader getHeader() {
		return header;
	}

	public void setHeader(final JHHeader header) {
		this.header = header;
	}

	public UpdateProducerAgreementRequest getRequest() {
		return request;
	}

	public void setRequest(final UpdateProducerAgreementRequest request) {
		this.request = request;
	}

}
