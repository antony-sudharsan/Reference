/**
 *
 */
package com.jh.signator.maintain.producer.agreement.model;

import com.manulife.esb.xsd.common.jh.header.JHHeader;
import com.manulife.esb.xsd.distribution.jhfn.maintainproduceragreement.UpdateProducerAgreementReply;

/**
 * Used to hold reply with response header.
 *
 */
public class UpdateProducerAgreementReplyWrapper {
	private JHHeader header;
	private UpdateProducerAgreementReply reply;

	public JHHeader getHeader() {
		return header;
	}

	public void setHeader(final JHHeader header) {
		this.header = header;
	}

	public UpdateProducerAgreementReply getReply() {
		return reply;
	}

	public void setReply(final UpdateProducerAgreementReply reply) {
		this.reply = reply;
	}

}
