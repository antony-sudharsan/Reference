/**
 *
 */
package com.jh.signator.maintain.producer.agreement.dao;

import java.util.List;

import org.apache.commons.lang3.StringUtils;

import com.manulife.esb.xsd.distribution.jhfn.maintainproduceragreement.CONDITIONALLOGIC;
import com.manulife.esb.xsd.distribution.jhfn.maintainproduceragreement.DATAFIELD;
import com.manulife.esb.xsd.distribution.jhfn.maintainproduceragreement.OPERATION;
import com.manulife.esb.xsd.distribution.jhfn.maintainproduceragreement.SEARCHCRITERIA;

/**
 * Handles adding filters to where clause for search queries.
 *
 */
public class SearchFilterCriteriaUtils {
	protected static final String P_ALIAS = " P.";
	protected static final String FIRM_ALIAS = " FIRM.";
	protected static final String CON_ALIAS = " CON.";
	protected static final String LIKE = " like ";
	protected static final String PERCENT = "%";
	protected static final String CONTRACT_CODE = "con_cd";
	protected static final String CONTRACT_TYPE_CODE = "con_typ_cd_no";
	protected static final String AGENT_TYPE_KEY = "agent_typ_key";
	protected static final String PRIMARY_CON_IND = "prim_con_ind";
	protected static final String YES_IND = "Y";
	protected static final String BIT_TRUE = "1";
	protected static final String EQUALS_ONE = "=1";
	protected static final String EQUALS_ZERO = "=0";
	protected static final String SINGLE_QUOTE = "'";

	public static boolean isSearchCriteriaValid(final List<SEARCHCRITERIA> searchCriterias) {
		boolean isValid = true;
		if (!searchCriterias.isEmpty()) {
			final SEARCHCRITERIA criteria = searchCriterias.get(0);
			if ((criteria.getLogic() != null) && (criteria.getLogic() == CONDITIONALLOGIC.OR)) {
				isValid = false;
			}
		}
		return isValid;
	}

	public static String buildSearchFilters(final List<SEARCHCRITERIA> searchCriterias) {
		final StringBuilder filterCriteria = new StringBuilder();

		for (final SEARCHCRITERIA searchCriteria : searchCriterias) {
			final String value = searchCriteria.getValue();
			if (StringUtils.isNotEmpty(value)) {
				final CONDITIONALLOGIC logic = searchCriteria.getLogic();
				String sqlCondition = CONDITIONALLOGIC.OR.value();
				if ((logic == null) || (logic == CONDITIONALLOGIC.AND)) {
					sqlCondition = CONDITIONALLOGIC.AND.value();
				}
				final StringBuilder filter = new StringBuilder(" ");
				boolean callAppend = true;

				switch (searchCriteria.getDataField()) {
				case FED_TAX_ID_NO:
					filter.append(sqlCondition).append(P_ALIAS).append(DATAFIELD.FED_TAX_ID_NO.value()).append(LIKE);
					break;
				case PARTY_ID_NO:
					filter.append(sqlCondition).append(P_ALIAS).append(DATAFIELD.PARTY_ID_NO.value()).append(LIKE);
					break;
				case PRD_ID:
					filter.append(sqlCondition).append(P_ALIAS).append(DATAFIELD.PRD_ID.value()).append(LIKE);
					break;
				case PYRL_NO:
					filter.append(sqlCondition).append(CON_ALIAS).append(DATAFIELD.PYRL_NO.value()).append(LIKE);
					break;
				case PRODUCER_AGREEMENT_CODE:
					filter.append(sqlCondition).append(CON_ALIAS).append(CONTRACT_CODE).append(LIKE);
					break;
				case PRODUCER_AGREEMENT_TYPE:
					filter.append(sqlCondition).append(CON_ALIAS).append(CONTRACT_TYPE_CODE).append(LIKE);
					break;
				case PRODUCER_AGREEMENT_DEFINITION:
					filter.append(sqlCondition).append(CON_ALIAS).append(AGENT_TYPE_KEY).append(LIKE);
					break;
				case ORG_NM:
					filter.append(sqlCondition).append(FIRM_ALIAS).append(DATAFIELD.ORG_NM.value()).append(LIKE);
					break;
				case ORG_AGENCY_CD:
					filter.append(sqlCondition).append(FIRM_ALIAS).append(DATAFIELD.ORG_AGENCY_CD.value()).append(LIKE);
					break;
				case ORG_DTCH_CD:
					filter.append(sqlCondition).append(FIRM_ALIAS).append(DATAFIELD.ORG_DTCH_CD.value()).append(LIKE);
					break;
				case PRODUCER_AGREEMENT_PRIMARY_IND:
					filter.append(sqlCondition).append(CON_ALIAS).append(PRIMARY_CON_IND);
					if (YES_IND.equals(value) || BIT_TRUE.equals(value)) {
						filter.append(EQUALS_ONE);
					} else {
						filter.append(EQUALS_ZERO);
					}
					callAppend = false;
					break;
				default:
					callAppend = false;
					break;
				}

				if (callAppend) {
					filter.append(appendOperationAndValue(searchCriteria.getOperation(), value));
				}
				filterCriteria.append(filter);
			}
		}

		return filterCriteria.toString();
	}

	protected static String appendOperationAndValue(final OPERATION operation, final String value) {
		final StringBuilder filter = new StringBuilder();
		switch (operation) {
		case BEGINS_WITH:
			filter.append(SINGLE_QUOTE).append(value).append(PERCENT).append(SINGLE_QUOTE);
			break;
		case ENDS_WITH:
			filter.append(SINGLE_QUOTE).append(PERCENT).append(value).append(SINGLE_QUOTE);
			break;
		case CONTAINS:
			filter.append(SINGLE_QUOTE).append(PERCENT).append(value).append(PERCENT).append(SINGLE_QUOTE);
			break;
		default:
			filter.append(SINGLE_QUOTE).append(value).append(SINGLE_QUOTE);
			break;
		}

		return filter.toString();

	}
}
