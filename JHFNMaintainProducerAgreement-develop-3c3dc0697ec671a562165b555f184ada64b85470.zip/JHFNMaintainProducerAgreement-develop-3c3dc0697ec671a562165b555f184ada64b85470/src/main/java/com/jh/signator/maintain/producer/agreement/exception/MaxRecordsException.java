/**
 *
 */
package com.jh.signator.maintain.producer.agreement.exception;

/**
 * Exception for max records.
 *
 */
public class MaxRecordsException extends BaseFaultException {

	private static final long serialVersionUID = -3723020711896654003L;
	private static final String DEFAULT_CODE = "998";
	private static final String DEFAULT_REASON = "Max Result Limit Encountered";
	private static final String DEFAULT_DETAILS_QUERY = "%d records found, it is greater than user maximum input of %d";
	private static final String DEFAULT_DETAILS_INPUT = "Max Result inputted of %d is greater than recommended %s max limit";
	private static final String FAULT_STRING = "Internal Error";

	public MaxRecordsException(final long recordsFound, final long maxRecords, final boolean isQuery) {
		super(DEFAULT_CODE, DEFAULT_REASON, formatDetail(recordsFound, maxRecords, isQuery), FAULT_STRING);
	}

	private static String formatDetail(final long recordsFound, final long maxRecords, final boolean isQuery) {
		if (isQuery) {
			return String.format(DEFAULT_DETAILS_QUERY, recordsFound, maxRecords);
		} else {
			return String.format(DEFAULT_DETAILS_INPUT, recordsFound, maxRecords);
		}

	}

}
