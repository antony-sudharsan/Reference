/**
 *
 */
package com.jh.signator.maintain.producer.agreement.model.data;

import org.apache.commons.lang3.builder.ToStringBuilder;

/**
 * Represents result set row from Get Contract Type Info Query.
 *
 */
public class ContractTypeInfo {
	private String contractCode;
	private Long contractTypeCodeNo;
	private String agentTypeKey;

	public String getContractCode() {
		return contractCode;
	}

	public void setContractCode(final String contractCode) {
		this.contractCode = contractCode;
	}

	public Long getContractTypeCodeNo() {
		return contractTypeCodeNo;
	}

	public void setContractTypeCodeNo(final Long contractTypeCodeNo) {
		this.contractTypeCodeNo = contractTypeCodeNo;
	}

	public String getAgentTypeKey() {
		return agentTypeKey;
	}

	public void setAgentTypeKey(final String agentTypeKey) {
		this.agentTypeKey = agentTypeKey;
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
}
