package com.jh.signator.maintain.producer.agreement.utils.endpoint;

import org.springframework.ws.client.WebServiceClientException;
import org.springframework.ws.client.support.interceptor.ClientInterceptor;
import org.springframework.ws.context.MessageContext;
import org.springframework.ws.soap.SoapHeader;
import org.springframework.ws.soap.SoapMessage;

import com.jh.signator.maintain.producer.agreement.utils.JHHeaderJaxbUtils;
import com.jh.signator.maintain.producer.agreement.utils.LoggerUtils;
import com.manulife.esb.xsd.common.jh.header.JHHeader;
import com.manulife.esb.xsd.common.jh.header.MessageSource;

public class TestClientInterceptor implements ClientInterceptor {
	private static final String MESSAGE_UUID = "ABC_1002";
	private static final String SOURCE_SYSTEM = "ESB";
	private static final String USER = "TEST";

	private final JHHeaderJaxbUtils jhHeaderJaxbUtils;

	public TestClientInterceptor() {
		this.jhHeaderJaxbUtils = new JHHeaderJaxbUtils();
		;
	}

	@Override
	public boolean handleRequest(final MessageContext messageContext) throws WebServiceClientException {
		final SoapMessage soapMessage = (SoapMessage) messageContext.getRequest();
		final SoapHeader soapHeader = soapMessage.getSoapHeader();
		final JHHeader jhHeader = createSampleJHHeader();
		jhHeaderJaxbUtils.marshallJHHeaderToResult(jhHeader, soapHeader.getResult());
		return true;
	}

	@Override
	public boolean handleResponse(final MessageContext messageContext) throws WebServiceClientException {
		return true;
	}

	@Override
	public boolean handleFault(final MessageContext messageContext) throws WebServiceClientException {
		return true;
	}

	@Override
	public void afterCompletion(final MessageContext messageContext, final Exception ex) throws WebServiceClientException {

	}

	private JHHeader createSampleJHHeader() {
		final JHHeader header = new JHHeader();
		header.setMessageUID(MESSAGE_UUID);
		final MessageSource messageSource = new MessageSource();
		messageSource.setApplicationName(SOURCE_SYSTEM);
		messageSource.setApplicationUserID(USER);
		messageSource.setUserID("user1");

		header.setMessageSource(messageSource);
		final LoggerUtils loggerUtils = new LoggerUtils();
		System.out.println(loggerUtils.writeAsJson(header));
		return header;
	}

}
