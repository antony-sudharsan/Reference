/**
 *
 */
package com.jh.signator.maintain.producer.agreement.utils.endpoint;

import org.hamcrest.Description;
import org.hamcrest.TypeSafeMatcher;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import org.springframework.ws.soap.SoapFaultDetail;
import org.springframework.ws.soap.client.SoapFaultClientException;

/**
 * Handles checking the SoapFault code.
 *
 */
public class SoapFaultDetailMatcher extends TypeSafeMatcher<SoapFaultClientException> {

	public static SoapFaultDetailMatcher hasCode(final String code) {
		return new SoapFaultDetailMatcher(code);
	}

	private Jaxb2Marshaller marshaller;
	private String actualCode;
	private final String expectedCode;

	private SoapFaultDetailMatcher(final String expectedCode) {
		this.expectedCode = expectedCode;

		try {
			marshaller = new Jaxb2Marshaller();
			marshaller.setPackagesToScan(com.manulife.esb.jhfn.soapfault.SoapFault.class.getPackage().getName());
			marshaller.afterPropertiesSet();
		} catch (final Exception e) {
			throw new RuntimeException(e);
		}
	}

	@Override
	public boolean matchesSafely(final SoapFaultClientException exception) {
		final SoapFaultDetail detail = exception.getSoapFault().getFaultDetail();

		final com.manulife.esb.jhfn.soapfault.SoapFault fault = (com.manulife.esb.jhfn.soapfault.SoapFault) marshaller
				.unmarshal(detail.getDetailEntries().next().getSource());
		actualCode = fault.getCode();
		return expectedCode.equals(actualCode);
	}

	@Override
	public void describeTo(final Description description) {
		description.appendValue(actualCode).appendText(" was found instead of ").appendValue(expectedCode);
	}
}
