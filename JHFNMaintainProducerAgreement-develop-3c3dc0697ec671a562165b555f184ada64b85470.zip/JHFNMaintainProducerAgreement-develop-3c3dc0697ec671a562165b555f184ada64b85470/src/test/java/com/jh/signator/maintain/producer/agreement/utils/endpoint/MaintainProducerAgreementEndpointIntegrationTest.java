/**
 *
 */
package com.jh.signator.maintain.producer.agreement.utils.endpoint;

import static org.assertj.core.api.Assertions.assertThat;

import java.io.IOException;
import java.math.BigInteger;
import java.sql.Timestamp;
import java.util.Iterator;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.springframework.boot.context.embedded.LocalServerPort;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.util.ClassUtils;
import org.springframework.ws.WebServiceMessage;
import org.springframework.ws.client.core.WebServiceMessageCallback;
import org.springframework.ws.client.core.WebServiceMessageExtractor;
import org.springframework.ws.client.core.WebServiceTemplate;
import org.springframework.ws.client.support.interceptor.ClientInterceptor;
import org.springframework.ws.soap.SoapHeader;
import org.springframework.ws.soap.SoapHeaderElement;
import org.springframework.ws.soap.SoapMessage;
import org.springframework.ws.support.MarshallingUtils;

import com.jh.signator.maintain.producer.agreement.model.CreateProducerAgreementReplyWrapper;
import com.jh.signator.maintain.producer.agreement.model.DeleteProducerAgreementReplyWrapper;
import com.jh.signator.maintain.producer.agreement.model.UpdateProducerAgreementReplyWrapper;
import com.jh.signator.maintain.producer.agreement.utils.MaintainProducerAgreementUtils;
import com.manulife.esb.jhfn.soapfault.SoapFault;
import com.manulife.esb.xsd.common.jh.header.JHHeader;
import com.manulife.esb.xsd.distribution.jhfn.maintainproduceragreement.CreateProducerAgreement;
import com.manulife.esb.xsd.distribution.jhfn.maintainproduceragreement.CreateProducerAgreement.ProducerAgreement;
import com.manulife.esb.xsd.distribution.jhfn.maintainproduceragreement.CreateProducerAgreementReply;
import com.manulife.esb.xsd.distribution.jhfn.maintainproduceragreement.CreateProducerAgreementRequest;
import com.manulife.esb.xsd.distribution.jhfn.maintainproduceragreement.DeleteProducerAgreement;
import com.manulife.esb.xsd.distribution.jhfn.maintainproduceragreement.DeleteProducerAgreementReply;
import com.manulife.esb.xsd.distribution.jhfn.maintainproduceragreement.DeleteProducerAgreementRequest;
import com.manulife.esb.xsd.distribution.jhfn.maintainproduceragreement.PRODUCER;
import com.manulife.esb.xsd.distribution.jhfn.maintainproduceragreement.PRODUCERAGREEMENT;
import com.manulife.esb.xsd.distribution.jhfn.maintainproduceragreement.ReadProducerAgreementReply;
import com.manulife.esb.xsd.distribution.jhfn.maintainproduceragreement.UpdateProducerAgreement;
import com.manulife.esb.xsd.distribution.jhfn.maintainproduceragreement.UpdateProducerAgreementReply;
import com.manulife.esb.xsd.distribution.jhfn.maintainproduceragreement.UpdateProducerAgreementRequest;

/**
 * Test class for MaintainProducerAgreementEndpoint.
 *
 */
@ActiveProfiles("test,test-fake")
@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
public class MaintainProducerAgreementEndpointIntegrationTest {

	private final Jaxb2Marshaller marshaller = new Jaxb2Marshaller();

	@LocalServerPort
	private int port;

	@Rule
	public ExpectedException exception = ExpectedException.none();

	private String endPointURI;

	@Before
	public void init() throws Exception {
		marshaller.setPackagesToScan(ClassUtils.getPackageName(CreateProducerAgreementRequest.class), ClassUtils.getPackageName(SoapFault.class),
				ClassUtils.getPackageName(JHHeader.class));
		marshaller.afterPropertiesSet();
		endPointURI = "http://localhost:" + port + "/MaintainProducerAgreement_1.0/";
	}

	/*
	 * @Test public void givenValidReadAgreementRequestThenExpectedReplyReturned() {
	 * 
	 * final WebServiceTemplate ws = new WebServiceTemplate(marshaller);
	 * ws.setDefaultUri(endPointURI); // client interceptor will set the sample
	 * request JH Header ws.setInterceptors(new ClientInterceptor[] { new
	 * TestClientInterceptor() });
	 * 
	 * final ReadProducerAgreementRequest request = getValidReadIdentityRequest();
	 * 
	 * // Use WebServiceMessageExtractor to get Body and Header final
	 * ReadProducerAgreementReplyWrapper responseAndHeader = ws.sendAndReceive(new
	 * WebServiceMessageCallback() {
	 * 
	 * @Override public void doWithMessage(final WebServiceMessage message) throws
	 * IOException { MarshallingUtils.marshal(marshaller, request, message); } },
	 * new WebServiceMessageExtractor<ReadProducerAgreementReplyWrapper>() {
	 * 
	 * @Override public ReadProducerAgreementReplyWrapper extractData(final
	 * WebServiceMessage message) throws IOException { final SoapHeader header =
	 * ((SoapMessage) message).getSoapHeader(); JHHeader responseJhHeader = null; //
	 * should be at most one header returned final Iterator<SoapHeaderElement> it =
	 * header.examineAllHeaderElements(); if (it.hasNext()) { responseJhHeader =
	 * (JHHeader) marshaller.unmarshal(it.next().getSource()); } final
	 * ReadProducerAgreementReply responseBody = (ReadProducerAgreementReply)
	 * MarshallingUtils.unmarshal(marshaller, message); final
	 * ReadProducerAgreementReplyWrapper replyWrapper = new
	 * ReadProducerAgreementReplyWrapper();
	 * replyWrapper.setHeader(responseJhHeader);
	 * replyWrapper.setReply(responseBody); return replyWrapper; } });
	 * 
	 * assertThat(responseAndHeader).isNotNull();
	 * assertThat(responseAndHeader.getReply()).isNotNull();
	 * assertThat(responseAndHeader.getHeader()).isNotNull();
	 * assertThat(responseAndHeader.getReply()).
	 * isEqualToComparingFieldByFieldRecursively(
	 * getExpectedValidReadProducerAgreementReply()); }
	 */

	@Test
	public void givenValidDeleteIdentityRequestThenExpectedReplyReturned() {

		final WebServiceTemplate ws = new WebServiceTemplate(marshaller);
		ws.setDefaultUri(endPointURI);
		// client interceptor will set the sample request JH Header
		ws.setInterceptors(new ClientInterceptor[] { new TestClientInterceptor() });

		final DeleteProducerAgreementRequest request = getValidDeleteIdentityRequest();

		// Use WebServiceMessageExtractor to get Body and Header
		final DeleteProducerAgreementReplyWrapper responseAndHeader = ws.sendAndReceive(new WebServiceMessageCallback() {
			@Override
			public void doWithMessage(final WebServiceMessage message) throws IOException {
				MarshallingUtils.marshal(marshaller, request, message);
			}
		}, new WebServiceMessageExtractor<DeleteProducerAgreementReplyWrapper>() {
			@Override
			public DeleteProducerAgreementReplyWrapper extractData(final WebServiceMessage message) throws IOException {
				final SoapHeader header = ((SoapMessage) message).getSoapHeader();
				JHHeader responseJhHeader = null;
				// should be at most one header returned
				final Iterator<SoapHeaderElement> it = header.examineAllHeaderElements();
				if (it.hasNext()) {
					responseJhHeader = (JHHeader) marshaller.unmarshal(it.next().getSource());
				}
				final DeleteProducerAgreementReply responseBody = (DeleteProducerAgreementReply) MarshallingUtils.unmarshal(marshaller, message);
				final DeleteProducerAgreementReplyWrapper replyWrapper = new DeleteProducerAgreementReplyWrapper();
				replyWrapper.setHeader(responseJhHeader);
				replyWrapper.setReply(responseBody);
				return replyWrapper;
			}
		});

		assertThat(responseAndHeader).isNotNull();
		assertThat(responseAndHeader.getReply()).isNotNull();
		assertThat(responseAndHeader.getHeader()).isNotNull();
		assertThat(responseAndHeader.getReply()).isEqualToComparingFieldByFieldRecursively(getExpectedValidDeleteProducerAgreementReply());
	}

	@Test
	public void givenValidUpdateIdentityRequestThenExpectedReplyReturned() {

		final WebServiceTemplate ws = new WebServiceTemplate(marshaller);
		ws.setDefaultUri(endPointURI);
		// client interceptor will set the sample request JH Header
		ws.setInterceptors(new ClientInterceptor[] { new TestClientInterceptor() });

		final UpdateProducerAgreementRequest request = getValidUpdateIdentityRequest();

		// Use WebServiceMessageExtractor to get Body and Header
		final UpdateProducerAgreementReplyWrapper responseAndHeader = ws.sendAndReceive(new WebServiceMessageCallback() {
			@Override
			public void doWithMessage(final WebServiceMessage message) throws IOException {
				MarshallingUtils.marshal(marshaller, request, message);
			}
		}, new WebServiceMessageExtractor<UpdateProducerAgreementReplyWrapper>() {
			@Override
			public UpdateProducerAgreementReplyWrapper extractData(final WebServiceMessage message) throws IOException {
				final SoapHeader header = ((SoapMessage) message).getSoapHeader();
				JHHeader responseJhHeader = null;
				// should be at most one header returned
				final Iterator<SoapHeaderElement> it = header.examineAllHeaderElements();
				if (it.hasNext()) {
					responseJhHeader = (JHHeader) marshaller.unmarshal(it.next().getSource());
				}
				final UpdateProducerAgreementReply responseBody = (UpdateProducerAgreementReply) MarshallingUtils.unmarshal(marshaller, message);
				final UpdateProducerAgreementReplyWrapper replyWrapper = new UpdateProducerAgreementReplyWrapper();
				replyWrapper.setHeader(responseJhHeader);
				replyWrapper.setReply(responseBody);
				return replyWrapper;
			}
		});

		assertThat(responseAndHeader).isNotNull();
		assertThat(responseAndHeader.getReply()).isNotNull();
		assertThat(responseAndHeader.getHeader()).isNotNull();
		assertThat(responseAndHeader.getReply()).isEqualToComparingFieldByFieldRecursively(getExpectedValidUpdateProducerAgreementReply());
	}

	@Test
	public void givenValidCreateIdentityRequestThenExpectedReplyReturned() {

		final WebServiceTemplate ws = new WebServiceTemplate(marshaller);
		ws.setDefaultUri(endPointURI);
		// client interceptor will set the sample request JH Header
		ws.setInterceptors(new ClientInterceptor[] { new TestClientInterceptor() });

		final CreateProducerAgreementRequest request = getValidCreateIdentityRequest();

		// Use WebServiceMessageExtractor to get Body and Header
		final CreateProducerAgreementReplyWrapper responseAndHeader = ws.sendAndReceive(new WebServiceMessageCallback() {
			@Override
			public void doWithMessage(final WebServiceMessage message) throws IOException {
				MarshallingUtils.marshal(marshaller, request, message);
			}
		}, new WebServiceMessageExtractor<CreateProducerAgreementReplyWrapper>() {
			@Override
			public CreateProducerAgreementReplyWrapper extractData(final WebServiceMessage message) throws IOException {
				final SoapHeader header = ((SoapMessage) message).getSoapHeader();
				JHHeader responseJhHeader = null;
				// should be at most one header returned
				final Iterator<SoapHeaderElement> it = header.examineAllHeaderElements();
				if (it.hasNext()) {
					responseJhHeader = (JHHeader) marshaller.unmarshal(it.next().getSource());
				}
				final CreateProducerAgreementReply responseBody = (CreateProducerAgreementReply) MarshallingUtils.unmarshal(marshaller, message);
				final CreateProducerAgreementReplyWrapper replyWrapper = new CreateProducerAgreementReplyWrapper();
				replyWrapper.setHeader(responseJhHeader);
				replyWrapper.setReply(responseBody);
				return replyWrapper;
			}
		});

		assertThat(responseAndHeader).isNotNull();
		assertThat(responseAndHeader.getReply()).isNotNull();
		assertThat(responseAndHeader.getHeader()).isNotNull();
		assertThat(responseAndHeader.getReply()).isEqualToComparingFieldByFieldRecursively(getExpectedValidCreateProducerAgreementReply());
	}

	public CreateProducerAgreementReply getExpectedValidCreateProducerAgreementReply() {
		final CreateProducerAgreementReply createProducerAgreementReply = new CreateProducerAgreementReply();
		final PRODUCER producer = new PRODUCER();
		final PRODUCERAGREEMENT producerAgreement = new PRODUCERAGREEMENT();
		producer.setID("4948");
		producerAgreement.setProducerAgreementID("188245");
		producer.setIDRefType(BigInteger.valueOf(8000));
		producerAgreement.setProducerID("4263");
		producerAgreement.setPayrollNo("159887");
		producerAgreement.setProducerAgreementCode("HV");
		producerAgreement.setProducerAgreementType("31");
		producerAgreement.setProducerAgreementPrimaryIndicator(false);
		producerAgreement.setProducerAgreementDefinition("MANAGING-DIRECTOR");
		producerAgreement.setProducerAgreementAgentOfficialStartDate(
				MaintainProducerAgreementUtils.convertTimestampToXmlGregorianCalendar(Timestamp.valueOf("2018-06-13 04:00:00.00")));
		producerAgreement.setEffDate(MaintainProducerAgreementUtils.convertTimestampToXmlGregorianCalendar(Timestamp.valueOf("2018-06-13 04:00:00.00")));
		producerAgreement.setAgencyCode("143");
		producerAgreement.setAgencyDetachedCode("0");
		producerAgreement.setAgencyName("PORTLAND");
		producerAgreement.setCreatedByNm("user1");
		producerAgreement.setUpdatedByNm("user1");
		producer.getProducerAgreement().add(producerAgreement);
		createProducerAgreementReply.setProducer(producer);
		return createProducerAgreementReply;
	}

	private UpdateProducerAgreementRequest getValidUpdateIdentityRequest() {
		final UpdateProducerAgreementRequest request = new UpdateProducerAgreementRequest();
		final UpdateProducerAgreement updateProducerAgreement = new UpdateProducerAgreement();
		final com.manulife.esb.xsd.distribution.jhfn.maintainproduceragreement.UpdateProducerAgreement.ProducerAgreement producerAgreement = new com.manulife.esb.xsd.distribution.jhfn.maintainproduceragreement.UpdateProducerAgreement.ProducerAgreement();
		// .producerAgreement.updateProducerAgreementRequest.s
		// UpdateProducerAgreement.ProducerAgreement producerAgreement
		// updateProducerAgreement.getProducerAgreement().
		producerAgreement.setProducerAgreementID("36196");
		updateProducerAgreement.setID("4948");
		updateProducerAgreement.setIDRefType(BigInteger.valueOf(8000));
		producerAgreement.setProducerID("4263");
		producerAgreement.setEffDate(MaintainProducerAgreementUtils.convertTimestampToXmlGregorianCalendar(Timestamp.valueOf("2018-06-13 04:00:00.00")));
		producerAgreement.setPayrollNo("159887");
		producerAgreement.setProducerAgreementCode("HV");
		producerAgreement.setProducerAgreementType("31");
		producerAgreement.setProducerAgreementPrimaryIndicator(false);
		producerAgreement.setProducerAgreementDefinition("MANAGING-DIRECTOR");
		producerAgreement.setProducerAgreementAgentOfficialStartDate(
				MaintainProducerAgreementUtils.convertTimestampToXmlGregorianCalendar(Timestamp.valueOf("2018-06-13 04:00:00.00")));
		producerAgreement.setEffDate(MaintainProducerAgreementUtils.convertTimestampToXmlGregorianCalendar(Timestamp.valueOf("2018-06-13 04:00:00.00")));
		producerAgreement.setAgencyCode("143");
		producerAgreement.setAgencyDetachedCode("0");

		updateProducerAgreement.getProducerAgreement().add(producerAgreement);
		request.setUpdateProducerAgreement(updateProducerAgreement);

		return request;
	}

	public UpdateProducerAgreementReply getExpectedValidUpdateProducerAgreementReply() {
		final UpdateProducerAgreementReply updateProducerAgreementReply = new UpdateProducerAgreementReply();
		final PRODUCER producer = new PRODUCER();
		final PRODUCERAGREEMENT producerAgreement = new PRODUCERAGREEMENT();
		producer.setID("4948");
		producerAgreement.setProducerAgreementID("188245");
		producer.setIDRefType(BigInteger.valueOf(8000));
		producerAgreement.setProducerID("4263");
		producerAgreement.setPayrollNo("159887");
		producerAgreement.setProducerAgreementCode("HV");
		// producerAgreement.setEffDate(MaintainProducerAgreementUtils.convertTimestampToXmlGregorianCalendar(Timestamp.valueOf("2018-06-13
		// 04:00:00.00")));
		// producerAgreement.setEndDate(MaintainProducerAgreementUtils.convertTimestampToXmlGregorianCalendar(Timestamp.valueOf("2018-06-13
		// 04:00:00.00")));
		producerAgreement.setProducerAgreementType("31");
		producerAgreement.setProducerAgreementPrimaryIndicator(false);
		producerAgreement.setProducerAgreementDefinition("MANAGING-DIRECTOR");
		// producerAgreement.setProducerAgreementAgentOfficialStartDate(
		// MaintainProducerAgreementUtils.convertTimestampToXmlGregorianCalendar(Timestamp.valueOf("2018-06-13
		// 04:00:00.00")));
		// producerAgreement.setEffDate(MaintainProducerAgreementUtils.convertTimestampToXmlGregorianCalendar(Timestamp.valueOf("2018-06-13
		// 04:00:00.00")));
		producerAgreement.setAgencyCode("143");
		producerAgreement.setAgencyDetachedCode("0");
		producerAgreement.setAgencyName("PORTLAND");
		producerAgreement.setCreatedByNm("user1");
		producerAgreement.setUpdatedByNm("user1");
		producer.getProducerAgreement().add(producerAgreement);
		updateProducerAgreementReply.setProducer(producer);
		return updateProducerAgreementReply;
	}

	private CreateProducerAgreementRequest getValidCreateIdentityRequest() {
		final CreateProducerAgreementRequest request = new CreateProducerAgreementRequest();
		final CreateProducerAgreement createProducerAgreement = new CreateProducerAgreement();
		final ProducerAgreement producerAgreement = new ProducerAgreement();
		createProducerAgreement.setID("4948");
		createProducerAgreement.setIDRefType(BigInteger.valueOf(8000));
		producerAgreement.setProducerID("4263");
		producerAgreement.setEffDate(MaintainProducerAgreementUtils.convertTimestampToXmlGregorianCalendar(Timestamp.valueOf("2018-06-13 04:00:00.00")));
		producerAgreement.setPayrollNo("159887");
		producerAgreement.setProducerAgreementCode("HV");
		producerAgreement.setProducerAgreementType("31");
		producerAgreement.setProducerAgreementPrimaryIndicator(false);
		producerAgreement.setProducerAgreementDefinition("MANAGING-DIRECTOR");
		producerAgreement.setProducerAgreementAgentOfficialStartDate(
				MaintainProducerAgreementUtils.convertTimestampToXmlGregorianCalendar(Timestamp.valueOf("2018-06-13 04:00:00.00")));
		producerAgreement.setEffDate(MaintainProducerAgreementUtils.convertTimestampToXmlGregorianCalendar(Timestamp.valueOf("2018-06-13 04:00:00.00")));
		producerAgreement.setAgencyCode("143");
		producerAgreement.setAgencyDetachedCode("0");

		createProducerAgreement.getProducerAgreement().add(producerAgreement);
		request.setCreateProducerAgreement(createProducerAgreement);

		return request;
	}

	public DeleteProducerAgreementReply getExpectedValidDeleteProducerAgreementReply() {
		final DeleteProducerAgreementReply deleteProducerAgreementReply = new DeleteProducerAgreementReply();
		final PRODUCER producer = new PRODUCER();
		final PRODUCERAGREEMENT producerAgreement = new PRODUCERAGREEMENT();
		producer.setID("4948");
		producerAgreement.setProducerAgreementID("188245");
		producer.setIDRefType(BigInteger.valueOf(8000));
		producerAgreement.setProducerID("4263");
		producerAgreement.setPayrollNo("159887");
		producerAgreement.setProducerAgreementCode("HV");
		// producerAgreement.setEffDate(MaintainProducerAgreementUtils.convertTimestampToXmlGregorianCalendar(Timestamp.valueOf("2018-06-13
		// 04:00:00.00")));
		// producerAgreement.setEndDate(MaintainProducerAgreementUtils.convertTimestampToXmlGregorianCalendar(Timestamp.valueOf("2018-06-13
		// 04:00:00.00")));
		producerAgreement.setProducerAgreementType("31");
		producerAgreement.setProducerAgreementPrimaryIndicator(false);
		producerAgreement.setProducerAgreementDefinition("MANAGING-DIRECTOR");
		// producerAgreement.setProducerAgreementAgentOfficialStartDate(
		// MaintainProducerAgreementUtils.convertTimestampToXmlGregorianCalendar(Timestamp.valueOf("2018-06-13
		// 04:00:00.00")));
		// producerAgreement.setEffDate(MaintainProducerAgreementUtils.convertTimestampToXmlGregorianCalendar(Timestamp.valueOf("2018-06-13
		// 04:00:00.00")));
		producerAgreement.setAgencyCode("143");
		producerAgreement.setAgencyDetachedCode("0");
		producerAgreement.setAgencyName("PORTLAND");
		producerAgreement.setCreatedByNm("user1");
		producerAgreement.setUpdatedByNm("user1");
		producer.getProducerAgreement().add(producerAgreement);
		deleteProducerAgreementReply.setProducer(producer);
		return deleteProducerAgreementReply;
	}

	private DeleteProducerAgreementRequest getValidDeleteIdentityRequest() {
		final DeleteProducerAgreementRequest request = new DeleteProducerAgreementRequest();
		final DeleteProducerAgreement deleteProducerAgreement = new DeleteProducerAgreement();
		final com.manulife.esb.xsd.distribution.jhfn.maintainproduceragreement.DeleteProducerAgreement.ProducerAgreement producerAgreement = new com.manulife.esb.xsd.distribution.jhfn.maintainproduceragreement.DeleteProducerAgreement.ProducerAgreement();
		deleteProducerAgreement.setID("4948");
		deleteProducerAgreement.setIDRefType(BigInteger.valueOf(8000));
		producerAgreement.setEndDate(MaintainProducerAgreementUtils.convertTimestampToXmlGregorianCalendar(Timestamp.valueOf("2018-06-13 04:00:00.00")));
		producerAgreement.setProducerAgreementID("36196");
		deleteProducerAgreement.getProducerAgreement().add(producerAgreement);
		request.setDeleteProducerAgreement(deleteProducerAgreement);

		return request;
	}

	public ReadProducerAgreementReply getExpectedValidReadProducerAgreementReply() {
		final ReadProducerAgreementReply readProducerAgreementReply = new ReadProducerAgreementReply();
		final PRODUCER producer = new PRODUCER();
		final PRODUCERAGREEMENT producerAgreement = new PRODUCERAGREEMENT();
		producer.setID("4948");
		producerAgreement.setProducerAgreementID("188245");
		producer.setIDRefType(BigInteger.valueOf(8000));
		producerAgreement.setProducerID("4263");
		producerAgreement.setPayrollNo("159887");
		producerAgreement.setProducerAgreementCode("HV");
		// producerAgreement.setEffDate(MaintainProducerAgreementUtils.convertTimestampToXmlGregorianCalendar(Timestamp.valueOf("2018-06-13
		// 04:00:00.00")));
		// producerAgreement.setEndDate(MaintainProducerAgreementUtils.convertTimestampToXmlGregorianCalendar(Timestamp.valueOf("2018-06-13
		// 04:00:00.00")));
		producerAgreement.setProducerAgreementType("31");
		producerAgreement.setProducerAgreementPrimaryIndicator(false);
		producerAgreement.setProducerAgreementDefinition("MANAGING-DIRECTOR");
		// producerAgreement.setProducerAgreementAgentOfficialStartDate(
		// MaintainProducerAgreementUtils.convertTimestampToXmlGregorianCalendar(Timestamp.valueOf("2018-06-13
		// 04:00:00.00")));
		// producerAgreement.setEffDate(MaintainProducerAgreementUtils.convertTimestampToXmlGregorianCalendar(Timestamp.valueOf("2018-06-13
		// 04:00:00.00")));
		producerAgreement.setAgencyCode("143");
		producerAgreement.setAgencyDetachedCode("0");
		producerAgreement.setAgencyName("PORTLAND");
		producerAgreement.setCreatedByNm("user1");
		producerAgreement.setUpdatedByNm("user1");
		producer.getProducerAgreement().add(producerAgreement);
		readProducerAgreementReply.setProducer(producer);
		return readProducerAgreementReply;
	}

}
