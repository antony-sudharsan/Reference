/**
 *
 */
package com.jh.signator.maintain.producer.agreement.dao;

import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Test;

import com.manulife.esb.xsd.distribution.jhfn.maintainproduceragreement.CONDITIONALLOGIC;
import com.manulife.esb.xsd.distribution.jhfn.maintainproduceragreement.DATAFIELD;
import com.manulife.esb.xsd.distribution.jhfn.maintainproduceragreement.OPERATION;
import com.manulife.esb.xsd.distribution.jhfn.maintainproduceragreement.SEARCHCRITERIA;

/**
 * Test class for SearchFilterCriteriaUtils.
 *
 */
public class SearchFilterCriteriaUtilsTest {
	private static final String TEST_VALUE = new String("4948");

	@Test
	public void givenValidSearchCriteriaThenIsValidSearchCriteriaReturnsTrue() {
		Assert.assertTrue(SearchFilterCriteriaUtils.isSearchCriteriaValid(createValidSearchCriteriaList()));
	}

	@Test
	public void givenOrAsFirstSearchCriteriaThenIsValidSearchCriteriaReturnsFalse() {
		Assert.assertFalse(SearchFilterCriteriaUtils.isSearchCriteriaValid(createInValidSearchCriteriaList()));
	}

	@Test
	public void testAppendOperationAndValueBeginsWith() {
		final String expectedString = "'" + TEST_VALUE + "%'";
		Assert.assertEquals(expectedString,
				SearchFilterCriteriaUtils.appendOperationAndValue(OPERATION.BEGINS_WITH, TEST_VALUE));
	}

	@Test
	public void testAppendOperationAndValueEndsWith() {
		final String expectedString = "'%" + TEST_VALUE + "'";
		Assert.assertEquals(expectedString,
				SearchFilterCriteriaUtils.appendOperationAndValue(OPERATION.ENDS_WITH, TEST_VALUE));
	}

	@Test
	public void testAppendOperationAndValueContains() {
		final String expectedString = "'%" + TEST_VALUE + "%'";
		Assert.assertEquals(expectedString,
				SearchFilterCriteriaUtils.appendOperationAndValue(OPERATION.CONTAINS, TEST_VALUE));
	}

	@Test
	public void testAppendOperationAndValueExactMatch() {
		final String expectedString = "'" + TEST_VALUE + "'";
		Assert.assertEquals(expectedString,
				SearchFilterCriteriaUtils.appendOperationAndValue(OPERATION.EXACT_MATCH, TEST_VALUE));
	}

	@Test
	public void testAndFedTaxIdNoExactMatch() {
		final List<SEARCHCRITERIA> criteriaList = new ArrayList<>();
		final SEARCHCRITERIA searchCriteria = new SEARCHCRITERIA();
		searchCriteria.setDataField(DATAFIELD.FED_TAX_ID_NO);
		searchCriteria.setValue(TEST_VALUE);
		searchCriteria.setLogic(CONDITIONALLOGIC.AND);
		searchCriteria.setOperation(OPERATION.EXACT_MATCH);
		criteriaList.add(searchCriteria);
		final String expectedString = " and P.fed_tax_id_no like '" + TEST_VALUE + "'";
		Assert.assertEquals(expectedString, SearchFilterCriteriaUtils.buildSearchFilters(criteriaList));
	}

	@Test
	public void testAndPartyIdNoBeginsWith() {
		final List<SEARCHCRITERIA> criteriaList = new ArrayList<>();
		final SEARCHCRITERIA searchCriteria = new SEARCHCRITERIA();
		searchCriteria.setDataField(DATAFIELD.PARTY_ID_NO);
		searchCriteria.setValue(TEST_VALUE);
		searchCriteria.setLogic(CONDITIONALLOGIC.AND);
		searchCriteria.setOperation(OPERATION.BEGINS_WITH);
		criteriaList.add(searchCriteria);
		final String expectedString = " and P.party_id_no like '" + TEST_VALUE + "%'";
		Assert.assertEquals(expectedString, SearchFilterCriteriaUtils.buildSearchFilters(criteriaList));
	}

	@Test
	public void testAndPrdIdOrPyrlNoEndsWith() {
		final List<SEARCHCRITERIA> criteriaList = new ArrayList<>();
		SEARCHCRITERIA searchCriteria = new SEARCHCRITERIA();
		searchCriteria.setDataField(DATAFIELD.PRD_ID);
		searchCriteria.setValue(TEST_VALUE);
		searchCriteria.setLogic(CONDITIONALLOGIC.AND);
		searchCriteria.setOperation(OPERATION.ENDS_WITH);
		criteriaList.add(searchCriteria);
		searchCriteria = new SEARCHCRITERIA();
		searchCriteria.setDataField(DATAFIELD.PYRL_NO);
		searchCriteria.setValue("456");
		searchCriteria.setLogic(CONDITIONALLOGIC.OR);
		searchCriteria.setOperation(OPERATION.ENDS_WITH);
		criteriaList.add(searchCriteria);
		final String expectedString = " and P.prd_id like '%" + TEST_VALUE + "' or CON.pyrl_no like '%456'";
		Assert.assertEquals(expectedString, SearchFilterCriteriaUtils.buildSearchFilters(criteriaList));
	}

	@Test
	public void testProducerAgreementPrimaryIndicatorConditions() {
		final List<SEARCHCRITERIA> criteriaList = new ArrayList<>();
		final SEARCHCRITERIA searchCriteria = new SEARCHCRITERIA();
		searchCriteria.setDataField(DATAFIELD.PRODUCER_AGREEMENT_PRIMARY_IND);
		searchCriteria.setValue("Y");
		searchCriteria.setLogic(CONDITIONALLOGIC.AND);
		searchCriteria.setOperation(OPERATION.EXACT_MATCH);
		criteriaList.add(searchCriteria);
		String expectedString = " and CON.prim_con_ind=1";
		Assert.assertEquals(expectedString, SearchFilterCriteriaUtils.buildSearchFilters(criteriaList));
		searchCriteria.setValue("1");
		Assert.assertEquals(expectedString, SearchFilterCriteriaUtils.buildSearchFilters(criteriaList));
		searchCriteria.setValue("N");
		expectedString = " and CON.prim_con_ind=0";
		Assert.assertEquals(expectedString, SearchFilterCriteriaUtils.buildSearchFilters(criteriaList));
	}

	@Test
	public void testAndOrgNameAndOrgAgencyCodeAndOrgDtchCd() {
		final List<SEARCHCRITERIA> criteriaList = new ArrayList<>();
		SEARCHCRITERIA searchCriteria = new SEARCHCRITERIA();
		searchCriteria.setDataField(DATAFIELD.ORG_NM);
		searchCriteria.setValue("123");
		searchCriteria.setLogic(CONDITIONALLOGIC.AND);
		searchCriteria.setOperation(OPERATION.EXACT_MATCH);
		criteriaList.add(searchCriteria);
		searchCriteria = new SEARCHCRITERIA();
		searchCriteria.setDataField(DATAFIELD.ORG_AGENCY_CD);
		searchCriteria.setValue("456");
		searchCriteria.setLogic(CONDITIONALLOGIC.AND);
		searchCriteria.setOperation(OPERATION.EXACT_MATCH);
		criteriaList.add(searchCriteria);
		searchCriteria = new SEARCHCRITERIA();
		searchCriteria.setDataField(DATAFIELD.ORG_DTCH_CD);
		searchCriteria.setValue("789");
		searchCriteria.setLogic(CONDITIONALLOGIC.AND);
		searchCriteria.setOperation(OPERATION.EXACT_MATCH);
		criteriaList.add(searchCriteria);
		final String expectedString = " and FIRM.org_nm like '123' and FIRM.org_agency_cd like '456' and FIRM.org_dtch_cd like '789'";
		Assert.assertEquals(expectedString, SearchFilterCriteriaUtils.buildSearchFilters(criteriaList));
	}

	@Test
	public void testAndProducerAgreementCodeAndProducerAgrementTypeAndProducerAgreementDefinitionContains() {
		final List<SEARCHCRITERIA> criteriaList = new ArrayList<>();
		SEARCHCRITERIA searchCriteria = new SEARCHCRITERIA();
		searchCriteria.setDataField(DATAFIELD.PRODUCER_AGREEMENT_CODE);
		searchCriteria.setValue("123");
		searchCriteria.setLogic(CONDITIONALLOGIC.AND);
		searchCriteria.setOperation(OPERATION.CONTAINS);
		criteriaList.add(searchCriteria);
		searchCriteria = new SEARCHCRITERIA();
		searchCriteria.setDataField(DATAFIELD.PRODUCER_AGREEMENT_TYPE);
		searchCriteria.setValue("456");
		searchCriteria.setLogic(CONDITIONALLOGIC.AND);
		searchCriteria.setOperation(OPERATION.CONTAINS);
		criteriaList.add(searchCriteria);
		searchCriteria = new SEARCHCRITERIA();
		searchCriteria.setDataField(DATAFIELD.PRODUCER_AGREEMENT_DEFINITION);
		searchCriteria.setValue("789");
		searchCriteria.setLogic(CONDITIONALLOGIC.AND);
		searchCriteria.setOperation(OPERATION.CONTAINS);
		criteriaList.add(searchCriteria);
		final String expectedString = " and CON.con_cd like '%123%' and CON.con_typ_cd_no like '%456%' and CON.agent_typ_key like '%789%'";
		Assert.assertEquals(expectedString, SearchFilterCriteriaUtils.buildSearchFilters(criteriaList));
	}

	private List<SEARCHCRITERIA> createValidSearchCriteriaList() {
		final List<SEARCHCRITERIA> criteriaList = new ArrayList<>();
		SEARCHCRITERIA searchCriteria = new SEARCHCRITERIA();
		searchCriteria.setDataField(DATAFIELD.PARTY_ID_NO);
		searchCriteria.setValue(TEST_VALUE);
		searchCriteria.setLogic(CONDITIONALLOGIC.AND);
		searchCriteria.setOperation(OPERATION.EXACT_MATCH);
		criteriaList.add(searchCriteria);
		searchCriteria = new SEARCHCRITERIA();
		searchCriteria.setDataField(DATAFIELD.PARTY_ID_NO);
		searchCriteria.setValue("2222");
		searchCriteria.setLogic(CONDITIONALLOGIC.OR);
		searchCriteria.setOperation(OPERATION.EXACT_MATCH);

		criteriaList.add(searchCriteria);

		return criteriaList;
	}

	private List<SEARCHCRITERIA> createInValidSearchCriteriaList() {
		final List<SEARCHCRITERIA> criteriaList = new ArrayList<>();
		final SEARCHCRITERIA searchCriteria = new SEARCHCRITERIA();
		searchCriteria.setDataField(DATAFIELD.PARTY_ID_NO);
		searchCriteria.setValue(TEST_VALUE);
		searchCriteria.setLogic(CONDITIONALLOGIC.OR);
		searchCriteria.setOperation(OPERATION.EXACT_MATCH);

		criteriaList.add(searchCriteria);

		return criteriaList;
	}

}
