/**
 *
 */
package com.jh.signator.maintain.producer.agreement.bizrule;

import static org.assertj.core.api.Assertions.assertThat;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

import com.jh.signator.maintain.producer.agreement.model.data.ProducerAgreementResult;
import com.jh.signator.maintain.producer.agreement.utils.MaintainProducerAgreementUtils;
import com.manulife.esb.xsd.distribution.jhfn.maintainproduceragreement.PRODUCER;
import com.manulife.esb.xsd.distribution.jhfn.maintainproduceragreement.PRODUCERAGREEMENT;

/**
 * Test class for MaintainProducerAgreementMapper.
 *
 */
public class MaintainProducerAgreementMapperTest {

	@Test
	public void givenFullyPopulatedProducerAgreementResultThenPRODUCERAGREEMENTMatchesExpected() {
		final MaintainProducerAgreementMapper mapper = new MaintainProducerAgreementMapper();
		assertThat(mapper.mapProducerAgreement(populateDBResult(true)))
				.isEqualToComparingFieldByFieldRecursively(populateExpected(true));
	}

	@Test
	public void givenParselyPopulatedProducerAgreementResultThenPRODUCERAGREEMENTMatchesExpected() {
		final MaintainProducerAgreementMapper mapper = new MaintainProducerAgreementMapper();
		assertThat(mapper.mapProducerAgreement(populateDBResult(false)))
				.isEqualToComparingFieldByFieldRecursively(populateExpected(false));
	}

	@Test
	public void givenMultipleProducerAgreementResultThenPRODUCERAGREEMENTListMatchesExpected() {
		final MaintainProducerAgreementMapper mapper = new MaintainProducerAgreementMapper();
		final List<ProducerAgreementResult> inputList = new ArrayList<>();
		inputList.add(populateDBResult(true));
		inputList.add(populateDBResult(false));

		final List<PRODUCERAGREEMENT> expectedOutput = new ArrayList<>();
		expectedOutput.add(populateExpected(true));
		expectedOutput.add(populateExpected(false));
		assertThat(mapper.mapProducerAgreement(inputList).size()).isEqualTo(expectedOutput.size());
		assertThat(mapper.mapProducerAgreement(inputList).get(0))
				.isEqualToComparingFieldByFieldRecursively(expectedOutput.get(0));
		assertThat(mapper.mapProducerAgreement(inputList).get(1))
				.isEqualToComparingFieldByFieldRecursively(expectedOutput.get(1));
	}

	@Test
	public void givenProducerAgreementResultsWithMultipleProducersThenMapProducerReturnsAsExpected() {
		final MaintainProducerAgreementMapper mapper = new MaintainProducerAgreementMapper();
		final List<ProducerAgreementResult> inputList = new ArrayList<>();
		inputList.add(populateDBResult(true));
		inputList.add(populateDBResult(false));
		inputList.get(1).setPartyIdNo(new Long(123));

		final List<PRODUCER> expectedOutput = new ArrayList<>();
		PRODUCER producer = new PRODUCER();
		producer.setID(inputList.get(0).getPartyIdNo().toString());
		producer.setIDRefType(MaintainProducerAgreementMapper.VALID_IDREF_TYPE);
		producer.getProducerAgreement().add(populateExpected(true));
		expectedOutput.add(producer);
		producer = new PRODUCER();
		producer.setID(inputList.get(1).getPartyIdNo().toString());
		producer.setIDRefType(MaintainProducerAgreementMapper.VALID_IDREF_TYPE);
		producer.getProducerAgreement().add(populateExpected(false));
		expectedOutput.add(producer);

		assertThat(mapper.mapProducer(inputList).size()).isEqualTo(expectedOutput.size());
		assertThat(mapper.mapProducer(inputList).get(0))
				.isEqualToComparingFieldByFieldRecursively(expectedOutput.get(0));
		assertThat(mapper.mapProducer(inputList).get(1))
				.isEqualToComparingFieldByFieldRecursively(expectedOutput.get(1));
	}

	private ProducerAgreementResult populateDBResult(final boolean allFields) {
		final ProducerAgreementResult result = new ProducerAgreementResult();

		result.setPartyIdNo(new Long(4948));
		result.setPrdcrConIdNo(new Long(188202));
		result.setPrdcrIdNo(new Long(4263));
		result.setCcstdt(Timestamp.valueOf("1999-04-01 00:00:00.0"));
		result.setPyrlNo(new Long(159887));
		result.setConCd("HV");
		result.setConTypCdNo(new Long(31));
		result.setAgentTypKey("MANAGING-DIRECTOR");
		result.setAgoffstdt(Timestamp.valueOf("1998-04-01 00:00:00.0"));
		result.setOrgPartyIdNo(new Long(43));
		result.setCreatDtm(Timestamp.valueOf("2018-06-25 12:33:29.597"));
		result.setCreatByNm("user1");
		result.setLastUpdDtm(Timestamp.valueOf("2018-06-25 14:34:53.647"));
		result.setLastUpdByNm("user2");
		if (allFields) {
			result.setCcstopdt(Timestamp.valueOf("2001-07-13 00:00:00.0"));
			result.setPrimConInd(new Long(1));
			result.setOrgPartyIdNo(new Long(43));
			result.setOrgAgencyCd(new Long(143));
			result.setOrgDtchCd(new Long(0));
			result.setOrgNm("PORTLAND                 ");
		}
		return result;
	}

	private PRODUCERAGREEMENT populateExpected(final boolean allFields) {
		final PRODUCERAGREEMENT producerAgreement = new PRODUCERAGREEMENT();

		producerAgreement.setProducerID(new Long(4263).toString());
		producerAgreement.setEffDate(MaintainProducerAgreementUtils
				.convertTimestampToXmlGregorianCalendar(Timestamp.valueOf("1999-04-01 00:00:00.0")));

		producerAgreement.setPayrollNo(new Long(159887).toString());
		producerAgreement.setProducerAgreementCode("HV");
		producerAgreement.setProducerAgreementType(new Long(31).toString());
		producerAgreement.setProducerAgreementID(new Long(188202).toString());
		producerAgreement.setProducerAgreementPrimaryIndicator(false);

		producerAgreement.setProducerAgreementDefinition("MANAGING-DIRECTOR");
		producerAgreement.setProducerAgreementAgentOfficialStartDate(MaintainProducerAgreementUtils
				.convertTimestampToXmlGregorianCalendar(Timestamp.valueOf("1998-04-01 00:00:00.0")));

		producerAgreement.setCreatedDate(MaintainProducerAgreementUtils
				.convertTimestampToXmlGregorianCalendar(Timestamp.valueOf("2018-06-25 12:33:29.597")));
		producerAgreement.setCreatedByNm("user1");
		producerAgreement.setUpdatedByNm("user2");
		producerAgreement.setUpdatedDate(MaintainProducerAgreementUtils
				.convertTimestampToXmlGregorianCalendar(Timestamp.valueOf("2018-06-25 14:34:53.647")));

		if (allFields) {
			producerAgreement.setProducerAgreementPrimaryIndicator(true);
			producerAgreement.setEndDate(MaintainProducerAgreementUtils
					.convertTimestampToXmlGregorianCalendar(Timestamp.valueOf("2001-07-13 00:00:00.0")));
			producerAgreement.setAgencyCode(new Long(143).toString());
			producerAgreement.setAgencyDetachedCode(new Long(0).toString());
			producerAgreement.setAgencyName("PORTLAND");
		}

		return producerAgreement;
	}
}
