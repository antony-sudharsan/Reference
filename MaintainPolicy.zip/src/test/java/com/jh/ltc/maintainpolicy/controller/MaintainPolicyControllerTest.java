package com.jh.ltc.maintainpolicy.controller;

import com.jh.ltc.maintainpolicy.orchestration.MaintainPolicyOrchestraion;
import com.jh.ltc.maintainpolicy.utils.LoggerUtils;
import com.manulife.esb.xsd.common.jh.header.JHHeader;
import com.manulife.esb.xsd.ltc.jh.maintainpolicy.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;

import static org.hamcrest.CoreMatchers.is;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ActiveProfiles("test")
@RunWith(SpringRunner.class)
@WebMvcTest(MaintainPolicyController.class)
public class MaintainPolicyControllerTest {

    @Autowired
    private MockMvc mvc;

    @MockBean
    private MaintainPolicyOrchestraion maintainPolicyOrchestraion;

    private final String GET_CLAIM_REQUEST = "{\n" +
            "  \"getClaimRequest\": {\n" +
            "    \"claimNumber\": \"R12002820\",\n" +
            "    \"polNumber\": \"4662607\",\n" +
            "    \"subLineOfBusiness\": {\n" +
            "      \"tc\": \"ER\",\n" +
            "      \"value\": \"2\"\n" +
            "    }\n" +
            "  },\n" +
            "  \"header\": {\n" +
            "      \"version\": \"1.0.0\",\n" +
            "      \"vonversationUID\": \"e155a3c4-c9c9-462e-931c-6a541560123\",\n" +
            "      \"messageUID\": \"SIT5658693\",\n" +
            "      \"relatesTo\": \"NA\",\n" +
            "      \"messageType\": \"Request\",\n" +
            "      \"originalMessageDateTime\": \"2014-04-30T13:20:00-05:00\",\n" +
            "      \"currentMessageDateTime\": \"2014-04-30T13:20:00-05:00\",\n" +
            "      \"messageSource\": {\n" +
            "        \"applicationName\": \"Life\",\n" +
            "        \"hostName\": \"localhost\",\n" +
            "        \"applicationUserID\": \"Tibco\",\n" +
            "        \"userID\": \"qwee\"\n" +
            "      },\n" +
            "      \"serviceInfo\": {\n" +
            "        \"serviceName\": \"MaintainPolicy\",\n" +
            "        \"serviceVersion\": \"1.0.0\",\n" +
            "        \"serviceOperation\": \"GetClaim\"\n" +
            "      },\n" +
            "      \"snvironmentID\": \"STAGE\",\n" +
            "      \"requestTimeOut\": \"10\"\n" +
            "    }\n" +
            "}";


    private final String GET_POLICY_REQUEST = "{\n" +
            "  \"getClaimRequest\": {\n" +
            "    \"claimNumber\": \"R12002820\",\n" +
            "    \"polNumber\": \"4662607\",\n" +
            "    \"subLineOfBusiness\": {\n" +
            "      \"tc\": \"ER\",\n" +
            "      \"value\": \"2\"\n" +
            "    }\n" +
            "  },\n" +
            "  \"header\": {\n" +
            "      \"version\": \"1.0.0\",\n" +
            "      \"vonversationUID\": \"e155a3c4-c9c9-462e-931c-6a541560123\",\n" +
            "      \"messageUID\": \"SIT5658693\",\n" +
            "      \"relatesTo\": \"NA\",\n" +
            "      \"messageType\": \"Request\",\n" +
            "      \"originalMessageDateTime\": \"2014-04-30T13:20:00-05:00\",\n" +
            "      \"currentMessageDateTime\": \"2014-04-30T13:20:00-05:00\",\n" +
            "      \"messageSource\": {\n" +
            "        \"applicationName\": \"Life\",\n" +
            "        \"hostName\": \"localhost\",\n" +
            "        \"applicationUserID\": \"Tibco\",\n" +
            "        \"userID\": \"qwee\"\n" +
            "      },\n" +
            "      \"serviceInfo\": {\n" +
            "        \"serviceName\": \"MaintainPolicy\",\n" +
            "        \"serviceVersion\": \"1.0.0\",\n" +
            "        \"serviceOperation\": \"GetClaim\"\n" +
            "      },\n" +
            "      \"snvironmentID\": \"STAGE\",\n" +
            "      \"requestTimeOut\": \"10\"\n" +
            "    }\n" +
            "}";

    private final String GET_AUTHDATA_REQUEST = "{\n" +
            "  \"getAuthDataRequest\": {\n" +
            "    \"polNumber\": \"4662607\",\n" +
            "    \"subLineOfBusiness\": {\n" +
            "      \"tc\": \"ER\",\n" +
            "      \"value\": \"1\"\n" +
            "    }\n" +
            "  },\n" +
            "  \"header\": {\n" +
            "      \"version\": \"1.0.0\",\n" +
            "      \"vonversationUID\": \"e155a3c4-c9c9-462e-931c-6a541560123\",\n" +
            "      \"messageUID\": \"SIT5658693\",\n" +
            "      \"relatesTo\": \"NA\",\n" +
            "      \"messageType\": \"Request\",\n" +
            "      \"originalMessageDateTime\": \"2014-04-30T13:20:00-05:00\",\n" +
            "      \"currentMessageDateTime\": \"2014-04-30T13:20:00-05:00\",\n" +
            "      \"messageSource\": {\n" +
            "        \"applicationName\": \"Life\",\n" +
            "        \"hostName\": \"localhost\",\n" +
            "        \"applicationUserID\": \"Tibco\",\n" +
            "        \"userID\": \"qwee\"\n" +
            "      },\n" +
            "      \"serviceInfo\": {\n" +
            "        \"serviceName\": \"MaintainPolicy\",\n" +
            "        \"serviceVersion\": \"1.0.0\",\n" +
            "        \"serviceOperation\": \"GetClaim\"\n" +
            "      },\n" +
            "      \"snvironmentID\": \"STAGE\",\n" +
            "      \"requestTimeOut\": \"10\"\n" +
            "    }\n" +
            "}";
    @MockBean
    private LoggerUtils loggerUtils;

    GetClaimResponse getClaimResponse = null;
    GetPolicyResponse policyResponse = null;
    GetAuthDataResponse authDataResponse = null;

    @Before
    public void setUp() throws Exception {
        getClaimResponse = populateClaimResponse();
        policyResponse = populatePolicyResponse();
        authDataResponse = populateAuthDataResponse();
    }

    private GetAuthDataResponse populateAuthDataResponse() {
        authDataResponse = new GetAuthDataResponse();
        GetAuthDataResponse.Policy policy = new GetAuthDataResponse.Policy();
        Insured insured = new Insured();
        policy.setPolNumber("1327284");

        insured.setFirstName("KEVIN");
        insured.setLastName("CASEY");
        insured.setMiddleName("P");
        policy.setInsured(insured);
        authDataResponse.setPolicy(policy);

        return authDataResponse;
    }

    private GetPolicyResponse populatePolicyResponse() {
        policyResponse = new GetPolicyResponse();
        GetPolicyResponse.Policy policy = new GetPolicyResponse.Policy();
        SubLineOfBusiness subLineOfBusiness = new SubLineOfBusiness();
        PolicyStatus policyStatus = new PolicyStatus();
        policy.setPolNumber("4662607");
        policy.setCarrierAdminSystem("LIFEPRO");
        policy.setPaymentCreditCode("90");
        policy.setPaymentDebitCode("12");
        policyResponse.setPolicy(policy);
        return policyResponse;

    }

    private GetClaimResponse populateClaimResponse() {
        getClaimResponse = new GetClaimResponse();
        GetClaimResponse.Policy policy = new GetClaimResponse.Policy();
        SubLineOfBusiness subLineOfBusiness = new SubLineOfBusiness();
        Claim claim = new Claim();

        policy.setPolNumber("4662607");
        subLineOfBusiness.setValue("TC");
        subLineOfBusiness.setTc("3");

        claim.setClaimNumber("R12002820");
        claim.setCarrierAdminSystem("PROMISE");

        policy.setSubLineOfBusiness(subLineOfBusiness);
        policy.setClaim(claim);
        getClaimResponse.setPolicy(policy);
        return getClaimResponse;
    }

    @After
    public void tearDown() throws Exception {
    }

    @Test
    public void getAuthData() throws Exception {
        when(maintainPolicyOrchestraion.getAuthData(any(JHHeader.class), any(GetAuthDataRequest.class)))
                .thenReturn(authDataResponse);

        mvc.perform(post("/jh/ins/ltc/datamart/authdata").content(GET_AUTHDATA_REQUEST)
                .contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
                .andDo(print())
                .andExpect(status().isOk()).andExpect(jsonPath("$.header.messageUID", is("SIT5658693")))
                .andExpect(jsonPath("$.getAuthDataResponse.policy.polNumber", is("1327284")))
                .andExpect(jsonPath("$.getAuthDataResponse.policy.insured.firstName", is("KEVIN")))
                .andExpect(jsonPath("$.getAuthDataResponse.policy.insured.lastName", is("CASEY")))
                .andExpect(jsonPath("$.getAuthDataResponse.policy.insured.middleName", is("P")));

        verify(maintainPolicyOrchestraion, times(1)).getAuthData(any(JHHeader.class), any(GetAuthDataRequest.class));
        verifyNoMoreInteractions(maintainPolicyOrchestraion);
    }

    @Test
    public void getPolicy() throws Exception {
        when(maintainPolicyOrchestraion.getPolicy(any(JHHeader.class), any(GetPolicyRequest.class)))
                .thenReturn(policyResponse);

        mvc.perform(post("/jh/ins/ltc/datamart/policy").content(GET_POLICY_REQUEST)
                .contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
                .andDo(print())
                .andExpect(status().isOk()).andExpect(jsonPath("$.header.messageUID", is("SIT5658693")))
                .andExpect(jsonPath("$.getPolicyResponse.policy.polNumber", is("4662607")))
                .andExpect(jsonPath("$.getPolicyResponse.policy.carrierAdminSystem", is("LIFEPRO")))
                .andExpect(jsonPath("$.getPolicyResponse.policy.paymentCreditCode", is("90")))
                .andExpect(jsonPath("$.getPolicyResponse.policy.paymentDebitCode", is("12")));

        verify(maintainPolicyOrchestraion, times(1)).getPolicy(any(JHHeader.class), any(GetPolicyRequest.class));
        verifyNoMoreInteractions(maintainPolicyOrchestraion);
    }

    @Test
    public void getClaim() throws Exception {
        when(maintainPolicyOrchestraion.getClaim(any(JHHeader.class), any(GetClaimRequest.class)))
                .thenReturn(getClaimResponse);

        mvc.perform(post("/jh/ins/ltc/datamart/claim").content(GET_CLAIM_REQUEST)
                .contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
                .andDo(print())
                .andExpect(status().isOk()).andExpect(jsonPath("$.header.messageUID", is("SIT5658693")))
                .andExpect(jsonPath("$.getClaimResponse.policy.polNumber", is("4662607")))
                .andExpect(jsonPath("$.getClaimResponse.policy.claim.claimNumber", is("R12002820")));

        verify(maintainPolicyOrchestraion, times(1)).getClaim(any(JHHeader.class), any(GetClaimRequest.class));
        verifyNoMoreInteractions(maintainPolicyOrchestraion);
    }

}