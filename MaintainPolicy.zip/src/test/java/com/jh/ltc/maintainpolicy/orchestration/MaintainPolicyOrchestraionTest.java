package com.jh.ltc.maintainpolicy.orchestration;

import com.jh.ltc.maintainpolicy.dao.MaintainPolicyDAO;
import com.jh.ltc.maintainpolicy.mapper.AuthDataMapper;
import com.jh.ltc.maintainpolicy.mapper.ClaimMapper;
import com.jh.ltc.maintainpolicy.mapper.PolicyMapper;
import com.jh.ltc.maintainpolicy.utils.LoggerUtils;
import com.manulife.esb.wsdl.ltc.jh.maintainpolicy.maintainpolicy.MaintainPolicyFault;
import com.manulife.esb.xsd.common.jh.header.JHHeader;
import com.manulife.esb.xsd.common.jh.header.MessageSource;
import com.manulife.esb.xsd.ltc.jh.maintainpolicy.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.HashMap;
import java.util.Map;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

@RunWith(SpringRunner.class)
public class MaintainPolicyOrchestraionTest {
    @Mock
    MaintainPolicyDAO maintainPolicyDAO;

    @InjectMocks
    MaintainPolicyOrchestraion maintainPolicyOrchestraion;

    @Mock
    ClaimMapper claimMapper;
    @Mock
    PolicyMapper policyMapper;
    @Mock
    AuthDataMapper authDataMapper;

    @Mock
    private LoggerUtils loggerUtils;

    GetClaimResponse getClaimResponse = null;
    GetPolicyResponse policyResponse = null;
    GetAuthDataResponse authDataResponse = null;

    GetClaimRequest getClaimRequest = new GetClaimRequest();

    GetPolicyRequest getPolicyRequest = new GetPolicyRequest();
    GetAuthDataRequest getAuthDataRequest = new GetAuthDataRequest();

    @Before
    public void setUp() throws Exception {
        getClaimResponse = populateClaimResponse();
        policyResponse = populatePolicyResponse();
        authDataResponse = populateAuthDataResponse();
        getClaimRequest.setPolNumber("4662607");
    }

    private GetAuthDataResponse populateAuthDataResponse() {
        authDataResponse = new GetAuthDataResponse();
        GetAuthDataResponse.Policy policy = new GetAuthDataResponse.Policy();
        Insured insured = new Insured();
        policy.setPolNumber("1327284");

        insured.setFirstName("KEVIN");
        insured.setLastName("CASEY");
        insured.setMiddleName("P");
        policy.setInsured(insured);
        authDataResponse.setPolicy(policy);

        return authDataResponse;
    }

    private GetPolicyResponse populatePolicyResponse() {
        policyResponse = new GetPolicyResponse();
        GetPolicyResponse.Policy policy = new GetPolicyResponse.Policy();
        SubLineOfBusiness subLineOfBusiness = new SubLineOfBusiness();
        PolicyStatus policyStatus = new PolicyStatus();
        policy.setPolNumber("4662607");
        policy.setCarrierAdminSystem("LIFEPRO");
        policy.setPaymentCreditCode("90");
        policy.setPaymentDebitCode("12");
        policyResponse.setPolicy(policy);
        return policyResponse;

    }

    private GetClaimResponse populateClaimResponse() {
        MockitoAnnotations.initMocks(this);
        getClaimResponse = new GetClaimResponse();
        GetClaimResponse.Policy policy = new GetClaimResponse.Policy();
        SubLineOfBusiness subLineOfBusiness = new SubLineOfBusiness();
        Claim claim = new Claim();

        policy.setPolNumber("4662607");
        subLineOfBusiness.setValue("TC");
        subLineOfBusiness.setTc("3");

        claim.setClaimNumber("R12002820");
        claim.setCarrierAdminSystem("PROMISE");

        policy.setSubLineOfBusiness(subLineOfBusiness);
        policy.setClaim(claim);
        getClaimResponse.setPolicy(policy);
        return getClaimResponse;
    }

    @Test
    public void getClaim() {
        Map<String, Object> returnMap = new HashMap<String, Object>();
        JHHeader header = new JHHeader();
        MessageSource message = new MessageSource();
        message.setUserID("1234");
        header.setMessageSource(message);

        when(maintainPolicyDAO.getClaim("1234", getClaimRequest)).thenReturn(returnMap);
        when(claimMapper.getClaimDetails("1234", "M123", returnMap)).thenReturn(getClaimResponse);
        assertEquals("4662607", getClaimResponse.getPolicy().getPolNumber());
        GetClaimResponse getClaimResponse = maintainPolicyOrchestraion.getClaim(header, getClaimRequest);
    }


    @Test
    public void getPolicy() throws MaintainPolicyFault {
        Map<String, Object> returnMap = new HashMap<String, Object>();
        JHHeader header = new JHHeader();
        MessageSource message = new MessageSource();
        message.setUserID("1234");
        header.setMessageSource(message);
        when(maintainPolicyDAO.getPolicy("1234", getPolicyRequest)).thenReturn(returnMap);
        Map<String, Object> riderResultset = new HashMap<>();
        when(maintainPolicyDAO.getPolicyRiderDetails("1234", getPolicyRequest)).thenReturn(returnMap);
        when(policyMapper.getPolicyDetails("1234", "M123", returnMap, riderResultset)).thenReturn(policyResponse);

        final GetPolicyResponse polcyResponse = maintainPolicyOrchestraion.getPolicy(header, getPolicyRequest);

        assertEquals("4662607", policyResponse.getPolicy().getPolNumber());
    }

    @Test
    public void getAuthData() {
        Map<String, Object> returnMap = new HashMap<String, Object>();
        JHHeader header = new JHHeader();
        MessageSource message = new MessageSource();
        message.setUserID("1234");
        header.setMessageSource(message);
        when(maintainPolicyDAO.getAuthData("1234", getAuthDataRequest)).thenReturn(returnMap);
        final GetAuthDataResponse autDataResponse = maintainPolicyOrchestraion.getAuthData(header, getAuthDataRequest);
        assertEquals("1327284", authDataResponse.getPolicy().getPolNumber());
    }

    @Test
    public void getAuthDataInsured() {
        Map<String, Object> returnMap = new HashMap<String, Object>();
        JHHeader header = new JHHeader();
        MessageSource message = new MessageSource();
        message.setUserID("1234");
        header.setMessageSource(message);
        when(maintainPolicyDAO.getAuthData("1234", getAuthDataRequest)).thenReturn(returnMap);
        final GetAuthDataResponse autDataResponse = maintainPolicyOrchestraion.getAuthData(header, getAuthDataRequest);
        assertEquals("KEVIN", authDataResponse.getPolicy().getInsured().getFirstName());
        assertEquals("CASEY", authDataResponse.getPolicy().getInsured().getLastName());
        assertEquals("P", authDataResponse.getPolicy().getInsured().getMiddleName());
    }

    @After
    public void tearDown() throws Exception {
    }

}