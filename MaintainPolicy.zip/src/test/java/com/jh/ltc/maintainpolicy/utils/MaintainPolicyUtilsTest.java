package com.jh.ltc.maintainpolicy.utils;

import org.junit.Before;
import org.junit.Test;

import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;
import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.GregorianCalendar;

import static org.junit.Assert.assertEquals;

public class MaintainPolicyUtilsTest {

    XMLGregorianCalendar xmlGregCal;
    MaintainPolicyUtils maintainPolicyUtils = null;
    Date oldDate;

    @Before
    public void setUp() throws Exception {
        maintainPolicyUtils = new MaintainPolicyUtils();
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");

        oldDate = Date.valueOf("2011-12-25");

        GregorianCalendar cal = new GregorianCalendar();
        cal.setTime(oldDate);

        xmlGregCal = DatatypeFactory.newInstance().newXMLGregorianCalendar(cal);
    }


    @Test
    public void convertUtilDateToGregoerianCalendar() {
        assertEquals(xmlGregCal, maintainPolicyUtils.convertUtilDateToGregoerianCalendar(oldDate));
    }


    @Test
    public void ifNullReturnEmptyNull() {
        assertEquals("", maintainPolicyUtils.ifNullReturnEmpty(null));
    }

    @Test
    public void ifNullReturnEmpty() {
        assertEquals("ABC", maintainPolicyUtils.ifNullReturnEmpty("ABC"));
    }
    @Test
    public void getStringShortNullValue() {
        assertEquals("", maintainPolicyUtils.getStringShortValue(null));
    }

    @Test
    public void getStringShortNotNullValue() {
        short bar = (short) 0;
        assertEquals("0", maintainPolicyUtils.getStringShortValue(bar));
    }
}