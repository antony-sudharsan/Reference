package com.jh.ltc.maintainpolicy;

import com.jh.common.logging.LoggerHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;

@Component
public class LogInitalizer {

    private static final Logger logger = LoggerFactory.getLogger(LogInitalizer.class);

    @Autowired
    private Environment env;

    @PostConstruct
    public void LoggerInstance() throws Exception {
        try {
            LoggerHandler.getInstance(env.getProperty("log.appID"), env.getProperty("log.svcName"),
                    env.getProperty("log.componentName"), env.getProperty("log.svcVersion"));
        } catch (final Exception e) {
            logger.error("Error initializing!", e);
            throw e;
        }

    }

}