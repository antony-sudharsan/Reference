package com.jh.ltc.maintainpolicy.model;

import com.manulife.esb.xsd.common.jh.header.JHHeader;
import com.manulife.esb.xsd.ltc.jh.maintainpolicy.GetClaimResponse;

/**
 * The type Get claim response wrapper.
 */
public class GetClaimResponseWrapper {

    private JHHeader header;
    private GetClaimResponse getClaimResponse;

    /**
     * Gets header.
     *
     * @return the header
     */
    public JHHeader getHeader() {
        return header;
    }

    /**
     * Sets header.
     *
     * @param header the header
     */
    public void setHeader(JHHeader header) {
        this.header = header;
    }

    /**
     * Gets get claim response.
     *
     * @return the get claim response
     */
    public GetClaimResponse getGetClaimResponse() {
        return getClaimResponse;
    }

    /**
     * Sets get claim response.
     *
     * @param getClaimResponse the get claim response
     */
    public void setGetClaimResponse(GetClaimResponse getClaimResponse) {
        this.getClaimResponse = getClaimResponse;
    }
}
