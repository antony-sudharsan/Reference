package com.jh.ltc.maintainpolicy.model;

import com.manulife.esb.xsd.common.jh.header.JHHeader;
import com.manulife.esb.xsd.ltc.jh.maintainpolicy.GetPolicyResponse;

/**
 * The type Get policy response wrapper.
 */
public class GetPolicyResponseWrapper {
    private JHHeader header;

    private GetPolicyResponse getPolicyResponse;

    /**
     * Gets header.
     *
     * @return the header
     */
    public JHHeader getHeader() {
        return header;
    }

    /**
     * Sets header.
     *
     * @param header the header
     */
    public void setHeader(JHHeader header) {
        this.header = header;
    }

    /**
     * Gets get policy response.
     *
     * @return the get policy response
     */
    public GetPolicyResponse getGetPolicyResponse() {
        return getPolicyResponse;
    }

    /**
     * Sets get policy response.
     *
     * @param getPolicyResponse the get policy response
     */
    public void setGetPolicyResponse(GetPolicyResponse getPolicyResponse) {
        this.getPolicyResponse = getPolicyResponse;
    }
}
