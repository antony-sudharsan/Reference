package com.jh.ltc.maintainpolicy.mapper;

import com.jh.common.logging.LoggerHandler;
import com.jh.common.utility.DataMappingCrossLookUp;
import com.jh.ltc.maintainpolicy.utils.MaintainPolicyUtils;
import com.manulife.esb.wsdl.ltc.jh.maintainpolicy.maintainpolicy.MaintainPolicyFault;
import com.manulife.esb.xsd.ltc.jh.maintainpolicy.Claim;
import com.manulife.esb.xsd.ltc.jh.maintainpolicy.ClaimStatus;
import com.manulife.esb.xsd.ltc.jh.maintainpolicy.GetClaimResponse;
import com.manulife.esb.xsd.ltc.jh.maintainpolicy.SubLineOfBusiness;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.xml.datatype.DatatypeConfigurationException;
import java.math.BigDecimal;
import java.sql.Date;
import java.text.ParseException;
import java.util.Map;

@Component
public class ClaimMapper {

    @Autowired
    MaintainPolicyUtils maintainPolicyUtils;

    /**
     * @param messageUUID
     * @param sourceSystemName
     * @param resultset
     *
     * @return
     *
     * @throws MaintainPolicyFault
     * @throws ParseException
     * @throws DatatypeConfigurationException
     */
    public GetClaimResponse getClaimDetails(String messageUUID, String sourceSystemName, Map<String, Object> resultset) {
        LoggerHandler.LogOut("INFO", "2", messageUUID, sourceSystemName, this.getClass().getName(),
                "Mapping the Result Set");
        GetClaimResponse getClaimResponse = new GetClaimResponse();
        GetClaimResponse.Policy policy = new GetClaimResponse.Policy();
        SubLineOfBusiness subLineOfBusiness = new SubLineOfBusiness();
        Claim claim = new Claim();

        ClaimStatus claimStatus = new ClaimStatus();

        try {

            if (resultset.get("O_POLICY_NUM") != null)
                policy.setPolNumber(String.valueOf(resultset.get("O_POLICY_NUM")).trim());

            if (resultset.get("O_LINE_OF_BUSINESS") != null) {
                subLineOfBusiness.setTc(String.valueOf(((short) resultset.get("O_LINE_OF_BUSINESS"))));
                subLineOfBusiness.setValue(DataMappingCrossLookUp.getValue("SubLineOfBusiness", String.valueOf(((short) resultset.get("O_LINE_OF_BUSINESS")))));
            }

            if (resultset.get("O_CLAIM_NUM") != null)
                claim.setClaimNumber((String) resultset.get("O_CLAIM_NUM"));

            if (resultset.get("O_CME_CLAIM_STATUS") != null) {
                claimStatus.setValue(DataMappingCrossLookUp.getValue("ClaimStatus", String.valueOf(resultset.get("O_CME_CLAIM_STATUS")).toLowerCase()));
                claimStatus.setTc(DataMappingCrossLookUp.getValue("ClaimStatusCodes", String.valueOf(resultset.get("O_CME_CLAIM_STATUS")).toLowerCase()));
            } else {
                claimStatus.setValue(DataMappingCrossLookUp.getValue("ClaimStatus", "default"));
                claimStatus.setTc(DataMappingCrossLookUp.getValue("ClaimStatusCodes", "default"));
            }
            claim.setClaimStatus(claimStatus);

            if (resultset.get("O_SRC_CLAIM_SYS_NM") != null)
                claim.setCarrierAdminSystem(String.valueOf(resultset.get("O_SRC_CLAIM_SYS_NM")).trim());

            if (resultset.get("O_PYMT_PROCESS_DT") != null)
                claim.setClaimPaymentDate(maintainPolicyUtils.convertUtilDateToGregoerianCalendar((Date) (resultset.get("O_PYMT_PROCESS_DT"))));

            if (resultset.get("O_PYMT_AMT") != null)
                claim.setClaimPaymentAmt(new BigDecimal(String.valueOf(resultset.get("O_PYMT_AMT"))));

            policy.setSubLineOfBusiness(subLineOfBusiness);
            policy.setClaim(claim);
            getClaimResponse.setPolicy(policy);

            LoggerHandler.LogOut("INFO", "1c", messageUUID, sourceSystemName, this.getClass().getName(), getClaimResponse.toString());

        } catch (Exception e) {
            LoggerHandler.ErrorOut(e, messageUUID, sourceSystemName, this.getClass().getName(), resultset.toString());
            throw e;
        }

        return getClaimResponse;
    }
}
