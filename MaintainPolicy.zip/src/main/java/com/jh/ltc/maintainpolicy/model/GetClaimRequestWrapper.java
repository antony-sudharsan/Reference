package com.jh.ltc.maintainpolicy.model;

import com.manulife.esb.xsd.common.jh.header.JHHeader;
import com.manulife.esb.xsd.ltc.jh.maintainpolicy.GetClaimRequest;

/**
 * The type Get claim request wrapper.
 */
public class GetClaimRequestWrapper {

    private JHHeader header;

    private GetClaimRequest getClaimRequest;

    /**
     * Gets header.
     *
     * @return the header
     */
    public JHHeader getHeader() {
        return header;
    }

    /**
     * Sets header.
     *
     * @param header the header
     */
    public void setHeader(JHHeader header) {
        this.header = header;
    }

    /**
     * Gets get claim request.
     *
     * @return the get claim request
     */
    public GetClaimRequest getGetClaimRequest() {
        return getClaimRequest;
    }

    /**
     * Sets get claim request.
     *
     * @param getClaimRequest the get claim request
     */
    public void setGetClaimRequest(GetClaimRequest getClaimRequest) {
        this.getClaimRequest = getClaimRequest;
    }
}
