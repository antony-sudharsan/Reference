package com.jh.ltc.maintainpolicy.model;

import com.manulife.esb.xsd.common.jh.header.JHHeader;
import com.manulife.esb.xsd.ltc.jh.maintainpolicy.GetAuthDataResponse;

/**
 * The type Get auth data response wrapper.
 */
public class GetAuthDataResponseWrapper {

    private JHHeader header;

    private GetAuthDataResponse getAuthDataResponse;

    /**
     * Gets header.
     *
     * @return the header
     */
    public JHHeader getHeader() {
        return header;
    }

    /**
     * Sets header.
     *
     * @param header the header
     */
    public void setHeader(JHHeader header) {
        this.header = header;
    }

    /**
     * Gets get auth data response.
     *
     * @return the get auth data response
     */
    public GetAuthDataResponse getGetAuthDataResponse() {
        return getAuthDataResponse;
    }

    /**
     * Sets get auth data response.
     *
     * @param getAuthDataResponse the get auth data response
     */
    public void setGetAuthDataResponse(GetAuthDataResponse getAuthDataResponse) {
        this.getAuthDataResponse = getAuthDataResponse;
    }
}
