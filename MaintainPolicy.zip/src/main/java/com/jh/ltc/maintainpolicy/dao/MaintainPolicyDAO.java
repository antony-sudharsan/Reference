package com.jh.ltc.maintainpolicy.dao;

import com.jh.common.logging.LoggerHandler;
import com.jh.ltc.maintainpolicy.utils.LoggerUtils;
import com.jh.ltc.maintainpolicy.utils.LoggingContextHolder;
import com.manulife.esb.xsd.ltc.jh.maintainpolicy.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.sql.Types;
import java.util.Map;

/**
 * The type Maintain policy dao.
 */
@Component
public class MaintainPolicyDAO {


    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Autowired
    private LoggerUtils loggerUtils;

    @Value("${RequestTimeoutLimit:10000}")
    private int requestTimeoutLimit;

    /**
     * Init.
     */
    @PostConstruct
    public void init() {
        if (requestTimeoutLimit != 0) {
            this.jdbcTemplate.setQueryTimeout(requestTimeoutLimit);
        }
    }


    /**
     * Gets claim.
     *
     * @param user    the user
     * @param request the request
     *
     * @return claim
     */
    public Map<String, Object> getClaim(String user, final GetClaimRequest request) {

        final String messageUUID = LoggingContextHolder.getLoggingContext().getMessageUUID();
        final String sourceSystemName = LoggingContextHolder.getLoggingContext().getSourceSystemName();
        final GetClaimResponse reply = new GetClaimResponse();

        LoggerHandler.LogOut("INFO", "3", messageUUID, sourceSystemName, this.getClass().getName(),
                "Entering getClaim " + loggerUtils.writeAsJson(request));

        SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName("usp_LTC_CME_GETCLAIM")
                .declareParameters(
                        new SqlParameter("CLAIM_NUM", Types.VARCHAR),
                        new SqlParameter("POLICY_NUM", Types.VARCHAR),
                        new SqlParameter("LINE_OF_BUSINESS", Types.VARCHAR),
                        new SqlOutParameter("O_POLICY_NUM", java.sql.Types.CHAR),
                        new SqlOutParameter("O_LINE_OF_BUSINESS", java.sql.Types.SMALLINT),
                        new SqlOutParameter("O_CLAIM_NUM", java.sql.Types.CHAR),
                        new SqlOutParameter("O_SRC_CLAIM_SYS_NM", java.sql.Types.CHAR),
                        new SqlOutParameter("O_CME_CLAIM_STATUS", java.sql.Types.CHAR),
                        new SqlOutParameter("O_PYMT_AMT", java.sql.Types.DECIMAL),
                        new SqlOutParameter("O_PYMT_PROCESS_DT", java.sql.Types.DATE),
                        new SqlOutParameter("O_ERR_CD", java.sql.Types.VARCHAR),
                        new SqlOutParameter("O_ERR_MSG", java.sql.Types.VARCHAR));

        SqlParameterSource in = new MapSqlParameterSource()
                .addValue("CLAIM_NUM", request.getClaimNumber())
                .addValue("POLICY_NUM", request.getPolNumber())
                .addValue("LINE_OF_BUSINESS", request.getSubLineOfBusiness().getValue());

        Map<String, Object> out = simpleJdbcCall.withReturnValue().execute(in);
        LoggerHandler.LogOut("INFO", "3", messageUUID, sourceSystemName, this.getClass().getName(),
                "Exiting getClaim " + loggerUtils.writeAsJson(out));
        return out;
    }


    /**
     * Gets policy.
     *
     * @param user    the user
     * @param request the request
     *
     * @return the policy
     */
    public Map<String, Object> getPolicy(String user, final GetPolicyRequest request) {

        final String messageUUID = LoggingContextHolder.getLoggingContext().getMessageUUID();
        final String sourceSystemName = LoggingContextHolder.getLoggingContext().getSourceSystemName();
        final GetClaimResponse reply = new GetClaimResponse();

        LoggerHandler.LogOut("INFO", "3", messageUUID, sourceSystemName, this.getClass().getName(),
                "Entering getPolicy " + loggerUtils.writeAsJson(request));

        SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName("usp_LTC_CME_GETPOLICY")
                .declareParameters(
                        new SqlParameter("POLICY_NUM", Types.VARCHAR),
                        new SqlParameter("LINE_OF_BUSINESS", Types.VARCHAR),
                        new SqlOutParameter("O_POLICY_NUM", java.sql.Types.CHAR),
                        new SqlOutParameter("O_LINE_OF_BUSINESS", java.sql.Types.SMALLINT),
                        new SqlOutParameter("O_POLICY_SRC_FILE", java.sql.Types.CHAR),
                        new SqlOutParameter("O_CME_POLICY_STATUS_CD", java.sql.Types.CHAR),
                        new SqlOutParameter("O_POLICY_EFF_DT", java.sql.Types.DATE),
                        new SqlOutParameter("O_POLICY_PAID_TO_DT", java.sql.Types.DATE),
                        new SqlOutParameter("O_PREMIUM_FREQUENCY", java.sql.Types.SMALLINT),
                        new SqlOutParameter("O_CME_BILLING_STATUS", java.sql.Types.CHAR),
                        new SqlOutParameter("O_CME_BILLING_TYPE", java.sql.Types.CHAR),
                        new SqlOutParameter("O_GROUP_BILLING_FREEZE_CD", java.sql.Types.CHAR),
                        new SqlOutParameter("O_LAST_POLICY_PREM_AMT", java.sql.Types.DECIMAL),
                        new SqlOutParameter("O_LAST_POLICY_PREM_PAID_DT", java.sql.Types.DATE),
                        new SqlOutParameter("O_PREMIUM_PAYMENT_DUE_DT", java.sql.Types.DATE),
                        new SqlOutParameter("O_LAST_POLICY_PREM_CREDIT_CD", java.sql.Types.INTEGER),
                        new SqlOutParameter("O_LAST_POLICY_PREM_DEBIT_CD", java.sql.Types.INTEGER),
                        new SqlOutParameter("O_ERR_CD", java.sql.Types.VARCHAR),
                        new SqlOutParameter("O_ERR_MSG", java.sql.Types.VARCHAR));


        SqlParameterSource in = new MapSqlParameterSource()
                .addValue("POLICY_NUM", request.getPolNumber())
                .addValue("LINE_OF_BUSINESS", request.getSubLineOfBusiness().getValue());

        Map<String, Object> out = simpleJdbcCall.withReturnValue().execute(in);
        LoggerHandler.LogOut("INFO", "3", messageUUID, sourceSystemName, this.getClass().getName(),
                "Exiting GetPolicy " + loggerUtils.writeAsJson(out));
        return out;
    }

    /**
     * Gets policy rider details.
     *
     * @param user    the user
     * @param request the request
     *
     * @return the policy rider details
     */
    public Map<String, Object> getPolicyRiderDetails(String user, GetPolicyRequest request) {

        final String messageUUID = LoggingContextHolder.getLoggingContext().getMessageUUID();
        final String sourceSystemName = LoggingContextHolder.getLoggingContext().getSourceSystemName();
        final GetClaimResponse reply = new GetClaimResponse();

        LoggerHandler.LogOut("INFO", "3", messageUUID, sourceSystemName, this.getClass().getName(),
                "Entering GetRider " + loggerUtils.writeAsJson(request));

        SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName("usp_LTC_CME_GETRIDER")
                .declareParameters(
                        new SqlParameter("POLICY_NUM", Types.VARCHAR),
                        new SqlParameter("LINE_OF_BUSINESS", Types.VARCHAR),
                        new SqlOutParameter("O_POLICY_NUM", java.sql.Types.CHAR),
                        new SqlOutParameter("O_LINE_OF_BUSINESS", java.sql.Types.SMALLINT),
                        new SqlOutParameter("O_ERR_CD", java.sql.Types.VARCHAR),
                        new SqlOutParameter("O_ERR_MSG", java.sql.Types.VARCHAR),
                        new SqlOutParameter("O_RIDER_NAME", java.sql.Types.VARCHAR));

        SqlParameterSource in = new MapSqlParameterSource()
                .addValue("POLICY_NUM", request.getPolNumber())
                .addValue("LINE_OF_BUSINESS", request.getSubLineOfBusiness().getValue());

        Map<String, Object> out = simpleJdbcCall.withReturnValue().execute(in);
        LoggerHandler.LogOut("INFO", "3", messageUUID, sourceSystemName, this.getClass().getName(),
                "Exiting GetRider " + loggerUtils.writeAsJson(out));
        return out;
    }


    /**
     * Gets auth data.
     *
     * @param user    the user
     * @param request the request
     *
     * @return the auth data
     */
    public Map<String, Object> getAuthData(String user, GetAuthDataRequest request) {

        final String messageUUID = LoggingContextHolder.getLoggingContext().getMessageUUID();
        final String sourceSystemName = LoggingContextHolder.getLoggingContext().getSourceSystemName();
        final GetAuthDataResponse reply = new GetAuthDataResponse();

        LoggerHandler.LogOut("INFO", "3", messageUUID, sourceSystemName, this.getClass().getName(),
                "Entering getAuthData " + loggerUtils.writeAsJson(request));

        SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName("usp_LTC_CME_GETAUTHDATA")
                .declareParameters(
                        new SqlParameter("POLICY_NUM", Types.VARCHAR),
                        new SqlParameter("LINE_OF_BUSINESS", Types.VARCHAR),
                        new SqlParameter("CUST_TYPE", Types.VARCHAR),
                        new SqlOutParameter("O_LINE_OF_BUSINESS", java.sql.Types.SMALLINT),
                        new SqlOutParameter("O_CME_POLICY_STATUS_CD", java.sql.Types.CHAR),
                        new SqlOutParameter("O_CLIENT_POLICY_NUM", java.sql.Types.VARCHAR),
                        new SqlOutParameter("O_SSN", java.sql.Types.CHAR),
                        new SqlOutParameter("O_BIRTH_DT", java.sql.Types.DATE),
                        new SqlOutParameter("O_UUID", java.sql.Types.CHAR),
                        new SqlOutParameter("O_PREFIX_NM", java.sql.Types.VARCHAR),
                        new SqlOutParameter("O_LAST_NM", java.sql.Types.VARCHAR),
                        new SqlOutParameter("O_FIRST_NM", java.sql.Types.VARCHAR),
                        new SqlOutParameter("O_MIDDLE_NM", java.sql.Types.VARCHAR),
                        new SqlOutParameter("O_SUFFIX_NM", java.sql.Types.VARCHAR),
                        new SqlOutParameter("O_ZIP_CD", java.sql.Types.VARCHAR),
                        new SqlOutParameter("O_CLIENT_NUM", java.sql.Types.VARCHAR),
                        new SqlOutParameter("O_CLIENT_NM", java.sql.Types.VARCHAR),
                        new SqlOutParameter("O_CLIENT_SHORT_NM", java.sql.Types.VARCHAR),
                        new SqlOutParameter("O_CLAIM_NUM", java.sql.Types.VARCHAR),
                        new SqlOutParameter("O_CLAIM_STATUS", java.sql.Types.VARCHAR),
                        new SqlOutParameter("O_ERR_CD", java.sql.Types.VARCHAR),
                        new SqlOutParameter("O_ERR_MSG", java.sql.Types.VARCHAR));

        SqlParameterSource in = new MapSqlParameterSource()
                .addValue("POLICY_NUM", request.getPolNumber())
                .addValue("LINE_OF_BUSINESS", request.getSubLineOfBusiness().getValue())
                .addValue("CUST_TYPE", request.getCustomerTypeCode());

        Map<String, Object> out = simpleJdbcCall.withReturnValue().execute(in);
        LoggerHandler.LogOut("INFO", "3", messageUUID, sourceSystemName, this.getClass().getName(),
                "Exiting getAuthData " + loggerUtils.writeAsJson(out));
        return out;

    }
}
