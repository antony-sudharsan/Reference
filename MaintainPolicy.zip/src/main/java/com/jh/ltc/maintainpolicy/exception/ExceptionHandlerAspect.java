package com.jh.ltc.maintainpolicy.exception;

import com.jh.common.logging.LoggerHandler;
import com.jh.ltc.maintainpolicy.utils.LoggingContext;
import com.jh.ltc.maintainpolicy.utils.LoggingContextHolder;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.core.annotation.Order;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.QueryTimeoutException;
import org.springframework.stereotype.Component;

/**
 * Exception Handler to handle throws and convert to proper fault exceptions.
 */
@Component
@Aspect
@Order(1)
public class ExceptionHandlerAspect {

    @Pointcut("execution(* com.jh.ltc.maintainpolicy.orchestration.MaintainPolicyOrchestraion.*(..))")
    public void serviceHandler() {

    }

    @AfterThrowing(pointcut = "serviceHandler()", throwing = "ex")
    public void handleException(final JoinPoint joinPoint, final Exception ex) throws Exception {

        if (ex instanceof BaseFaultException) {
            throw ex;
        } else {
            // only log if not one we threw directly as it will be logged in outer layer,
            // either endpoint or controller
            final LoggingContext loggingContext = LoggingContextHolder.getLoggingContext();
            final String className = joinPoint.getSignature().getDeclaringTypeName();
            LoggerHandler.ErrorOut(ex, loggingContext.getMessageUUID(), loggingContext.getSourceSystemName(), className,
                    ex.getMessage());

            if (ex instanceof QueryTimeoutException) {
                throw ex;
            } else if (ex instanceof DataAccessException) {
                throw ex;
            } else if (ex instanceof Exception) {
                throw new TechnicalErrorException(ex.getMessage(), ex);
            }
        }
    }
}
