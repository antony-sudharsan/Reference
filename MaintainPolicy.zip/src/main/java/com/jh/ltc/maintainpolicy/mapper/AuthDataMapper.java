package com.jh.ltc.maintainpolicy.mapper;

import com.jh.common.logging.LoggerHandler;
import com.jh.common.utility.DataMappingCrossLookUp;
import com.jh.ltc.maintainpolicy.utils.MaintainPolicyUtils;
import com.manulife.esb.xsd.ltc.jh.maintainpolicy.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.sql.Date;
import java.util.Map;

@Component
public class AuthDataMapper {

    @Autowired
    MaintainPolicyUtils maintainPolicyUtils;


    public GetAuthDataResponse getAuthDetails(String messageUUID, String sourceSystemName, Map<String, Object> resultset) {
        LoggerHandler.LogOut("INFO", "2", messageUUID, sourceSystemName, this.getClass().getName(),
                "Mapping the Result Set");
        GetAuthDataResponse getAuthDataResponse = new GetAuthDataResponse();
        GetAuthDataResponse.Policy policy = new GetAuthDataResponse.Policy();
        SubLineOfBusiness subLineOfBusiness = new SubLineOfBusiness();
        PolicyStatus policyStatus = new PolicyStatus();
        Insured insured = new Insured();
        Client client = new Client();
        GovtIDTC govtIDTC = new GovtIDTC();
        ClaimStatus claimStatus = new ClaimStatus();
        GetAuthDataResponse.Policy.Claim claim = new GetAuthDataResponse.Policy.Claim();
        Address address = new Address();
        try {

            if (resultset.get("O_POLICY_NUM") != null)
                policy.setPolNumber(String.valueOf(resultset.get("O_POLICY_NUM")).trim());

            if (resultset.get("O_LINE_OF_BUSINESS") != null) {
                subLineOfBusiness.setTc(maintainPolicyUtils.getStringShortValue(resultset.get("O_LINE_OF_BUSINESS")));
                subLineOfBusiness.setValue(DataMappingCrossLookUp.getValue("SubLineOfBusiness", String.valueOf((short) resultset.get("O_LINE_OF_BUSINESS"))));
            }

            if (resultset.get("O_CME_POLICY_STATUS_CD") != null) {
                policyStatus.setValue(DataMappingCrossLookUp.getValue("PolicyStatus", String.valueOf(resultset.get("O_CME_POLICY_STATUS_CD")).toUpperCase()));
            } else {
                policyStatus.setValue(DataMappingCrossLookUp.getValue("PolicyStatus", "DEFAULT"));
            }

            if (resultset.get("O_CME_POLICY_STATUS_CD") != null) {
                policyStatus.setTc(DataMappingCrossLookUp.getValue("PolicyStatusCodes", String.valueOf(resultset.get("O_CME_POLICY_STATUS_CD")).toUpperCase()));
            } else {
                policyStatus.setTc(DataMappingCrossLookUp.getValue("PolicyStatusCodes", "DEFAULT"));
            }

            if (resultset.get("O_CLIENT_POLICY_NUM") != null)
                client.setIDReferenceNo(String.valueOf(resultset.get("O_CLIENT_POLICY_NUM")).trim());

            //Mapping Insured

            if (resultset.get("SSN") != null)
                insured.setGovtID(String.valueOf(resultset.get("SSN")).trim());

            govtIDTC.setTc("1");
            insured.setGovtIDTC(govtIDTC);

            if (resultset.get("O_BIRTH_DT") != null)
                insured.setBirthDate(maintainPolicyUtils.convertUtilDateToGregoerianCalendar((Date) (resultset.get("O_BIRTH_DT"))));

            if (resultset.get("O_UUID") != null)
                insured.setPersonSysKey(String.valueOf(resultset.get("O_UUID")).trim());

            if (resultset.get("O_PREFIX_NM") != null)
                insured.setPrefix(String.valueOf(resultset.get("O_PREFIX_NM")).trim());

            if (resultset.get("O_LAST_NM") != null)
                insured.setLastName(String.valueOf(resultset.get("O_LAST_NM")).trim());

            if (resultset.get("O_FIRST_NM") != null)
                insured.setFirstName(String.valueOf(resultset.get("O_FIRST_NM")).trim());
            if (resultset.get("O_MIDDLE_NM") != null)
                insured.setMiddleName(String.valueOf(resultset.get("O_MIDDLE_NM")).trim());

            if (resultset.get("O_SUFFIX_NM") != null)
                insured.setSuffix(String.valueOf(resultset.get("O_SUFFIX_NM")).trim());

            address.setLine1("N/A");
            address.setCity("N/A");
            address.setState("N/A");
            address.setZip(String.valueOf(resultset.get("O_ZIP_CD")));

            //Mapping Client
            if (resultset.get("O_CLIENT_NUM") != null)
                client.setIDReferenceNo(String.valueOf(resultset.get("O_CLIENT_NUM")).trim());

            if (resultset.get("O_CLIENT_NM") != null)
                client.setFullName(String.valueOf(resultset.get("O_CLIENT_NM")).trim());
            if (resultset.get("O_CLIENT_SHORT_NM") != null)
                client.setAbbrName(String.valueOf(resultset.get("O_CLIENT_SHORT_NM")).trim());

            //Mapping Claim
            if (resultset.get("O_CLAIM_NUM") != null)
                claim.setClaimNumber(String.valueOf(resultset.get("O_CLAIM_NUM")).trim());

            if (resultset.get("O_CLAIM_STATUS") != null) {
                claimStatus.setValue(DataMappingCrossLookUp.getValue("ClaimStatus", String.valueOf(resultset.get("O_CLAIM_STATUS"))));
                claimStatus.setTc(DataMappingCrossLookUp.getValue("ClaimStatusCodes", String.valueOf(resultset.get("O_CLAIM_STATUS"))));
            } else {
                claimStatus.setValue(DataMappingCrossLookUp.getValue("ClaimStatus", "DEFAULT"));
                claimStatus.setTc(DataMappingCrossLookUp.getValue("ClaimStatusCodes", "DEFAULT"));
            }


            insured.setGovtIDTC(govtIDTC);
            insured.setAddress(address);
            claim.setClaimStatus(claimStatus);
            policy.setClient(client);
            policy.setInsured(insured);
            policy.setSubLineOfBusiness(subLineOfBusiness);
            policy.setPolicyStatus(policyStatus);
            policy.setClaim(claim);
            getAuthDataResponse.setPolicy(policy);

            LoggerHandler.LogOut("INFO", "1c", messageUUID, sourceSystemName, this.getClass().getName(), getAuthDataResponse.toString());

        } catch (Exception e) {
            LoggerHandler.ErrorOut(e, messageUUID, sourceSystemName, this.getClass().getName(), getAuthDataResponse.toString());
            throw e;
        }

        return getAuthDataResponse;
    }

}
