package com.jh.ltc.maintainpolicy.model;

import com.manulife.esb.xsd.common.jh.header.JHHeader;
import com.manulife.esb.xsd.ltc.jh.maintainpolicy.GetPolicyRequest;

/**
 * The type Get policy request wrapper.
 */
public class GetPolicyRequestWrapper {

    private JHHeader header;

    private GetPolicyRequest getPolicyRequest;

    /**
     * Gets header.
     *
     * @return the header
     */
    public JHHeader getHeader() {
        return header;
    }

    /**
     * Sets header.
     *
     * @param header the header
     */
    public void setHeader(JHHeader header) {
        this.header = header;
    }

    /**
     * Gets get policy request.
     *
     * @return the get policy request
     */
    public GetPolicyRequest getGetPolicyRequest() {
        return getPolicyRequest;
    }

    /**
     * Sets get policy request.
     *
     * @param getPolicyRequest the get policy request
     */
    public void setGetPolicyRequest(GetPolicyRequest getPolicyRequest) {
        this.getPolicyRequest = getPolicyRequest;
    }
}
