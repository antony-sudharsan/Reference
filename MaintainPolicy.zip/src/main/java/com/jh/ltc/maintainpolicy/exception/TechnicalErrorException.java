package com.jh.ltc.maintainpolicy.exception;

import com.jh.ltc.maintainpolicy.utils.Utility;

/**
 * Represents SoapFault for Technical Error.
 */
public class TechnicalErrorException extends BaseFaultException {

    private static final long serialVersionUID = 1L;

    private static final String DEFAULT_CODE = "9999";
    private static final String DEFAULT_REASON = "Technical Error";
    private static final String FAULT_STRING = "Internal Error";

    public TechnicalErrorException(final String message, final Throwable cause) {
        super(DEFAULT_CODE, DEFAULT_REASON, getMessage(message, cause), FAULT_STRING, cause);
    }

    private static String getMessage(final String message, final Throwable cause) {
        String detail = message;
        if (cause != null) {
            detail = message + ", " + Utility.getStackTrace(cause);
        }
        return detail;
    }

}
