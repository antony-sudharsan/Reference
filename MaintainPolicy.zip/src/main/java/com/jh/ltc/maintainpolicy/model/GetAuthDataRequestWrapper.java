package com.jh.ltc.maintainpolicy.model;

import com.manulife.esb.xsd.common.jh.header.JHHeader;
import com.manulife.esb.xsd.ltc.jh.maintainpolicy.GetAuthDataRequest;

/**
 * The type Get auth data request wrapper.
 */
public class GetAuthDataRequestWrapper {

    private JHHeader header;
    private GetAuthDataRequest getAuthDataRequest;

    /**
     * Gets header.
     *
     * @return the header
     */
    public JHHeader getHeader() {
        return header;
    }

    /**
     * Sets header.
     *
     * @param header the header
     */
    public void setHeader(JHHeader header) {
        this.header = header;
    }

    /**
     * Gets get auth data request.
     *
     * @return the get auth data request
     */
    public GetAuthDataRequest getGetAuthDataRequest() {
        return getAuthDataRequest;
    }

    /**
     * Sets get auth data request.
     *
     * @param getAuthDataRequest the get auth data request
     */
    public void setGetAuthDataRequest(GetAuthDataRequest getAuthDataRequest) {
        this.getAuthDataRequest = getAuthDataRequest;
    }
}
