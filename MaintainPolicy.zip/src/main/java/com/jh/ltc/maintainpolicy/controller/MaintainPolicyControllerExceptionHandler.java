package com.jh.ltc.maintainpolicy.controller;

import com.jh.ltc.maintainpolicy.exception.BaseFaultException;
import com.jh.ltc.maintainpolicy.exception.ExceptionResponse;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

@ControllerAdvice
public class MaintainPolicyControllerExceptionHandler extends ResponseEntityExceptionHandler {

    @ExceptionHandler(BaseFaultException.class)
    public final ResponseEntity<Object> handleException(BaseFaultException ex, WebRequest request) {

        ExceptionResponse resp = new ExceptionResponse(ex.getCode(), ex.getReason(), ex.getReason());

        if (ex.getCode().equals("TECHNICAL_ERROR_CODE")) {
            return new ResponseEntity(resp, HttpStatus.INTERNAL_SERVER_ERROR);
        } else if (ex.getCode().equals("TIMEOUT_ERROR_CODE")) {
            return new ResponseEntity(resp, HttpStatus.REQUEST_TIMEOUT);
        } else {
            return new ResponseEntity(resp, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

}
