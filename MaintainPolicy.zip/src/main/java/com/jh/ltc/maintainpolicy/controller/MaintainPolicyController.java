package com.jh.ltc.maintainpolicy.controller;

import com.jh.common.logging.LoggerHandler;
import com.jh.ltc.maintainpolicy.model.*;
import com.jh.ltc.maintainpolicy.orchestration.MaintainPolicyOrchestraion;
import com.jh.ltc.maintainpolicy.utils.JHHeaderUtils;
import com.jh.ltc.maintainpolicy.utils.LoggerUtils;
import com.jh.ltc.maintainpolicy.utils.LoggingContextHolder;
import com.manulife.esb.xsd.ltc.jh.maintainpolicy.GetAuthDataResponse;
import com.manulife.esb.xsd.ltc.jh.maintainpolicy.GetClaimResponse;
import com.manulife.esb.xsd.ltc.jh.maintainpolicy.GetPolicyResponse;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.DataBinder;
import org.springframework.web.bind.annotation.*;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

@RestController
@EnableSwagger2
@RequestMapping("/jh/ins/ltc/datamart")
public class MaintainPolicyController {

    private final LoggerUtils loggerUtils;

    @Autowired
    MaintainPolicyOrchestraion maintainPolicyOrchestraion;


    @InitBinder
    public void activateDirectFieldAccess(final DataBinder dataBinder) {
        dataBinder.initDirectFieldAccess();
    }

    @Autowired
    public MaintainPolicyController(final MaintainPolicyOrchestraion maintainPolicyOrchestraion,
                                    final LoggerUtils loggerUtils) {
        this.loggerUtils = loggerUtils;
        this.maintainPolicyOrchestraion = maintainPolicyOrchestraion;
    }


    @ApiOperation(
            value = "Get Auth Data",
            notes = "Service will retrive Auth data",
            response = GetAuthDataResponseWrapper.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Success"),
            @ApiResponse(code = 406, message = "Service Processing Error"),
            @ApiResponse(code = 408, message = "Request Timeout"),
            @ApiResponse(code = 500, message = "SQL Server Backend returned an error"),
            @ApiResponse(code = 400, message = "Validation Failed"),
            @ApiResponse(code = 404, message = "Auth data Record not found "),
            @ApiResponse(code = 401, message = "Unauthorized to perform operation")
    })
    @RequestMapping(value = "/authdata", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<GetAuthDataResponseWrapper> getAuthData(@RequestBody GetAuthDataRequestWrapper request)
            throws Exception {
        final String messageUUID = JHHeaderUtils.retrieveOrDefaultMessageUID(request.getHeader(),
                "CreateProducerAgreement");
        final String sourceSystemName = JHHeaderUtils.retrieveOrDefaultSourceSystemName(request.getHeader());

        GetAuthDataResponseWrapper getAuthDataResponseWrapper = new GetAuthDataResponseWrapper();
        try {
            LoggingContextHolder.getLoggingContext().setContext(messageUUID, sourceSystemName);

            JHHeaderUtils.validateHeader(request.getHeader());
            LoggerHandler.LogOut("INFO", "1", messageUUID, sourceSystemName, this.getClass().getName(), "Entering Auth Data Controller");

            GetAuthDataResponse getAuthDataResponse = (GetAuthDataResponse) maintainPolicyOrchestraion.getAuthData(request.getHeader(), request.getGetAuthDataRequest());

            getAuthDataResponseWrapper.setGetAuthDataResponse(getAuthDataResponse);
            getAuthDataResponseWrapper.setHeader(request.getHeader());

            LoggerHandler.LogOut("INFO", "6", messageUUID, sourceSystemName, this.getClass().getName(), "Exiting Auth Data Controller");
            LoggerHandler.LogOut("DEBUG", "6", messageUUID, sourceSystemName, this.getClass().getName(), "Controller Create Success");

        } catch (final Exception e) {
            LoggerHandler.ErrorOut(e, messageUUID, sourceSystemName, this.getClass().getName(), e.getMessage());
            throw e;
        }

        return new ResponseEntity(getAuthDataResponseWrapper, new HttpHeaders(), HttpStatus.OK);
    }


    @ApiOperation(
            value = "Get Policy Data",
            notes = "Service will retrive Policy data",
            response = GetPolicyResponseWrapper.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Success"),
            @ApiResponse(code = 406, message = "Service Processing Error"),
            @ApiResponse(code = 408, message = "Request Timeout"),
            @ApiResponse(code = 500, message = "SQL Server Backend returned an error"),
            @ApiResponse(code = 400, message = "Validation Failed"),
            @ApiResponse(code = 404, message = "Policy data Record not found "),
            @ApiResponse(code = 401, message = "Unauthorized to perform operation")
    })

    @RequestMapping(value = "/policy", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<GetPolicyResponseWrapper> getPolicy(@RequestBody GetPolicyRequestWrapper getPolicyRequestWrapper)
            throws Exception {
        final String messageUUID = JHHeaderUtils.retrieveOrDefaultMessageUID(getPolicyRequestWrapper.getHeader(),
                "CreateProducerAgreement");
        final String sourceSystemName = JHHeaderUtils.retrieveOrDefaultSourceSystemName(getPolicyRequestWrapper.getHeader());

        GetPolicyResponseWrapper getPolicyResponseWrapper = new GetPolicyResponseWrapper();
        GetPolicyResponse getPolicyResponse = null;
        try {

            JHHeaderUtils.validateHeader(getPolicyRequestWrapper.getHeader());
            LoggerHandler.LogOut("INFO", "1", messageUUID, sourceSystemName, this.getClass().getName(), "Entering Get Policy Details Controller");

            getPolicyResponse = (GetPolicyResponse) maintainPolicyOrchestraion.getPolicy(getPolicyRequestWrapper.getHeader(), getPolicyRequestWrapper.getGetPolicyRequest());
            getPolicyResponseWrapper.setGetPolicyResponse(getPolicyResponse);
            getPolicyResponseWrapper.setHeader(getPolicyRequestWrapper.getHeader());
            LoggerHandler.LogOut("INFO", "6", messageUUID, sourceSystemName, this.getClass().getName(), "Exiting  Get Policy Details Controller");
            LoggerHandler.LogOut("DEBUG", "6", messageUUID, sourceSystemName, this.getClass().getName(), "Controller Create Success");

        } catch (final Exception e) {
            LoggerHandler.ErrorOut(e, messageUUID, sourceSystemName, this.getClass().getName(), e.getMessage());
            throw e;
        }

        return new ResponseEntity(getPolicyResponseWrapper, new HttpHeaders(), HttpStatus.OK);
    }

    @ApiOperation(
            value = "Get Claim Data",
            notes = "Service will retrive Claim data",
            response = GetClaimResponseWrapper.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Success"),
            @ApiResponse(code = 406, message = "Service Processing Error"),
            @ApiResponse(code = 408, message = "Request Timeout"),
            @ApiResponse(code = 500, message = "SQL Server Backend returned an error"),
            @ApiResponse(code = 400, message = "Validation Failed"),
            @ApiResponse(code = 404, message = "Policy data Record not found "),
            @ApiResponse(code = 401, message = "Unauthorized to perform operation")
    })


    @RequestMapping(value = "/claim", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<GetClaimResponseWrapper> getClaim(@RequestBody GetClaimRequestWrapper getClaimRequestWrapper)
            throws Exception {
        final String messageUUID = JHHeaderUtils.retrieveOrDefaultMessageUID(getClaimRequestWrapper.getHeader(),
                "CreateProducerAgreement");
        final String sourceSystemName = JHHeaderUtils.retrieveOrDefaultSourceSystemName(getClaimRequestWrapper.getHeader());

        GetClaimResponseWrapper getClaimResponseWrapper = new GetClaimResponseWrapper();
        GetClaimResponse getClaimResponse = null;
        try {
            JHHeaderUtils.validateHeader(getClaimRequestWrapper.getHeader());
            LoggerHandler.LogOut("INFO", "1", messageUUID, sourceSystemName, this.getClass().getName(), "Entering Get Claim Details Controller");

            getClaimResponse = (GetClaimResponse) maintainPolicyOrchestraion.getClaim(getClaimRequestWrapper.getHeader(), getClaimRequestWrapper.getGetClaimRequest());

            getClaimResponseWrapper.setGetClaimResponse(getClaimResponse);
            getClaimResponseWrapper.setHeader(getClaimRequestWrapper.getHeader());
            LoggerHandler.LogOut("INFO", "6", messageUUID, sourceSystemName, this.getClass().getName(), "Exiting  Get Claim Details Controller");
            LoggerHandler.LogOut("DEBUG", "6", messageUUID, sourceSystemName, this.getClass().getName(), "Controller Create Success");

        } catch (final Exception e) {
            LoggerHandler.ErrorOut(e, messageUUID, sourceSystemName, this.getClass().getName(), e.getMessage());
            throw e;
        }

        return new ResponseEntity(getClaimResponseWrapper, new HttpHeaders(), HttpStatus.OK);
    }


}
