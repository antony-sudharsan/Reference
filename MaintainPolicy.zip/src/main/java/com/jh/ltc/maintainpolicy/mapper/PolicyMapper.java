package com.jh.ltc.maintainpolicy.mapper;

import com.jh.common.logging.LoggerHandler;
import com.jh.common.utility.DataMappingCrossLookUp;
import com.jh.ltc.maintainpolicy.utils.MaintainPolicyUtils;
import com.manulife.esb.xsd.ltc.jh.maintainpolicy.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.sql.Date;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

@Component
public class PolicyMapper {

    @Autowired
    MaintainPolicyUtils maintainPolicyUtils;


    public GetPolicyResponse getPolicyDetails(String messageUUID, String sourceSystemName, Map<String, Object> policyResultset, Map<String, Object> riderResultset) {
        LoggerHandler.LogOut("INFO", "2", messageUUID, sourceSystemName, this.getClass().getName(),
                "Mapping the Result Set");
        GetPolicyResponse getPolicyResponse = new GetPolicyResponse();
        GetPolicyResponse.Policy policy = new GetPolicyResponse.Policy();
        SubLineOfBusiness subLineOfBusiness = new SubLineOfBusiness();
        PolicyStatus policyStatus = new PolicyStatus();
        PaymentMode paymentMode = new PaymentMode();
        PaymentMethod paymentMethod = new PaymentMethod();
        BillingStatus billingStatus = new BillingStatus();

        List<Rider> riderObjList = null;
        try {

            if (policyResultset.get("O_POLICY_NUM") != null)
                policy.setPolNumber(String.valueOf(policyResultset.get("O_POLICY_NUM")).trim());


            subLineOfBusiness.setTc(maintainPolicyUtils.getStringShortValue(policyResultset.get("O_LINE_OF_BUSINESS")));

            if (policyResultset.get("O_LINE_OF_BUSINESS") != null) {
                subLineOfBusiness.setValue(DataMappingCrossLookUp.getValue("SubLineOfBusiness", String.valueOf(((short) policyResultset.get("O_LINE_OF_BUSINESS"))).toUpperCase()));
            } else {
                subLineOfBusiness.setValue(DataMappingCrossLookUp.getValue("SubLineOfBusiness", "DEFAULT"));
            }

            if (policyResultset.get("O_POLICY_SRC_FILE") != null)
                policy.setCarrierAdminSystem(String.valueOf(policyResultset.get("O_POLICY_SRC_FILE")).trim());


            if (policyResultset.get("O_CME_POLICY_STATUS_CD") != null) {
                policyStatus.setValue(DataMappingCrossLookUp.getValue("PolicyStatus", String.valueOf(policyResultset.get("O_CME_POLICY_STATUS_CD")).toUpperCase()));
                policyStatus.setTc(DataMappingCrossLookUp.getValue("PolicyStatusCodes", String.valueOf(policyResultset.get("O_CME_POLICY_STATUS_CD")).toUpperCase()));
            } else {
                policyStatus.setValue(DataMappingCrossLookUp.getValue("PolicyStatus", "DEFAULT"));
                policyStatus.setTc(DataMappingCrossLookUp.getValue("PolicyStatusCodes", "DEFAULT"));
            }


            if (policyResultset.get("O_POLICY_EFF_DT") != null)
                policy.setEffDate(maintainPolicyUtils.convertUtilDateToGregoerianCalendar((Date) (policyResultset.get("O_POLICY_EFF_DT"))));

            if (policyResultset.get("O_POLICY_PAID_TO_DT") != null)
                policy.setPaidToDate(maintainPolicyUtils.convertUtilDateToGregoerianCalendar((Date) (policyResultset.get("O_POLICY_PAID_TO_DT"))));

            if (policyResultset.get("O_PREMIUM_FREQUENCY") != null) {
                paymentMode.setValue(DataMappingCrossLookUp.getValue("PaymentMode", String.valueOf(policyResultset.get("O_PREMIUM_FREQUENCY")).toUpperCase()));
                paymentMode.setTc(DataMappingCrossLookUp.getValue("PaymentModeCodes", String.valueOf(policyResultset.get("O_PREMIUM_FREQUENCY")).toUpperCase()));
            } else {
                paymentMode.setValue(DataMappingCrossLookUp.getValue("PaymentMode", "DEFAULT"));
                paymentMode.setTc(DataMappingCrossLookUp.getValue("PaymentModeCodes", "DEFAuLT"));
            }

            if (policyResultset.get("O_CME_BILLING_STATUS") != null) {
                billingStatus.setValue(DataMappingCrossLookUp.getValue("BillingStatus", String.valueOf(policyResultset.get("O_CME_BILLING_STATUS")).toUpperCase()));
                billingStatus.setTc(DataMappingCrossLookUp.getValue("BillingStatusCodes", String.valueOf(policyResultset.get("O_CME_BILLING_STATUS")).toUpperCase()));
            } else {
                billingStatus.setValue(DataMappingCrossLookUp.getValue("BillingStatus", "DEFAULT"));
                billingStatus.setTc(DataMappingCrossLookUp.getValue("BillingStatusCodes", "DEFAULT"));
            }

            if (policyResultset.get("O_CME_BILLING_TYPE") != null) {
                paymentMethod.setValue(DataMappingCrossLookUp.getValue("PaymentMethod", String.valueOf(policyResultset.get("O_CME_BILLING_TYPE")).toUpperCase()));
                paymentMethod.setTc(DataMappingCrossLookUp.getValue("PaymentMethodCodes", String.valueOf(policyResultset.get("O_CME_BILLING_TYPE")).toUpperCase()));
            } else {
                paymentMethod.setValue(DataMappingCrossLookUp.getValue("PaymentMethod", "DEFAULT"));
                paymentMethod.setTc(DataMappingCrossLookUp.getValue("PaymentMethodCodes", "DEFAULT"));
            }


            policy.setBillingFreezeCode(String.valueOf(policyResultset.get("O_GROUP_BILLING_FREEZE_CD")));

            if (policyResultset.get("O_LAST_POLICY_PREM_AMT") != null)
                policy.setPaymentAmt(new BigDecimal(String.valueOf((policyResultset.get("O_LAST_POLICY_PREM_AMT")))));


            if (policyResultset.get("O_LAST_POLICY_PREM_PAID_DT") != null)
                policy.setLastCOIDate(maintainPolicyUtils.convertUtilDateToGregoerianCalendar((Date) (policyResultset.get("O_LAST_POLICY_PREM_PAID_DT"))));


            if (policyResultset.get("O_PREMIUM_PAYMENT_DUE_DT") != null)
                policy.setPaymentDueDate(maintainPolicyUtils.convertUtilDateToGregoerianCalendar((Date) (policyResultset.get("O_PREMIUM_PAYMENT_DUE_DT"))));

            policy.setPaymentCreditCode(String.valueOf(policyResultset.get("O_LAST_POLICY_PREM_CREDIT_CD")));

            policy.setPaymentDebitCode(String.valueOf(policyResultset.get("O_LAST_POLICY_PREM_DEBIT_CD")));

            policy.setFinTransCode(String.valueOf(policyResultset.get("O_LAST_POLICY_PREM_TXN_CD")));


            // Mapping Rider Details if available
            if (riderResultset != null) {

                List<String> riderList = Arrays.asList(String.valueOf(riderResultset.get("O_RIDER_NAME")).split(","));

                riderList.forEach(item -> {
                    Rider rider = new Rider();
                    rider.setShortName(item);
                    riderObjList.add(rider);
                });
            }

            policy.setRider(riderObjList);
            policy.setBillingStatus(billingStatus);
            policy.setPaymentMethod(paymentMethod);
            policy.setPaymentMode(paymentMode);
            policy.setSubLineOfBusiness(subLineOfBusiness);
            policy.setPolicyStatus(policyStatus);
            getPolicyResponse.setPolicy(policy);

            LoggerHandler.LogOut("INFO", "1c", messageUUID, sourceSystemName, this.getClass().getName(), getPolicyResponse.toString());

        } catch (Exception e) {
            LoggerHandler.ErrorOut(e, messageUUID, sourceSystemName, this.getClass().getName(), getPolicyResponse.toString());
            throw e;
        }

        return getPolicyResponse;
    }

}
