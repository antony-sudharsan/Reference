package com.jh.ltc.maintainpolicy.orchestration;

import com.jh.common.logging.LoggerHandler;
import com.jh.ltc.maintainpolicy.dao.MaintainPolicyDAO;
import com.jh.ltc.maintainpolicy.exception.InvalidInputException;
import com.jh.ltc.maintainpolicy.mapper.AuthDataMapper;
import com.jh.ltc.maintainpolicy.mapper.ClaimMapper;
import com.jh.ltc.maintainpolicy.mapper.PolicyMapper;
import com.jh.ltc.maintainpolicy.utils.LoggerUtils;
import com.jh.ltc.maintainpolicy.utils.LoggingContextHolder;
import com.manulife.esb.wsdl.ltc.jh.maintainpolicy.maintainpolicy.MaintainPolicyFault;
import com.manulife.esb.xsd.common.jh.header.JHHeader;
import com.manulife.esb.xsd.ltc.jh.maintainpolicy.*;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Map;

/**
 * The type Maintain policy orchestraion.
 */
@Component
public class MaintainPolicyOrchestraion {

    @Autowired
    private LoggerUtils loggerUtils;
    @Autowired
    private MaintainPolicyDAO maintainPolicyDAO;
    @Autowired
    ClaimMapper claimMapper;
    @Autowired
    PolicyMapper policyMapper;

    @Autowired
    AuthDataMapper authDataMapper;

    /**
     * Gets claim.
     *
     * @param header  the header
     * @param request the request
     *
     * @return claim
     *
     * @throws MaintainPolicyFault the maintain policy fault
     */
    public GetClaimResponse getClaim(final JHHeader header, final GetClaimRequest request) {

        final String messageUUID = LoggingContextHolder.getLoggingContext().getMessageUUID();
        final String sourceSystemName = LoggingContextHolder.getLoggingContext().getSourceSystemName();
        GetClaimResponse reply = new GetClaimResponse();

        LoggerHandler.LogOut("INFO", "2", messageUUID, sourceSystemName, this.getClass().getName(),
                "Entering getclaim " + loggerUtils.writeAsJson(request));

        final String user = retrieveAndValidateUser(header);

        Map<String, Object> resultObject = maintainPolicyDAO.getClaim(user, request);

        reply = claimMapper.getClaimDetails(messageUUID, sourceSystemName, resultObject);

        System.out.println("Inside the ############################### >>" + loggerUtils.writeAsJson(reply));
        LoggerHandler.LogOut("INFO", "3", messageUUID, sourceSystemName, this.getClass().getName(),
                "Exiting GetClaim " + loggerUtils.writeAsJson(reply));

        return reply;
    }


    /**
     * Gets policy.
     *
     * @param header  the header
     * @param request the request
     *
     * @return the policy
     *
     * @throws MaintainPolicyFault the maintain policy fault
     */
    public GetPolicyResponse getPolicy(final JHHeader header, final GetPolicyRequest request) {

        final String messageUUID = LoggingContextHolder.getLoggingContext().getMessageUUID();
        final String sourceSystemName = LoggingContextHolder.getLoggingContext().getSourceSystemName();
        GetPolicyResponse reply = new GetPolicyResponse();

        LoggerHandler.LogOut("INFO", "2", messageUUID, sourceSystemName, this.getClass().getName(),
                "Entering getPolicy " + loggerUtils.writeAsJson(request));

        final String user = retrieveAndValidateUser(header);

        Map<String, Object> policyResultset = maintainPolicyDAO.getPolicy(user, request);
        Map<String, Object> riderResultset = null;

        if (policyResultset.get("O_LINE_OF_BUSINESS") != null && policyResultset.get("O_LINE_OF_BUSINESS").equals(1)) {

            LoggerHandler.LogOut("INFO", "2a", messageUUID, sourceSystemName, this.getClass().getName(),
                    "Entering getPolicy " + loggerUtils.writeAsJson(request));
            riderResultset = maintainPolicyDAO.getPolicyRiderDetails(user, request);
        }

        reply = policyMapper.getPolicyDetails(messageUUID, sourceSystemName, policyResultset, riderResultset);

        LoggerHandler.LogOut("INFO", "3", messageUUID, sourceSystemName, this.getClass().getName(),
                "Exiting getPolicy " + loggerUtils.writeAsJson(reply));


        return reply;
    }


    /**
     * Gets auth data.
     *
     * @param header  the header
     * @param request the request
     *
     * @return auth data
     *
     * @throws MaintainPolicyFault the maintain policy fault
     */
    public GetAuthDataResponse getAuthData(final JHHeader header, final GetAuthDataRequest request) {
        final String messageUUID = LoggingContextHolder.getLoggingContext().getMessageUUID();
        final String sourceSystemName = LoggingContextHolder.getLoggingContext().getSourceSystemName();
        GetAuthDataResponse reply = new GetAuthDataResponse();

        LoggerHandler.LogOut("INFO", "2", messageUUID, sourceSystemName, this.getClass().getName(),
                "Entering getAuthData " + loggerUtils.writeAsJson(request));

        final String user = retrieveAndValidateUser(header);


        Map<String, Object> resultObject = maintainPolicyDAO.getAuthData(user, request);
        reply = authDataMapper.getAuthDetails(messageUUID, sourceSystemName, resultObject);

        LoggerHandler.LogOut("INFO", "3", messageUUID, sourceSystemName, this.getClass().getName(),
                "Exiting getAuthData " + loggerUtils.writeAsJson(reply));


        return reply;
    }

    /**
     * Retrieve user from header, and if not found throw proper exception.
     *
     * @param header
     *
     * @return
     */
    private String retrieveAndValidateUser(final JHHeader header) {
        final String user = header.getMessageSource().getUserID();
        if (StringUtils.isEmpty(user)) {
            throw new InvalidInputException();
        }
        return user;
    }

}
