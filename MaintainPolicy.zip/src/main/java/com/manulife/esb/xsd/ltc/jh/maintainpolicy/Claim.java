
package com.manulife.esb.xsd.ltc.jh.maintainpolicy;

import javax.xml.bind.annotation.*;
import javax.xml.datatype.XMLGregorianCalendar;
import java.math.BigDecimal;


/**
 * <p>Java class for anonymous complex type.
 *
 * <p>The following schema fragment specifies the expected content contained within this class.
 *
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy}ClaimNumber"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy}ClaimStatus"/>
 *         &lt;element name="CarrierAdminSystem" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy}ClaimStatusEffDate" minOccurs="0"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy}ClaimPaymentDate" minOccurs="0"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy}ClaimPaymentAmt" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
        "claimNumber",
        "claimStatus",
        "carrierAdminSystem",
        "claimStatusEffDate",
        "claimPaymentDate",
        "claimPaymentAmt"
})
@XmlRootElement(name = "Claim")
public class Claim {

    @XmlElement(name = "ClaimNumber", required = true)
    protected String claimNumber;
    @XmlElement(name = "ClaimStatus", required = true)
    protected ClaimStatus claimStatus;
    @XmlElement(name = "CarrierAdminSystem")
    protected String carrierAdminSystem;
    @XmlElement(name = "ClaimStatusEffDate")
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar claimStatusEffDate;
    @XmlElement(name = "ClaimPaymentDate")
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar claimPaymentDate;
    @XmlElement(name = "ClaimPaymentAmt")
    protected BigDecimal claimPaymentAmt;

    /**
     * Map to HOClaimReferenceID
     *
     * @return possible object is
     * {@link String }
     */
    public String getClaimNumber() {
        return claimNumber;
    }

    /**
     * Sets the value of the claimNumber property.
     *
     * @param value allowed object is
     *              {@link String }
     */
    public void setClaimNumber(String value) {
        this.claimNumber = value;
    }

    /**
     * Gets the value of the claimStatus property.
     *
     * @return possible object is
     * {@link ClaimStatus }
     */
    public ClaimStatus getClaimStatus() {
        return claimStatus;
    }

    /**
     * Sets the value of the claimStatus property.
     *
     * @param value allowed object is
     *              {@link ClaimStatus }
     */
    public void setClaimStatus(ClaimStatus value) {
        this.claimStatus = value;
    }

    /**
     * Gets the value of the carrierAdminSystem property.
     *
     * @return possible object is
     * {@link String }
     */
    public String getCarrierAdminSystem() {
        return carrierAdminSystem;
    }

    /**
     * Sets the value of the carrierAdminSystem property.
     *
     * @param value allowed object is
     *              {@link String }
     */
    public void setCarrierAdminSystem(String value) {
        this.carrierAdminSystem = value;
    }

    /**
     * Gets the value of the claimStatusEffDate property.
     *
     * @return possible object is
     * {@link XMLGregorianCalendar }
     */
    public XMLGregorianCalendar getClaimStatusEffDate() {
        return claimStatusEffDate;
    }

    /**
     * Sets the value of the claimStatusEffDate property.
     *
     * @param value allowed object is
     *              {@link XMLGregorianCalendar }
     */
    public void setClaimStatusEffDate(XMLGregorianCalendar value) {
        this.claimStatusEffDate = value;
    }

    /**
     * Gets the value of the claimPaymentDate property.
     *
     * @return possible object is
     * {@link XMLGregorianCalendar }
     */
    public XMLGregorianCalendar getClaimPaymentDate() {
        return claimPaymentDate;
    }

    /**
     * Sets the value of the claimPaymentDate property.
     *
     * @param value allowed object is
     *              {@link XMLGregorianCalendar }
     */
    public void setClaimPaymentDate(XMLGregorianCalendar value) {
        this.claimPaymentDate = value;
    }

    /**
     * Gets the value of the claimPaymentAmt property.
     *
     * @return possible object is
     * {@link BigDecimal }
     */
    public BigDecimal getClaimPaymentAmt() {
        return claimPaymentAmt;
    }

    /**
     * Sets the value of the claimPaymentAmt property.
     *
     * @param value allowed object is
     *              {@link BigDecimal }
     */
    public void setClaimPaymentAmt(BigDecimal value) {
        this.claimPaymentAmt = value;
    }

}
