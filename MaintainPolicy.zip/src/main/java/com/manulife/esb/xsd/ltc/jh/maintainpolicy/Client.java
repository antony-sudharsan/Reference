
package com.manulife.esb.xsd.ltc.jh.maintainpolicy;

import javax.xml.bind.annotation.*;


/**
 * <p>Java class for anonymous complex type.
 *
 * <p>The following schema fragment specifies the expected content contained within this class.
 *
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy}FullName"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy}AbbrName"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy}IDReferenceNo"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
        "fullName",
        "abbrName",
        "idReferenceNo"
})
@XmlRootElement(name = "Client")
public class Client {

    @XmlElement(name = "FullName", required = true)
    protected String fullName;
    @XmlElement(name = "AbbrName", required = true)
    protected String abbrName;
    @XmlElement(name = "IDReferenceNo", required = true)
    protected String idReferenceNo;

    /**
     * Gets the value of the fullName property.
     *
     * @return possible object is
     * {@link String }
     */
    public String getFullName() {
        return fullName;
    }

    /**
     * Sets the value of the fullName property.
     *
     * @param value allowed object is
     *              {@link String }
     */
    public void setFullName(String value) {
        this.fullName = value;
    }

    /**
     * Gets the value of the abbrName property.
     *
     * @return possible object is
     * {@link String }
     */
    public String getAbbrName() {
        return abbrName;
    }

    /**
     * Sets the value of the abbrName property.
     *
     * @param value allowed object is
     *              {@link String }
     */
    public void setAbbrName(String value) {
        this.abbrName = value;
    }

    /**
     * Gets the value of the idReferenceNo property.
     *
     * @return possible object is
     * {@link String }
     */
    public String getIDReferenceNo() {
        return idReferenceNo;
    }

    /**
     * Sets the value of the idReferenceNo property.
     *
     * @param value allowed object is
     *              {@link String }
     */
    public void setIDReferenceNo(String value) {
        this.idReferenceNo = value;
    }

}
