
package com.manulife.esb.xsd.ltc.jh.maintainpolicy;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.namespace.QName;
import java.math.BigDecimal;


/**
 * This object contains factory methods for each
 * Java content interface and Java element interface
 * generated in the com.manulife.esb.xsd.ltc.jh.maintainpolicy package.
 * <p>An ObjectFactory allows you to programatically
 * construct new instances of the Java representation
 * for XML content. The Java representation of XML
 * content can consist of schema derived interfaces
 * and classes representing the binding of schema
 * type definitions, element declarations and model
 * groups.  Factory methods for each of these are
 * provided in this class.
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _FullName_QNAME = new QName("http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy", "FullName");
    private final static QName _PaymentAmt_QNAME = new QName("http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy", "PaymentAmt");
    private final static QName _Line3_QNAME = new QName("http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy", "Line3");
    private final static QName _Line2_QNAME = new QName("http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy", "Line2");
    private final static QName _Line1_QNAME = new QName("http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy", "Line1");
    private final static QName _PaymentDebitCode_QNAME = new QName("http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy", "PaymentDebitCode");
    private final static QName _PersonSysKey_QNAME = new QName("http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy", "PersonSysKey");
    private final static QName _FirstName_QNAME = new QName("http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy", "FirstName");
    private final static QName _ClaimNumber_QNAME = new QName("http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy", "ClaimNumber");
    private final static QName _MiddleName_QNAME = new QName("http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy", "MiddleName");
    private final static QName _PaidToDate_QNAME = new QName("http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy", "PaidToDate");
    private final static QName _PaymentCreditCode_QNAME = new QName("http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy", "PaymentCreditCode");
    private final static QName _CarrierAdminSystem_QNAME = new QName("http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy", "CarrierAdminSystem");
    private final static QName _PaymentDueDate_QNAME = new QName("http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy", "PaymentDueDate");
    private final static QName _Prefix_QNAME = new QName("http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy", "Prefix");
    private final static QName _ClaimPaymentAmt_QNAME = new QName("http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy", "ClaimPaymentAmt");
    private final static QName _EffDate_QNAME = new QName("http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy", "EffDate");
    private final static QName _State_QNAME = new QName("http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy", "State");
    private final static QName _PolNumber_QNAME = new QName("http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy", "PolNumber");
    private final static QName _Suffix_QNAME = new QName("http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy", "Suffix");
    private final static QName _BirthDate_QNAME = new QName("http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy", "BirthDate");
    private final static QName _LossReportDate_QNAME = new QName("http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy", "LossReportDate");
    private final static QName _LastName_QNAME = new QName("http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy", "LastName");
    private final static QName _ClaimPaymentDate_QNAME = new QName("http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy", "ClaimPaymentDate");
    private final static QName _BillingFreezeCode_QNAME = new QName("http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy", "BillingFreezeCode");
    private final static QName _IDReferenceNo_QNAME = new QName("http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy", "IDReferenceNo");
    private final static QName _CertificateNo_QNAME = new QName("http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy", "CertificateNo");
    private final static QName _City_QNAME = new QName("http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy", "City");
    private final static QName _ClaimStatusEffDate_QNAME = new QName("http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy", "ClaimStatusEffDate");
    private final static QName _GovtID_QNAME = new QName("http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy", "GovtID");
    private final static QName _FinTransCode_QNAME = new QName("http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy", "FinTransCode");
    private final static QName _LastCOIDate_QNAME = new QName("http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy", "LastCOIDate");
    private final static QName _Zip_QNAME = new QName("http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy", "Zip");
    private final static QName _ShortName_QNAME = new QName("http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy", "ShortName");
    private final static QName _AbbrName_QNAME = new QName("http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy", "AbbrName");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.manulife.esb.xsd.ltc.jh.maintainpolicy
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link GetAuthDataRequest }
     */
    public GetAuthDataRequest createGetAuthDataRequest() {
        return new GetAuthDataRequest();
    }

    /**
     * Create an instance of {@link GetPolicyResponse }
     */
    public GetPolicyResponse createGetPolicyResponse() {
        return new GetPolicyResponse();
    }

    /**
     * Create an instance of {@link GetClaimResponse }
     */
    public GetClaimResponse createGetClaimResponse() {
        return new GetClaimResponse();
    }

    /**
     * Create an instance of {@link GetAuthDataResponse }
     */
    public GetAuthDataResponse createGetAuthDataResponse() {
        return new GetAuthDataResponse();
    }

    /**
     * Create an instance of {@link GetAuthDataResponse.Policy }
     */
    public GetAuthDataResponse.Policy createGetAuthDataResponsePolicy() {
        return new GetAuthDataResponse.Policy();
    }

    /**
     * Create an instance of {@link Address }
     */
    public Address createAddress() {
        return new Address();
    }

    /**
     * Create an instance of {@link GetClaimFault }
     */
    public GetClaimFault createGetClaimFault() {
        return new GetClaimFault();
    }

    /**
     * Create an instance of {@link Client }
     */
    public Client createClient() {
        return new Client();
    }

    /**
     * Create an instance of {@link GetAuthDataFault }
     */
    public GetAuthDataFault createGetAuthDataFault() {
        return new GetAuthDataFault();
    }

    /**
     * Create an instance of {@link SubLineOfBusiness }
     */
    public SubLineOfBusiness createSubLineOfBusiness() {
        return new SubLineOfBusiness();
    }

    /**
     * Create an instance of {@link GetAuthDataRequest.CustomerTypeCode }
     */
    public GetAuthDataRequest.CustomerTypeCode createGetAuthDataRequestCustomerTypeCode() {
        return new GetAuthDataRequest.CustomerTypeCode();
    }

    /**
     * Create an instance of {@link GetPolicyResponse.Policy }
     */
    public GetPolicyResponse.Policy createGetPolicyResponsePolicy() {
        return new GetPolicyResponse.Policy();
    }

    /**
     * Create an instance of {@link Insured }
     */
    public Insured createInsured() {
        return new Insured();
    }

    /**
     * Create an instance of {@link GovtIDTC }
     */
    public GovtIDTC createGovtIDTC() {
        return new GovtIDTC();
    }

    /**
     * Create an instance of {@link com.manulife.esb.xsd.ltc.jh.maintainpolicy.CustomerTypeCode }
     */
    public com.manulife.esb.xsd.ltc.jh.maintainpolicy.CustomerTypeCode createCustomerTypeCode() {
        return new com.manulife.esb.xsd.ltc.jh.maintainpolicy.CustomerTypeCode();
    }

    /**
     * Create an instance of {@link PolicyStatus }
     */
    public PolicyStatus createPolicyStatus() {
        return new PolicyStatus();
    }

    /**
     * Create an instance of {@link PaymentMethod }
     */
    public PaymentMethod createPaymentMethod() {
        return new PaymentMethod();
    }

    /**
     * Create an instance of {@link PaymentMode }
     */
    public PaymentMode createPaymentMode() {
        return new PaymentMode();
    }

    /**
     * Create an instance of {@link GetPolicyRequest }
     */
    public GetPolicyRequest createGetPolicyRequest() {
        return new GetPolicyRequest();
    }

    /**
     * Create an instance of {@link GetClaimResponse.Policy }
     */
    public GetClaimResponse.Policy createGetClaimResponsePolicy() {
        return new GetClaimResponse.Policy();
    }

    /**
     * Create an instance of {@link GetPolicyFault }
     */
    public GetPolicyFault createGetPolicyFault() {
        return new GetPolicyFault();
    }

    /**
     * Create an instance of {@link BillingStatus }
     */
    public BillingStatus createBillingStatus() {
        return new BillingStatus();
    }

    /**
     * Create an instance of {@link Rider }
     */
    public Rider createRider() {
        return new Rider();
    }

    /**
     * Create an instance of {@link ClaimStatus }
     */
    public ClaimStatus createClaimStatus() {
        return new ClaimStatus();
    }

    /**
     * Create an instance of {@link GetClaimRequest }
     */
    public GetClaimRequest createGetClaimRequest() {
        return new GetClaimRequest();
    }

    /**
     * Create an instance of {@link com.manulife.esb.xsd.ltc.jh.maintainpolicy.Claim }
     */
    public com.manulife.esb.xsd.ltc.jh.maintainpolicy.Claim createClaim() {
        return new com.manulife.esb.xsd.ltc.jh.maintainpolicy.Claim();
    }

    /**
     * Create an instance of {@link GetAuthDataResponse.Policy.Claim }
     */
    public GetAuthDataResponse.Policy.Claim createGetAuthDataResponsePolicyClaim() {
        return new GetAuthDataResponse.Policy.Claim();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy", name = "FullName")
    public JAXBElement<String> createFullName(String value) {
        return new JAXBElement<String>(_FullName_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}}
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy", name = "PaymentAmt")
    public JAXBElement<BigDecimal> createPaymentAmt(BigDecimal value) {
        return new JAXBElement<BigDecimal>(_PaymentAmt_QNAME, BigDecimal.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy", name = "Line3")
    public JAXBElement<String> createLine3(String value) {
        return new JAXBElement<String>(_Line3_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy", name = "Line2")
    public JAXBElement<String> createLine2(String value) {
        return new JAXBElement<String>(_Line2_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy", name = "Line1")
    public JAXBElement<String> createLine1(String value) {
        return new JAXBElement<String>(_Line1_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy", name = "PaymentDebitCode")
    public JAXBElement<String> createPaymentDebitCode(String value) {
        return new JAXBElement<String>(_PaymentDebitCode_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy", name = "PersonSysKey")
    public JAXBElement<String> createPersonSysKey(String value) {
        return new JAXBElement<String>(_PersonSysKey_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy", name = "FirstName")
    public JAXBElement<String> createFirstName(String value) {
        return new JAXBElement<String>(_FirstName_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy", name = "ClaimNumber")
    public JAXBElement<String> createClaimNumber(String value) {
        return new JAXBElement<String>(_ClaimNumber_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy", name = "MiddleName")
    public JAXBElement<String> createMiddleName(String value) {
        return new JAXBElement<String>(_MiddleName_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}}
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy", name = "PaidToDate")
    public JAXBElement<XMLGregorianCalendar> createPaidToDate(XMLGregorianCalendar value) {
        return new JAXBElement<XMLGregorianCalendar>(_PaidToDate_QNAME, XMLGregorianCalendar.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy", name = "PaymentCreditCode")
    public JAXBElement<String> createPaymentCreditCode(String value) {
        return new JAXBElement<String>(_PaymentCreditCode_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy", name = "CarrierAdminSystem")
    public JAXBElement<String> createCarrierAdminSystem(String value) {
        return new JAXBElement<String>(_CarrierAdminSystem_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}}
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy", name = "PaymentDueDate")
    public JAXBElement<XMLGregorianCalendar> createPaymentDueDate(XMLGregorianCalendar value) {
        return new JAXBElement<XMLGregorianCalendar>(_PaymentDueDate_QNAME, XMLGregorianCalendar.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy", name = "Prefix")
    public JAXBElement<String> createPrefix(String value) {
        return new JAXBElement<String>(_Prefix_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}}
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy", name = "ClaimPaymentAmt")
    public JAXBElement<BigDecimal> createClaimPaymentAmt(BigDecimal value) {
        return new JAXBElement<BigDecimal>(_ClaimPaymentAmt_QNAME, BigDecimal.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}}
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy", name = "EffDate")
    public JAXBElement<XMLGregorianCalendar> createEffDate(XMLGregorianCalendar value) {
        return new JAXBElement<XMLGregorianCalendar>(_EffDate_QNAME, XMLGregorianCalendar.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy", name = "State")
    public JAXBElement<String> createState(String value) {
        return new JAXBElement<String>(_State_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy", name = "PolNumber")
    public JAXBElement<String> createPolNumber(String value) {
        return new JAXBElement<String>(_PolNumber_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy", name = "Suffix")
    public JAXBElement<String> createSuffix(String value) {
        return new JAXBElement<String>(_Suffix_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}}
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy", name = "BirthDate")
    public JAXBElement<XMLGregorianCalendar> createBirthDate(XMLGregorianCalendar value) {
        return new JAXBElement<XMLGregorianCalendar>(_BirthDate_QNAME, XMLGregorianCalendar.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}}
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy", name = "LossReportDate")
    public JAXBElement<XMLGregorianCalendar> createLossReportDate(XMLGregorianCalendar value) {
        return new JAXBElement<XMLGregorianCalendar>(_LossReportDate_QNAME, XMLGregorianCalendar.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy", name = "LastName")
    public JAXBElement<String> createLastName(String value) {
        return new JAXBElement<String>(_LastName_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}}
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy", name = "ClaimPaymentDate")
    public JAXBElement<XMLGregorianCalendar> createClaimPaymentDate(XMLGregorianCalendar value) {
        return new JAXBElement<XMLGregorianCalendar>(_ClaimPaymentDate_QNAME, XMLGregorianCalendar.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy", name = "BillingFreezeCode")
    public JAXBElement<String> createBillingFreezeCode(String value) {
        return new JAXBElement<String>(_BillingFreezeCode_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy", name = "IDReferenceNo")
    public JAXBElement<String> createIDReferenceNo(String value) {
        return new JAXBElement<String>(_IDReferenceNo_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy", name = "CertificateNo")
    public JAXBElement<String> createCertificateNo(String value) {
        return new JAXBElement<String>(_CertificateNo_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy", name = "City")
    public JAXBElement<String> createCity(String value) {
        return new JAXBElement<String>(_City_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}}
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy", name = "ClaimStatusEffDate")
    public JAXBElement<XMLGregorianCalendar> createClaimStatusEffDate(XMLGregorianCalendar value) {
        return new JAXBElement<XMLGregorianCalendar>(_ClaimStatusEffDate_QNAME, XMLGregorianCalendar.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy", name = "GovtID")
    public JAXBElement<String> createGovtID(String value) {
        return new JAXBElement<String>(_GovtID_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy", name = "FinTransCode")
    public JAXBElement<String> createFinTransCode(String value) {
        return new JAXBElement<String>(_FinTransCode_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}}
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy", name = "LastCOIDate")
    public JAXBElement<XMLGregorianCalendar> createLastCOIDate(XMLGregorianCalendar value) {
        return new JAXBElement<XMLGregorianCalendar>(_LastCOIDate_QNAME, XMLGregorianCalendar.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy", name = "Zip")
    public JAXBElement<String> createZip(String value) {
        return new JAXBElement<String>(_Zip_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy", name = "ShortName")
    public JAXBElement<String> createShortName(String value) {
        return new JAXBElement<String>(_ShortName_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy", name = "AbbrName")
    public JAXBElement<String> createAbbrName(String value) {
        return new JAXBElement<String>(_AbbrName_QNAME, String.class, null, value);
    }

}
