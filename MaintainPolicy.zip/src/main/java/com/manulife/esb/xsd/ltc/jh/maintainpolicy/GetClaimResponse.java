
package com.manulife.esb.xsd.ltc.jh.maintainpolicy;

import javax.xml.bind.annotation.*;


/**
 * <p>Java class for anonymous complex type.
 *
 * <p>The following schema fragment specifies the expected content contained within this class.
 *
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Policy" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element ref="{http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy}PolNumber"/>
 *                   &lt;element ref="{http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy}SubLineOfBusiness" minOccurs="0"/>
 *                   &lt;element ref="{http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy}Claim" minOccurs="0"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
        "policy"
})
@XmlRootElement(name = "GetClaim_response")
public class GetClaimResponse {

    @XmlElement(name = "Policy")
    protected GetClaimResponse.Policy policy;

    /**
     * Gets the value of the policy property.
     *
     * @return possible object is
     * {@link GetClaimResponse.Policy }
     */
    public GetClaimResponse.Policy getPolicy() {
        return policy;
    }

    /**
     * Sets the value of the policy property.
     *
     * @param value allowed object is
     *              {@link GetClaimResponse.Policy }
     */
    public void setPolicy(GetClaimResponse.Policy value) {
        this.policy = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     *
     * <p>The following schema fragment specifies the expected content contained within this class.
     *
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element ref="{http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy}PolNumber"/>
     *         &lt;element ref="{http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy}SubLineOfBusiness" minOccurs="0"/>
     *         &lt;element ref="{http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy}Claim" minOccurs="0"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
            "polNumber",
            "subLineOfBusiness",
            "claim"
    })
    public static class Policy {

        @XmlElement(name = "PolNumber", required = true)
        protected String polNumber;
        @XmlElement(name = "SubLineOfBusiness")
        protected SubLineOfBusiness subLineOfBusiness;
        @XmlElement(name = "Claim")
        protected Claim claim;

        /**
         * Gets the value of the polNumber property.
         *
         * @return possible object is
         * {@link String }
         */
        public String getPolNumber() {
            return polNumber;
        }

        /**
         * Sets the value of the polNumber property.
         *
         * @param value allowed object is
         *              {@link String }
         */
        public void setPolNumber(String value) {
            this.polNumber = value;
        }

        /**
         * Gets the value of the subLineOfBusiness property.
         *
         * @return possible object is
         * {@link SubLineOfBusiness }
         */
        public SubLineOfBusiness getSubLineOfBusiness() {
            return subLineOfBusiness;
        }

        /**
         * Sets the value of the subLineOfBusiness property.
         *
         * @param value allowed object is
         *              {@link SubLineOfBusiness }
         */
        public void setSubLineOfBusiness(SubLineOfBusiness value) {
            this.subLineOfBusiness = value;
        }

        /**
         * Gets the value of the claim property.
         *
         * @return possible object is
         * {@link Claim }
         */
        public Claim getClaim() {
            return claim;
        }

        /**
         * Sets the value of the claim property.
         *
         * @param value allowed object is
         *              {@link Claim }
         */
        public void setClaim(Claim value) {
            this.claim = value;
        }

    }

}
