
package com.manulife.esb.xsd.ltc.jh.maintainpolicy;

import javax.xml.bind.annotation.*;


/**
 * <p>Java class for anonymous complex type.
 *
 * <p>The following schema fragment specifies the expected content contained within this class.
 *
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy}PolNumber"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy}SubLineOfBusiness"/>
 *         &lt;element name="CustomerTypeCode">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;attribute name="tc" type="{http://www.w3.org/2001/XMLSchema}string" />
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
        "polNumber",
        "subLineOfBusiness",
        "customerTypeCode"
})
@XmlRootElement(name = "GetAuthData_request")
public class GetAuthDataRequest {

    @XmlElement(name = "PolNumber", required = true)
    protected String polNumber;
    @XmlElement(name = "SubLineOfBusiness", required = true)
    protected SubLineOfBusiness subLineOfBusiness;
    @XmlElement(name = "CustomerTypeCode", required = true)
    protected GetAuthDataRequest.CustomerTypeCode customerTypeCode;

    /**
     * Gets the value of the polNumber property.
     *
     * @return possible object is
     * {@link String }
     */
    public String getPolNumber() {
        return polNumber;
    }

    /**
     * Sets the value of the polNumber property.
     *
     * @param value allowed object is
     *              {@link String }
     */
    public void setPolNumber(String value) {
        this.polNumber = value;
    }

    /**
     * Gets the value of the subLineOfBusiness property.
     *
     * @return possible object is
     * {@link SubLineOfBusiness }
     */
    public SubLineOfBusiness getSubLineOfBusiness() {
        return subLineOfBusiness;
    }

    /**
     * Sets the value of the subLineOfBusiness property.
     *
     * @param value allowed object is
     *              {@link SubLineOfBusiness }
     */
    public void setSubLineOfBusiness(SubLineOfBusiness value) {
        this.subLineOfBusiness = value;
    }

    /**
     * Gets the value of the customerTypeCode property.
     *
     * @return possible object is
     * {@link GetAuthDataRequest.CustomerTypeCode }
     */
    public GetAuthDataRequest.CustomerTypeCode getCustomerTypeCode() {
        return customerTypeCode;
    }

    /**
     * Sets the value of the customerTypeCode property.
     *
     * @param value allowed object is
     *              {@link GetAuthDataRequest.CustomerTypeCode }
     */
    public void setCustomerTypeCode(GetAuthDataRequest.CustomerTypeCode value) {
        this.customerTypeCode = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     *
     * <p>The following schema fragment specifies the expected content contained within this class.
     *
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;attribute name="tc" type="{http://www.w3.org/2001/XMLSchema}string" />
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "")
    public static class CustomerTypeCode {

        @XmlAttribute(name = "tc")
        protected String tc;

        /**
         * Gets the value of the tc property.
         *
         * @return possible object is
         * {@link String }
         */
        public String getTc() {
            return tc;
        }

        /**
         * Sets the value of the tc property.
         *
         * @param value allowed object is
         *              {@link String }
         */
        public void setTc(String value) {
            this.tc = value;
        }

    }

}
