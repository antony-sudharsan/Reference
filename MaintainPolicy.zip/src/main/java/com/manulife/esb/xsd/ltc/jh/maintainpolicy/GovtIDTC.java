
package com.manulife.esb.xsd.ltc.jh.maintainpolicy;

import javax.xml.bind.annotation.*;


/**
 * <p>Java class for anonymous complex type.
 *
 * <p>The following schema fragment specifies the expected content contained within this class.
 *
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;attribute name="tc" type="{http://www.w3.org/2001/XMLSchema}anySimpleType" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "")
@XmlRootElement(name = "GovtIDTC")
public class GovtIDTC {

    @XmlAttribute(name = "tc")
    @XmlSchemaType(name = "anySimpleType")
    protected String tc;

    /**
     * Gets the value of the tc property.
     *
     * @return possible object is
     * {@link String }
     */
    public String getTc() {
        return tc;
    }

    /**
     * Sets the value of the tc property.
     *
     * @param value allowed object is
     *              {@link String }
     */
    public void setTc(String value) {
        this.tc = value;
    }

}
