
package com.manulife.esb.xsd.ltc.jh.maintainpolicy;

import javax.xml.bind.annotation.*;


/**
 * <p>Java class for anonymous complex type.
 *
 * <p>The following schema fragment specifies the expected content contained within this class.
 *
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Policy" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element ref="{http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy}PolNumber"/>
 *                   &lt;element ref="{http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy}CertificateNo"/>
 *                   &lt;element ref="{http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy}SubLineOfBusiness" minOccurs="0"/>
 *                   &lt;element ref="{http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy}PolicyStatus"/>
 *                   &lt;element ref="{http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy}Insured"/>
 *                   &lt;element ref="{http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy}Client" minOccurs="0"/>
 *                   &lt;element name="Claim" minOccurs="0">
 *                     &lt;complexType>
 *                       &lt;complexContent>
 *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                           &lt;sequence>
 *                             &lt;element ref="{http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy}ClaimNumber" minOccurs="0"/>
 *                             &lt;element ref="{http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy}ClaimStatus" minOccurs="0"/>
 *                           &lt;/sequence>
 *                         &lt;/restriction>
 *                       &lt;/complexContent>
 *                     &lt;/complexType>
 *                   &lt;/element>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
        "policy"
})
@XmlRootElement(name = "GetAuthData_response")
public class GetAuthDataResponse {

    @XmlElement(name = "Policy")
    protected GetAuthDataResponse.Policy policy;

    /**
     * Gets the value of the policy property.
     *
     * @return possible object is
     * {@link GetAuthDataResponse.Policy }
     */
    public GetAuthDataResponse.Policy getPolicy() {
        return policy;
    }

    /**
     * Sets the value of the policy property.
     *
     * @param value allowed object is
     *              {@link GetAuthDataResponse.Policy }
     */
    public void setPolicy(GetAuthDataResponse.Policy value) {
        this.policy = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     *
     * <p>The following schema fragment specifies the expected content contained within this class.
     *
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element ref="{http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy}PolNumber"/>
     *         &lt;element ref="{http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy}CertificateNo"/>
     *         &lt;element ref="{http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy}SubLineOfBusiness" minOccurs="0"/>
     *         &lt;element ref="{http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy}PolicyStatus"/>
     *         &lt;element ref="{http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy}Insured"/>
     *         &lt;element ref="{http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy}Client" minOccurs="0"/>
     *         &lt;element name="Claim" minOccurs="0">
     *           &lt;complexType>
     *             &lt;complexContent>
     *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *                 &lt;sequence>
     *                   &lt;element ref="{http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy}ClaimNumber" minOccurs="0"/>
     *                   &lt;element ref="{http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy}ClaimStatus" minOccurs="0"/>
     *                 &lt;/sequence>
     *               &lt;/restriction>
     *             &lt;/complexContent>
     *           &lt;/complexType>
     *         &lt;/element>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
            "polNumber",
            "certificateNo",
            "subLineOfBusiness",
            "policyStatus",
            "insured",
            "client",
            "claim"
    })
    public static class Policy {

        @XmlElement(name = "PolNumber", required = true)
        protected String polNumber;
        @XmlElement(name = "CertificateNo", required = true)
        protected String certificateNo;
        @XmlElement(name = "SubLineOfBusiness")
        protected SubLineOfBusiness subLineOfBusiness;
        @XmlElement(name = "PolicyStatus", required = true)
        protected PolicyStatus policyStatus;
        @XmlElement(name = "Insured", required = true)
        protected Insured insured;
        @XmlElement(name = "Client")
        protected Client client;
        @XmlElement(name = "Claim")
        protected GetAuthDataResponse.Policy.Claim claim;

        /**
         * Gets the value of the polNumber property.
         *
         * @return possible object is
         * {@link String }
         */
        public String getPolNumber() {
            return polNumber;
        }

        /**
         * Sets the value of the polNumber property.
         *
         * @param value allowed object is
         *              {@link String }
         */
        public void setPolNumber(String value) {
            this.polNumber = value;
        }

        /**
         * Gets the value of the certificateNo property.
         *
         * @return possible object is
         * {@link String }
         */
        public String getCertificateNo() {
            return certificateNo;
        }

        /**
         * Sets the value of the certificateNo property.
         *
         * @param value allowed object is
         *              {@link String }
         */
        public void setCertificateNo(String value) {
            this.certificateNo = value;
        }

        /**
         * Gets the value of the subLineOfBusiness property.
         *
         * @return possible object is
         * {@link SubLineOfBusiness }
         */
        public SubLineOfBusiness getSubLineOfBusiness() {
            return subLineOfBusiness;
        }

        /**
         * Sets the value of the subLineOfBusiness property.
         *
         * @param value allowed object is
         *              {@link SubLineOfBusiness }
         */
        public void setSubLineOfBusiness(SubLineOfBusiness value) {
            this.subLineOfBusiness = value;
        }

        /**
         * Gets the value of the policyStatus property.
         *
         * @return possible object is
         * {@link PolicyStatus }
         */
        public PolicyStatus getPolicyStatus() {
            return policyStatus;
        }

        /**
         * Sets the value of the policyStatus property.
         *
         * @param value allowed object is
         *              {@link PolicyStatus }
         */
        public void setPolicyStatus(PolicyStatus value) {
            this.policyStatus = value;
        }

        /**
         * Gets the value of the insured property.
         *
         * @return possible object is
         * {@link Insured }
         */
        public Insured getInsured() {
            return insured;
        }

        /**
         * Sets the value of the insured property.
         *
         * @param value allowed object is
         *              {@link Insured }
         */
        public void setInsured(Insured value) {
            this.insured = value;
        }

        /**
         * Gets the value of the client property.
         *
         * @return possible object is
         * {@link Client }
         */
        public Client getClient() {
            return client;
        }

        /**
         * Sets the value of the client property.
         *
         * @param value allowed object is
         *              {@link Client }
         */
        public void setClient(Client value) {
            this.client = value;
        }

        /**
         * Gets the value of the claim property.
         *
         * @return possible object is
         * {@link GetAuthDataResponse.Policy.Claim }
         */
        public GetAuthDataResponse.Policy.Claim getClaim() {
            return claim;
        }

        /**
         * Sets the value of the claim property.
         *
         * @param value allowed object is
         *              {@link GetAuthDataResponse.Policy.Claim }
         */
        public void setClaim(GetAuthDataResponse.Policy.Claim value) {
            this.claim = value;
        }


        /**
         * <p>Java class for anonymous complex type.
         *
         * <p>The following schema fragment specifies the expected content contained within this class.
         *
         * <pre>
         * &lt;complexType>
         *   &lt;complexContent>
         *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
         *       &lt;sequence>
         *         &lt;element ref="{http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy}ClaimNumber" minOccurs="0"/>
         *         &lt;element ref="{http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy}ClaimStatus" minOccurs="0"/>
         *       &lt;/sequence>
         *     &lt;/restriction>
         *   &lt;/complexContent>
         * &lt;/complexType>
         * </pre>
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "", propOrder = {
                "claimNumber",
                "claimStatus"
        })
        public static class Claim {

            @XmlElement(name = "ClaimNumber")
            protected String claimNumber;
            @XmlElement(name = "ClaimStatus")
            protected ClaimStatus claimStatus;

            /**
             * Map to HOClaimReferenceID
             *
             * @return possible object is
             * {@link String }
             */
            public String getClaimNumber() {
                return claimNumber;
            }

            /**
             * Sets the value of the claimNumber property.
             *
             * @param value allowed object is
             *              {@link String }
             */
            public void setClaimNumber(String value) {
                this.claimNumber = value;
            }

            /**
             * Gets the value of the claimStatus property.
             *
             * @return possible object is
             * {@link ClaimStatus }
             */
            public ClaimStatus getClaimStatus() {
                return claimStatus;
            }

            /**
             * Sets the value of the claimStatus property.
             *
             * @param value allowed object is
             *              {@link ClaimStatus }
             */
            public void setClaimStatus(ClaimStatus value) {
                this.claimStatus = value;
            }

        }

    }

}
