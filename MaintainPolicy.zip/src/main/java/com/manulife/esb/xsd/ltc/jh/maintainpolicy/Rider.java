
package com.manulife.esb.xsd.ltc.jh.maintainpolicy;

import javax.xml.bind.annotation.*;


/**
 * <p>Java class for anonymous complex type.
 *
 * <p>The following schema fragment specifies the expected content contained within this class.
 *
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy}ShortName"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
        "shortName"
})
@XmlRootElement(name = "Rider")
public class Rider {

    @XmlElement(name = "ShortName", required = true)
    protected String shortName;

    /**
     * Gets the value of the shortName property.
     *
     * @return possible object is
     * {@link String }
     */
    public String getShortName() {
        return shortName;
    }

    /**
     * Sets the value of the shortName property.
     *
     * @param value allowed object is
     *              {@link String }
     */
    public void setShortName(String value) {
        this.shortName = value;
    }

}
