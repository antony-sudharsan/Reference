
package com.manulife.esb.xsd.ltc.jh.maintainpolicy;

import javax.xml.bind.annotation.*;
import javax.xml.datatype.XMLGregorianCalendar;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;


/**
 * <p>Java class for anonymous complex type.
 *
 * <p>The following schema fragment specifies the expected content contained within this class.
 *
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Policy" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element ref="{http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy}PolNumber"/>
 *                   &lt;element ref="{http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy}PolicyStatus"/>
 *                   &lt;element ref="{http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy}SubLineOfBusiness" minOccurs="0"/>
 *                   &lt;element name="CarrierAdminSystem" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                   &lt;element ref="{http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy}EffDate" minOccurs="0"/>
 *                   &lt;element ref="{http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy}PaymentMode" minOccurs="0"/>
 *                   &lt;element ref="{http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy}PaymentMethod" minOccurs="0"/>
 *                   &lt;element ref="{http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy}BillingStatus" minOccurs="0"/>
 *                   &lt;element ref="{http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy}BillingFreezeCode" minOccurs="0"/>
 *                   &lt;element ref="{http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy}FinTransCode" minOccurs="0"/>
 *                   &lt;element ref="{http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy}PaymentAmt" minOccurs="0"/>
 *                   &lt;element ref="{http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy}LastCOIDate" minOccurs="0"/>
 *                   &lt;element ref="{http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy}PaidToDate" minOccurs="0"/>
 *                   &lt;element ref="{http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy}PaymentDueDate" minOccurs="0"/>
 *                   &lt;element ref="{http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy}PaymentDebitCode" minOccurs="0"/>
 *                   &lt;element ref="{http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy}PaymentCreditCode" minOccurs="0"/>
 *                   &lt;element ref="{http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy}Rider" maxOccurs="unbounded" minOccurs="0"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
        "policy"
})
@XmlRootElement(name = "GetPolicy_response")
public class GetPolicyResponse {

    @XmlElement(name = "Policy")
    protected GetPolicyResponse.Policy policy;

    /**
     * Gets the value of the policy property.
     *
     * @return possible object is
     * {@link GetPolicyResponse.Policy }
     */
    public GetPolicyResponse.Policy getPolicy() {
        return policy;
    }

    /**
     * Sets the value of the policy property.
     *
     * @param value allowed object is
     *              {@link GetPolicyResponse.Policy }
     */
    public void setPolicy(GetPolicyResponse.Policy value) {
        this.policy = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     *
     * <p>The following schema fragment specifies the expected content contained within this class.
     *
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element ref="{http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy}PolNumber"/>
     *         &lt;element ref="{http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy}PolicyStatus"/>
     *         &lt;element ref="{http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy}SubLineOfBusiness" minOccurs="0"/>
     *         &lt;element name="CarrierAdminSystem" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *         &lt;element ref="{http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy}EffDate" minOccurs="0"/>
     *         &lt;element ref="{http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy}PaymentMode" minOccurs="0"/>
     *         &lt;element ref="{http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy}PaymentMethod" minOccurs="0"/>
     *         &lt;element ref="{http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy}BillingStatus" minOccurs="0"/>
     *         &lt;element ref="{http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy}BillingFreezeCode" minOccurs="0"/>
     *         &lt;element ref="{http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy}FinTransCode" minOccurs="0"/>
     *         &lt;element ref="{http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy}PaymentAmt" minOccurs="0"/>
     *         &lt;element ref="{http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy}LastCOIDate" minOccurs="0"/>
     *         &lt;element ref="{http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy}PaidToDate" minOccurs="0"/>
     *         &lt;element ref="{http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy}PaymentDueDate" minOccurs="0"/>
     *         &lt;element ref="{http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy}PaymentDebitCode" minOccurs="0"/>
     *         &lt;element ref="{http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy}PaymentCreditCode" minOccurs="0"/>
     *         &lt;element ref="{http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy}Rider" maxOccurs="unbounded" minOccurs="0"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
            "polNumber",
            "policyStatus",
            "subLineOfBusiness",
            "carrierAdminSystem",
            "effDate",
            "paymentMode",
            "paymentMethod",
            "billingStatus",
            "billingFreezeCode",
            "finTransCode",
            "paymentAmt",
            "lastCOIDate",
            "paidToDate",
            "paymentDueDate",
            "paymentDebitCode",
            "paymentCreditCode",
            "rider"
    })
    public static class Policy {

        @XmlElement(name = "PolNumber", required = true)
        protected String polNumber;
        @XmlElement(name = "PolicyStatus", required = true)
        protected PolicyStatus policyStatus;
        @XmlElement(name = "SubLineOfBusiness")
        protected SubLineOfBusiness subLineOfBusiness;
        @XmlElement(name = "CarrierAdminSystem")
        protected String carrierAdminSystem;
        @XmlElement(name = "EffDate")
        @XmlSchemaType(name = "dateTime")
        protected XMLGregorianCalendar effDate;
        @XmlElement(name = "PaymentMode")
        protected PaymentMode paymentMode;
        @XmlElement(name = "PaymentMethod")
        protected PaymentMethod paymentMethod;
        @XmlElement(name = "BillingStatus")
        protected BillingStatus billingStatus;
        @XmlElement(name = "BillingFreezeCode")
        protected String billingFreezeCode;
        @XmlElement(name = "FinTransCode")
        protected String finTransCode;
        @XmlElement(name = "PaymentAmt")
        protected BigDecimal paymentAmt;
        @XmlElement(name = "LastCOIDate")
        @XmlSchemaType(name = "dateTime")
        protected XMLGregorianCalendar lastCOIDate;
        @XmlElement(name = "PaidToDate")
        @XmlSchemaType(name = "dateTime")
        protected XMLGregorianCalendar paidToDate;
        @XmlElement(name = "PaymentDueDate")
        @XmlSchemaType(name = "dateTime")
        protected XMLGregorianCalendar paymentDueDate;
        @XmlElement(name = "PaymentDebitCode")
        protected String paymentDebitCode;
        @XmlElement(name = "PaymentCreditCode")
        protected String paymentCreditCode;

        public void setRider(List<Rider> rider) {
            this.rider = rider;
        }

        @XmlElement(name = "Rider")
        protected List<Rider> rider;

        /**
         * Gets the value of the polNumber property.
         *
         * @return possible object is
         * {@link String }
         */
        public String getPolNumber() {
            return polNumber;
        }

        /**
         * Sets the value of the polNumber property.
         *
         * @param value allowed object is
         *              {@link String }
         */
        public void setPolNumber(String value) {
            this.polNumber = value;
        }

        /**
         * Gets the value of the policyStatus property.
         *
         * @return possible object is
         * {@link PolicyStatus }
         */
        public PolicyStatus getPolicyStatus() {
            return policyStatus;
        }

        /**
         * Sets the value of the policyStatus property.
         *
         * @param value allowed object is
         *              {@link PolicyStatus }
         */
        public void setPolicyStatus(PolicyStatus value) {
            this.policyStatus = value;
        }

        /**
         * Gets the value of the subLineOfBusiness property.
         *
         * @return possible object is
         * {@link SubLineOfBusiness }
         */
        public SubLineOfBusiness getSubLineOfBusiness() {
            return subLineOfBusiness;
        }

        /**
         * Sets the value of the subLineOfBusiness property.
         *
         * @param value allowed object is
         *              {@link SubLineOfBusiness }
         */
        public void setSubLineOfBusiness(SubLineOfBusiness value) {
            this.subLineOfBusiness = value;
        }

        /**
         * Gets the value of the carrierAdminSystem property.
         *
         * @return possible object is
         * {@link String }
         */
        public String getCarrierAdminSystem() {
            return carrierAdminSystem;
        }

        /**
         * Sets the value of the carrierAdminSystem property.
         *
         * @param value allowed object is
         *              {@link String }
         */
        public void setCarrierAdminSystem(String value) {
            this.carrierAdminSystem = value;
        }

        /**
         * Gets the value of the effDate property.
         *
         * @return possible object is
         * {@link XMLGregorianCalendar }
         */
        public XMLGregorianCalendar getEffDate() {
            return effDate;
        }

        /**
         * Sets the value of the effDate property.
         *
         * @param value allowed object is
         *              {@link XMLGregorianCalendar }
         */
        public void setEffDate(XMLGregorianCalendar value) {
            this.effDate = value;
        }

        /**
         * Gets the value of the paymentMode property.
         *
         * @return possible object is
         * {@link PaymentMode }
         */
        public PaymentMode getPaymentMode() {
            return paymentMode;
        }

        /**
         * Sets the value of the paymentMode property.
         *
         * @param value allowed object is
         *              {@link PaymentMode }
         */
        public void setPaymentMode(PaymentMode value) {
            this.paymentMode = value;
        }

        /**
         * Gets the value of the paymentMethod property.
         *
         * @return possible object is
         * {@link PaymentMethod }
         */
        public PaymentMethod getPaymentMethod() {
            return paymentMethod;
        }

        /**
         * Sets the value of the paymentMethod property.
         *
         * @param value allowed object is
         *              {@link PaymentMethod }
         */
        public void setPaymentMethod(PaymentMethod value) {
            this.paymentMethod = value;
        }

        /**
         * Gets the value of the billingStatus property.
         *
         * @return possible object is
         * {@link BillingStatus }
         */
        public BillingStatus getBillingStatus() {
            return billingStatus;
        }

        /**
         * Sets the value of the billingStatus property.
         *
         * @param value allowed object is
         *              {@link BillingStatus }
         */
        public void setBillingStatus(BillingStatus value) {
            this.billingStatus = value;
        }

        /**
         * Gets the value of the billingFreezeCode property.
         *
         * @return possible object is
         * {@link String }
         */
        public String getBillingFreezeCode() {
            return billingFreezeCode;
        }

        /**
         * Sets the value of the billingFreezeCode property.
         *
         * @param value allowed object is
         *              {@link String }
         */
        public void setBillingFreezeCode(String value) {
            this.billingFreezeCode = value;
        }

        /**
         * FT02 = Direct/ABW Payment;
         * FT09 = Waived Premium;
         * FT10 = Admin Credit;
         * FT11 = Reversal;
         * FT14 = Bounce/ABW kickout;
         * FT18 = Money moved Trust to non-Trust for conversion/payment;
         * FT19 = Money moved non-Trust to Trust for conversion/payment;
         *
         * @return possible object is
         * {@link String }
         */
        public String getFinTransCode() {
            return finTransCode;
        }

        /**
         * Sets the value of the finTransCode property.
         *
         * @param value allowed object is
         *              {@link String }
         */
        public void setFinTransCode(String value) {
            this.finTransCode = value;
        }

        /**
         * Gets the value of the paymentAmt property.
         *
         * @return possible object is
         * {@link BigDecimal }
         */
        public BigDecimal getPaymentAmt() {
            return paymentAmt;
        }

        /**
         * Sets the value of the paymentAmt property.
         *
         * @param value allowed object is
         *              {@link BigDecimal }
         */
        public void setPaymentAmt(BigDecimal value) {
            this.paymentAmt = value;
        }

        /**
         * Gets the value of the lastCOIDate property.
         *
         * @return possible object is
         * {@link XMLGregorianCalendar }
         */
        public XMLGregorianCalendar getLastCOIDate() {
            return lastCOIDate;
        }

        /**
         * Sets the value of the lastCOIDate property.
         *
         * @param value allowed object is
         *              {@link XMLGregorianCalendar }
         */
        public void setLastCOIDate(XMLGregorianCalendar value) {
            this.lastCOIDate = value;
        }

        /**
         * Gets the value of the paidToDate property.
         *
         * @return possible object is
         * {@link XMLGregorianCalendar }
         */
        public XMLGregorianCalendar getPaidToDate() {
            return paidToDate;
        }

        /**
         * Sets the value of the paidToDate property.
         *
         * @param value allowed object is
         *              {@link XMLGregorianCalendar }
         */
        public void setPaidToDate(XMLGregorianCalendar value) {
            this.paidToDate = value;
        }

        /**
         * Gets the value of the paymentDueDate property.
         *
         * @return possible object is
         * {@link XMLGregorianCalendar }
         */
        public XMLGregorianCalendar getPaymentDueDate() {
            return paymentDueDate;
        }

        /**
         * Sets the value of the paymentDueDate property.
         *
         * @param value allowed object is
         *              {@link XMLGregorianCalendar }
         */
        public void setPaymentDueDate(XMLGregorianCalendar value) {
            this.paymentDueDate = value;
        }

        /**
         * Gets the value of the paymentDebitCode property.
         *
         * @return possible object is
         * {@link String }
         */
        public String getPaymentDebitCode() {
            return paymentDebitCode;
        }

        /**
         * Sets the value of the paymentDebitCode property.
         *
         * @param value allowed object is
         *              {@link String }
         */
        public void setPaymentDebitCode(String value) {
            this.paymentDebitCode = value;
        }

        /**
         * Gets the value of the paymentCreditCode property.
         *
         * @return possible object is
         * {@link String }
         */
        public String getPaymentCreditCode() {
            return paymentCreditCode;
        }

        /**
         * Sets the value of the paymentCreditCode property.
         *
         * @param value allowed object is
         *              {@link String }
         */
        public void setPaymentCreditCode(String value) {
            this.paymentCreditCode = value;
        }

        /**
         * Gets the value of the rider property.
         * <p>
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the rider property.
         * <p>
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getRider().add(newItem);
         * </pre>
         * <p>
         * <p>
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link Rider }
         */
        public List<Rider> getRider() {
            if (rider == null) {
                rider = new ArrayList<Rider>();
            }
            return this.rider;
        }

    }

}
