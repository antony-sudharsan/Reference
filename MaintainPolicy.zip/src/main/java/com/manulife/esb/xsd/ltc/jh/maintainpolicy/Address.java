
package com.manulife.esb.xsd.ltc.jh.maintainpolicy;

import javax.xml.bind.annotation.*;


/**
 * <p>Java class for anonymous complex type.
 *
 * <p>The following schema fragment specifies the expected content contained within this class.
 *
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy}Line1"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy}Line2" minOccurs="0"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy}Line3" minOccurs="0"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy}City"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy}State"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy}Zip"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
        "line1",
        "line2",
        "line3",
        "city",
        "state",
        "zip"
})
@XmlRootElement(name = "Address")
public class Address {

    @XmlElement(name = "Line1", required = true)
    protected String line1;
    @XmlElement(name = "Line2")
    protected String line2;
    @XmlElement(name = "Line3")
    protected String line3;
    @XmlElement(name = "City", required = true)
    protected String city;
    @XmlElement(name = "State", required = true)
    protected String state;
    @XmlElement(name = "Zip", required = true)
    protected String zip;

    /**
     * Gets the value of the line1 property.
     *
     * @return possible object is
     * {@link String }
     */
    public String getLine1() {
        return line1;
    }

    /**
     * Sets the value of the line1 property.
     *
     * @param value allowed object is
     *              {@link String }
     */
    public void setLine1(String value) {
        this.line1 = value;
    }

    /**
     * Gets the value of the line2 property.
     *
     * @return possible object is
     * {@link String }
     */
    public String getLine2() {
        return line2;
    }

    /**
     * Sets the value of the line2 property.
     *
     * @param value allowed object is
     *              {@link String }
     */
    public void setLine2(String value) {
        this.line2 = value;
    }

    /**
     * Gets the value of the line3 property.
     *
     * @return possible object is
     * {@link String }
     */
    public String getLine3() {
        return line3;
    }

    /**
     * Sets the value of the line3 property.
     *
     * @param value allowed object is
     *              {@link String }
     */
    public void setLine3(String value) {
        this.line3 = value;
    }

    /**
     * Gets the value of the city property.
     *
     * @return possible object is
     * {@link String }
     */
    public String getCity() {
        return city;
    }

    /**
     * Sets the value of the city property.
     *
     * @param value allowed object is
     *              {@link String }
     */
    public void setCity(String value) {
        this.city = value;
    }

    /**
     * Gets the value of the state property.
     *
     * @return possible object is
     * {@link String }
     */
    public String getState() {
        return state;
    }

    /**
     * Sets the value of the state property.
     *
     * @param value allowed object is
     *              {@link String }
     */
    public void setState(String value) {
        this.state = value;
    }

    /**
     * Gets the value of the zip property.
     *
     * @return possible object is
     * {@link String }
     */
    public String getZip() {
        return zip;
    }

    /**
     * Sets the value of the zip property.
     *
     * @param value allowed object is
     *              {@link String }
     */
    public void setZip(String value) {
        this.zip = value;
    }

}
