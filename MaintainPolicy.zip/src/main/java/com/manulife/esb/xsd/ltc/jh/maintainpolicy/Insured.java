
package com.manulife.esb.xsd.ltc.jh.maintainpolicy;

import javax.xml.bind.annotation.*;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for anonymous complex type.
 *
 * <p>The following schema fragment specifies the expected content contained within this class.
 *
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy}PersonSysKey"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy}GovtID"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy}GovtIDTC" minOccurs="0"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy}BirthDate" minOccurs="0"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy}Prefix" minOccurs="0"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy}FirstName"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy}LastName"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy}MiddleName" minOccurs="0"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy}Suffix" minOccurs="0"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/LTC/jh/MaintainPolicy}Address"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
        "personSysKey",
        "govtID",
        "govtIDTC",
        "birthDate",
        "prefix",
        "firstName",
        "lastName",
        "middleName",
        "suffix",
        "address"
})
@XmlRootElement(name = "Insured")
public class Insured {

    @XmlElement(name = "PersonSysKey", required = true)
    protected String personSysKey;
    @XmlElement(name = "GovtID", required = true)
    protected String govtID;
    @XmlElement(name = "GovtIDTC")
    protected GovtIDTC govtIDTC;
    @XmlElement(name = "BirthDate")
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar birthDate;
    @XmlElement(name = "Prefix")
    protected String prefix;
    @XmlElement(name = "FirstName", required = true)
    protected String firstName;
    @XmlElement(name = "LastName", required = true)
    protected String lastName;
    @XmlElement(name = "MiddleName")
    protected String middleName;
    @XmlElement(name = "Suffix")
    protected String suffix;
    @XmlElement(name = "Address", required = true)
    protected Address address;

    /**
     * Gets the value of the personSysKey property.
     *
     * @return possible object is
     * {@link String }
     */
    public String getPersonSysKey() {
        return personSysKey;
    }

    /**
     * Sets the value of the personSysKey property.
     *
     * @param value allowed object is
     *              {@link String }
     */
    public void setPersonSysKey(String value) {
        this.personSysKey = value;
    }

    /**
     * Gets the value of the govtID property.
     *
     * @return possible object is
     * {@link String }
     */
    public String getGovtID() {
        return govtID;
    }

    /**
     * Sets the value of the govtID property.
     *
     * @param value allowed object is
     *              {@link String }
     */
    public void setGovtID(String value) {
        this.govtID = value;
    }

    /**
     * Gets the value of the govtIDTC property.
     *
     * @return possible object is
     * {@link GovtIDTC }
     */
    public GovtIDTC getGovtIDTC() {
        return govtIDTC;
    }

    /**
     * Sets the value of the govtIDTC property.
     *
     * @param value allowed object is
     *              {@link GovtIDTC }
     */
    public void setGovtIDTC(GovtIDTC value) {
        this.govtIDTC = value;
    }

    /**
     * Gets the value of the birthDate property.
     *
     * @return possible object is
     * {@link XMLGregorianCalendar }
     */
    public XMLGregorianCalendar getBirthDate() {
        return birthDate;
    }

    /**
     * Sets the value of the birthDate property.
     *
     * @param value allowed object is
     *              {@link XMLGregorianCalendar }
     */
    public void setBirthDate(XMLGregorianCalendar value) {
        this.birthDate = value;
    }

    /**
     * Gets the value of the prefix property.
     *
     * @return possible object is
     * {@link String }
     */
    public String getPrefix() {
        return prefix;
    }

    /**
     * Sets the value of the prefix property.
     *
     * @param value allowed object is
     *              {@link String }
     */
    public void setPrefix(String value) {
        this.prefix = value;
    }

    /**
     * Gets the value of the firstName property.
     *
     * @return possible object is
     * {@link String }
     */
    public String getFirstName() {
        return firstName;
    }

    /**
     * Sets the value of the firstName property.
     *
     * @param value allowed object is
     *              {@link String }
     */
    public void setFirstName(String value) {
        this.firstName = value;
    }

    /**
     * Gets the value of the lastName property.
     *
     * @return possible object is
     * {@link String }
     */
    public String getLastName() {
        return lastName;
    }

    /**
     * Sets the value of the lastName property.
     *
     * @param value allowed object is
     *              {@link String }
     */
    public void setLastName(String value) {
        this.lastName = value;
    }

    /**
     * Gets the value of the middleName property.
     *
     * @return possible object is
     * {@link String }
     */
    public String getMiddleName() {
        return middleName;
    }

    /**
     * Sets the value of the middleName property.
     *
     * @param value allowed object is
     *              {@link String }
     */
    public void setMiddleName(String value) {
        this.middleName = value;
    }

    /**
     * Gets the value of the suffix property.
     *
     * @return possible object is
     * {@link String }
     */
    public String getSuffix() {
        return suffix;
    }

    /**
     * Sets the value of the suffix property.
     *
     * @param value allowed object is
     *              {@link String }
     */
    public void setSuffix(String value) {
        this.suffix = value;
    }

    /**
     * Gets the value of the address property.
     *
     * @return possible object is
     * {@link Address }
     */
    public Address getAddress() {
        return address;
    }

    /**
     * Sets the value of the address property.
     *
     * @param value allowed object is
     *              {@link Address }
     */
    public void setAddress(Address value) {
        this.address = value;
    }

}
