# Maintain Policy  Design Document
## Introduction
    This document defines the service specification for SOA components making up the MaintainPolicy service for John Hancock LTC.
    This service supports operations related to MaintainPolicy. The operations currently specified are:  

1. GetClaim
2. GetPolicy
3. GetAuthData

## REST Operations
|Operation|URI|Method|
|---|:---:|---:|
|GetClaim|/jh/ins/ltc/datamart/claim|POST|
|GetPolicy  |/jh/ins/ltc/datamart/policy|POST|
|GetAuthData|//jh/ins/ltc/datamart/authdata|POST|

# SOAP Endpoint URL
Operation|URI|Local Part|
---|---|---|
GetClaim|https://maintainpolicy-dev.apps.cac.preview.pcf.manulife.com/|GetClaim_request|
GetPolicy|https://maintainpolicy-dev.apps.cac.preview.pcf.manulife.com/|GetPolicy_request|
GetAuthData|https://maintainpolicy-dev.apps.cac.preview.pcf.manulife.com/|GetAuthData_request|

## Swagger URL
https://jhfnmaintainproduceragreement-dev.apps.cac.preview.pcf.manulife.com/swagger-ui.html

## Audit Point
No|Reference Interpretation
---|---
1|Data received From Input
2|Data Sent to End System
3|Data Output received from End System
4|Data sent back to Output

## HTTP Error Codes
# For REST Service
Error Code|Error Description
---|---
200|Success
408|Request Timeout 
417|Max Records (Search only)       
500|Technical Error
400|Invalid Input, Bad Request of Validation Failed.
404|Record not found 

# For SOAP Service
Code|Reason|Detail
---|---|---
999|No Data Found|No Data Found based on criteria
993|Invalid Input|Invalid information entered for input.
998|[] records found, refine search criteria|[] records found, it is greater than user maximum input of []
9999|Technical Error|Stacktrace Message
99999|Service Timed Out|Service Timed Out


## Notes
To run locally, set profile to **local** and ensure the following environment variables are defined:
- datasourceurl
- dbusername
- dbpassword
