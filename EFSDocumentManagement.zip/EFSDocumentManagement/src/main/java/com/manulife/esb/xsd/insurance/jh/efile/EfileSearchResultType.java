
package com.manulife.esb.xsd.insurance.jh.efile;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for EfileSearchResult_Type complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="EfileSearchResult_Type">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/insurance/jh/Efile}EfileId" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/insurance/jh/Efile}EfileTag" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/insurance/jh/Efile}KeyedValue" maxOccurs="unbounded"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "EfileSearchResult_Type", propOrder = {
    "efileId",
    "efileTag",
    "keyedValue"
})
public class EfileSearchResultType {

    @XmlElement(name = "EfileId")
    protected List<String> efileId;
    @XmlElement(name = "EfileTag")
    protected List<String> efileTag;
    @XmlElement(name = "KeyedValue", required = true)
    protected List<KeyedValueType> keyedValue;

    /**
     * Gets the value of the efileId property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the efileId property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getEfileId().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getEfileId() {
        if (efileId == null) {
            efileId = new ArrayList<String>();
        }
        return this.efileId;
    }

    /**
     * Gets the value of the efileTag property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the efileTag property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getEfileTag().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getEfileTag() {
        if (efileTag == null) {
            efileTag = new ArrayList<String>();
        }
        return this.efileTag;
    }

    /**
     * Gets the value of the keyedValue property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the keyedValue property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getKeyedValue().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link KeyedValueType }
     * 
     * 
     */
    public List<KeyedValueType> getKeyedValue() {
        if (keyedValue == null) {
            keyedValue = new ArrayList<KeyedValueType>();
        }
        return this.keyedValue;
    }

}
