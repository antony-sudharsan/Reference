
package com.manulife.esb.xsd.insurance.jh.efile;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.manulife.esb.xsd.insurance.jh.efile package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _APPPassword_QNAME = new QName("http://www.esb.manulife.com/xsd/insurance/jh/Efile", "APP-Password");
    private final static QName _EfileSearchCriteria_QNAME = new QName("http://www.esb.manulife.com/xsd/insurance/jh/Efile", "EfileSearchCriteria");
    private final static QName _KeyName_QNAME = new QName("http://www.esb.manulife.com/xsd/insurance/jh/Efile", "KeyName");
    private final static QName _APPUserID_QNAME = new QName("http://www.esb.manulife.com/xsd/insurance/jh/Efile", "APP-UserID");
    private final static QName _KeyedValue_QNAME = new QName("http://www.esb.manulife.com/xsd/insurance/jh/Efile", "KeyedValue");
    private final static QName _EfileTag_QNAME = new QName("http://www.esb.manulife.com/xsd/insurance/jh/Efile", "EfileTag");
    private final static QName _APPResponseHeader_QNAME = new QName("http://www.esb.manulife.com/xsd/insurance/jh/Efile", "APP-ResponseHeader");
    private final static QName _EfileId_QNAME = new QName("http://www.esb.manulife.com/xsd/insurance/jh/Efile", "EfileId");
    private final static QName _APPSessionID_QNAME = new QName("http://www.esb.manulife.com/xsd/insurance/jh/Efile", "APP-SessionID");
    private final static QName _APPAuthentication_QNAME = new QName("http://www.esb.manulife.com/xsd/insurance/jh/Efile", "APP-Authentication");
    private final static QName _EfileSearchResult_QNAME = new QName("http://www.esb.manulife.com/xsd/insurance/jh/Efile", "EfileSearchResult");
    private final static QName _EfileSearchResults_QNAME = new QName("http://www.esb.manulife.com/xsd/insurance/jh/Efile", "EfileSearchResults");
    private final static QName _KeyValue_QNAME = new QName("http://www.esb.manulife.com/xsd/insurance/jh/Efile", "KeyValue");
    private final static QName _Document_QNAME = new QName("http://www.esb.manulife.com/xsd/insurance/jh/Efile", "Document");
    private final static QName _DocumentId_QNAME = new QName("http://www.esb.manulife.com/xsd/insurance/jh/Efile", "DocumentId");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.manulife.esb.xsd.insurance.jh.efile
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link UpdateDocumentMetadataFault }
     * 
     */
    public UpdateDocumentMetadataFault createUpdateDocumentMetadataFault() {
        return new UpdateDocumentMetadataFault();
    }

    /**
     * Create an instance of {@link SearchDocumentMetadataRequest }
     * 
     */
    public SearchDocumentMetadataRequest createSearchDocumentMetadataRequest() {
        return new SearchDocumentMetadataRequest();
    }

    /**
     * Create an instance of {@link EfileSearchCriteriaType }
     * 
     */
    public EfileSearchCriteriaType createEfileSearchCriteriaType() {
        return new EfileSearchCriteriaType();
    }

    /**
     * Create an instance of {@link EfileSearchResultsType }
     * 
     */
    public EfileSearchResultsType createEfileSearchResultsType() {
        return new EfileSearchResultsType();
    }

    /**
     * Create an instance of {@link KeyedValueType }
     * 
     */
    public KeyedValueType createKeyedValueType() {
        return new KeyedValueType();
    }

    /**
     * Create an instance of {@link SearchDocumentMetadataFault }
     * 
     */
    public SearchDocumentMetadataFault createSearchDocumentMetadataFault() {
        return new SearchDocumentMetadataFault();
    }

    /**
     * Create an instance of {@link DocumentType }
     * 
     */
    public DocumentType createDocumentType() {
        return new DocumentType();
    }

    /**
     * Create an instance of {@link APPResponseHeaderType }
     * 
     */
    public APPResponseHeaderType createAPPResponseHeaderType() {
        return new APPResponseHeaderType();
    }

    /**
     * Create an instance of {@link APPAuthenticationType }
     * 
     */
    public APPAuthenticationType createAPPAuthenticationType() {
        return new APPAuthenticationType();
    }

    /**
     * Create an instance of {@link UpdateDocumentMetadataResponse }
     * 
     */
    public UpdateDocumentMetadataResponse createUpdateDocumentMetadataResponse() {
        return new UpdateDocumentMetadataResponse();
    }

    /**
     * Create an instance of {@link SearchDocumentMetadataResponse }
     * 
     */
    public SearchDocumentMetadataResponse createSearchDocumentMetadataResponse() {
        return new SearchDocumentMetadataResponse();
    }

    /**
     * Create an instance of {@link UpdateDocumentMetadataRequest }
     * 
     */
    public UpdateDocumentMetadataRequest createUpdateDocumentMetadataRequest() {
        return new UpdateDocumentMetadataRequest();
    }

    /**
     * Create an instance of {@link EfileSearchResultType }
     * 
     */
    public EfileSearchResultType createEfileSearchResultType() {
        return new EfileSearchResultType();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/insurance/jh/Efile", name = "APP-Password")
    public JAXBElement<String> createAPPPassword(String value) {
        return new JAXBElement<String>(_APPPassword_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link EfileSearchCriteriaType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/insurance/jh/Efile", name = "EfileSearchCriteria")
    public JAXBElement<EfileSearchCriteriaType> createEfileSearchCriteria(EfileSearchCriteriaType value) {
        return new JAXBElement<EfileSearchCriteriaType>(_EfileSearchCriteria_QNAME, EfileSearchCriteriaType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/insurance/jh/Efile", name = "KeyName")
    public JAXBElement<String> createKeyName(String value) {
        return new JAXBElement<String>(_KeyName_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/insurance/jh/Efile", name = "APP-UserID")
    public JAXBElement<String> createAPPUserID(String value) {
        return new JAXBElement<String>(_APPUserID_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link KeyedValueType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/insurance/jh/Efile", name = "KeyedValue")
    public JAXBElement<KeyedValueType> createKeyedValue(KeyedValueType value) {
        return new JAXBElement<KeyedValueType>(_KeyedValue_QNAME, KeyedValueType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/insurance/jh/Efile", name = "EfileTag")
    public JAXBElement<String> createEfileTag(String value) {
        return new JAXBElement<String>(_EfileTag_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link APPResponseHeaderType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/insurance/jh/Efile", name = "APP-ResponseHeader")
    public JAXBElement<APPResponseHeaderType> createAPPResponseHeader(APPResponseHeaderType value) {
        return new JAXBElement<APPResponseHeaderType>(_APPResponseHeader_QNAME, APPResponseHeaderType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/insurance/jh/Efile", name = "EfileId")
    public JAXBElement<String> createEfileId(String value) {
        return new JAXBElement<String>(_EfileId_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/insurance/jh/Efile", name = "APP-SessionID")
    public JAXBElement<String> createAPPSessionID(String value) {
        return new JAXBElement<String>(_APPSessionID_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link APPAuthenticationType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/insurance/jh/Efile", name = "APP-Authentication")
    public JAXBElement<APPAuthenticationType> createAPPAuthentication(APPAuthenticationType value) {
        return new JAXBElement<APPAuthenticationType>(_APPAuthentication_QNAME, APPAuthenticationType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link EfileSearchResultType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/insurance/jh/Efile", name = "EfileSearchResult")
    public JAXBElement<EfileSearchResultType> createEfileSearchResult(EfileSearchResultType value) {
        return new JAXBElement<EfileSearchResultType>(_EfileSearchResult_QNAME, EfileSearchResultType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link EfileSearchResultsType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/insurance/jh/Efile", name = "EfileSearchResults")
    public JAXBElement<EfileSearchResultsType> createEfileSearchResults(EfileSearchResultsType value) {
        return new JAXBElement<EfileSearchResultsType>(_EfileSearchResults_QNAME, EfileSearchResultsType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/insurance/jh/Efile", name = "KeyValue")
    public JAXBElement<String> createKeyValue(String value) {
        return new JAXBElement<String>(_KeyValue_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DocumentType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/insurance/jh/Efile", name = "Document")
    public JAXBElement<DocumentType> createDocument(DocumentType value) {
        return new JAXBElement<DocumentType>(_Document_QNAME, DocumentType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/insurance/jh/Efile", name = "DocumentId")
    public JAXBElement<String> createDocumentId(String value) {
        return new JAXBElement<String>(_DocumentId_QNAME, String.class, null, value);
    }

}
