
package com.manulife.esb.xsd.insurance.jh.efile;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for APP-Authentication_Type complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="APP-Authentication_Type">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;choice>
 *         &lt;sequence>
 *           &lt;element ref="{http://www.esb.manulife.com/xsd/insurance/jh/Efile}APP-SessionID"/>
 *         &lt;/sequence>
 *         &lt;sequence>
 *           &lt;element ref="{http://www.esb.manulife.com/xsd/insurance/jh/Efile}APP-UserID"/>
 *           &lt;element ref="{http://www.esb.manulife.com/xsd/insurance/jh/Efile}APP-Password"/>
 *         &lt;/sequence>
 *       &lt;/choice>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "APP-Authentication_Type", propOrder = {
    "appSessionID",
    "appUserID",
    "appPassword"
})
public class APPAuthenticationType {

    @XmlElement(name = "APP-SessionID")
    protected String appSessionID;
    @XmlElement(name = "APP-UserID")
    protected String appUserID;
    @XmlElement(name = "APP-Password")
    protected String appPassword;

    /**
     * Gets the value of the appSessionID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAPPSessionID() {
        return appSessionID;
    }

    /**
     * Sets the value of the appSessionID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAPPSessionID(String value) {
        this.appSessionID = value;
    }

    /**
     * Gets the value of the appUserID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAPPUserID() {
        return appUserID;
    }

    /**
     * Sets the value of the appUserID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAPPUserID(String value) {
        this.appUserID = value;
    }

    /**
     * Gets the value of the appPassword property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAPPPassword() {
        return appPassword;
    }

    /**
     * Sets the value of the appPassword property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAPPPassword(String value) {
        this.appPassword = value;
    }

}
