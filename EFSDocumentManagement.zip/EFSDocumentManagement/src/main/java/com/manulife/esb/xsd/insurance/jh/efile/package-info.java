@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.esb.manulife.com/xsd/insurance/jh/Efile", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.manulife.esb.xsd.insurance.jh.efile;
