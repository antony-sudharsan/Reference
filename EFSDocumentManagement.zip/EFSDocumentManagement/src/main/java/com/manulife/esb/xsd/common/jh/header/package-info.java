@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.esb.manulife.com/xsd/common/jh/header", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.manulife.esb.xsd.common.jh.header;
