
package com.manulife.esb.xsd.insurance.jh.efile;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for APP-ResponseHeader_Type complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="APP-ResponseHeader_Type">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/insurance/jh/Efile}APP-SessionID"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "APP-ResponseHeader_Type", propOrder = {
    "appSessionID"
})
public class APPResponseHeaderType {

    @XmlElement(name = "APP-SessionID", required = true)
    protected String appSessionID;

    /**
     * Gets the value of the appSessionID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAPPSessionID() {
        return appSessionID;
    }

    /**
     * Sets the value of the appSessionID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAPPSessionID(String value) {
        this.appSessionID = value;
    }

}
