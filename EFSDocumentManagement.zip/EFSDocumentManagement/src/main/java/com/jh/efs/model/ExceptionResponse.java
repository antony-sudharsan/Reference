package com.jh.efs.model;

import lombok.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ExceptionResponse {

    private String code;
    private String message;
    private String details;
}
