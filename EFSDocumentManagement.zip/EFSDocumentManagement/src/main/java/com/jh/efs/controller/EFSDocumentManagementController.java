package com.jh.efs.controller;

import com.jh.common.logging.LoggerHandler;
import com.jh.efs.constant.EFSHeaderEnum;
import com.jh.efs.constant.EFSURIConst;
import com.jh.efs.constant.SystemConst;
import com.jh.efs.model.Key;
import com.jh.efs.model.SearchRequestBodyModel;
import com.jh.efs.service.impl.EFSServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

import static com.jh.efs.validator.EFSValidator.*;

@RestController
@RequestMapping(SystemConst.API_PRIFIX)
@EnableSwagger2
public class EFSDocumentManagementController {

    @Autowired
    private EFSServiceImpl eFSService;

    @ApiOperation(
            value = "Login Operation",
            notes = "Service will logon in EFS System ",
            response = ResponseEntity.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Success"),
            @ApiResponse(code = 500, message = "Internal Server Error"),
            @ApiResponse(code = 400, message = "Bad Request"),
            @ApiResponse(code = 404, message = "Not Found"),
            @ApiResponse(code = 401, message = "Unauthorized"),
            @ApiResponse(code = 408, message = "Request Timeout")
      })
    @GetMapping(EFSURIConst.LOGON)
    public ResponseEntity<String> eFSLogOn(@RequestHeader(value="APP-UserID",required = false) String username,
                                                 @RequestHeader(value="APP-Password",required = false) String password) throws Exception{
        LoggerHandler.LogOut("INFO", "1", "EfsTransactionId", "EfssourceSystemName", this.getClass().getName(), "Header for LogOn - Username : "+username + "  Password : " + password);
        validateArgumentUserNameAndPassword(username, password);
        Map<EFSHeaderEnum, String> rp = new HashMap<>();
        setRequestheader(username, password, rp);
        setCommonParams(rp);
//        return eFSService.eFSLogon(rp);
        return null;
    }

    @ApiOperation(
            value = "LogOff Operation",
            notes = "Service will logoff from EFS System ",
            response = ResponseEntity.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Success"),
            @ApiResponse(code = 500, message = "Internal Server Error"),
            @ApiResponse(code = 400, message = "Bad Request"),
            @ApiResponse(code = 404, message = "Not Found"),
            @ApiResponse(code = 401, message = "Unauthorized"),
            @ApiResponse(code = 408, message = "Request Timeout")
    })

    @GetMapping(EFSURIConst.LOGOFF)
    public ResponseEntity<String> eFSLogOff(@RequestHeader(value = "APP-SessionID",required = false) String sessionId, @RequestHeader(value="APP-UserID",required = false) String username,
                                                  @RequestHeader(value = "APP-Password",required = false) String password) throws Exception{

        String msgPayload = "LogOff API - APP-SessionID : "+sessionId + " APP-UserID : " + username + " Password" + password;
        LoggerHandler.LogOut("INFO", "1", "EfsTransactionId", "EfssourceSystemName", this.getClass().getName(), msgPayload);
        validateArgumentUserNameAndPasswordAndSessionID(username, password, sessionId);
        Map<EFSHeaderEnum, String> rp = new HashMap<>();
        setRequestheader(username, password, rp);
        setCommonParams(rp);
        rp.put(EFSHeaderEnum.APP_SESSIONID, sessionId);
//        return eFSService.eFSLogoff(rp);
        return null;
    }

    @ApiOperation(
            value = "Search Operation",
            notes = "Service will search for particular record in EFS System ",
            response = Key.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Success"),
            @ApiResponse(code = 500, message = "Internal Server Error"),
            @ApiResponse(code = 400, message = "Bad Request"),
            @ApiResponse(code = 404, message = "Not Found"),
            @ApiResponse(code = 401, message = "Unauthorized"),
            @ApiResponse(code = 408, message = "Request Timeout")
    })

    @PostMapping(EFSURIConst.SEARCH)
    public ResponseEntity<String> eFSSearch(@RequestHeader(value = "APP-UserID",required = false) String username, @RequestHeader(value = "APP-Password",required = false) String password,
                                                  @RequestBody(required = false) SearchRequestBodyModel srbm) throws Exception{

        LoggerHandler.LogOut("INFO", "1", "EfsTransactionId", "EfssourceSystemName", this.getClass().getName(), "Header for Search - Username : "+username + "  Password : " + password);
        validateArgumentUserNamePasswordAndRequestBody(username, password, srbm);
        Map<EFSHeaderEnum, String> rp = new HashMap<>();
        setRequestheader(username, password, rp);
        setCommonParams(rp);
//        return eFSService.eFSSearch(rp, srbm);
        return null;
    }

    @ApiOperation(
            value = "Update Operation",
            notes = "Service will Update a particular record in EFS System ",
            response = Key.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Success"),
            @ApiResponse(code = 500, message = "Internal Server Error"),
            @ApiResponse(code = 400, message = "Bad Request"),
            @ApiResponse(code = 404, message = "Not Found"),
            @ApiResponse(code = 401, message = "Unauthorized"),
            @ApiResponse(code = 408, message = "Request Timeout")
    })
    @PostMapping(EFSURIConst.UPDATE)
    public ResponseEntity<String> eFSUpdate(@RequestHeader(value = "APP-Key",required = false) String key, @RequestHeader(value = "APP-UserID",required = false) String username,
                                                  @RequestHeader(value = "APP-Password",required = false) String password,
                                                  @RequestHeader(value = "APP-Etag",required = false) String etag, @RequestBody(required = false) SearchRequestBodyModel srbm)
            throws Exception{

        String mesPayload = "Header Value for Update- APP-Key : " + key + "  APP-UserID : " + username + "  Password : " + password + "  APP-Etag : " + etag;
        LoggerHandler.LogOut("INFO", "1", "EfsTransactionId", "EfssourceSystemName", this.getClass().getName(), mesPayload);
        validateArgumentUserNamePasswordAndRequestBody(username, password, srbm);
        Map<EFSHeaderEnum, String> rp = new HashMap<>();
        rp.put(EFSHeaderEnum.APP_KEY, key);
        rp.put(EFSHeaderEnum.APP_ETAG, etag);
        setRequestheader(username, password, rp);
        setCommonParams(rp);
//        return eFSService.eFSUpdate(rp, srbm);
        return null;
    }

    @ApiOperation(
            value = "Add Reference Operation",
            notes = "Service will Add reference in the record in EFS System ",
            response = Key.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Success"),
            @ApiResponse(code = 500, message = "Internal Server Error"),
            @ApiResponse(code = 400, message = "Bad Request"),
            @ApiResponse(code = 404, message = "Not Found"),
            @ApiResponse(code = 401, message = "Unauthorized"),
            @ApiResponse(code = 408, message = "Request Timeout")
    })
    @PostMapping(EFSURIConst.ADD_REFERENCE)
    public ResponseEntity<String> eFSAddReference(@RequestHeader(value = "APP-Key",required = false) String key, @RequestHeader(value = "APP-UserID",required = false) String username,
                                                  @RequestHeader(value = "APP-Password",required = false) String password,
                                                  @RequestHeader(value = "APP-Etag",required = false) String etag, @RequestBody(required = false) SearchRequestBodyModel srbm)
            throws Exception{

        String mesPayload = "Header Value for Update- APP-Key : " + key + "  APP-UserID : " + username + "  Password : " + password + "  APP-Etag : " + etag;
        LoggerHandler.LogOut("INFO", "1", "EfsTransactionId", "EfssourceSystemName", this.getClass().getName(), mesPayload);
        validateArgumentUserNamePasswordAndRequestBody(username, password, srbm);
        Map<EFSHeaderEnum, String> rp = new HashMap<>();
        rp.put(EFSHeaderEnum.APP_KEY, key);
        rp.put(EFSHeaderEnum.APP_ETAG, etag);
        setRequestheader(username, password, rp);
        setCommonParams(rp);
//        return eFSService.eFSAddReference(rp, srbm);
        return null;
    }

    @ApiOperation(
            value = "Metadata Operation",
            notes = "Service will return metadata from  EFS System ",
            response = Key.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Success"),
            @ApiResponse(code = 500, message = "Internal Server Error"),
            @ApiResponse(code = 400, message = "Bad Request"),
            @ApiResponse(code = 404, message = "Not Found"),
            @ApiResponse(code = 401, message = "Unauthorized"),
            @ApiResponse(code = 408, message = "Request Timeout")
    })
    @GetMapping(EFSURIConst.METADATA)
    public ResponseEntity<String> eFSMetadata(@RequestHeader(value = "APP-Key",required = false) String key,
                                                    @RequestHeader(value = "APP-UserID",required = false) String username,
                                                    @RequestHeader(value = "APP-Password",required = false) String password) throws Exception{

        String mesPayload = "Header Value for Metadata- APP-Key : " + key + "  APP-UserID : " + username + "  Password : " + password ;
        LoggerHandler.LogOut("INFO", "1", "EfsTransactionId", "EfssourceSystemName", this.getClass().getName(), mesPayload);
        validateArgumentUserNameAndPasswordAndAppKey(username, password, key);
        Map<EFSHeaderEnum, String> rp = new HashMap<>();
        rp.put(EFSHeaderEnum.APP_KEY, key);
        setRequestheader(username, password, rp);
        setCommonParams(rp);
//        return eFSService.eFSMetadata(rp);
        return null;

    }

    private void setRequestheader(String username, String passowrd, Map<EFSHeaderEnum, String> rp) {
        rp.put(EFSHeaderEnum.APP_USERNAME, username);
        rp.put(EFSHeaderEnum.APP_PASSWORD, passowrd);
    }

    private void setCommonParams(Map<EFSHeaderEnum, String> rp) {
        rp.put(EFSHeaderEnum.HMAC_KEY, "jsaSj3d8sJ22fdfG");
        rp.put(EFSHeaderEnum.SECRET_KEY, "ad426898f7774d92941yy3g30836aabc");
        rp.put(EFSHeaderEnum.APP_SESSIONID, "");
    }
}