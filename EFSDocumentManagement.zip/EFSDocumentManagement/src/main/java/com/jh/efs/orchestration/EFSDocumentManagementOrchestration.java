package com.jh.efs.orchestration;

import com.jh.efs.constant.EFSHeaderEnum;
import com.jh.efs.constant.EFSURIConst;
import com.jh.efs.model.HeaderParamsModel;
import com.jh.efs.model.SearchParamsModel;
import com.jh.efs.model.SearchRequestBodyModel;
import com.jh.efs.searchrequestmodel.EfsSearch;
import com.jh.efs.searchrequestmodel.Eqv;
import com.jh.efs.searchresultsmodel.EfsSearchResults;
import com.jh.efs.service.impl.EFSServiceImpl;
import com.jh.efs.utils.EFSHeadersParamsUtils;
import com.jh.efs.utils.RESTClientUtil;
import com.manulife.esb.xsd.common.jh.header.JHHeader;
import com.manulife.esb.xsd.insurance.jh.efile.*;
import org.json.JSONObject;
import org.json.XML;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import java.io.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.jh.efs.utils.EFSHeadersParamsUtils.convertToJson;

@Component
public class EFSDocumentManagementOrchestration {

    @Autowired
    private EFSServiceImpl eFSService;

    @Autowired
    private RestTemplate restTemplate;

    public SearchDocumentMetadataResponse searchDocumentMetadata(JHHeader header, SearchDocumentMetadataRequest request) throws Exception {
        SearchDocumentMetadataResponse searchDocumentMetadataResponse = new SearchDocumentMetadataResponse();
        Map<String, String> parms = new HashMap<>();

        /*SearchRequestBodyModel searchRequestBodyModel = new SearchRequestBodyModel();
        List<SearchParamsModel> eqvList = new ArrayList<>();
        SearchParamsModel searchParamsModel = new SearchParamsModel();
        searchParamsModel.setName("PLID");
        searchParamsModel.setValue("1111112");
        eqvList.add(searchParamsModel);
        searchRequestBodyModel.setEqv(eqvList);*/


        EfsSearch searchRequestBodyModel = new EfsSearch();
        List<Eqv> eqvList = new ArrayList<>();
        Eqv eqv = new Eqv();
        eqv.setName("PLID");
        eqv.setValue("1111112");
        eqvList.add(eqv);
        searchRequestBodyModel.setEqv(eqvList);


      JAXBContext jaxbContext = JAXBContext.newInstance(EfsSearch.class);
        Marshaller jaxbMarshaller = jaxbContext.createMarshaller();

        StringWriter sw = new StringWriter();

        jaxbMarshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
        jaxbMarshaller.marshal(searchRequestBodyModel,sw);


       EfileSearchCriteriaType efileSearchCriteria = new EfileSearchCriteriaType();
        List<KeyedValueType> keyedValueList = new ArrayList<>();
        KeyedValueType keyedValueType = new KeyedValueType();
        keyedValueType.setKeyName("PLID");
        keyedValueType.setKeyValue("1111112");
        keyedValueList.add(keyedValueType);
        efileSearchCriteria.setKeyedValue(keyedValueList);


        Map<EFSHeaderEnum, String> rp = new HashMap<>();
        rp.put(EFSHeaderEnum.APP_USERNAME, "TPP");
        rp.put(EFSHeaderEnum.APP_PASSWORD, "Efs1234!");

        rp.put(EFSHeaderEnum.HMAC_KEY, "jsaSj3d8sJ22fdfG");
        rp.put(EFSHeaderEnum.SECRET_KEY, "ad426898f7774d92941yy3g30836aabc");
        rp.put(EFSHeaderEnum.APP_SESSIONID, "");

        HttpHeaders headers = getHttpHeadersCommonParams(rp, parms);
        headers.setContentType(MediaType.APPLICATION_XML);
        List<MediaType> acceptMediaType = new ArrayList<>();
        acceptMediaType.add(MediaType.APPLICATION_XML);
        headers.setAccept(acceptMediaType);
//        ResponseEntity<String> result = RESTClientUtil.callRESTAPI(restTemplate, headers, EFSURIConst.SEARCH, HttpMethod.PUT, convertToJson(searchRequestBodyModel));
        ResponseEntity<String> result = RESTClientUtil.callRESTAPI(restTemplate, headers, EFSURIConst.SEARCH, HttpMethod.PUT, sw.toString());
        System.out.println("The value of the output result >>" + result);


        String resultStr  = result.toString().replace("<200 OK,","").replace(",{}>","");


        BufferedWriter writer = null;
        try
        {
            writer = new BufferedWriter( new FileWriter( "result.xml"));
            writer.write( resultStr);

        }
        catch ( IOException e)
        {
        }
        finally
        {
            try
            {
                if ( writer != null)
                    writer.close( );
            }
            catch ( IOException e)
            {
            }
        }


        JAXBContext jaxbContextUnmarshal = JAXBContext.newInstance(EfsSearchResults.class);
        Unmarshaller jaxbUnmarshaller = jaxbContextUnmarshal.createUnmarshaller();

        EfsSearchResults efsSearchResults = (EfsSearchResults)jaxbUnmarshaller.unmarshal(new StringReader(resultStr));

        System.out.println("The value of the List Itemes >>"+efsSearchResults.getKey().size());

        return searchDocumentMetadataResponse;
    }

    public UpdateDocumentMetadataResponse updateDocumentMetadata(JHHeader header, UpdateDocumentMetadataRequest request) {
        return null;
    }

    private HttpHeaders getHttpHeadersCommonParams(Map<EFSHeaderEnum, String> rp, Map<String, String> parms) throws Exception {
        parms.clear();
        HttpHeaders headers = new HttpHeaders();
        HeaderParamsModel hpm = EFSHeadersParamsUtils.getHeaderParams(rp);
        parms.put(EFSHeaderEnum.AUTH.getParam(), hpm.getEFSAuth());
        parms.put(EFSHeaderEnum.KEY.getParam(), hpm.getEFSKey());
        parms.put(EFSHeaderEnum.SIGN.getParam(), hpm.getEFSSign());
        parms.put(EFSHeaderEnum.DATE.getParam(), hpm.getEFSDate());

        headers.setAll(parms);
        return headers;
    }
}
