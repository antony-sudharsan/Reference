package com.jh.efs.exception;

import lombok.Getter;
import lombok.Setter;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
public class EFSInternalServerException extends RuntimeException{

    @Getter
    @Setter
    private String details;
    public EFSInternalServerException(String exception){
        super(exception);
    }

    public EFSInternalServerException(String exception,String details){
        super(exception);
        this.details = details;
    }
}