package com.jh.efs.validator;

import com.jh.efs.exception.EFSNotFoundException;
import com.jh.efs.model.SearchRequestBodyModel;

public class EFSValidator {

    private static final String messageHeader = "Missing or Invalid header parameter";
    private static final String messageBody = "Missing or Invalid body parameter";

    public static void validateArgumentUserNameAndPassword(String username, String password) throws EFSNotFoundException {
        checkUserNameAndPassword(username, password);
    }

    public static void validateArgumentUserNameAndPasswordAndSessionID(String username, String password, String sessionId) throws EFSNotFoundException {
        checkUserNameAndPassword(username, password);
        if (checkIfNullorEmpty(sessionId)) {
            throw new EFSNotFoundException(messageHeader,"Session Id is empty");
        }
    }

    public static void validateArgumentUserNameAndPasswordAndAppKey(String username, String password, String appkey) throws EFSNotFoundException {
        checkUserNameAndPassword(username, password);
        if (checkIfNullorEmpty(appkey)) {
            throw new EFSNotFoundException(messageHeader,"App Key is empty");
        }
    }

    public static void validateArgumentUserNamePasswordAndRequestBody(String username, String password,
                                                                      SearchRequestBodyModel requestbody) throws EFSNotFoundException {
        if(requestbody == null)
            throw  new EFSNotFoundException(messageBody,"Request Body is empty");

        checkUserNameAndPassword(username, password);
        if (requestbody.getEqv() == null || requestbody.getEqv().isEmpty()) {
            throw new EFSNotFoundException(messageBody,"Request Body is empty");
        }else if (checkIfNullorEmpty(requestbody.getEqv().get(0).getName()) || checkIfNullorEmpty(requestbody.getEqv().get(0).getValue())){
            throw new EFSNotFoundException(messageBody,"Parameter Name or Value is empty");
        }
    }

    private static void checkUserNameAndPassword(String username, String password) throws EFSNotFoundException {

        if (checkIfNullorEmpty(username)|| checkIfNullorEmpty(password)) {
            throw new EFSNotFoundException(messageHeader,"UserId or Password is empty");
        }
    }

    private static boolean checkIfNullorEmpty(String targetCheckValue){
        return (targetCheckValue == null || targetCheckValue.isEmpty());
    }

}