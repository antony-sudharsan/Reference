package com.jh.efs.model;

import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@ToString
public class SearchRequestModel {
    @ApiModelProperty(value = "EQV List",required = true)
    private Eqv[] eqv;

    public Eqv[] getEqv() {
        return eqv;
    }

    public void setEqv(Eqv[] eqv) {
        this.eqv = eqv;
    }
}