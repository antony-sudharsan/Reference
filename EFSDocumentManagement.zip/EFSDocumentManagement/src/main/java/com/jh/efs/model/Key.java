package com.jh.efs.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@ToString
@ApiModel
public class Key {
    @Getter
    @Setter
    @ApiModelProperty(value = "Eqv List",required = true)
    private Eqv[] eqv;

}

