package com.jh.efs.model;


import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@ToString
public class Eqv
{
    @Getter
    @Setter
    @ApiModelProperty(value = "Name",required = true)
    private String name;
    @Getter
    @Setter
    @ApiModelProperty(value = "Value",required = true)
    private String value;
}
