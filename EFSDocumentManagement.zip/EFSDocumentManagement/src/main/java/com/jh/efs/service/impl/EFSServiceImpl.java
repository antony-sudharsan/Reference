package com.jh.efs.service.impl;

import com.jh.efs.constant.EFSHeaderEnum;
import com.jh.efs.constant.EFSURIConst;
import com.jh.efs.model.HeaderParamsModel;
import com.jh.efs.model.SearchRequestBodyModel;
import com.jh.efs.utils.EFSHeadersParamsUtils;
import com.jh.efs.utils.RESTClientUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.jh.efs.utils.EFSHeadersParamsUtils.convertToJson;

@Service
public class EFSServiceImpl {

    @Autowired
    private RestTemplate restTemplate;

    public ResponseEntity<String> eFSLogon(Map<EFSHeaderEnum, String> rp) throws Exception {
        Map<String, String> parms = new HashMap<>();
        HttpHeaders headers = getHttpHeadersCommonParams(rp, parms);
        ResponseEntity<String> result = RESTClientUtil.callRESTAPI(restTemplate, headers, EFSURIConst.LOGON, HttpMethod.PUT, "parameters");
        return result;
    }

    private HttpHeaders getHttpHeadersCommonParams(Map<EFSHeaderEnum, String> rp, Map<String, String> parms) throws Exception {
        parms.clear();
        HttpHeaders headers = new HttpHeaders();
        HeaderParamsModel hpm = EFSHeadersParamsUtils.getHeaderParams(rp);
        parms.put(EFSHeaderEnum.AUTH.getParam(), hpm.getEFSAuth());
        parms.put(EFSHeaderEnum.KEY.getParam(), hpm.getEFSKey());
        parms.put(EFSHeaderEnum.SIGN.getParam(), hpm.getEFSSign());
        parms.put(EFSHeaderEnum.DATE.getParam(), hpm.getEFSDate());

        headers.setAll(parms);
        return headers;
    }

    public ResponseEntity<String> eFSLogoff(Map<EFSHeaderEnum, String> rp) throws Exception{
        Map<String, String> parms = new HashMap<>();
        HttpHeaders headers = getHttpHeadersCommonParams(rp, parms);
        headers.setContentType(MediaType.APPLICATION_ATOM_XML);

        ResponseEntity<String> result = RESTClientUtil.callRESTAPI(restTemplate, headers, EFSURIConst.LOGOFF, HttpMethod.PUT, "parameters");
        return result;
    }

    public ResponseEntity<String> eFSSearch(Map<EFSHeaderEnum, String> rp, SearchRequestBodyModel srbm) throws Exception{
        Map<String, String> parms = new HashMap<>();
        HttpHeaders headers = getHttpHeadersCommonParams(rp, parms);
        headers.setContentType(MediaType.APPLICATION_JSON);
        List<MediaType> acceptMediaType = new ArrayList<>();
        acceptMediaType.add(MediaType.APPLICATION_JSON);
        headers.setAccept(acceptMediaType);
        ResponseEntity<String> result = RESTClientUtil.callRESTAPI(restTemplate, headers, EFSURIConst.SEARCH, HttpMethod.PUT, convertToJson(srbm));
        return result;
    }

    public ResponseEntity<String> eFSUpdate(Map<EFSHeaderEnum, String> rp, SearchRequestBodyModel srbm) throws Exception{
        Map<String, String> parms = new HashMap<>();
        HttpHeaders headers = getHttpHeadersCommonParams(rp, parms);
        headers.setContentType(MediaType.APPLICATION_JSON);
        List<MediaType> acceptMediaType = new ArrayList<>();
        acceptMediaType.add(MediaType.APPLICATION_JSON);
        headers.setAccept(acceptMediaType);

        String bindUri = EFSURIConst.UPDATE + prepareUpdateURI(rp.get(EFSHeaderEnum.APP_KEY), rp.get(EFSHeaderEnum.APP_ETAG));

        ResponseEntity<String> result = RESTClientUtil.callRESTAPI(restTemplate, headers, bindUri, HttpMethod.POST, convertToJson(srbm));
        return result;
    }

    public ResponseEntity<String> eFSAddReference(Map<EFSHeaderEnum, String> rp, SearchRequestBodyModel srbm) throws Exception{
        Map<String, String> parms = new HashMap<>();
        HttpHeaders headers = getHttpHeadersCommonParams(rp, parms);
        headers.setContentType(MediaType.APPLICATION_JSON);
        List<MediaType> acceptMediaType = new ArrayList<>();
        acceptMediaType.add(MediaType.APPLICATION_JSON);
        headers.setAccept(acceptMediaType);
        String bindUri = EFSURIConst.ADD_REFERENCE + prepareUpdateURI(rp.get(EFSHeaderEnum.APP_KEY), rp.get(EFSHeaderEnum.APP_ETAG));
System.out.println(" bind URI reference" + bindUri);
        ResponseEntity<String> result = RESTClientUtil.callRESTAPI(restTemplate, headers, bindUri, HttpMethod.POST, convertToJson(srbm));
        return result;
    }


    public ResponseEntity<String> eFSMetadata(Map<EFSHeaderEnum, String> rp) throws Exception{

        Map<String, String> parms = new HashMap<>();
        HttpHeaders headers = getHttpHeadersCommonParams(rp, parms);
        headers.setContentType(MediaType.APPLICATION_ATOM_XML);
        String bindUri = EFSURIConst.METADATA_WITHOUT_KEY + rp.get(EFSHeaderEnum.APP_KEY);

        List<MediaType> acceptMediaType = new ArrayList<>();
        acceptMediaType.add(MediaType.APPLICATION_JSON);
        headers.setAccept(acceptMediaType);

        ResponseEntity<String> result = RESTClientUtil.callRESTAPI(restTemplate, headers, bindUri, HttpMethod.GET, "");
        return result;
    }

    private String prepareUpdateURI(String key, String etag) {
        return String.format("/%s?etag=%s", key, etag);
    }

}