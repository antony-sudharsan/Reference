package com.jh.efs.utils;

/**
 * Used to access LoggingContext from ThreadLocal.
 */
public final class LoggingContextHolder {

    private LoggingContextHolder() {

    }

    private static ThreadLocal<LoggingContext> holder = new ThreadLocal<LoggingContext>() {
        @Override
        public LoggingContext initialValue() {
            return new LoggingContext();
        }
    };

    public static LoggingContext getLoggingContext() {
        return holder.get();
    }
}
