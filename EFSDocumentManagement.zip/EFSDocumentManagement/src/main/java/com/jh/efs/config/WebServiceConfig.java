package com.jh.efs.config;

import com.jh.efs.endpoint.EFSEndpointInterceptor;
import com.jh.efs.exception.BaseFaultException;
import com.jh.efs.exception.DetailSoapFaultDefinitionExceptionResolver;
import com.jh.efs.utils.JHHeaderJaxbUtils;
import org.springframework.boot.web.servlet.ServletRegistrationBean;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;
import org.springframework.ws.config.annotation.EnableWs;
import org.springframework.ws.config.annotation.WsConfigurerAdapter;
import org.springframework.ws.server.EndpointInterceptor;
import org.springframework.ws.soap.server.endpoint.SoapFaultDefinition;
import org.springframework.ws.soap.server.endpoint.SoapFaultMappingExceptionResolver;
import org.springframework.ws.soap.server.endpoint.interceptor.PayloadValidatingInterceptor;
import org.springframework.ws.transport.http.MessageDispatcherServlet;
import org.springframework.ws.wsdl.wsdl11.SimpleWsdl11Definition;
import org.springframework.xml.xsd.SimpleXsdSchema;
import org.springframework.xml.xsd.XsdSchema;

import java.util.List;
import java.util.Properties;

/**
 * Configures Web Service Endpoint for Producer2Application Operations.
 */
@EnableWs
@Configuration
public class WebServiceConfig extends WsConfigurerAdapter {

    @Bean
    public ServletRegistrationBean messageDispatcherServlet(final ApplicationContext applicationContext) {
        final MessageDispatcherServlet servlet = new MessageDispatcherServlet();
        servlet.setApplicationContext(applicationContext);
        servlet.setTransformWsdlLocations(true);
        servlet.setTransformSchemaLocations(true);
        return new ServletRegistrationBean(servlet, "/Services/EFSDocumentManagement_2/EFSDocumentManagement.serviceagent/EFSDocumentManagementSOAP/*");
    }

    // Note: Could use wsdl from TIBCO but it has embedded tibco namespaces
    // To retrieve wsdl
    // http://localhost:8080/Services/EFSDocumentManagement_2/EFSDocumentManagement.serviceagent/EFSDocumentManagementSOAP/EFSDocumentManagement.wsdl
    @Bean(name = "EFSDocumentManagement")
    public SimpleWsdl11Definition producerWsdl11Definition() {
        final SimpleWsdl11Definition wsdl = new SimpleWsdl11Definition(
                new ClassPathResource("EFSDocumentManagement.wsdl"));

        return wsdl;
    }

    @Bean
    public JHHeaderJaxbUtils jhHeaderJaxbUtils() {
        return new JHHeaderJaxbUtils();
    }

    // will expose imported schema
    // http://localhost:8080/MaintainProducerAgreement_1.0/JHFNMaintainProducerAgreement.xsd
    @Bean(name = "Producer2")
    public XsdSchema maintainProducerAgreementSchema() {
        return new SimpleXsdSchema(new ClassPathResource("EFSDocumentManagement.xsd"));
    }

    // will expose imported schema
    // http://localhost:8080/MaintainProducerAgreement_1.0/JHHeader_0.5.0.xsd
    @Bean(name = "JHHeader_0.5.0")
    public XsdSchema headerSchema() {
        return new SimpleXsdSchema(new ClassPathResource("JHHeader_0.5.0.xsd"));
    }

    // will expose imported schema
    // http://localhost:8080/MaintainProducerAgreement_1.0/SOAPFault.xsd
    @Bean(name = "SOAPFault")
    public XsdSchema soapFaultSchema() {
        return new SimpleXsdSchema(new ClassPathResource("SOAPFault.xsd"));
    }

    @Bean
    public SoapFaultMappingExceptionResolver exceptionResolver() {
        final SoapFaultMappingExceptionResolver exceptionResolver = new DetailSoapFaultDefinitionExceptionResolver();

        final SoapFaultDefinition faultDefinition = new SoapFaultDefinition();
        faultDefinition.setFaultCode(SoapFaultDefinition.SERVER);
        faultDefinition.setFaultStringOrReason("Internal Error");
        exceptionResolver.setDefaultFault(faultDefinition);

        final Properties errorMappings = new Properties();
        errorMappings.setProperty(Exception.class.getName(), SoapFaultDefinition.SERVER.toString());
        errorMappings.setProperty(BaseFaultException.class.getName(), SoapFaultDefinition.SERVER.toString());
        exceptionResolver.setExceptionMappings(errorMappings);
        exceptionResolver.setOrder(1);
        return exceptionResolver;
    }

    @Override
    public void addInterceptors(final List<EndpointInterceptor> interceptors) {

        final PayloadValidatingInterceptor validatingInterceptor = new PayloadValidatingInterceptor();
        validatingInterceptor.setValidateRequest(true);
        validatingInterceptor.setValidateResponse(true);
        validatingInterceptor.setXsdSchema(maintainProducerAgreementSchema());
        interceptors.add(validatingInterceptor);

        // will handle adding soap response header
        interceptors.add(new EFSEndpointInterceptor(jhHeaderJaxbUtils()));
    }

}
