package com.jh.efs.controller;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

@ControllerAdvice
@RestController
public class EFSResponseEntityExceptionHandler extends ResponseEntityExceptionHandler {


/*

    @ExceptionHandler(EFSBadRequestException.class)
    public final ResponseEntity<Object> handleBadRequestExceptions(EFSBadRequestException ex, WebRequest request) {
        return new ResponseEntity<>(new ExceptionResponse(getHttpStatusAsString(HttpStatus.BAD_REQUEST),ex.getMessage(),ex.getDetails()), HttpStatus.BAD_REQUEST);
    }


    @ExceptionHandler(EFSTimeOutException.class)
    public final ResponseEntity<Object> handleBadRequestExceptions(EFSTimeOutException ex, WebRequest request) {
        return new ResponseEntity<>(new ExceptionResponse(getHttpStatusAsString(HttpStatus.REQUEST_TIMEOUT),ex.getMessage(),ex.getDetails()), HttpStatus.REQUEST_TIMEOUT);
    }

    @ExceptionHandler(EFSNotFoundException.class)
    public final ResponseEntity<Object> handleNotFoundException(EFSNotFoundException ex, WebRequest request) {
        return new ResponseEntity<>(new ExceptionResponse("400",ex.getMessage(),ex.getDetails()), HttpStatus.NOT_FOUND);
    }

    @ExceptionHandler(EFSInternalServerException.class)
    public final ResponseEntity<Object> handleInternalServerErrorException(EFSInternalServerException ex, WebRequest request) {
        return new ResponseEntity<>(new ExceptionResponse(getHttpStatusAsString(HttpStatus.INTERNAL_SERVER_ERROR),ex.getMessage(),ex.getDetails()),HttpStatus.NOT_FOUND);
    }

    @ExceptionHandler(EFSUnAuthorizedException.class)
    public final ResponseEntity<Object> handleUnAuthorizedException(EFSUnAuthorizedException ex, WebRequest request) {
        return new ResponseEntity<>(new ExceptionResponse(getHttpStatusAsString(HttpStatus.UNAUTHORIZED),ex.getMessage(),ex.getDetails()),HttpStatus.UNAUTHORIZED);
    }

    @ExceptionHandler(Exception.class)
    public final ResponseEntity<Object> handleAllExceptions(Exception ex, WebRequest request) {
        return new ResponseEntity(new ExceptionResponse(getHttpStatusAsString(HttpStatus.INTERNAL_SERVER_ERROR), ex.getMessage(),
                ex.toString()), HttpStatus.INTERNAL_SERVER_ERROR);

    }
*/

    private String getHttpStatusAsString(HttpStatus status){
        return String.valueOf(status.value());
    }
}