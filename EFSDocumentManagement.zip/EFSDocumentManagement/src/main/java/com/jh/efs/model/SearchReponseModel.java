package com.jh.efs.model;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import io.swagger.annotations.ApiModelProperty;

@ToString
public class SearchReponseModel {
    @ApiModelProperty(value = "Message",required = true)
    private String message;

    @ApiModelProperty(value = "Key",required = true)
    private Key key;

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public Key getKey() {
        return key;
    }

    public void setKey(Key key) {
        this.key = key;
    }
}