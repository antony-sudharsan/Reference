package com.jh.efs;
import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import com.jh.common.logging.LoggerHandler;



@Component
public class OnStartUp {

    @Autowired
    private Environment env;

    @PostConstruct
    public void init() {
        try
        {
            LoggerHandler.getInstance(env.getProperty("log.appID"), env.getProperty("log.svcName"), env.getProperty("log.componentName"), env.getProperty("log.svcVersion"));
        } catch(Exception e)
        {
            System.out.println("Error in Log Initialization in EFS Doc Manangement service" + e.getStackTrace());;
        }
    }

}