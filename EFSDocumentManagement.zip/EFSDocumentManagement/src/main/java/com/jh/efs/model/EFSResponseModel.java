package com.jh.efs.model;

public class EFSResponseModel extends HeaderParamsModel {
}
