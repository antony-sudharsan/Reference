package com.jh.efs.exception;

import lombok.Getter;
import lombok.Setter;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(HttpStatus.NOT_FOUND)
public class EFSNotFoundException extends RuntimeException{

    @Getter
    @Setter
    private String details;
    public EFSNotFoundException(String exception){
        super(exception);
    }

    public EFSNotFoundException(String exception,String details){
        super(exception);
        this.details = details;
    }
}
