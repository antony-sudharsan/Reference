package com.jh.efs.model;

import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.List;

@ToString
public class SearchRequestBodyModel {


    @ApiModelProperty(value = "EQV List",required = true)
    private List<SearchParamsModel> eqv;

    public List<SearchParamsModel> getEqv() {
        return eqv;
    }

    public void setEqv(List<SearchParamsModel> eqv) {
        this.eqv = eqv;
    }
}