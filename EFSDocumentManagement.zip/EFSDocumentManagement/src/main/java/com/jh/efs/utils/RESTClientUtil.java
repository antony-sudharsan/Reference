package com.jh.efs.utils;

import com.jh.common.logging.LoggerHandler;
import com.jh.efs.constant.EFSURIConst;
import com.jh.efs.exception.EFSBadRequestException;
import com.jh.efs.exception.EFSInternalServerException;
import com.jh.efs.exception.EFSTimeOutException;
import com.jh.efs.exception.EFSUnAuthorizedException;
import com.jh.efs.config.ClientHttpRequestFactory;
import com.manulife.esb.wsdl.insurance.jh.efile.SearchDocumentMetadataFault;
import com.manulife.esb.xsd.common.jh.commonmessage.FaultType;
import org.springframework.http.*;
import org.springframework.web.client.*;

public class RESTClientUtil {

    public static ResponseEntity<String> callRESTAPI(RestTemplate restTemplate, HttpHeaders headers, String endPoint, HttpMethod method, String body) throws RuntimeException, SearchDocumentMetadataFault {

        restTemplate.setRequestFactory(ClientHttpRequestFactory.getInstance());


        String url = "https://efsjhann-np.dstcorp.net/testapp/EFSWS/api/v1/action" + endPoint;

        String messagepayloadRequest = "Header Detail : "+ headers.toString() + "  EFS URL : " +url +"   Method : "+ method.name() + "  Body : " +body;
        LoggerHandler.LogOut("DEBUG","1","EFSDocMan","EFSDocMan",RESTClientUtil.class.getName(),"EFS Request : => "+messagepayloadRequest);

        HttpEntity<String> entity = new HttpEntity<String>(body, headers);

        ResponseEntity<String> result = null;
        try {
            result = restTemplate.exchange(url, method, entity, String.class);
        }catch (HttpClientErrorException | HttpServerErrorException ex){
            LoggerHandler.ErrorOut(ex,"EFSUID","EFSsourceSystem",RESTClientUtil.class.getName(),"Exception From EFS System");
            if(HttpStatus.UNAUTHORIZED == ex.getStatusCode()){
                com.manulife.esb.xsd.insurance.jh.efile.SearchDocumentMetadataFault searchDocumentMetadataFault = new com.manulife.esb.xsd.insurance.jh.efile.SearchDocumentMetadataFault();
                FaultType fault = new FaultType();
                fault.setErrorCode("10001");
                fault.setErrorDescription("Invalid Credentials From EFS System");
                searchDocumentMetadataFault.setFault(fault);
                throw new SearchDocumentMetadataFault("Invalid Credentials",searchDocumentMetadataFault);
            }else if(HttpStatus.REQUEST_TIMEOUT == ex.getStatusCode()){

                com.manulife.esb.xsd.insurance.jh.efile.SearchDocumentMetadataFault searchDocumentMetadataFault = new com.manulife.esb.xsd.insurance.jh.efile.SearchDocumentMetadataFault();
                FaultType fault = new FaultType();
                fault.setErrorCode("10002");
                fault.setErrorDescription("Time Out Request From EFS System");
                searchDocumentMetadataFault.setFault(fault);
                throw new SearchDocumentMetadataFault("Time out Request",searchDocumentMetadataFault);

            }else if(HttpStatus.BAD_REQUEST == ex.getStatusCode()){

                com.manulife.esb.xsd.insurance.jh.efile.SearchDocumentMetadataFault searchDocumentMetadataFault = new com.manulife.esb.xsd.insurance.jh.efile.SearchDocumentMetadataFault();
                FaultType fault = new FaultType();
                fault.setErrorCode("TCH-GEN-5001");
                fault.setErrorDescription("B4vad Request From EFS System");
                searchDocumentMetadataFault.setFault(fault);
                throw new SearchDocumentMetadataFault("Invalid Request",searchDocumentMetadataFault);

            }else if(HttpStatus.INTERNAL_SERVER_ERROR == ex.getStatusCode()){

                com.manulife.esb.xsd.insurance.jh.efile.SearchDocumentMetadataFault searchDocumentMetadataFault = new com.manulife.esb.xsd.insurance.jh.efile.SearchDocumentMetadataFault();
                FaultType fault = new FaultType();
                fault.setErrorCode("10004");
                fault.setErrorDescription("Internal Server Error From EFS System");
                searchDocumentMetadataFault.setFault(fault);
                throw new SearchDocumentMetadataFault("Internal Server Error",searchDocumentMetadataFault);

            }else{
                com.manulife.esb.xsd.insurance.jh.efile.SearchDocumentMetadataFault searchDocumentMetadataFault = new com.manulife.esb.xsd.insurance.jh.efile.SearchDocumentMetadataFault();
                FaultType fault = new FaultType();
                fault.setErrorCode("10005");
                fault.setErrorDescription("Request fail To EFS System");
                searchDocumentMetadataFault.setFault(fault);
                throw new SearchDocumentMetadataFault("Request fail",searchDocumentMetadataFault);
            }
        }
        result = new ResponseEntity<String>((result.getBody() == null) ? "" : result.getBody().toString(), (EFSURIConst.LOGON.contains(endPoint)) ? result.getHeaders() :
                new HttpHeaders(), HttpStatus.OK);
        return result;
    }
}