package com.jh.efs.exception;

import lombok.Getter;
import lombok.Setter;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(HttpStatus.REQUEST_TIMEOUT)
public class EFSTimeOutException extends RuntimeException{

    @Getter
    @Setter
    private String details;
    public EFSTimeOutException(String exception){
        super(exception);
    }

    public EFSTimeOutException(String exception, String details){
        super(exception);
        this.details = details;
    }
}
