package com.jh.efs.model;

public class EFSRequestModel extends HeaderParamsModel {
}
