package com.jh.efs.endpoint;

import com.jh.common.logging.LoggerHandler;
import com.jh.efs.exception.BadRequestException;
import com.jh.efs.orchestration.EFSDocumentManagementOrchestration;
import com.jh.efs.utils.*;
import com.manulife.esb.xsd.common.jh.header.JHHeader;
import com.manulife.esb.xsd.insurance.jh.efile.SearchDocumentMetadataRequest;
import com.manulife.esb.xsd.insurance.jh.efile.SearchDocumentMetadataResponse;
import com.manulife.esb.xsd.insurance.jh.efile.UpdateDocumentMetadataRequest;
import com.manulife.esb.xsd.insurance.jh.efile.UpdateDocumentMetadataResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ws.context.MessageContext;
import org.springframework.ws.server.endpoint.annotation.Endpoint;
import org.springframework.ws.server.endpoint.annotation.PayloadRoot;
import org.springframework.ws.server.endpoint.annotation.RequestPayload;
import org.springframework.ws.server.endpoint.annotation.ResponsePayload;
import org.springframework.ws.soap.SoapHeaderElement;
import org.springframework.ws.soap.server.endpoint.annotation.SoapHeader;

/**
 * Exposes Producer2Application Operations via SOAP.
 */
@Endpoint
public class EFSDocumentManagementEndpoint {
    private static final String NAMESPACE_URI = "http://www.esb.manulife.com/xsd/insurance/jh/Efile";

    private static final String JH_HEADER_NS = "http://www.esb.manulife.com/xsd/common/jh/header";

    private final JHHeaderJaxbUtils jhHeaderJaxbUtils;
    private final LoggerUtils loggerUtils;

    EFSDocumentManagementOrchestration efsDocumentManagementOrchestration;

    @Autowired
    public EFSDocumentManagementEndpoint(final EFSDocumentManagementOrchestration efsDocumentManagementOrchestration,
                                         final JHHeaderJaxbUtils jhHeaderJaxbUtils, final LoggerUtils loggerUtils) {
        this.efsDocumentManagementOrchestration = efsDocumentManagementOrchestration;
        this.jhHeaderJaxbUtils = jhHeaderJaxbUtils;
        this.loggerUtils = loggerUtils;
    }


    @PayloadRoot(namespace = NAMESPACE_URI, localPart = "UpdateDocumentMetadata_request")
    @ResponsePayload
    public UpdateDocumentMetadataResponse updateDocumentMetadata(final @RequestPayload UpdateDocumentMetadataRequest request,
                                                             final @SoapHeader("{" + JH_HEADER_NS + "}JHHeader") SoapHeaderElement jhHeaderElement,
                                                             final MessageContext messageContext) throws Exception {
        UpdateDocumentMetadataResponse reply = null;
        JHHeader header = parseHeader(jhHeaderElement);
        JHHeaderUtils.validateHeader(header);

        final String messageUUID = JHHeaderUtils.retrieveOrDefaultMessageUID(header, "CheckLicenseStatus");
        final String sourceSystemName = JHHeaderUtils.retrieveOrDefaultSourceSystemName(header);

        try {
            LoggingContextHolder.getLoggingContext().setContext(messageUUID, sourceSystemName);
            LoggerHandler.LogOut("INFO", "1", messageUUID, sourceSystemName, this.getClass().getName(),
                    "Entering updateDocumentMetadata EndPoint " + loggerUtils.writeAsJson(request));

            reply = efsDocumentManagementOrchestration.updateDocumentMetadata(header, request);


            LoggerHandler.LogOut("INFO", "8", messageUUID, sourceSystemName, this.getClass().getName(),
                    "Exiting checkLicenseStatus EndPoint " + loggerUtils.writeAsJson(reply));

        } catch (final Exception e) {
            LoggerHandler.ErrorOut(e, messageUUID, sourceSystemName, this.getClass().getName(), e.getMessage());
            throw e;
        }

        // add response header as a property to be used by EndpointInterceptor
        // Current service does not modify header on response
        messageContext.setProperty(HeaderKey.JH_HEADER_KEY.getValue(), header);
        LoggingContextHolder.getLoggingContext().clear();

        return reply;
    }


    @PayloadRoot(namespace = NAMESPACE_URI, localPart = "SearchDocumentMetadata_request")
    @ResponsePayload
    public SearchDocumentMetadataResponse searchDocumentMetadata(final @RequestPayload SearchDocumentMetadataRequest request,
                                                             final @SoapHeader("{" + JH_HEADER_NS + "}JHHeader") SoapHeaderElement jhHeaderElement,
                                                             final MessageContext messageContext) throws Exception {
        SearchDocumentMetadataResponse reply = null;
        JHHeader header = parseHeader(jhHeaderElement);
        JHHeaderUtils.validateHeader(header);

        final String messageUUID = JHHeaderUtils.retrieveOrDefaultMessageUID(header, "CheckLicenseStatus");
        final String sourceSystemName = JHHeaderUtils.retrieveOrDefaultSourceSystemName(header);

        try {
            LoggingContextHolder.getLoggingContext().setContext(messageUUID, sourceSystemName);
            LoggerHandler.LogOut("INFO", "1", messageUUID, sourceSystemName, this.getClass().getName(),
                    "Entering searchDocumentMetadata EndPoint " + loggerUtils.writeAsJson(request));


            /**
             * Search Document
             *
             */
            reply =  efsDocumentManagementOrchestration.searchDocumentMetadata(header, request);

            LoggerHandler.LogOut("INFO", "8", messageUUID, sourceSystemName, this.getClass().getName(),
                    "Exiting searchDocumentMetadata EndPoint " + loggerUtils.writeAsJson(reply));

        } catch (final Exception e) {
            LoggerHandler.ErrorOut(e, messageUUID, sourceSystemName, this.getClass().getName(), e.getMessage());
            throw e;
        }

        // add response header as a property to be used by EndpointInterceptor
        // Current service does not modify header on response
        messageContext.setProperty(HeaderKey.JH_HEADER_KEY.getValue(), header);
        LoggingContextHolder.getLoggingContext().clear();

        return reply;
    }






    private JHHeader parseHeader(final SoapHeaderElement jhHeaderElement) {
        // parse JH Header if present
        JHHeader header = null;
        if (null != jhHeaderElement) {
            header = jhHeaderJaxbUtils.unmarshallJHHeader(jhHeaderElement);
        } else {
            throw new BadRequestException("Missing Header");
        }

        return header;
    }

}