package com.jh.efs.model;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import io.swagger.annotations.ApiModelProperty;

@ToString
public class HeaderParamsModel {


    @ApiModelProperty(value = "EFSAuth")
    private String EFSAuth;

    @ApiModelProperty(value = "EFSKey")
    private String EFSKey;

    @ApiModelProperty(value = "EFSDate")
    private String EFSDate;

    @ApiModelProperty(value = "EFSSign")
    private String EFSSign;

    public String getEFSAuth() {
        return EFSAuth;
    }

    public void setEFSAuth(String EFSAuth) {
        this.EFSAuth = EFSAuth;
    }

    public String getEFSKey() {
        return EFSKey;
    }

    public void setEFSKey(String EFSKey) {
        this.EFSKey = EFSKey;
    }

    public String getEFSDate() {
        return EFSDate;
    }

    public void setEFSDate(String EFSDate) {
        this.EFSDate = EFSDate;
    }

    public String getEFSSign() {
        return EFSSign;
    }

    public void setEFSSign(String EFSSign) {
        this.EFSSign = EFSSign;
    }
}
