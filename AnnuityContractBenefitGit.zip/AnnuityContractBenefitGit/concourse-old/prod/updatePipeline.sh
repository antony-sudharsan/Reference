#!/bin/bash

#fly --target manulife-ci login --concourse-url https://concourse.sys.use.cf.manulife.com --insecure

C:\Concorse\fly -t manulife-ci set-pipeline -c pipeline.yml -p WorkManagement -n -l ../concourse-credentials.yml

fly -t manulife-ci unpause-pipeline -p WorkManagement
