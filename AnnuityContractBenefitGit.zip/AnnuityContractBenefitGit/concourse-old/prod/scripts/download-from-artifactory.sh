#!/bin/bash
set -o errexit
set -o xtrace

TARGET_DIR=$PWD/target
mkdir -p $TARGET_DIR

cd gitfolder

export JFROG_CLI_OFFER_CONFIG=false && jfrog rt dl "soa-migration-maven-snapshot-local/com/manulife/poc/ankit/AnnuityContract/0.0.1-SNAPSHOT/*.jar" "--url=https://artifactory.platform.manulife.io/artifactory" --user=user --password=APCYXWVLjd5ufKYq

pwd
#TARGET_DIR=$PWD/target
#mkdir -p $TARGET_DIR
#cd gitfolder

ls -l
cp -R com/manulife/poc/ankit/AnnuityContract/0.0.1-SNAPSHOT/*.jar $TARGET_DIR/

  
cp manifest-dev.yml $TARGET_DIR/
cp manifest-test.yml $TARGET_DIR/
ls -l $TARGET_DIR
