package com.jh.annuity.utils;

import org.springframework.stereotype.Component;

import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;
import java.util.Date;
import java.util.GregorianCalendar;

/**
 * The type Annuity contract utils.
 */
@Component
public class AnnuityContractUtils {

    /**
     * Convert util date to gregoerian calendar xml gregorian calendar.
     *
     * @param inputDate the input date
     *
     * @return xml gregorian calendar
     */
    public XMLGregorianCalendar convertUtilDateToGregoerianCalendar(Date inputDate)  {
        GregorianCalendar gregorianCalContactEffDate = new GregorianCalendar();
        gregorianCalContactEffDate.setTime(inputDate);
        XMLGregorianCalendar date2 = null;
        try {
            date2 = DatatypeFactory.newInstance().newXMLGregorianCalendar(gregorianCalContactEffDate);
        } catch (Exception e) {

        }
        return date2;
    }



}
