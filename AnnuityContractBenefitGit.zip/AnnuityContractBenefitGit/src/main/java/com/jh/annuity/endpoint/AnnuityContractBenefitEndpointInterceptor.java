package com.jh.annuity.endpoint;

import com.jh.annuity.utils.HeaderKey;
import com.jh.annuity.utils.JHHeaderJaxbUtils;
import com.manulife.esb.xsd.common.jh.header.JHHeader;
import org.springframework.ws.context.MessageContext;
import org.springframework.ws.server.EndpointInterceptor;
import org.springframework.ws.soap.SoapHeader;
import org.springframework.ws.soap.SoapMessage;

/**
 * Interceptor for AnnuityContractBenefitEndpointInterceptor.
 */
public class AnnuityContractBenefitEndpointInterceptor implements EndpointInterceptor {

	private final JHHeaderJaxbUtils jhHeaderJaxbUtils;

    /**
     * Instantiates a new Annuity contract benefit endpoint interceptor.
     *
     * @param jhHeaderJaxbUtils the jh header jaxb utils
     */
    public AnnuityContractBenefitEndpointInterceptor(final JHHeaderJaxbUtils jhHeaderJaxbUtils) {
		this.jhHeaderJaxbUtils = jhHeaderJaxbUtils;
	}

	@Override
	public boolean handleRequest(final MessageContext messageContext, final Object endpoint) throws Exception {
		return true;
	}

	/**
	 * Adds SoapHeader for JHHeader if represent in the MessageContext.
	 *
	 * @see EndpointInterceptor#handleResponse(MessageContext,
	 *      Object)
	 */
	@Override
	public boolean handleResponse(final MessageContext messageContext, final Object endpoint) throws Exception {

		// if the header property is present then add a SoapHeader
		if (messageContext.containsProperty(HeaderKey.JH_HEADER_KEY.getValue())) {
			final JHHeader jhHeader = (JHHeader) messageContext.getProperty(HeaderKey.JH_HEADER_KEY.getValue());
			final SoapMessage soapMessage = (SoapMessage) messageContext.getResponse();
			final SoapHeader soapHeader = soapMessage.getSoapHeader();
			jhHeaderJaxbUtils.marshallJHHeaderToResult(jhHeader, soapHeader.getResult());
		}
		return true;
	}

	@Override
	public boolean handleFault(final MessageContext messageContext, final Object endpoint) throws Exception {
		return true;
	}

	@Override
	public void afterCompletion(final MessageContext messageContext, final Object endpoint, final Exception ex)
			throws Exception {
	}

}
