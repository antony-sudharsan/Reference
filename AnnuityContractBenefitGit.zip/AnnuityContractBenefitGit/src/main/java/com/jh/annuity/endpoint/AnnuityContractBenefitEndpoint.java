package com.jh.annuity.endpoint;

import com.jh.annuity.constants.AnnuityContractBenefitsConstants;
import com.jh.annuity.exception.BadRequestException;
import com.jh.annuity.exception.InvalidInputException;
import com.jh.annuity.exception.TechnicalErrorException;
import com.jh.annuity.model.GetAnnuityContractResponseWrapper;
import com.jh.annuity.orchestration.AnnuityContractBenefitsOrchestration;
import com.jh.annuity.utils.HeaderKey;
import com.jh.annuity.utils.JHHeaderJaxbUtils;
import com.jh.annuity.utils.LoggerUtils;
import com.jh.annuity.utils.LoggingContextHolder;
import com.jh.common.logging.LoggerHandler;
import com.manulife.esb.xsd.annuity.jh.annuitycontract.GetAnnuityContractFault;
import com.manulife.esb.xsd.annuity.jh.annuitycontract.GetAnnuityContractRequest;
import com.manulife.esb.xsd.annuity.jh.annuitycontract.GetAnnuityContractResponse;
import com.manulife.esb.xsd.common.jh.commonmessage.FaultType;
import com.manulife.esb.xsd.common.jh.header.JHHeader;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.QueryTimeoutException;
import org.springframework.ws.context.MessageContext;
import org.springframework.ws.server.endpoint.annotation.Endpoint;
import org.springframework.ws.server.endpoint.annotation.PayloadRoot;
import org.springframework.ws.server.endpoint.annotation.RequestPayload;
import org.springframework.ws.server.endpoint.annotation.ResponsePayload;
import org.springframework.ws.soap.SoapHeaderElement;
import org.springframework.ws.soap.server.endpoint.annotation.SoapHeader;

/**
 * The type Annuity contract benefit endpoint.
 */
@Endpoint
public class AnnuityContractBenefitEndpoint {

    private static final String NAMESPACE_URI = "http://www.esb.manulife.com/xsd/annuity/jh/AnnuityContract";


    private static final String JH_HEADER_NS = "http://www.esb.manulife.com/xsd/common/jh/header";

    @Autowired
    private AnnuityContractBenefitsOrchestration annuityContractBenefitsOrchestration;
    @Autowired
    private JHHeaderJaxbUtils jhHeaderJaxbUtils;
    @Autowired
    private LoggerUtils loggerUtils;


    /**
     * Instantiates a new Annuity contract benefit endpoint.
     *
     * @param annuityContractBenefitsOrchestration the annuity contract benefits orchestration
     * @param jhHeaderJaxbUtils                    the jh header jaxb utils
     * @param loggerUtils                          the logger utils
     */
    @Autowired
    public AnnuityContractBenefitEndpoint(AnnuityContractBenefitsOrchestration annuityContractBenefitsOrchestration, JHHeaderJaxbUtils jhHeaderJaxbUtils, LoggerUtils loggerUtils) {
        this.annuityContractBenefitsOrchestration = annuityContractBenefitsOrchestration;
        this.jhHeaderJaxbUtils = jhHeaderJaxbUtils;
        this.loggerUtils = loggerUtils;
    }

    /**
     * Gets contract details.
     *
     * @param request         the request
     * @param jhHeaderElement the jh header element
     * @param messageContext  the message context
     *
     * @return contract details
     *
     * @throws Exception the exception
     */
    @PayloadRoot(namespace = NAMESPACE_URI, localPart = "GetAnnuityContract_request")
    @ResponsePayload
    public GetAnnuityContractResponse getContractDetails(
            @RequestPayload GetAnnuityContractRequest request,
            @SoapHeader("{" + JH_HEADER_NS + "}JHHeader") SoapHeaderElement jhHeaderElement,
            MessageContext messageContext) throws Exception {

        GetAnnuityContractResponse reply = null;
        JHHeader header = parseHeader(jhHeaderElement);
        validateHeader(header);
        GetAnnuityContractResponseWrapper annuityContractResponseWrapper = new GetAnnuityContractResponseWrapper();
        String messageUUID = header.getMessageUID();
        String sourceSystemName = header.getMessageSource().getApplicationName();
        String userId = header.getMessageSource().getUserID();

        try {

            LoggerHandler.LogOut("INFO", "1", messageUUID, sourceSystemName, this.getClass().getName(),
                    "Entering Get Annuity Contract EndPoint " + loggerUtils.writeAsJson(request));

            annuityContractResponseWrapper = annuityContractBenefitsOrchestration.getContractDetails(header, request);


            LoggerHandler.LogOut("INFO", "6", messageUUID, sourceSystemName, this.getClass().getName(),
                    "Exiting GetAnnuityContract EndPoint " + loggerUtils.writeAsJson(reply));

            reply = annuityContractResponseWrapper.getGetAnnuityContractResponse();
        } catch (InvalidInputException e) {
            throw e;
        } catch (QueryTimeoutException e) {
            throw e;

        } catch (DataAccessException e) {
            throw e;

        } catch (Exception e) {
            throw new TechnicalErrorException(AnnuityContractBenefitsConstants.TECHNICAL_ERROR_CODE, e.getCause());
        }
        // add response header as a property to be used by EndpointInterceptor
        messageContext.setProperty(HeaderKey.JH_HEADER_KEY.getValue(), annuityContractResponseWrapper.getJhHeader());
        LoggingContextHolder.getLoggingContext().clear();

        return reply;
    }


    /**
     * @param jhHeaderElement
     *
     * @return
     */
    private JHHeader parseHeader(final SoapHeaderElement jhHeaderElement) {
        // parse JH Header if present
        JHHeader header = null;
        if (null != jhHeaderElement) {
            header = jhHeaderJaxbUtils.unmarshallJHHeader(jhHeaderElement);
        } else {
            throw new BadRequestException("Missing Header");
        }

        return header;
    }

    /**
     * @param header
     */
    private void validateHeader(final JHHeader header) {
        if ((header == null) || (header.getMessageSource() == null)
                || StringUtils.isEmpty(header.getMessageSource().getApplicationName())) {
            throw new BadRequestException("Invalid Header Sent");
        }
    }
}
