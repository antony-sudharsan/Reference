package com.jh.annuity.dao;

import com.jh.annuity.constants.AnnuityContractBenefitsConstants;
import com.jh.annuity.exception.QueryException;
import com.jh.annuity.exception.SQLServerErrorException;
import com.jh.annuity.exception.TechnicalErrorException;
import com.jh.annuity.model.GetAnnuityContractResponseWrapper;
import com.jh.common.logging.LoggerHandler;
import com.manulife.esb.xsd.annuity.jh.annuitycontract.GetAnnuityContractFault;
import com.manulife.esb.xsd.annuity.jh.annuitycontract.GetAnnuityContractResponse;
import com.manulife.esb.xsd.common.jh.commonmessage.FaultType;
import com.manulife.esb.xsd.common.jh.header.JHHeader;
import com.manulife.esb.xsd.common.jh.header.Status;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.QueryTimeoutException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.sql.SQLException;

/**
 * The type Annuity contract dao.
 */
@Component
public class AnnuityContractDAO {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Value("${RequestTimeoutLimit:10000}")
    private int requestTimeoutLimit;

    /**
     * Init.
     */
    @PostConstruct
    public void init() {
        if (requestTimeoutLimit != 0) {
            this.jdbcTemplate.setQueryTimeout(requestTimeoutLimit);
        }
    }


    public GetAnnuityContractResponseWrapper getContractDetailsData(JHHeader header, String contractID)
            throws Exception {
        GetAnnuityContractResponse annuityContractResponse = null;

        GetAnnuityContractResponseWrapper annuityContractResponseWrapper = new GetAnnuityContractResponseWrapper();
        try {

            String messageUUID = header.getMessageUID();
            String sourceSystemName = header.getMessageSource().getApplicationName();
            String userId = header.getMessageSource().getUserID();

            LoggerHandler.LogOut("INFO", "3", messageUUID, sourceSystemName, this.getClass().getName(), "Contract Id>" + contractID);

            annuityContractResponse = (GetAnnuityContractResponse) this.jdbcTemplate.queryForObject(AnnuityContractBenefitsConstants.GET_ANNUITY, new Object[]{contractID}, new ContractRowMapper());

            annuityContractResponseWrapper.setGetAnnuityContractResponse(annuityContractResponse);

            // Setting up the header values
            annuityContractResponseWrapper.setJhHeader(getStatusHeader(header,annuityContractResponse));

            LoggerHandler.LogOut("INFO", "4", messageUUID, sourceSystemName, this.getClass().getName(), "Exiting getContractDetailsData ");
            LoggerHandler.LogOut("DEBUG", "4", messageUUID, sourceSystemName, this.getClass().getName(), "Passed getContractDetailsData");
        } catch (QueryTimeoutException e) {
            throw new QueryException(AnnuityContractBenefitsConstants.TIMEOUT_ERROR_CODE, e.getCause());

        } catch (DataAccessException e) {
            throw new SQLServerErrorException(AnnuityContractBenefitsConstants.TECHNICAL_ERROR_CODE, e.getCause());

        } catch (Exception e) {
            throw new TechnicalErrorException(AnnuityContractBenefitsConstants.TECHNICAL_ERROR_CODE, e.getCause());
        } finally {

        }
        return annuityContractResponseWrapper;

    }

    /**
     *
     * @param header
     * @param annuityContractResponse
     * @return
     */
    private JHHeader  getStatusHeader(JHHeader header,GetAnnuityContractResponse annuityContractResponse){
        if(annuityContractResponse.getAnnuityContractId() !=  null){
            Status status = new Status();
            status.setStatusCode(0);
            status.setStatusDescription("OK");
            header.setStatus(status);
        }
        else{
            Status status = new Status();
            status.setStatusCode(1);
            status.setStatusDescription("Data not found");
            header.setStatus(status);
        }
        return header;
    }


}
