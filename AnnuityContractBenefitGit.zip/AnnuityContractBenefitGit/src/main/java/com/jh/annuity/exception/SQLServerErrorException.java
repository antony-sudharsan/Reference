package com.jh.annuity.exception;


import com.jh.annuity.utils.Utility;

/**
 * The type Sql server error exception.
 */
public class SQLServerErrorException extends BaseFaultException {
	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	private static final String DEFAULT_CODE = "TCH-JDBC-E5008";
	private static final String DEFAULT_REASON = "SQL Exception";
	private static final String FAULT_STRING = "JDBC SQL Exception";

	/**
	 * Instantiates a new Sql server error exception.
	 *
	 * @param message the message
	 * @param cause   the cause
	 */
	public SQLServerErrorException(final String message, final Throwable cause) {
		super(DEFAULT_CODE, DEFAULT_REASON, getMessage(message, cause), FAULT_STRING, cause);
	}

	private static String getMessage(final String message, final Throwable cause) {
		String detail = message;
		if (cause != null) {
			detail = message + ", " + Utility.getStackTrace(cause);
		}
		return detail;
	}

}
