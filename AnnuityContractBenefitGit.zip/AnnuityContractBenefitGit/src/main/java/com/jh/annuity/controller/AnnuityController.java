package com.jh.annuity.controller;

import com.jh.annuity.constants.AnnuityContractBenefitsConstants;
import com.jh.annuity.model.GetAnnuityContractRequestWrapper;
import com.jh.annuity.model.GetAnnuityContractResponseWrapper;
import com.jh.annuity.orchestration.AnnuityContractBenefitsOrchestration;
import com.jh.annuity.utils.JHHeaderUtils;
import com.jh.annuity.validator.AnnuityValidator;
import com.jh.common.logging.LoggerHandler;
import com.manulife.esb.xsd.annuity.jh.annuitycontract.GetAnnuityContractFault;
import com.manulife.esb.xsd.annuity.jh.annuitycontract.GetAnnuityContractRequest;
import com.manulife.esb.xsd.annuity.jh.annuitycontract.GetAnnuityContractResponse;
import com.manulife.esb.xsd.common.jh.commonmessage.FaultType;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

/**
 * The type Annuity controller.
 */
@RestController
@EnableSwagger2
public class AnnuityController {

    /**
     * The Annuity contract benefits orchestration.
     */
    @Autowired
	AnnuityContractBenefitsOrchestration annuityContractBenefitsOrchestration;

    /**
     * The Validator.
     */
    @Autowired
	AnnuityValidator validator;


    @ApiOperation(
	        value = "Get Annuity Contract Details",
	        notes = "Service will retrive Annuity Contract Details based on Contract ID",
	        response = GetAnnuityContractResponse.class)
	@ApiResponses(value = {
	        @ApiResponse(code = 200, message = "Success"),
	        @ApiResponse(code = 406, message = "Service Processing Error"),
	        @ApiResponse(code = 408, message = "Request Timeout"),	     
	        @ApiResponse(code = 500, message = "SQL Server Backend returned an error"),
	        @ApiResponse(code = 400, message = "Validation Failed"),
	        @ApiResponse(code = 404, message = "Annuity Contract Record not found "),
	        @ApiResponse(code = 401, message = "Unauthorized to perform operation")
	})
	
	
	@RequestMapping(value ="/jh/wealth/ann/contract/valuation", method = RequestMethod.POST,produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<GetAnnuityContractResponseWrapper>  getContractDetails( @RequestBody GetAnnuityContractRequestWrapper request)
	throws Exception
	{
		final String messageUUID = JHHeaderUtils.retrieveOrDefaultMessageUID(request.getJhHeader(),
				"checkLicenseStatus");
		final String sourceSystemName = JHHeaderUtils.retrieveOrDefaultSourceSystemName(request.getJhHeader());

		GetAnnuityContractResponseWrapper contractBenefits = null;
		try {
		
			LoggerHandler.LogOut("INFO", "1", messageUUID, sourceSystemName, this.getClass().getName(), "Entering getContract Controller");

			contractBenefits= (GetAnnuityContractResponseWrapper)annuityContractBenefitsOrchestration.getContractDetails(request.getJhHeader(), request.getGetAnnuityContractRequest());
			
			LoggerHandler.LogOut("INFO", "6", messageUUID, sourceSystemName, this.getClass().getName(), "Exiting getContract Controller");
			LoggerHandler.LogOut("DEBUG", "6", messageUUID, sourceSystemName, this.getClass().getName(), "Controller Create Success");

		} catch (final Exception e) {
            LoggerHandler.ErrorOut(e, messageUUID, sourceSystemName, this.getClass().getName(), e.getMessage());
            throw e;
        }

		HttpHeaders headers = new HttpHeaders();
		return  new ResponseEntity(contractBenefits,headers,HttpStatus.OK);


	}
	
		  


	    
	

}
