package com.jh.annuity.exception;


import com.jh.annuity.utils.Utility;

/**
 * The type Technical error exception.
 */
public class TechnicalErrorException extends BaseFaultException {
	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	private static final String DEFAULT_CODE = "9999";
	private static final String DEFAULT_REASON = "Technical Error";
	private static final String FAULT_STRING = "Internal Error";

    /**
     * Instantiates a new Technical error exception.
     *
     * @param message the message
     * @param cause   the cause
     */
    public TechnicalErrorException(final String message, final Throwable cause) {
		super(DEFAULT_CODE, DEFAULT_REASON, getMessage(message, cause), FAULT_STRING, cause);
	}

	private static String getMessage(final String message, final Throwable cause) {
		String detail = message;
		if (cause != null) {
			detail = message + ", " + Utility.getStackTrace(cause);
		}
		return detail;
	}

}
