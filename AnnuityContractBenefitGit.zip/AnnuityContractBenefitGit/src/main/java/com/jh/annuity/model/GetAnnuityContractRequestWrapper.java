package com.jh.annuity.model;

import com.manulife.esb.xsd.annuity.jh.annuitycontract.GetAnnuityContractRequest;
import com.manulife.esb.xsd.common.jh.header.JHHeader;

public class GetAnnuityContractRequestWrapper {

    private JHHeader jhHeader;

    private GetAnnuityContractRequest getAnnuityContractRequest;

    public JHHeader getJhHeader() {
        return jhHeader;
    }

    public void setJhHeader(JHHeader jhHeader) {
        this.jhHeader = jhHeader;
    }

    public GetAnnuityContractRequest getGetAnnuityContractRequest() {
        return getAnnuityContractRequest;
    }

    public void setGetAnnuityContractRequest(GetAnnuityContractRequest getAnnuityContractRequest) {
        this.getAnnuityContractRequest = getAnnuityContractRequest;
    }
}
