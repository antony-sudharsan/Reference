package com.jh.annuity.exception;

/**
 * The type Invalid input exception.
 */
public class InvalidInputException extends BaseFaultException {
	private static final long serialVersionUID = -6016805724195451879L;

	private static final String DEFAULT_CODE = "BIZ-DATA-E5003";
	private static final String DEFAULT_REASON = "Invalid Input Data";
	private static final String DEFAULT_DETAILS = "Invalid information entered for input.";
	private static final String FAULT_STRING = "Internal Error";

    /**
     * Instantiates a new Invalid input exception.
     */
    public InvalidInputException() {
		super(DEFAULT_CODE, DEFAULT_REASON, DEFAULT_DETAILS, FAULT_STRING);
	}

}
