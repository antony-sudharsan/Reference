package com.jh.annuity.model;

import com.manulife.esb.xsd.annuity.jh.annuitycontract.GetAnnuityContractResponse;
import com.manulife.esb.xsd.common.jh.header.JHHeader;

public class GetAnnuityContractResponseWrapper {

    private JHHeader jhHeader;
    private GetAnnuityContractResponse getAnnuityContractResponse;

    public JHHeader getJhHeader() {
        return jhHeader;
    }

    public void setJhHeader(JHHeader jhHeader) {
        this.jhHeader = jhHeader;
    }

    public GetAnnuityContractResponse getGetAnnuityContractResponse() {
        return getAnnuityContractResponse;
    }

    public void setGetAnnuityContractResponse(GetAnnuityContractResponse getAnnuityContractResponse) {
        this.getAnnuityContractResponse = getAnnuityContractResponse;
    }
}
