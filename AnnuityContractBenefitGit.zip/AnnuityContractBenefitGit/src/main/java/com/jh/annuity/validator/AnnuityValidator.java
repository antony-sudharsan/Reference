package com.jh.annuity.validator;

import com.jh.annuity.constants.AnnuityContractBenefitsConstants;
import com.jh.annuity.exception.InvalidInputException;
import com.manulife.esb.xsd.annuity.jh.annuitycontract.GetAnnuityContractFault;
import com.manulife.esb.xsd.common.jh.commonmessage.FaultType;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;

/**
 * The type Annuity validator.
 */
@Component
public class AnnuityValidator {

    /**
     * Validate request.
     *
     * @param contractID       the contract id
     * @param messageUUID      the message uuid
     * @param sourceSystemName the source system name
     *
     * @throws GetAnnuityContractFault the get annuity contract fault
     */
    public void  validateRequest(String contractID,String messageUUID, String sourceSystemName)
			throws InvalidInputException {

        if (checkIfNullorEmpty(contractID) || checkIfNullorEmpty(messageUUID) || checkIfNullorEmpty(sourceSystemName)) {

            new InvalidInputException();

        }

	}

    /**
     * Check if nullor empty boolean.
     *
     * @param targetCheckValue the target check value
     *
     * @return boolean
     */
    public boolean checkIfNullorEmpty(String targetCheckValue) {
		return (targetCheckValue == null || targetCheckValue.isEmpty());
	}

    /**
     * Check amount boolean.
     *
     * @param targetCheckValue the target check value
     *
     * @return boolean
     */
    public boolean checkAmount(BigDecimal targetCheckValue) {
		return (targetCheckValue.doubleValue() == 0);
	}

}