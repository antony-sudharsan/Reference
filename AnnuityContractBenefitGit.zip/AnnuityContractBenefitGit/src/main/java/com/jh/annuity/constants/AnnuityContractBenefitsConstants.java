package com.jh.annuity.constants;

/**
 * The type Annuity contract benefits constants.
 */
public class AnnuityContractBenefitsConstants {

    // ####### Error Messages #####################

    /**
     * The constant TECHNICAL_ERROR_REASON.
     */
    public static String TECHNICAL_ERROR_REASON = "Technical Error";
    /**
     * The constant INVALID_INPUT_ERROR_REASON.
     */
    public static String INVALID_INPUT_ERROR_REASON = "Invalid Input";
    /**
     * The constant TIMEOUT_ERROR_REASON.
     */
    public static String TIMEOUT_ERROR_REASON = "Service Timedout";
    /**
     * The constant NO_RECORD_FOUND_ERROR_REASON.
     */
    public static String NO_RECORD_FOUND_ERROR_REASON = "No Data Found";
    /**
     * The constant MAX_RECORD_ERROR_REASON.
     */
    public static String MAX_RECORD_ERROR_REASON = "Max Result Limit Encountered";


    // ####### Error Codes #####################

    /**
     * The constant TECHNICAL_ERROR_CODE.
     */
    public static String TECHNICAL_ERROR_CODE = "9999";
    /**
     * The constant INVALID_INPUT_ERROR_CODE.
     */
    public static String INVALID_INPUT_ERROR_CODE = "993";
    /**
     * The constant TIMEOUT_ERROR_CODE.
     */
    public static String TIMEOUT_ERROR_CODE = "99999";
    /**
     * The constant NO_RECORD_FOUND_ERROR_CODE.
     */
    public static String NO_RECORD_FOUND_ERROR_CODE = "999";
    /**
     * The constant MAX_RECORD_ERROR_CODE.
     */
    public static String MAX_RECORD_ERROR_CODE = "998";

    // ### Queries ##############################

    /**
     * The constant GET_ANNUITY.
     */
    public static String GET_ANNUITY = "SELECT JH_AnnuityContractID, ValuationDate,CurrentCashValue,GMDBAmount,DeathProceeds FROM ANN_CDL.dbo.tblValuation where JH_AnnuityContractID=?";

    /**
     * Instantiates a new Annuity contract benefits constants.
     */
    public AnnuityContractBenefitsConstants() {
    }
}
