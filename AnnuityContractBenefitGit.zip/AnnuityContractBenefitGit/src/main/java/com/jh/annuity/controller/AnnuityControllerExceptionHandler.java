package com.jh.annuity.controller;

import com.jh.annuity.exception.ExceptionResponse;
import com.manulife.esb.xsd.annuity.jh.annuitycontract.GetAnnuityContractFault;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

/**
 * The type Annuity controller exception handler.
 */
@ControllerAdvice
public class AnnuityControllerExceptionHandler extends ResponseEntityExceptionHandler{

    /**
     * Handle exception response entity.
     *
     * @param ex      the ex
     * @param request the request
     *
     * @return the response entity
     */
    @ExceptionHandler(GetAnnuityContractFault.class)
	public final ResponseEntity<Object> handleException(GetAnnuityContractFault ex, WebRequest request) {

		ExceptionResponse resp = new ExceptionResponse(ex.getFault().getErrorCode(),ex.getFault().getErrorDescription(),ex.getFault().getErrorDescription());

		 if (ex.getFault().getErrorCode().equals("TECHNICAL_ERROR_CODE")) {
			return new ResponseEntity(resp, HttpStatus.INTERNAL_SERVER_ERROR);
		}  else if (ex.getFault().getErrorCode().equals("TIMEOUT_ERROR_CODE")) {
			return new ResponseEntity(resp, HttpStatus.REQUEST_TIMEOUT);
		} else {
			return new ResponseEntity(resp, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

}
