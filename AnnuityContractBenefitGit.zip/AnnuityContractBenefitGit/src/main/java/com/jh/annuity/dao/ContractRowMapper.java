package com.jh.annuity.dao;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.jh.annuity.utils.AnnuityContractUtils;
import com.manulife.esb.xsd.annuity.jh.annuitycontract.ContractBenefits;
import com.manulife.esb.xsd.annuity.jh.annuitycontract.GetAnnuityContractResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import javax.xml.datatype.DatatypeConfigurationException;

/**
 * The type Contract row mapper.
 */
@Component
public class ContractRowMapper implements RowMapper{
	
	private static String JH_ANNUITYCONTRACT_ID = "JH_AnnuityContractID";
	private static String CURRENT_CASH_VALUE = "CurrentCashValue";
	private static String VALUATION_DATE = "ValuationDate";
	private static String DEATH_PROCEEDS = "DeathProceeds";
	private static String GMDB_AMOUNT = "GMDBAmount";

    /**
     * The Annuity contract utils.
     */
    AnnuityContractUtils annuityContractUtils = new AnnuityContractUtils();

    /**
     *
     * @param row
     * @param rowNum
     * @return
     * @throws SQLException
     */
   @Override
   public GetAnnuityContractResponse mapRow(ResultSet row, int rowNum) throws SQLException {

	   GetAnnuityContractResponse contractResponse = new GetAnnuityContractResponse();
	   ContractBenefits contractBenefits = new ContractBenefits();
	   contractResponse.setAnnuityContractId(row.getString(JH_ANNUITYCONTRACT_ID));
       contractBenefits.setContractAmt(row.getBigDecimal(CURRENT_CASH_VALUE));
       contractBenefits.setDeathBenefitAmt(row.getBigDecimal(DEATH_PROCEEDS));
       contractBenefits.setGuarMinDeathBenefitAmt(row.getBigDecimal(GMDB_AMOUNT));
       contractBenefits.setContractValueAsOfDate(annuityContractUtils.convertUtilDateToGregoerianCalendar(row.getDate(VALUATION_DATE)));
	   contractResponse.setContractBenefits(contractBenefits);

	return contractResponse;
   }
}