package com.jh.annuity.orchestration;

import com.jh.annuity.constants.AnnuityContractBenefitsConstants;
import com.jh.annuity.dao.AnnuityContractDAO;
import com.jh.annuity.exception.InvalidInputException;
import com.jh.annuity.exception.QueryException;
import com.jh.annuity.exception.SQLServerErrorException;
import com.jh.annuity.exception.TechnicalErrorException;
import com.jh.annuity.model.GetAnnuityContractResponseWrapper;
import com.jh.annuity.validator.AnnuityValidator;
import com.jh.common.logging.LoggerHandler;
import com.manulife.esb.xsd.annuity.jh.annuitycontract.GetAnnuityContractFault;
import com.manulife.esb.xsd.annuity.jh.annuitycontract.GetAnnuityContractRequest;
import com.manulife.esb.xsd.annuity.jh.annuitycontract.GetAnnuityContractResponse;
import com.manulife.esb.xsd.common.jh.commonmessage.FaultType;
import com.manulife.esb.xsd.common.jh.header.JHHeader;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.QueryTimeoutException;
import org.springframework.stereotype.Component;

/**
 * The type Annuity contract benefits orchestration.
 */
@Component
public class AnnuityContractBenefitsOrchestration {

    /**
     * The Annuity contract dao.
     */
    @Autowired
    AnnuityContractDAO annuityContractDAO;

    /**
     * The Annuity validator.
     */
    @Autowired
    AnnuityValidator annuityValidator;


    public GetAnnuityContractResponseWrapper getContractDetails(JHHeader header, GetAnnuityContractRequest request) throws Exception
    {
        GetAnnuityContractResponseWrapper annuityContractResponseWrapper = new GetAnnuityContractResponseWrapper();
        try {

            String messageUUID = header.getMessageUID();
            String sourceSystemName = header.getMessageSource().getApplicationName();
            String userId = header.getMessageSource().getUserID();

            annuityValidator.validateRequest(request.getAnnuityContractId(), messageUUID, sourceSystemName);

            LoggerHandler.LogOut("INFO", "2", messageUUID, sourceSystemName, this.getClass().getName(), "Entering getContractDetails");

            annuityContractResponseWrapper =  annuityContractDAO.getContractDetailsData(header, request.getAnnuityContractId());

            LoggerHandler.LogOut("INFO", "5", messageUUID, sourceSystemName, this.getClass().getName(), "Exiting getContractDetails ");
            LoggerHandler.LogOut("DEBUG", "5", messageUUID, sourceSystemName, this.getClass().getName(), "Passed getContractDetails");

        }catch (InvalidInputException e) {
            throw e;

        } catch (QueryTimeoutException e) {
            throw e;

        } catch (DataAccessException e) {
            throw e;

        }  catch (Exception e) {
            throw new TechnicalErrorException(AnnuityContractBenefitsConstants.TECHNICAL_ERROR_CODE, e.getCause());
        }
        return annuityContractResponseWrapper;
    }
}
