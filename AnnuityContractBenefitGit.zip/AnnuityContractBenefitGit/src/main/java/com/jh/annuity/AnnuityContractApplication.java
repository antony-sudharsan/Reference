package com.jh.annuity;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * The type Annuity contract application.
 */
@SpringBootApplication
public class AnnuityContractApplication {


    /**
     * The entry point of application.
     *
     * @param args the input arguments
     */
    public static void main(String[] args) {
		SpringApplication.run(AnnuityContractApplication.class, args);
	}
	

}
