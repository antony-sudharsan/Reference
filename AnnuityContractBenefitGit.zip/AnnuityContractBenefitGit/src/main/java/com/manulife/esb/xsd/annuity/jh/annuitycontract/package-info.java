@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.esb.manulife.com/xsd/annuity/jh/AnnuityContract", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.manulife.esb.xsd.annuity.jh.annuitycontract;
