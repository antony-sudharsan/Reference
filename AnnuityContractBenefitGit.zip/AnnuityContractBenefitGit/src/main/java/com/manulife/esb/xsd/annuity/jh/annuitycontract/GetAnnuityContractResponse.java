
package com.manulife.esb.xsd.annuity.jh.annuitycontract;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 *
 * <p>The following schema fragment specifies the expected content contained within this class.
 *
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/annuity/jh/AnnuityContract}AnnuityContractId"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/annuity/jh/AnnuityContract}ContractBenefits" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "annuityContractId",
    "contractBenefits"
})
@XmlRootElement(name = "GetAnnuityContract_response")
public class GetAnnuityContractResponse {

    /**
     * The Annuity contract id.
     */
    @XmlElement(name = "AnnuityContractId", required = true)
    protected String annuityContractId;
    /**
     * The Contract benefits.
     */
    @XmlElement(name = "ContractBenefits")
    protected ContractBenefits contractBenefits;

    /**
     * Gets the value of the annuityContractId property.
     *
     * @return possible      object is     {@link String }
     */
    public String getAnnuityContractId() {
        return annuityContractId;
    }

    /**
     * Sets the value of the annuityContractId property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setAnnuityContractId(String value) {
        this.annuityContractId = value;
    }

    /**
     * Gets the value of the contractBenefits property.
     *
     * @return possible      object is     {@link ContractBenefits }
     */
    public ContractBenefits getContractBenefits() {
        return contractBenefits;
    }

    /**
     * Sets the value of the contractBenefits property.
     *
     * @param value allowed object is     {@link ContractBenefits }
     */
    public void setContractBenefits(ContractBenefits value) {
        this.contractBenefits = value;
    }

}
