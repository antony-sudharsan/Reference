
package com.manulife.esb.xsd.annuity.jh.annuitycontract;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each
 * Java content interface and Java element interface
 * generated in the com.manulife.esb.xsd.annuity.jh.annuitycontract package.
 * <p>An ObjectFactory allows you to programatically
 * construct new instances of the Java representation
 * for XML content. The Java representation of XML
 * content can consist of schema derived interfaces
 * and classes representing the binding of schema
 * type definitions, element declarations and model
 * groups.  Factory methods for each of these are
 * provided in this class.
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _AnnuityContractId_QNAME = new QName("http://www.esb.manulife.com/xsd/annuity/jh/AnnuityContract", "AnnuityContractId");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.manulife.esb.xsd.annuity.jh.annuitycontract
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link ContractBenefits }
     *
     * @return the contract benefits
     */
    public ContractBenefits createContractBenefits() {
        return new ContractBenefits();
    }

    /**
     * Create an instance of {@link GetAnnuityContractFault }
     *
     * @return the get annuity contract fault
     */
    public GetAnnuityContractFault createGetAnnuityContractFault() {
        return new GetAnnuityContractFault();
    }

    /**
     * Create an instance of {@link GetAnnuityContractRequest }
     *
     * @return the get annuity contract request
     */
    public GetAnnuityContractRequest createGetAnnuityContractRequest() {
        return new GetAnnuityContractRequest();
    }

    /**
     * Create an instance of {@link GetAnnuityContractResponse }
     *
     * @return the get annuity contract response
     */
    public GetAnnuityContractResponse createGetAnnuityContractResponse() {
        return new GetAnnuityContractResponse();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/annuity/jh/AnnuityContract", name = "AnnuityContractId")
    public JAXBElement<String> createAnnuityContractId(String value) {
        return new JAXBElement<String>(_AnnuityContractId_QNAME, String.class, null, value);
    }

}
