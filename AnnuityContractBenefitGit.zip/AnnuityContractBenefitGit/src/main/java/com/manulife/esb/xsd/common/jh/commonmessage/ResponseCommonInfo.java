
package com.manulife.esb.xsd.common.jh.commonmessage;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.manulife.esb.xsd.common.jh.header.JHHeader;


/**
 * <p>Java class for ResponseCommonInfo complex type.
 *
 * <p>The following schema fragment specifies the expected content contained within this class.
 *
 * <pre>
 * &lt;complexType name="ResponseCommonInfo">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/common/jh/header}JHHeader"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ResponseCommonInfo", propOrder = {
    "jhHeader"
})
public class ResponseCommonInfo {

    /**
     * The Jh header.
     */
    @XmlElement(name = "JHHeader", namespace = "http://www.esb.manulife.com/xsd/common/jh/header", required = true)
    protected JHHeader jhHeader;

    /**
     * Gets the value of the jhHeader property.
     *
     * @return possible      object is     {@link JHHeader }
     */
    public JHHeader getJHHeader() {
        return jhHeader;
    }

    /**
     * Sets the value of the jhHeader property.
     *
     * @param value allowed object is     {@link JHHeader }
     */
    public void setJHHeader(JHHeader value) {
        this.jhHeader = value;
    }

}
