
package com.manulife.esb.xsd.annuity.jh.annuitycontract;

import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for anonymous complex type.
 *
 * <p>The following schema fragment specifies the expected content contained within this class.
 *
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="ContractValueAsOfDate" type="{http://www.w3.org/2001/XMLSchema}date"/>
 *         &lt;element name="ContractAmt" type="{http://www.w3.org/2001/XMLSchema}decimal"/>
 *         &lt;element name="GuarMinDeathBenefitAmt" type="{http://www.w3.org/2001/XMLSchema}decimal"/>
 *         &lt;element name="DeathBenefitAmt" type="{http://www.w3.org/2001/XMLSchema}decimal"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "contractValueAsOfDate",
    "contractAmt",
    "guarMinDeathBenefitAmt",
    "deathBenefitAmt"
})
@XmlRootElement(name = "ContractBenefits")
public class ContractBenefits {

    /**
     * The Contract value as of date.
     */
    @XmlElement(name = "ContractValueAsOfDate", required = true)
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar contractValueAsOfDate;
    /**
     * The Contract amt.
     */
    @XmlElement(name = "ContractAmt", required = true)
    protected BigDecimal contractAmt;
    /**
     * The Guar min death benefit amt.
     */
    @XmlElement(name = "GuarMinDeathBenefitAmt", required = true)
    protected BigDecimal guarMinDeathBenefitAmt;
    /**
     * The Death benefit amt.
     */
    @XmlElement(name = "DeathBenefitAmt", required = true)
    protected BigDecimal deathBenefitAmt;

    /**
     * Gets the value of the contractValueAsOfDate property.
     *
     * @return possible      object is     {@link XMLGregorianCalendar }
     */
    public XMLGregorianCalendar getContractValueAsOfDate() {
        return contractValueAsOfDate;
    }

    /**
     * Sets the value of the contractValueAsOfDate property.
     *
     * @param value allowed object is     {@link XMLGregorianCalendar }
     */
    public void setContractValueAsOfDate(XMLGregorianCalendar value) {
        this.contractValueAsOfDate = value;
    }

    /**
     * Gets the value of the contractAmt property.
     *
     * @return possible      object is     {@link BigDecimal }
     */
    public BigDecimal getContractAmt() {
        return contractAmt;
    }

    /**
     * Sets the value of the contractAmt property.
     *
     * @param value allowed object is     {@link BigDecimal }
     */
    public void setContractAmt(BigDecimal value) {
        this.contractAmt = value;
    }

    /**
     * Gets the value of the guarMinDeathBenefitAmt property.
     *
     * @return possible      object is     {@link BigDecimal }
     */
    public BigDecimal getGuarMinDeathBenefitAmt() {
        return guarMinDeathBenefitAmt;
    }

    /**
     * Sets the value of the guarMinDeathBenefitAmt property.
     *
     * @param value allowed object is     {@link BigDecimal }
     */
    public void setGuarMinDeathBenefitAmt(BigDecimal value) {
        this.guarMinDeathBenefitAmt = value;
    }

    /**
     * Gets the value of the deathBenefitAmt property.
     *
     * @return possible      object is     {@link BigDecimal }
     */
    public BigDecimal getDeathBenefitAmt() {
        return deathBenefitAmt;
    }

    /**
     * Sets the value of the deathBenefitAmt property.
     *
     * @param value allowed object is     {@link BigDecimal }
     */
    public void setDeathBenefitAmt(BigDecimal value) {
        this.deathBenefitAmt = value;
    }

}
