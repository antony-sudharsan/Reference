
package com.manulife.esb.xsd.common.jh.commonmessage;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for RequestParameters complex type.
 *
 * <p>The following schema fragment specifies the expected content contained within this class.
 *
 * <pre>
 * &lt;complexType name="RequestParameters">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="RequestParameter" type="{http://www.esb.manulife.com/xsd/common/jh/CommonMessage}RequestParameter"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "RequestParameters", propOrder = {
    "requestParameter"
})
public class RequestParameters {

    /**
     * The Request parameter.
     */
    @XmlElement(name = "RequestParameter", required = true)
    protected RequestParameter requestParameter;

    /**
     * Gets the value of the requestParameter property.
     *
     * @return possible      object is     {@link RequestParameter }
     */
    public RequestParameter getRequestParameter() {
        return requestParameter;
    }

    /**
     * Sets the value of the requestParameter property.
     *
     * @param value allowed object is     {@link RequestParameter }
     */
    public void setRequestParameter(RequestParameter value) {
        this.requestParameter = value;
    }

}
