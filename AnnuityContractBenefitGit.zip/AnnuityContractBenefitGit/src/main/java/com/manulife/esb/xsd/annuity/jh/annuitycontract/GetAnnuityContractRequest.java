
package com.manulife.esb.xsd.annuity.jh.annuitycontract;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 *
 * <p>The following schema fragment specifies the expected content contained within this class.
 *
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/annuity/jh/AnnuityContract}AnnuityContractId"/>
 *         &lt;element name="ContractBenefitsInd" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "annuityContractId",
    "contractBenefitsInd"
})
@XmlRootElement(name = "GetAnnuityContract_request")
public class GetAnnuityContractRequest {

    /**
     * The Annuity contract id.
     */
    @XmlElement(name = "AnnuityContractId", required = true)
    protected String annuityContractId;
    /**
     * The Contract benefits ind.
     */
    @XmlElement(name = "ContractBenefitsInd")
    protected Boolean contractBenefitsInd;

    /**
     * Gets the value of the annuityContractId property.
     *
     * @return possible      object is     {@link String }
     */
    public String getAnnuityContractId() {
        return annuityContractId;
    }

    /**
     * Sets the value of the annuityContractId property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setAnnuityContractId(String value) {
        this.annuityContractId = value;
    }

    /**
     * Gets the value of the contractBenefitsInd property.
     *
     * @return possible      object is     {@link Boolean }
     */
    public Boolean isContractBenefitsInd() {
        return contractBenefitsInd;
    }

    /**
     * Sets the value of the contractBenefitsInd property.
     *
     * @param value allowed object is     {@link Boolean }
     */
    public void setContractBenefitsInd(Boolean value) {
        this.contractBenefitsInd = value;
    }

}
