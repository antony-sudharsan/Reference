package com.jh.annuity.controller;

import com.jh.annuity.model.GetAnnuityContractRequestWrapper;
import com.jh.annuity.model.GetAnnuityContractResponseWrapper;
import com.jh.annuity.orchestration.AnnuityContractBenefitsOrchestration;
import com.jh.annuity.validator.AnnuityValidator;
import com.jh.common.logging.LoggerHandler;
import com.manulife.esb.xsd.annuity.jh.annuitycontract.ContractBenefits;
import com.manulife.esb.xsd.annuity.jh.annuitycontract.GetAnnuityContractRequest;
import com.manulife.esb.xsd.annuity.jh.annuitycontract.GetAnnuityContractResponse;
import com.manulife.esb.xsd.common.jh.header.JHHeader;
import com.manulife.esb.xsd.common.jh.header.MessageSource;
import com.manulife.esb.xsd.common.jh.header.ServiceInfo;
import org.codehaus.jackson.map.ObjectMapper;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;

import java.math.BigDecimal;

import static org.hamcrest.CoreMatchers.is;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@RunWith(SpringRunner.class)
/**
 * @WebMvcTest.
 * It will auto-configure the Spring MVC infrastructure for our unit tests.
 * Setting up WebMvc Context for the Controller which is under test("AnnuityController")
 */
@WebMvcTest(AnnuityController.class)
public class AnnuityContractControllerTest {

    /**
     * Initializing MockMvc
     */
    @Autowired
    private MockMvc mvc;

    @MockBean
    AnnuityValidator annuityValidator;
    GetAnnuityContractRequest annuityContractRequest = null;
    GetAnnuityContractRequestWrapper annuityContractRequestWrapper = null;
    JHHeader header = null;

    @Mock
    AnnuityController annuityController;
    GetAnnuityContractResponse annuityContractResponse = null;
    GetAnnuityContractResponseWrapper annuityContractResponseWrapper = null;
    /**
     * @MockBean
     * The class is included in the spring-boot-test library.
     * It allows to add Mockito mocks in a Spring ApplicationContext.
     * If a bean, compatible with the declared class exists in the context, it replaces it by the mock.
     * If it is not the case, it adds the mock in the context as a bean.
     */
    @MockBean
    private AnnuityContractBenefitsOrchestration annuityContractBenefitsOrchestration;

    /*
     * converts a Java object into JSON representation
     */
    public static String asJsonString(final Object obj) {
        try {
            String returnStr = new ObjectMapper().writeValueAsString(obj);
            return returnStr;

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * @Before
     * Method will be called before each test case execution
     */

	@Before
    public void setup() throws Exception{

        annuityContractRequest = new GetAnnuityContractRequest();
        annuityContractRequestWrapper = new GetAnnuityContractRequestWrapper();
        annuityContractResponse = new GetAnnuityContractResponse();
        annuityContractResponseWrapper = new GetAnnuityContractResponseWrapper();
        annuityContractRequest.setContractBenefitsInd(true);
        annuityContractRequest.setAnnuityContractId("FNA70053569");


        MessageSource messageSource = new MessageSource();
        ServiceInfo serviceInfo = new ServiceInfo();

        header = new JHHeader();

        header.setMessageUID("AAAA");

        messageSource.setUserID("CallidusCloud");
        messageSource.setApplicationName("575812");
        messageSource.setApplicationUserID("CallidusCloud");
        messageSource.setHostName("174.129.237.57");
        messageSource.setProcessID("1");

        serviceInfo.setServiceName("Annuity Contract");
        serviceInfo.setServiceOperation("getContractDetails");
        serviceInfo.setServiceVersion("1.0");

        header.setMessageSource(messageSource);
        header.setServiceInfo(serviceInfo);

        annuityContractResponse.setAnnuityContractId("FNA70053569");
        ContractBenefits contractBenefits = new ContractBenefits ();
    	contractBenefits.setContractAmt(new BigDecimal(50276));
    	contractBenefits.setDeathBenefitAmt(new BigDecimal(50276));
    	contractBenefits.setGuarMinDeathBenefitAmt(new BigDecimal(50143));
        annuityContractResponse.setContractBenefits(contractBenefits);
        annuityContractResponseWrapper.setGetAnnuityContractResponse(annuityContractResponse);
        annuityContractResponseWrapper.setJhHeader(header);

    	LoggerHandler.getInstance("AM","AnnuityContract", "AnnuityContract", "1.0");
    }

   @Test
    public void getContractDetailsTestAnnuity() throws Exception{
       when(annuityContractBenefitsOrchestration.getContractDetails(  any(JHHeader.class), any(GetAnnuityContractRequest.class))).thenReturn(annuityContractResponseWrapper);
        mvc.perform(post("/jh/wealth/ann/contract/valuation")
                .content(asJsonString(annuityContractResponseWrapper))
                .accept(MediaType.APPLICATION_JSON_VALUE)
                .contentType(MediaType.APPLICATION_JSON_VALUE)
                .header("MessageUUID", "1234")
                .header("sourceSystemName", "FNA"))
        		.andExpect(status().isOk())
                .andExpect(jsonPath("$.getAnnuityContractResponse.annuityContractId").value("FNA70053569"))
                .andExpect(jsonPath("$.getAnnuityContractResponse.contractBenefits.contractAmt", is(50276)))
                .andExpect(jsonPath("$.getAnnuityContractResponse.contractBenefits.guarMinDeathBenefitAmt", is(50143)))
                .andExpect(jsonPath("$.getAnnuityContractResponse.contractBenefits.deathBenefitAmt", is(50276)));
    }

    @Test
    public void getContractDetailsTestAnnuityValue() throws Exception{
        when(annuityContractBenefitsOrchestration.getContractDetails(  any(JHHeader.class), any(GetAnnuityContractRequest.class))).thenReturn(annuityContractResponseWrapper);
        mvc.perform(post("/jh/wealth/ann/contract/valuation")
                .content(asJsonString(annuityContractResponseWrapper))
                .accept(MediaType.APPLICATION_JSON_VALUE)
                .contentType(MediaType.APPLICATION_JSON_VALUE)
                .header("MessageUUID", "1234")
                .header("sourceSystemName", "FNA"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.getAnnuityContractResponse.annuityContractId").value("FNA70053569"))
                .andExpect(jsonPath("$.getAnnuityContractResponse.contractBenefits.contractAmt", is(50276)))
                .andExpect(jsonPath("$.getAnnuityContractResponse.contractBenefits.guarMinDeathBenefitAmt", is(50143)))
                .andExpect(jsonPath("$.getAnnuityContractResponse.contractBenefits.deathBenefitAmt", is(50276)));
    }

    @After
    public void teardown(){
        GetAnnuityContractRequest annuityContractRequest = null;
        GetAnnuityContractResponse annuityContractResponse = null;
    }

}