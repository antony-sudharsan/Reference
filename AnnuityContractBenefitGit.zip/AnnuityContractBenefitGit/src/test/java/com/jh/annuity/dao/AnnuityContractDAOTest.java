package com.jh.annuity.dao;

import com.jh.annuity.model.GetAnnuityContractRequestWrapper;
import com.jh.annuity.model.GetAnnuityContractResponseWrapper;
import com.jh.common.logging.LoggerHandler;
import com.manulife.esb.xsd.annuity.jh.annuitycontract.ContractBenefits;
import com.manulife.esb.xsd.annuity.jh.annuitycontract.GetAnnuityContractRequest;
import com.manulife.esb.xsd.annuity.jh.annuitycontract.GetAnnuityContractResponse;
import com.manulife.esb.xsd.common.jh.header.JHHeader;
import com.manulife.esb.xsd.common.jh.header.MessageSource;
import com.manulife.esb.xsd.common.jh.header.ServiceInfo;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.test.context.junit4.SpringRunner;

import java.math.BigDecimal;

import static junit.framework.TestCase.assertEquals;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@RunWith(SpringRunner.class)
public class AnnuityContractDAOTest {

    @Mock
    JdbcTemplate template = mock(JdbcTemplate.class);

    GetAnnuityContractRequest annuityContractRequest = null;
    GetAnnuityContractResponse annuityContractResponse = null;

    @InjectMocks
    AnnuityContractDAO annuityContractDAO;

    GetAnnuityContractRequestWrapper annuityContractRequestWrapper = null;
    JHHeader header = null;
    GetAnnuityContractResponseWrapper annuityContractResponseWrapper = null;


    @Before
    public void setup() throws Exception{

        annuityContractRequest = new GetAnnuityContractRequest();
        annuityContractRequestWrapper = new GetAnnuityContractRequestWrapper();
        annuityContractResponse = new GetAnnuityContractResponse();
        annuityContractResponseWrapper = new GetAnnuityContractResponseWrapper();
        annuityContractRequest.setContractBenefitsInd(true);
        annuityContractRequest.setAnnuityContractId("FNA70053569");


        MessageSource messageSource = new MessageSource();
        ServiceInfo serviceInfo = new ServiceInfo();

        header = new JHHeader();

        header.setMessageUID("AAAA");

        messageSource.setUserID("CallidusCloud");
        messageSource.setApplicationName("575812");
        messageSource.setApplicationUserID("CallidusCloud");
        messageSource.setHostName("174.129.237.57");
        messageSource.setProcessID("1");

        serviceInfo.setServiceName("Annuity Contract");
        serviceInfo.setServiceOperation("getContractDetails");
        serviceInfo.setServiceVersion("1.0");

        header.setMessageSource(messageSource);
        header.setServiceInfo(serviceInfo);

        annuityContractResponse.setAnnuityContractId("FNA70053569");
        ContractBenefits contractBenefits = new ContractBenefits ();
        contractBenefits.setContractAmt(new BigDecimal(50276));
        contractBenefits.setDeathBenefitAmt(new BigDecimal(50276));
        contractBenefits.setGuarMinDeathBenefitAmt(new BigDecimal(50143));
        annuityContractResponse.setContractBenefits(contractBenefits);
        annuityContractResponseWrapper.setGetAnnuityContractResponse(annuityContractResponse);
        annuityContractResponseWrapper.setJhHeader(header);

        LoggerHandler.getInstance("AM","AnnuityContract", "AnnuityContract", "1.0");
    }
    @Test
    public void getContractDetailsData() throws Exception {
        when(template.queryForObject(anyString(),any(Object[].class),any(RowMapper.class))).thenReturn(annuityContractResponse);
        GetAnnuityContractResponseWrapper annuityContractResponseWrapper = annuityContractDAO.getContractDetailsData(header, "FNA70053569");
        assertEquals("FNA70053569",annuityContractResponseWrapper.getGetAnnuityContractResponse().getAnnuityContractId());
        assertEquals(new BigDecimal(50276),annuityContractResponseWrapper.getGetAnnuityContractResponse().getContractBenefits().getContractAmt());

    }

    @Test
    public void getContractDetailsAllData() throws Exception {
        when(template.queryForObject(anyString(),any(Object[].class),any(RowMapper.class))).thenReturn(annuityContractResponse);
        GetAnnuityContractResponseWrapper annuityContractResponsewrapper = annuityContractDAO.getContractDetailsData(header, "FNA70053569");
        assertEquals("FNA70053569",annuityContractResponseWrapper.getGetAnnuityContractResponse().getAnnuityContractId());
        assertEquals(new BigDecimal(50276),annuityContractResponseWrapper.getGetAnnuityContractResponse().getContractBenefits().getContractAmt());
        assertEquals(new BigDecimal(50276),annuityContractResponseWrapper.getGetAnnuityContractResponse().getContractBenefits().getDeathBenefitAmt());
        assertEquals(new BigDecimal(50143),annuityContractResponseWrapper.getGetAnnuityContractResponse().getContractBenefits().getGuarMinDeathBenefitAmt());
    }
}