package com.jh.annuity.validator;

import com.jh.annuity.exception.BaseFaultException;
import com.jh.annuity.exception.InvalidInputException;
import com.manulife.esb.xsd.annuity.jh.annuitycontract.GetAnnuityContractFault;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.junit4.SpringRunner;

import static org.junit.Assert.assertTrue;

@RunWith(SpringRunner.class)
public class AnnuityValidatorTest {

    AnnuityValidator annuityValidator = null;

    @Before
    public void setUp() throws Exception {
        annuityValidator = new AnnuityValidator();
    }

    @After
    public void tearDown() throws Exception {
    }

    @Test
    public void validateNullValue() {
        assertTrue(annuityValidator.checkIfNullorEmpty(null));
    }

    @Test
    public void validateEmptyValue() {
        assertTrue(annuityValidator.checkIfNullorEmpty(""));
    }


}