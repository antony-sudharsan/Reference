package com.jh.annuity.utils;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.junit4.SpringRunner;

import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.GregorianCalendar;

import static org.junit.Assert.assertEquals;
@RunWith(SpringRunner.class)
public class AnnuityContractUtilsTest {

    Date oldDate;

    XMLGregorianCalendar xmlGregCal;
    AnnuityContractUtils annuityContractUtils = null;

    @Before
    public void setUp() throws Exception {
        annuityContractUtils = new AnnuityContractUtils();
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        oldDate = sdf.parse("21/12/2012");
        DateFormat format = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
        GregorianCalendar cal = new GregorianCalendar();
        cal.setTime(oldDate);
        xmlGregCal = DatatypeFactory.newInstance().newXMLGregorianCalendar(cal);
    }

    @After
    public void tearDown() throws Exception {
    }

    /**
     *
     */
    @Test
    public void convertUtilDateToGregoerianCalendar() {
        assertEquals(xmlGregCal,annuityContractUtils.convertUtilDateToGregoerianCalendar(oldDate));
    }
}