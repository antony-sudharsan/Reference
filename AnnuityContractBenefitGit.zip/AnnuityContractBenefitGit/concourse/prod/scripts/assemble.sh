#!/bin/bash
set -o errexit
set -o xtrace

TARGET_DIR=$PWD/target
mkdir -p $TARGET_DIR

cd source

#gradle assemble

chmod +x gradlew
APP_ENV=CI ./gradlew clean build -x test
pwd
ls -l
ls -l build/libs/
cp -R build $TARGET_DIR/
cp manifest-dev.yml $TARGET_DIR/
#cp manifest-uat.yml $TARGET_DIR/
#cp manifest-prod.yml $TARGET_DIR/
