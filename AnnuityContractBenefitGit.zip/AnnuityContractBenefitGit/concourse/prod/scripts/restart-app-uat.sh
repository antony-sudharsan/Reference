#!/bin/bash
set -o errexit
set -o xtrace

cf restage enterprise-pipeline-prod-demo-uat


