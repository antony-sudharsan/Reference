#!/bin/bash

# Replace GEES with the team name for your space
fly --target manulife-ci login --team-name GEES --concourse-url https://concourse.platform.manulife.io --insecure

# Replace 'enterprise-pipeline-prod-demo' with your application's pipeline name

fly -t manulife-ci set-pipeline -p enterprise-pipeline-prod-demo -c pipeline.yml -l config.yml

fly -t manulife-ci unpause-pipeline -p enterprise-pipeline-prod-demo
