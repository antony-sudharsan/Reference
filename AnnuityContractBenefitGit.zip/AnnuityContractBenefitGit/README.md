# ANNUITYCONTRACTBENEFIT  Design Document
## Introduction
    This document defines the service specification for SOA components making up the  AnnuityContractBenefit service for John Hancock LTC.
	This service supports operations related to AnnuityContractBenefit . The operations currently specified are:
	getContractDetails – Service will retrive Annuity Contract Details based on Contract ID 

## Operation
Operation|URI|Method
---|---|---
getContractDetails|/jh/wealth/ann/contract/valuation|GET


## Swagger URL
https://annuitycontract.apps.cac.preview.pcf.manulife.com/swagger-ui.html

## Audit Point
No|Reference Interpretation
---|---
1|Data received From Annuity
2|Data Sent to Annuity DB
3|Data Output received from Annuity DB
4|Data sent back to Annuity

## SOAP End Points


## HTTP Error Codes

Error Code|Error Description
---|---
200|Success
406|Service Processing Error
408|Request Timeout	     
500|SQL Server Backend returned an error
400|Validation Failed
404|Annuity Contract Record not found 
401|Unauthorized to perform operation
