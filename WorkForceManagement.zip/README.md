# Work Force Management Design Document
## Introduction
    This document defines the service specification for SOA components making up the Work Force Management service for John Hancock LTC.
    This service supports operations related to Work Force Management. The operations currently specified are:  

1. CreateObjects
2. UpdateObjects

## REST Operations
|Operation|URI|Method|
|---|:---:|---:|
|CreateObjects|/createobjects|POST|
|UpdateObjects|/updateobjects|POST|

# SOAP Endpoint URL
Operation|URI|Local Part|
---|---|---|
CreateObjects|https://workforcemanagement-dev.apps.cac.preview.pcf.manulife.com/|createObjects|
UpdateObjects|https://workforcemanagement-dev.apps.cac.preview.pcf.manulife.com/|updateObjects|

## Swagger URL
https://workforcemanagement-dev.apps.cac.preview.pcf.manulife.com/swagger-ui.html

## Audit Point
No|Reference Interpretation
---|---
1|Data received From Input
2|Data Sent to End System
3|Data Output received from End System
4|Data sent back to Output

## HTTP Error Codes
# For REST Service
Error Code|Error Description
---|---
200|Success
408|Request Timeout 
417|Max Records (Search only)       
500|Technical Error
400|Invalid Input, Bad Request of Validation Failed.
404|Record not found 

# For SOAP Service
Code|Reason|Detail
---|---|---
999|No Data Found|No Data Found based on criteria
993|Invalid Input|Invalid information entered for input.
998|[] records found, refine search criteria|[] records found, it is greater than user maximum input of []
9999|Technical Error|Stacktrace Message
99999|Service Timed Out|Service Timed Out


## Notes

Update Object Operation Flow:

The logic is as in TICBO
         
  1. Get the Business Area and Validate it, else throw exception
  2. Map the Retrieve input Object from the UpdateObjects request
  3. Invoke the invokeRetrieveService with the input object mapped in Step2
  4. Validate the whether any lock is present in the Retrieve Object, if locked throw LockedException
  5. Place a lock into the object using the invokeUpdateLockService
  6. Validate the response from the Step 5
  7. Now update the request object with the Lock status as "N"
  8. Update the Object by invoking the invokeUpdateWebService using the request in Step 7
  9. Map the Response to the SOAP response
