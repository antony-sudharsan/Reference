package com.jh.workmanagement.orchestration;

import com.jh.common.logging.LoggerHandler;
import com.jh.workmanagement.exception.InvalidBusinessAreaException;
import com.jh.workmanagement.exception.InvalidBusinessTypeException;
import com.jh.workmanagement.mapper.WorkManagementMapperHelper;
import com.jh.workmanagement.model.UpdateObjectsResponseWrapper;
import com.jh.workmanagement.service.WorkManagementWebServiceClient;
import com.jh.workmanagement.utils.LoggerUtils;
import com.jh.workmanagement.utils.LoggingContextHolder;
import com.jh.workmanagement.validator.WorkManagementValidator;
import com.manulife.esb.wsdl.wealth.pfs.workmanagement_1.WorkManagementFault;
import com.manulife.esb.xsd.common.jh.header.JHHeader;
import com.manulife.esb.xsd.jh.workmanagement.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.lang.Exception;
import java.util.ArrayList;
import java.util.List;

/**
 * The type Update work management orchestration.
 */
@Component
public class UpdateWorkManagementOrchestration {

    @Autowired
    private LoggerUtils loggerUtils;

    /**
     * The Work management validator.
     */
    @Autowired
    WorkManagementValidator workManagementValidator;


    /**
     * The Work management mapper helper.
     */
    @Autowired
    WorkManagementMapperHelper workManagementMapperHelper;

    /**
     * The Work management web service client.
     */
    @Autowired
    WorkManagementWebServiceClient workManagementWebServiceClient;

    /**
     * Update work management update objects response.
     *
     * @param header the source system name
     * @param request          the request
     *
     * @return the update objects response
     *
     * @throws WorkManagementFault the work management fault
     * @throws Exception           the exception
     */
    public UpdateObjectsResponseWrapper updateWorkManagement(JHHeader header, UpdateObjects request) throws WorkManagementFault, Exception {

        final String messageUUID = LoggingContextHolder.getLoggingContext().getMessageUUID();
        final String sourceSystemName = LoggingContextHolder.getLoggingContext().getSourceSystemName();
        String userId = header.getMessageSource().getUserID();

        UpdateObjectsResponseWrapper updateObjectsResponseWrapper = new UpdateObjectsResponseWrapper();

        System.out.println("Inside the Create  Orchestration Method >>"+loggerUtils.writeAsJson(request));
        LoggerHandler.LogOut("INFO", "1", "messageUUID", "sourceSystemName", this.getClass().getName(),
                "Entering Update Orchestration>> " + loggerUtils.writeAsJson(request));

        UpdateObjectsResponse updateObjectsResponse = new UpdateObjectsResponse();
        com.dstawd.processing.ws.UpdateObjects  awdUpdateObjectReq = mapInput(request);

        String businessArea = getBusinessArea(request);

        if (!workManagementValidator.ValidateBusinessArea(businessArea)) {
            throw new InvalidBusinessAreaException();
        }


        if (!workManagementValidator.ValidateBusinessType(request)) {
            throw new InvalidBusinessTypeException();
        }

        com.dstawd.processing.ws.UpdateObjectsResponse currentLockObjectAWDResponse = (com.dstawd.processing.ws.UpdateObjectsResponse) workManagementWebServiceClient.invokeRetrieveService("LIFE", messageUUID, sourceSystemName, awdUpdateObjectReq);


        if (workManagementValidator.validateLock(currentLockObjectAWDResponse.getUpdateObjectsResponse(),messageUUID,sourceSystemName) ){

            com.dstawd.processing.ws.UpdateObjectsResponse updateLockObjectAWDResponse = (com.dstawd.processing.ws.UpdateObjectsResponse) workManagementWebServiceClient.invokeUpdateLockService("LIFE", messageUUID, sourceSystemName, awdUpdateObjectReq);

            if (workManagementValidator.validateLockUpdateRequest(updateLockObjectAWDResponse.getUpdateObjectsResponse(), messageUUID,sourceSystemName)) {
                // TODO how to get the business area



                com.dstawd.processing.ws.UpdateObjectsResponse updateObjectAWDResponse = (com.dstawd.processing.ws.UpdateObjectsResponse) workManagementWebServiceClient.invokeUpdateWebService("LIFE", messageUUID, sourceSystemName, awdUpdateObjectReq);

                updateObjectsResponse = mapOutput(updateObjectAWDResponse.getUpdateObjectsResponse(), updateObjectsResponse);
            }

        }

        LoggerHandler.LogOut("INFO", "1", "messageUUID", "sourceSystemName", this.getClass().getName(),
                "Existing Update Orchestration>> " + loggerUtils.writeAsJson(updateObjectsResponse));
        updateObjectsResponseWrapper.setHeader(header);
        updateObjectsResponseWrapper.setUpdateObjects(updateObjectsResponse);
        return updateObjectsResponseWrapper;
    }

    private String getBusinessArea(UpdateObjects request) {
        String businessArea = "";
        if (request.getUpdateObjectRequest().getUpdateFolderInstanceOrUpdateSourceInstanceOrUpdateWorkInstance() != null) {

            List<Object> awdInstancesList = request.getUpdateObjectRequest().getUpdateFolderInstanceOrUpdateSourceInstanceOrUpdateWorkInstance();

            if (awdInstancesList != null) {

                for (int i = 0; i < awdInstancesList.size(); i++) {

                    Object obj = awdInstancesList.get(i);

                    if (obj instanceof CreateWorkInstance) {
                        CreateWorkInstance createWorkInstance = (CreateWorkInstance) obj;

                        businessArea = createWorkInstance.getCreateAWDInstance().getBusinessArea().toUpperCase();

                    }

                }
            }

        }
        return businessArea;
    }

    /**
     * Map output update objects response.
     *
     * @param updateObjectAWDResponse the update object awd response
     * @param updateObjectsResponse   the update objects response
     *
     * @return the update objects response
     */
    public UpdateObjectsResponse mapOutput(com.dstawd.processing.ws.GetObjectsResponse updateObjectAWDResponse, UpdateObjectsResponse updateObjectsResponse){

        GetObjectsResponse objectsResponse = new GetObjectsResponse();

        if(updateObjectAWDResponse.getImmediateRelationships() != null){
            objectsResponse.setImmediateRelationships(workManagementMapperHelper.mapImmediateRelationships(updateObjectAWDResponse.getImmediateRelationships()));
        }
        objectsResponse.setFolderInstanceOrSourceInstanceOrWorkInstance(workManagementMapperHelper.returnMapAWDInstance(updateObjectAWDResponse.getWorkInstanceOrFolderInstanceOrSourceInstance()));

        updateObjectsResponse.setUpdateObjectsResponse(objectsResponse);
        return updateObjectsResponse;
    }


    /**
     * Map input com . dstawd . processing . ws . update objects.
     *
     * @param wmRequest the wm request
     *
     * @return the com . dstawd . processing . ws . update objects
     */
    public com.dstawd.processing.ws.UpdateObjects mapInput(UpdateObjects wmRequest) {

        com.dstawd.processing.ws.UpdateObjects outUpdateAWDRequest = new com.dstawd.processing.ws.UpdateObjects();

        com.dstawd.processing.ws.UpdateObjectRequest outUpdateObjectRequest = new com.dstawd.processing.ws.UpdateObjectRequest();

        if(wmRequest.getUpdateObjectRequest() != null && wmRequest.getUpdateObjectRequest().getResponseDetails() != null ) {
            outUpdateObjectRequest.setResponseDetails(workManagementMapperHelper.mapResponseDetails(wmRequest.getUpdateObjectRequest().getResponseDetails()));
        }

        outUpdateObjectRequest.setUpdateWorkInstanceOrUpdateFolderInstanceOrUpdateSourceInstance(mapAWDInstance(wmRequest.getUpdateObjectRequest().getUpdateFolderInstanceOrUpdateSourceInstanceOrUpdateWorkInstance()));

        outUpdateAWDRequest.setUpdateObjectRequest(outUpdateObjectRequest);

        return outUpdateAWDRequest;

    }

    /**
     * Map awd instance list.
     *
     * @param inputAWDInstanceList the input awd instance list
     *
     * @return the list
     */
    public List<com.dstawd.processing.ws.UpdateAWDInstance> mapAWDInstance(List<Object> inputAWDInstanceList) {

        List<com.dstawd.processing.ws.UpdateAWDInstance> outUpdateAWDInstaceList = new ArrayList<>();

        if (inputAWDInstanceList != null) {

            for (int i = 0; i < inputAWDInstanceList.size(); i++) {

                Object obj = inputAWDInstanceList.get(i);

                if (obj instanceof UpdateFolderInstance) {
                    UpdateFolderInstance inUpdateFolderInstance = (UpdateFolderInstance) obj;

                    com.dstawd.processing.ws.UpdateFolderInstance outUpdateFolderInstance = new com.dstawd.processing.ws.UpdateFolderInstance();

                    outUpdateFolderInstance.setType(inUpdateFolderInstance.getUpdateAWDInstance().getType());
                    outUpdateFolderInstance.setBusinessArea(inUpdateFolderInstance.getUpdateAWDInstance().getBusinessArea());
                    outUpdateFolderInstance.setId(inUpdateFolderInstance.getUpdateAWDInstance().getId());
                    outUpdateFolderInstance.setDuration(inUpdateFolderInstance.getUpdateAWDInstance().getDuration());
                    // Mapping the Field Value
                    outUpdateFolderInstance.setFieldValues(mapFieldValue(inUpdateFolderInstance.getUpdateAWDInstance().getFieldValues().getDeleteFieldValueOrFieldValue()));

                    outUpdateFolderInstance.setAddManualComment(inUpdateFolderInstance.getUpdateAWDInstance().getAddManualComment());
                    outUpdateFolderInstance.setLock(inUpdateFolderInstance.getUpdateAWDInstance().getLock());

                    outUpdateAWDInstaceList.add(outUpdateFolderInstance);

                } else if (obj instanceof UpdateSourceInstance) {
                    com.dstawd.processing.ws.UpdateSourceInstance outUpdateSourceInstance = new com.dstawd.processing.ws.UpdateSourceInstance();
                    UpdateSourceInstance inUpdateSourceInstance = (UpdateSourceInstance) obj;


                    outUpdateSourceInstance.setLock(inUpdateSourceInstance.getUpdateAWDInstance().getLock());
                    outUpdateSourceInstance.setAddManualComment(inUpdateSourceInstance.getUpdateAWDInstance().getAddManualComment());
                    outUpdateSourceInstance.setDuration(inUpdateSourceInstance.getUpdateAWDInstance().getDuration());
                    outUpdateSourceInstance.setId(inUpdateSourceInstance.getUpdateAWDInstance().getId());
                    outUpdateSourceInstance.setBusinessArea(inUpdateSourceInstance.getUpdateAWDInstance().getBusinessArea());
                    outUpdateSourceInstance.setType(inUpdateSourceInstance.getUpdateAWDInstance().getType());

                    // Map the FieldValues
                    outUpdateSourceInstance.setFieldValues(mapFieldValue(inUpdateSourceInstance.getUpdateAWDInstance().getFieldValues().getDeleteFieldValueOrFieldValue()));

                    outUpdateSourceInstance.setAccessMethod(inUpdateSourceInstance.getAccessMethod());
                    outUpdateSourceInstance.setAnnotationBlob(inUpdateSourceInstance.getAnnotationBlob());
                    outUpdateSourceInstance.setArchiveBox(inUpdateSourceInstance.getArchiveBox());
                    outUpdateSourceInstance.setArchiveStartPage(inUpdateSourceInstance.getArchiveStartPage());
                    outUpdateSourceInstance.setReceiveTime(inUpdateSourceInstance.getReceiveTime());


                    outUpdateSourceInstance.setFormat(inUpdateSourceInstance.getFormat());
                    outUpdateSourceInstance.setMailType(inUpdateSourceInstance.getMailType());
                    outUpdateSourceInstance.setPageCount(String.valueOf(inUpdateSourceInstance.getPageCount()));
                    outUpdateSourceInstance.setReceiveTime(inUpdateSourceInstance.getReceiveTime());
                    outUpdateSourceInstance.setSecurityLevel(inUpdateSourceInstance.getSecurityLevel());

                    outUpdateAWDInstaceList.add(outUpdateSourceInstance);

                } else if (obj instanceof UpdateWorkInstance) {
                    com.dstawd.processing.ws.UpdateWorkInstance outUpdateWorkInstance = new com.dstawd.processing.ws.UpdateWorkInstance();
                    UpdateWorkInstance inUpdateWorkInstance = (UpdateWorkInstance) obj;

                    outUpdateWorkInstance.setLock(inUpdateWorkInstance.getUpdateAWDInstance().getLock());
                    outUpdateWorkInstance.setAddManualComment(inUpdateWorkInstance.getUpdateAWDInstance().getAddManualComment());
                    outUpdateWorkInstance.setDuration(inUpdateWorkInstance.getUpdateAWDInstance().getDuration());
                    outUpdateWorkInstance.setId(inUpdateWorkInstance.getUpdateAWDInstance().getId());
                    outUpdateWorkInstance.setBusinessArea(inUpdateWorkInstance.getUpdateAWDInstance().getBusinessArea());
                    outUpdateWorkInstance.setType(inUpdateWorkInstance.getUpdateAWDInstance().getType());

                    // Map the FieldValues
                    outUpdateWorkInstance.setFieldValues(mapFieldValue(inUpdateWorkInstance.getUpdateAWDInstance().getFieldValues().getDeleteFieldValueOrFieldValue()));


                    if(outUpdateWorkInstance.getSuspend() != null) {
                        outUpdateWorkInstance.setSuspend(mapSuspend(inUpdateWorkInstance.getSuspend()));
                    }
                    outUpdateWorkInstance.setStatus(inUpdateWorkInstance.getStatus());
                    outUpdateWorkInstance.setWorkStep(inUpdateWorkInstance.getWorkStep());
                    if(outUpdateWorkInstance.getRouting() != null) {
                        outUpdateWorkInstance.setRouting(mapRouting(inUpdateWorkInstance.getRouting()));
                    }
                    outUpdateWorkInstance.setQueue(inUpdateWorkInstance.getQueue());
                    outUpdateWorkInstance.setPriority(inUpdateWorkInstance.getPriority());
                    outUpdateWorkInstance.setPriorityIncrease(inUpdateWorkInstance.getPriorityIncrease());
                    outUpdateWorkInstance.setAssignTo(inUpdateWorkInstance.getAssignTo());
                    outUpdateWorkInstance.setAutocase(inUpdateWorkInstance.getAutocase());

                    outUpdateAWDInstaceList.add(outUpdateWorkInstance);
                }
            }
        }
        return outUpdateAWDInstaceList;
    }

    /**
     * Map routing com . dstawd . processing . ws . routing.
     *
     * @param inRouting the in routing
     *
     * @return the com . dstawd . processing . ws . routing
     */
    public com.dstawd.processing.ws.Routing mapRouting (Routing inRouting){
        com.dstawd.processing.ws.Routing retRouting = new com.dstawd.processing.ws.Routing();

        retRouting.setBusinessArea(inRouting.getBusinessArea());
        retRouting.setRoute(inRouting.getRoute());
        retRouting.setStatus(inRouting.getStatus());
        retRouting.setType(inRouting.getType());
        retRouting.setValue(inRouting.getValue());

        return retRouting;
    }

    /**
     * Map suspend com . dstawd . processing . ws . suspend.
     *
     * @param inSuspend the in suspend
     *
     * @return the com . dstawd . processing . ws . suspend
     */
    public com.dstawd.processing.ws.Suspend mapSuspend(Suspend inSuspend) {
        com.dstawd.processing.ws.Suspend outSupend = new com.dstawd.processing.ws.Suspend();

        if(inSuspend != null) {
            outSupend.setActivationDate(inSuspend.getActivationDate());
            outSupend.setActivationRoutingStatus(inSuspend.getActivationRoutingStatus());
            outSupend.setDuration(inSuspend.getDuration());
            outSupend.setReasonCode(inSuspend.getReasonCode());
        }
        return outSupend;
    }


    /**
     * Map field value com . dstawd . processing . ws . update awd instance . field values.
     *
     * @param inputObjectList the input object list
     *
     * @return the com . dstawd . processing . ws . update awd instance . field values
     */
    public com.dstawd.processing.ws.UpdateAWDInstance.FieldValues mapFieldValue(List<Object> inputObjectList) {

        com.dstawd.processing.ws.UpdateAWDInstance.FieldValues outFieldValues = new com.dstawd.processing.ws.UpdateAWDInstance.FieldValues();
        List<Object>  outFieldValueList;

        if (inputObjectList != null && inputObjectList.size() > 0) {
            outFieldValueList = new ArrayList<>();
            com.dstawd.processing.ws.FieldValue retFieldValue = null;
            com.dstawd.processing.ws.DeleteFieldValue retDeleteFieldValue = null;

            for (int i = 0; i < inputObjectList.size(); i++) {
                Object inputObj = inputObjectList.get(i);

                if(inputObj instanceof DeleteFieldValue){
                    retDeleteFieldValue = new com.dstawd.processing.ws.DeleteFieldValue();
                    retDeleteFieldValue.setName(((DeleteFieldValue) inputObj).getName());
                    outFieldValueList.add(retDeleteFieldValue);
                } else if(inputObj instanceof FieldValue){
                    retFieldValue = new com.dstawd.processing.ws.FieldValue();
                    retFieldValue.setName(((FieldValue) inputObj).getName());
                    retFieldValue.setValue(((FieldValue) inputObj).getValue());
                    retFieldValue.setSequence(((FieldValue) inputObj).getSequence());
                    outFieldValueList.add(retFieldValue);
                }

            }

            outFieldValues.setFieldValueOrDeleteFieldValue(outFieldValueList);
        }


        return outFieldValues;
    }


}
