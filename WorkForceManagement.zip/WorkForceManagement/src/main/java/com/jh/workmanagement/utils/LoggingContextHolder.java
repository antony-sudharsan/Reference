package com.jh.workmanagement.utils;

/**
 * The type Logging context holder.
 */
public final class LoggingContextHolder {

	private LoggingContextHolder() {

	}

	private static ThreadLocal<LoggingContext> holder = new ThreadLocal<LoggingContext>() {
		@Override
		public LoggingContext initialValue() {
			return new LoggingContext();
		}
	};

    /**
     * Gets logging context.
     *
     * @return the logging context
     */
    public static LoggingContext getLoggingContext() {
		return holder.get();
	}
}
