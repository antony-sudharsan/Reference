package com.jh.workmanagement.model;

import com.manulife.esb.xsd.common.jh.header.JHHeader;
import com.manulife.esb.xsd.jh.workmanagement.CreateObjectsResponse;

public class CreateObjectsResponseWrapper {

    private JHHeader header;
    private CreateObjectsResponse createObjectsResponse;

    public JHHeader getHeader() {
        return header;
    }

    public void setHeader(JHHeader header) {
        this.header = header;
    }

    public CreateObjectsResponse getCreateObjectsResponse() {
        return createObjectsResponse;
    }

    public void setCreateObjectsResponse(CreateObjectsResponse createObjectsResponse) {
        this.createObjectsResponse = createObjectsResponse;
    }


}
