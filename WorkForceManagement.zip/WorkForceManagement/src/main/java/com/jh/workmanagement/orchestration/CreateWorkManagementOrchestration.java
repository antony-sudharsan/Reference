package com.jh.workmanagement.orchestration;

import com.jh.common.logging.LoggerHandler;
import com.jh.workmanagement.exception.InvalidBusinessAreaException;
import com.jh.workmanagement.exception.InvalidBusinessTypeException;
import com.jh.workmanagement.mapper.WorkManagementMapperHelper;
import com.jh.workmanagement.model.CreateObjectsResponseWrapper;
import com.jh.workmanagement.service.WorkManagementWebServiceClient;
import com.jh.workmanagement.utils.LoggerUtils;
import com.jh.workmanagement.utils.LoggingContextHolder;
import com.jh.workmanagement.validator.WorkManagementValidator;
import com.manulife.esb.wsdl.wealth.pfs.workmanagement_1.WorkManagementFault;
import com.manulife.esb.xsd.common.jh.header.JHHeader;
import com.manulife.esb.xsd.jh.workmanagement.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.lang.Exception;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

/**
 * The type Create work management orchestration.
 */
@Component
public class CreateWorkManagementOrchestration {

    @Autowired
    private LoggerUtils loggerUtils;

    /**
     * The Work management validator.
     */
    @Autowired
    WorkManagementValidator workManagementValidator;

    /**
     * The Work management mapper helper.
     */
    @Autowired
    WorkManagementMapperHelper workManagementMapperHelper;

    /**
     * The Work management web service client.
     */
    @Autowired
    WorkManagementWebServiceClient workManagementWebServiceClient;

    /**
     * Create work management create objects response.
     *
     * @param header           the JHHeader
     *
     * @return the create objects response
     *
     * @throws WorkManagementFault the work management fault
     * @throws Exception           the exception
     */
    public CreateObjectsResponseWrapper createWorkManagement(JHHeader header, CreateObjects request) throws WorkManagementFault, Exception {

        final String messageUUID = LoggingContextHolder.getLoggingContext().getMessageUUID();
        final String sourceSystemName = LoggingContextHolder.getLoggingContext().getSourceSystemName();

        System.out.println("Inside the Create  Orchestration Method >>" + loggerUtils.writeAsJson(request));
        LoggerHandler.LogOut("INFO", "1", "messageUUID", "sourceSystemName", this.getClass().getName(),
                "Entering Create Orchestration>> " + loggerUtils.writeAsJson(request));
        CreateObjectsResponseWrapper createObjectsResponseWrapper = new CreateObjectsResponseWrapper();
        CreateObjectsResponse createObjectsResponse = new CreateObjectsResponse();
        // TODO Business Validation
        String businessArea = getBusinessArea(request);

        if (!workManagementValidator.ValidateBusinessArea(businessArea)) {
            throw new InvalidBusinessAreaException();
        }


        if (workManagementValidator.ValidateBusinessType(request)) {
            throw new InvalidBusinessTypeException();
        }

        com.dstawd.processing.ws.CreateObjects awdCreateRequest = mapInput(request);


        LoggerHandler.LogOut("INFO", "1", "messageUUID", "sourceSystemName", this.getClass().getName(),
                "The Value of the businessArea>> " + businessArea);

        com.dstawd.processing.ws.CreateObjectsResponse createObjectAWDResponse = (com.dstawd.processing.ws.CreateObjectsResponse) workManagementWebServiceClient.invokeCreateWebService(businessArea, messageUUID, sourceSystemName, awdCreateRequest);

        createObjectsResponse = mapOutput(createObjectAWDResponse.getCreateObjectsResponse(), createObjectsResponse);

        LoggerHandler.LogOut("INFO", "1", "messageUUID", "sourceSystemName", this.getClass().getName(),
                "Output of the Create Objects>> " + loggerUtils.writeAsJson(createObjectsResponse));

        createObjectsResponseWrapper.setHeader(header);

        createObjectsResponseWrapper.setCreateObjectsResponse(createObjectsResponse);
        return createObjectsResponseWrapper;
    }

    /**
     * @param request
     *
     * @return
     */
    private String getBusinessArea(CreateObjects request) {
        String businessArea = "";
        if (request.getCreateObjectRequest().getCreateFolderInstanceOrCreateSourceInstanceOrCreateWorkInstance() != null) {

            List<Object> awdInstancesList = request.getCreateObjectRequest().getCreateFolderInstanceOrCreateSourceInstanceOrCreateWorkInstance();

            if (awdInstancesList != null) {

                for (int i = 0; i < awdInstancesList.size(); i++) {

                    Object obj = awdInstancesList.get(i);

                    if (obj instanceof CreateWorkInstance) {
                        CreateWorkInstance createWorkInstance = (CreateWorkInstance) obj;

                        businessArea = createWorkInstance.getCreateAWDInstance().getBusinessArea().toUpperCase();

                    }

                }
            }

        }
        return businessArea;
    }

    /**
     * Map output create objects response.
     *
     * @param createObjectAWDResponse the create object awd response
     * @param createObjectsResponse   the create objects response
     *
     * @return the create objects response
     */
    public CreateObjectsResponse mapOutput(com.dstawd.processing.ws.GetObjectsResponse createObjectAWDResponse, CreateObjectsResponse createObjectsResponse) {

        GetObjectsResponse objectsResponse = new GetObjectsResponse();
        if (createObjectAWDResponse.getImmediateRelationships() != null) {
            objectsResponse.setImmediateRelationships(workManagementMapperHelper.mapImmediateRelationships(createObjectAWDResponse.getImmediateRelationships()));
        }
        objectsResponse.setFolderInstanceOrSourceInstanceOrWorkInstance(returnMapAWDInstance(createObjectAWDResponse.getWorkInstanceOrFolderInstanceOrSourceInstance()));

        createObjectsResponse.setObjectsResponse(objectsResponse);
        return createObjectsResponse;
    }


    /**
     * Return map awd instance list.
     *
     * @param awdInstancesList the awd instances list
     *
     * @return the list
     */
    public List<Object> returnMapAWDInstance(List<com.dstawd.processing.ws.AwdInstance> awdInstancesList) {

        List<Object> returnAWDInstanceList = null;

        if (awdInstancesList != null) {
            returnAWDInstanceList = new ArrayList<>();
            for (int i = 0; i < awdInstancesList.size(); i++) {

                com.dstawd.processing.ws.AwdInstance awdInstance = awdInstancesList.get(i);

                if (awdInstance instanceof com.dstawd.processing.ws.SourceInstance) {
                    SourceInstance retSourceInstance = new SourceInstance();

                    retSourceInstance.setAccessMethod(((com.dstawd.processing.ws.SourceInstance) awdInstance).getAccessMethod());
                    retSourceInstance.setAnnotationBlob(((com.dstawd.processing.ws.SourceInstance) awdInstance).getAnnotationBlob());
                    retSourceInstance.setArchiveBox(((com.dstawd.processing.ws.SourceInstance) awdInstance).getArchiveBox());
                    retSourceInstance.setArchiveStartPage(((com.dstawd.processing.ws.SourceInstance) awdInstance).getArchiveStartPage());
                    // Mapping the super class AWD Instance
                    retSourceInstance.setAwdInstance(workManagementMapperHelper.retMapSourceAWDInstance((com.dstawd.processing.ws.SourceInstance) awdInstance));
                    retSourceInstance.setCommentsExist(((com.dstawd.processing.ws.SourceInstance) awdInstance).getCommentsExist());
                    retSourceInstance.setContentId(((com.dstawd.processing.ws.SourceInstance) awdInstance).getContentId());
                    retSourceInstance.setCreateStation(((com.dstawd.processing.ws.SourceInstance) awdInstance).getCreateStation());
                    retSourceInstance.setCreateUser(((com.dstawd.processing.ws.SourceInstance) awdInstance).getCreateUser());
                    retSourceInstance.setFormat(((com.dstawd.processing.ws.SourceInstance) awdInstance).getFormat());
                    retSourceInstance.setMailType(((com.dstawd.processing.ws.SourceInstance) awdInstance).getMailType());
                    retSourceInstance.setOpticalStatus(((com.dstawd.processing.ws.SourceInstance) awdInstance).getOpticalStatus());
                    retSourceInstance.setPageCount(new BigInteger(((com.dstawd.processing.ws.SourceInstance) awdInstance).getPageCount()));
                    retSourceInstance.setPath(((com.dstawd.processing.ws.SourceInstance) awdInstance).getPath());
                    retSourceInstance.setSecurityLevel(((com.dstawd.processing.ws.SourceInstance) awdInstance).getSecurityLevel());
                    retSourceInstance.setRevisable(((com.dstawd.processing.ws.SourceInstance) awdInstance).getRevisable());
                    retSourceInstance.setReceiveTime(((com.dstawd.processing.ws.SourceInstance) awdInstance).getReceiveTime());
                    returnAWDInstanceList.add(retSourceInstance);

                } else if (awdInstance instanceof com.dstawd.processing.ws.WorkInstance) {
                    WorkInstance retWorkInstance = new WorkInstance();
                    retWorkInstance.setAssignedTo(((com.dstawd.processing.ws.WorkInstance) awdInstance).getAssignedTo());
                    // Map the AWD Instance
                    retWorkInstance.setAwdInstance(workManagementMapperHelper.retMapSourceAWDInstance((com.dstawd.processing.ws.WorkInstance) awdInstance));
                    retWorkInstance.setInstanceType(((com.dstawd.processing.ws.WorkInstance) awdInstance).getInstanceType());
                    retWorkInstance.setPriority(((com.dstawd.processing.ws.WorkInstance) awdInstance).getPriority());
                    retWorkInstance.setPriorityIncrease(((com.dstawd.processing.ws.WorkInstance) awdInstance).getPriorityIncrease());
                    retWorkInstance.setQueue(((com.dstawd.processing.ws.WorkInstance) awdInstance).getQueue());
                    retWorkInstance.setStatus(((com.dstawd.processing.ws.WorkInstance) awdInstance).getStatus());
                    // Mapping the suspend data
                    if (((com.dstawd.processing.ws.WorkInstance) awdInstance).getSuspended() != null) {
                        retWorkInstance.setSuspended(workManagementMapperHelper.retMapAWDSuspend(((com.dstawd.processing.ws.WorkInstance) awdInstance).getSuspended()));
                    }
                    // Mapping the WorkFlow
                    if (((com.dstawd.processing.ws.WorkInstance) awdInstance).getWorkFlow() != null) {
                        retWorkInstance.setWorkFlow(workManagementMapperHelper.retMapWorkFlow(((com.dstawd.processing.ws.WorkInstance) awdInstance).getWorkFlow()));
                    }
                    returnAWDInstanceList.add(retWorkInstance);
                } else if (awdInstance instanceof com.dstawd.processing.ws.FolderInstance) {
                    FolderInstance retFolderInstance = new FolderInstance();

                    retFolderInstance.setAwdInstance(workManagementMapperHelper.retMapSourceAWDInstance((com.dstawd.processing.ws.FolderInstance) awdInstance));
                    retFolderInstance.setCreateStation(((com.dstawd.processing.ws.FolderInstance) awdInstance).getCreateStation());
                    retFolderInstance.setCreateUser(((com.dstawd.processing.ws.FolderInstance) awdInstance).getCreateUser());
                    returnAWDInstanceList.add(retFolderInstance);
                }

            }
        }
        return returnAWDInstanceList;
    }


    /**
     * Map input com . dstawd . processing . ws . create objects.
     *
     * @param wmRequest the wm request
     *
     * @return the com . dstawd . processing . ws . create objects
     */
    public com.dstawd.processing.ws.CreateObjects mapInput(CreateObjects wmRequest) {

        com.dstawd.processing.ws.CreateObjects outCreateAWDRequest = new com.dstawd.processing.ws.CreateObjects();

        com.dstawd.processing.ws.CreateObjectRequest outCreateObjectRequest = new com.dstawd.processing.ws.CreateObjectRequest();

        if (wmRequest.getCreateObjectRequest() != null && wmRequest.getCreateObjectRequest().getResponseDetails() != null) {
            outCreateObjectRequest.setResponseDetails(workManagementMapperHelper.mapResponseDetails(wmRequest.getCreateObjectRequest().getResponseDetails()));
        }
        if (wmRequest.getCreateObjectRequest() != null && wmRequest.getCreateObjectRequest().getRelationships() != null) {
            outCreateObjectRequest.setRelationships(mapRelationships(wmRequest.getCreateObjectRequest().getRelationships()));
        }
        outCreateObjectRequest.setCreateWorkInstanceOrCreateFolderInstanceOrCreateSourceInstance(mapAWDInstance(wmRequest.getCreateObjectRequest().getCreateFolderInstanceOrCreateSourceInstanceOrCreateWorkInstance()));

        outCreateAWDRequest.setCreateObjectRequest(outCreateObjectRequest);

        return outCreateAWDRequest;

    }

    /**
     * Map field value com . dstawd . processing . ws . create awd instance . field values.
     *
     * @param inputFieldValueList the input field value list
     *
     * @return the com . dstawd . processing . ws . create awd instance . field values
     */
    public com.dstawd.processing.ws.CreateAWDInstance.FieldValues mapFieldValue(List<FieldValue> inputFieldValueList) {
        com.dstawd.processing.ws.CreateAWDInstance.FieldValues outFieldValues = new com.dstawd.processing.ws.CreateAWDInstance.FieldValues();
        List<com.dstawd.processing.ws.FieldValue> outFieldValueList;

        if (inputFieldValueList != null && inputFieldValueList.size() > 0) {
            outFieldValueList = new ArrayList<>();
            com.dstawd.processing.ws.FieldValue outFieldValue = null;

            for (int i = 0; i < inputFieldValueList.size(); i++) {
                FieldValue inputFieldValue = (FieldValue) inputFieldValueList.get(i);
                outFieldValue = new com.dstawd.processing.ws.FieldValue();

                outFieldValue.setValue(inputFieldValue.getValue());
                outFieldValue.setName(inputFieldValue.getName());
                outFieldValue.setSequence(inputFieldValue.getSequence());

                outFieldValueList.add(outFieldValue);
            }

            outFieldValues.setFieldValue(outFieldValueList);
        }


        return outFieldValues;
    }

    /**
     * Map attachment list com . dstawd . processing . ws . create source instance . attachment list.
     *
     * @param inAttachmentList the in attachment list
     *
     * @return the com . dstawd . processing . ws . create source instance . attachment list
     */
    public com.dstawd.processing.ws.CreateSourceInstance.AttachmentList mapAttachmentList(List<Attachment> inAttachmentList) {

        com.dstawd.processing.ws.CreateSourceInstance.AttachmentList outAttachment = new com.dstawd.processing.ws.CreateSourceInstance.AttachmentList();

        List<com.dstawd.processing.ws.Attachment> outAttachmentList = new ArrayList<>();

        com.dstawd.processing.ws.Attachment outAttachement;
        Attachment attachment = null;

        if (inAttachmentList != null && inAttachmentList.size() > 0) {

            for (int i = 0; i < inAttachmentList.size(); i++) {
                attachment = (Attachment) inAttachmentList.get(i);

                outAttachement = new com.dstawd.processing.ws.Attachment();

                outAttachement.setBinaryData(attachment.getBinaryData());
                outAttachement.setSequence(attachment.getSequence());
                outAttachmentList.add(outAttachement);
            }
        }

        outAttachment.setAttachment(outAttachmentList);
        return outAttachment;
    }

    /**
     * Map awd instance list.
     *
     * @param inputAWDInstanceList the input awd instance list
     *
     * @return the list
     */
    public List<com.dstawd.processing.ws.CreateAWDInstance> mapAWDInstance(List<Object> inputAWDInstanceList) {
        List<com.dstawd.processing.ws.CreateAWDInstance> outCreateAWDInstaceList = new ArrayList<>();

        if (inputAWDInstanceList != null) {

            for (int i = 0; i < inputAWDInstanceList.size(); i++) {

                Object obj = inputAWDInstanceList.get(i);

                if (obj instanceof CreateFolderInstance) {
                    CreateFolderInstance inCreateFolderInstance = (CreateFolderInstance) obj;
                    com.dstawd.processing.ws.CreateAWDInstance outCreateFolderInstance = new com.dstawd.processing.ws.CreateFolderInstance();

                    outCreateFolderInstance.setType(inCreateFolderInstance.getCreateAWDInstance().getType());
                    outCreateFolderInstance.setBusinessArea(inCreateFolderInstance.getCreateAWDInstance().getBusinessArea());

                    // Mapping the Field Value
                    outCreateFolderInstance.setFieldValues(mapFieldValue(inCreateFolderInstance.getCreateAWDInstance().getFieldValues().getFieldValue()));

                    outCreateFolderInstance.setAddManualComment(inCreateFolderInstance.getCreateAWDInstance().getAddManualComment());
                    ((com.dstawd.processing.ws.CreateFolderInstance) outCreateFolderInstance).setCreateStation(inCreateFolderInstance.getCreateStation());
                    outCreateFolderInstance.setLock(inCreateFolderInstance.getCreateAWDInstance().getLock());
                    outCreateFolderInstance.setRelationshipId(inCreateFolderInstance.getCreateAWDInstance().getRelationshipId());

                    outCreateAWDInstaceList.add(outCreateFolderInstance);

                } else if (obj instanceof CreateSourceInstance) {
                    com.dstawd.processing.ws.CreateAWDInstance outCreateSourceInstance = new com.dstawd.processing.ws.CreateSourceInstance();
                    CreateSourceInstance inCreateSourceInstance = (CreateSourceInstance) obj;

                    outCreateSourceInstance.setRelationshipId(inCreateSourceInstance.getCreateAWDInstance().getRelationshipId());
                    outCreateSourceInstance.setLock(inCreateSourceInstance.getCreateAWDInstance().getLock());
                    ((com.dstawd.processing.ws.CreateSourceInstance) outCreateSourceInstance).setCreateStation(inCreateSourceInstance.getCreateStation());
                    outCreateSourceInstance.setAddManualComment(inCreateSourceInstance.getCreateAWDInstance().getAddManualComment());
                    // Map the FieldValues
                    outCreateSourceInstance.setFieldValues(mapFieldValue(inCreateSourceInstance.getCreateAWDInstance().getFieldValues().getFieldValue()));
                    outCreateSourceInstance.setBusinessArea(inCreateSourceInstance.getCreateAWDInstance().getBusinessArea());
                    outCreateSourceInstance.setType(inCreateSourceInstance.getCreateAWDInstance().getType());
                    ((com.dstawd.processing.ws.CreateSourceInstance) outCreateSourceInstance).setAccessMethod(inCreateSourceInstance.getAccessMethod());
                    ((com.dstawd.processing.ws.CreateSourceInstance) outCreateSourceInstance).setAnnotationBlob(inCreateSourceInstance.getAnnotationBlob());
                    ((com.dstawd.processing.ws.CreateSourceInstance) outCreateSourceInstance).setArchiveBox(inCreateSourceInstance.getArchiveBox());
                    ((com.dstawd.processing.ws.CreateSourceInstance) outCreateSourceInstance).setArchiveStartPage(inCreateSourceInstance.getArchiveStartPage());
                    // Map the Attachments
                    if (inCreateSourceInstance.getAttachmentList() != null && inCreateSourceInstance.getAttachmentList().getAttachment() != null) {
                        ((com.dstawd.processing.ws.CreateSourceInstance) outCreateSourceInstance).setAttachmentList(mapAttachmentList(inCreateSourceInstance.getAttachmentList().getAttachment()));
                    }
                    ((com.dstawd.processing.ws.CreateSourceInstance) outCreateSourceInstance).setContentId(inCreateSourceInstance.getContentId());
                    ((com.dstawd.processing.ws.CreateSourceInstance) outCreateSourceInstance).setFormat(inCreateSourceInstance.getFormat());
                    ((com.dstawd.processing.ws.CreateSourceInstance) outCreateSourceInstance).setMailType(inCreateSourceInstance.getMailType());
                    ((com.dstawd.processing.ws.CreateSourceInstance) outCreateSourceInstance).setPageCount(String.valueOf(inCreateSourceInstance.getPageCount()));
                    ((com.dstawd.processing.ws.CreateSourceInstance) outCreateSourceInstance).setReceiveTime(inCreateSourceInstance.getReceiveTime());
                    ((com.dstawd.processing.ws.CreateSourceInstance) outCreateSourceInstance).setSecurityLevel(inCreateSourceInstance.getSecurityLevel());

                    outCreateAWDInstaceList.add(outCreateSourceInstance);

                } else if (obj instanceof CreateWorkInstance) {
                    com.dstawd.processing.ws.CreateAWDInstance outCreateWorkInstance = new com.dstawd.processing.ws.CreateWorkInstance();
                    CreateWorkInstance inCreateWorkInstance = (CreateWorkInstance) obj;


                    outCreateWorkInstance.setType(inCreateWorkInstance.getCreateAWDInstance().getType());
                    outCreateWorkInstance.setBusinessArea(inCreateWorkInstance.getCreateAWDInstance().getBusinessArea());
                    outCreateWorkInstance.setFieldValues(mapFieldValue(inCreateWorkInstance.getCreateAWDInstance().getFieldValues().getFieldValue()));

                    outCreateWorkInstance.setAddManualComment(inCreateWorkInstance.getCreateAWDInstance().getAddManualComment());
                    outCreateWorkInstance.setLock(inCreateWorkInstance.getCreateAWDInstance().getLock());
                    outCreateWorkInstance.setRelationshipId(inCreateWorkInstance.getCreateAWDInstance().getRelationshipId());
                    ((com.dstawd.processing.ws.CreateWorkInstance) outCreateWorkInstance).setStatus(inCreateWorkInstance.getStatus());
                    ((com.dstawd.processing.ws.CreateWorkInstance) outCreateWorkInstance).setAssignTo(inCreateWorkInstance.getAssignTo());
                    ((com.dstawd.processing.ws.CreateWorkInstance) outCreateWorkInstance).setAutocase(inCreateWorkInstance.getAutocase());
                    ((com.dstawd.processing.ws.CreateWorkInstance) outCreateWorkInstance).setPriorityIncrease(inCreateWorkInstance.getPriorityIncrease());
                    ((com.dstawd.processing.ws.CreateWorkInstance) outCreateWorkInstance).setQueue(inCreateWorkInstance.getQueue());
                    if (inCreateWorkInstance.getSuspend() != null) {
                        ((com.dstawd.processing.ws.CreateWorkInstance) outCreateWorkInstance).setSuspend(mapSuspend(inCreateWorkInstance.getSuspend()));
                    }
                    ((com.dstawd.processing.ws.CreateWorkInstance) outCreateWorkInstance).setWorkStep(inCreateWorkInstance.getWorkStep());

                    outCreateAWDInstaceList.add(outCreateWorkInstance);
                }

            }
        }
        return outCreateAWDInstaceList;
    }

    /**
     * Map suspend com . dstawd . processing . ws . suspend.
     *
     * @param inSuspend the in suspend
     *
     * @return the com . dstawd . processing . ws . suspend
     */
    public com.dstawd.processing.ws.Suspend mapSuspend(Suspend inSuspend) {
        com.dstawd.processing.ws.Suspend outSupend = new com.dstawd.processing.ws.Suspend();

        if (inSuspend != null) {
            outSupend.setActivationDate(inSuspend.getActivationDate());
            outSupend.setActivationRoutingStatus(inSuspend.getActivationRoutingStatus());
            outSupend.setDuration(inSuspend.getDuration());
            outSupend.setReasonCode(inSuspend.getReasonCode());
        }
        return outSupend;
    }


    /**
     * Map relationships com . dstawd . processing . ws . create object request . relationships.
     *
     * @param inRelationships the in relationships
     *
     * @return the com . dstawd . processing . ws . create object request . relationships
     */
// Method to Map the Relationship details
    public com.dstawd.processing.ws.CreateObjectRequest.Relationships mapRelationships(Relationships inRelationships) {
        com.dstawd.processing.ws.CreateObjectRequest.Relationships outRelationships = new com.dstawd.processing.ws.CreateObjectRequest.Relationships();

        List<com.dstawd.processing.ws.RelateObjects> outRelateObjectsList;
        com.dstawd.processing.ws.RelateObjects outRelateObjs;

        if (inRelationships != null && inRelationships.getRelateObjects() != null) {
            outRelateObjectsList = new ArrayList<>();
            for (int i = 0; i < inRelationships.getRelateObjects().size(); i++) {
                RelateObjects inRelateObjects = inRelationships.getRelateObjects().get(i);

                outRelateObjs = new com.dstawd.processing.ws.RelateObjects();

                outRelateObjs.setChildRelationshipId(inRelateObjects.getChildRelationshipId());
                outRelateObjs.setParentRelationshipId(inRelateObjects.getParentRelationshipId());
                outRelateObjs.setChildId(inRelateObjects.getChildId());
                outRelateObjs.setParentId(inRelateObjects.getParentId());
                outRelateObjectsList.add(outRelateObjs);
            }
            outRelationships.setRelateObjects(outRelateObjectsList);
        }

        return outRelationships;
    }


}
