package com.jh.workmanagement.validator;

import com.jh.common.logging.LoggerHandler;
import com.manulife.esb.xsd.jh.workmanagement.CreateObjects;
import com.manulife.esb.xsd.jh.workmanagement.CreateWorkInstance;
import com.manulife.esb.xsd.jh.workmanagement.UpdateObjects;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * The type Work management validator.
 */
@Component
public class WorkManagementValidator {

    @Value("#{'${BUSINESS_AREAS}'.split(',')}")
    private List<String> businessAreaList;

    @Value("#{'${INVALID_BUSINESS_TYPE}'.split(',')}")
    private List<String> businessTypeList;

    /**
     * The User 1.
     */
    @Value("${AuthenticationAWDAnnuities}")
    String user1;
    /**
     * The User 2.
     */
    @Value("${AuthenticationAWDMutual}")
    String user2;
    /**
     * The User 3.
     */
    @Value("${AuthenticationAWDRPS10}")
    String user3;

    /**
     * Validate business area boolean.
     *
     * @param businessArea the create object request
     *
     * @return the boolean
     *
     * @throws Exception the exception
     */
    public boolean ValidateBusinessArea(String businessArea) throws Exception {
        boolean status = false;

        if (businessAreaList != null && businessAreaList.contains(businessArea)) {

            status = true;
        }
        return status;
    }

    public boolean ValidateBusinessType(CreateObjects request) throws Exception {
        boolean status = false;

        String businessType = "";
        if (request.getCreateObjectRequest().getCreateFolderInstanceOrCreateSourceInstanceOrCreateWorkInstance() != null) {

            List<Object> awdInstancesList = request.getCreateObjectRequest().getCreateFolderInstanceOrCreateSourceInstanceOrCreateWorkInstance();

            if (awdInstancesList != null) {

                for (int i = 0; i < awdInstancesList.size(); i++) {

                    Object obj = awdInstancesList.get(i);

                    if (obj instanceof CreateWorkInstance) {
                        CreateWorkInstance createWorkInstance = (CreateWorkInstance) obj;

                        businessType = createWorkInstance.getCreateAWDInstance().getType();

                    }

                }
            }

        }

        if (businessTypeList != null && businessTypeList.contains(businessType)) {

            status = true;
        }
        return status;
    }


    public boolean ValidateBusinessType(UpdateObjects request) throws Exception {
        boolean status = false;

        String businessType = "";
        if (request.getUpdateObjectRequest().getUpdateFolderInstanceOrUpdateSourceInstanceOrUpdateWorkInstance() != null) {

            List<Object> awdInstancesList = request.getUpdateObjectRequest().getUpdateFolderInstanceOrUpdateSourceInstanceOrUpdateWorkInstance();

            if (awdInstancesList != null) {

                for (int i = 0; i < awdInstancesList.size(); i++) {

                    Object obj = awdInstancesList.get(i);

                    if (obj instanceof CreateWorkInstance) {
                        CreateWorkInstance createWorkInstance = (CreateWorkInstance) obj;

                        businessType = createWorkInstance.getCreateAWDInstance().getType();

                    }

                }
            }

        }

        if (businessTypeList != null && businessTypeList.contains(businessType)) {

            status = true;
        }
        return status;
    }
    /**
     * Validate lock boolean.
     *
     * @param getObjectsResponse the get objects response
     * @param messageUUID        the message uuid
     * @param sourceSystemName   the source system name
     *
     * @return the boolean
     *
     * @throws Exception the exception
     */
    public boolean validateLock(com.dstawd.processing.ws.GetObjectsResponse getObjectsResponse,  String messageUUID, String sourceSystemName) throws Exception {
        LoggerHandler.LogOut("INFO", "2", messageUUID, sourceSystemName, this.getClass().getName(), "Entering validateLock");


        boolean status = false;

        if (getObjectsResponse != null && getObjectsResponse.getWorkInstanceOrFolderInstanceOrSourceInstance() != null) {
            String lockedBy = getObjectsResponse.getWorkInstanceOrFolderInstanceOrSourceInstance().get(0).getLockedBy();
            if (lockedBy != null && (lockedBy.equals("") || lockedBy.equalsIgnoreCase(user1) || lockedBy.equalsIgnoreCase(user2) || lockedBy.equalsIgnoreCase(user3))) {
                status = true;
            }
        }

        LoggerHandler.LogOut("INFO", "2", messageUUID, sourceSystemName, this.getClass().getName(), "Exiting validateLock");
        LoggerHandler.LogOut("DEBUG", "2", messageUUID, sourceSystemName, this.getClass().getName(), "ValidateLock Status" + status);

        return status;
    }

    /**
     * Validate lock update request boolean.
     *
     * @param getObjectsResponse the get objects response
     * @param messageUUID        the message uuid
     * @param sourceSystemName   the source system name
     *
     * @return the boolean
     *
     * @throws Exception the exception
     */
    public boolean validateLockUpdateRequest(com.dstawd.processing.ws.GetObjectsResponse getObjectsResponse,  String messageUUID, String sourceSystemName) throws Exception {
        LoggerHandler.LogOut("INFO", "2", messageUUID, sourceSystemName, this.getClass().getName(), "Entering validateLockUpdateRequest");

        boolean status = false;
        if (getObjectsResponse != null && getObjectsResponse.getWorkInstanceOrFolderInstanceOrSourceInstance() != null) {
            status = true;

        }
        LoggerHandler.LogOut("INFO", "2", messageUUID, sourceSystemName, this.getClass().getName(), "Exiting validateLockUpdateRequest");
        LoggerHandler.LogOut("DEBUG", "2", messageUUID, sourceSystemName, this.getClass().getName(), "validateLockUpdateRequest Status" + status);


        return status;

    }


}
