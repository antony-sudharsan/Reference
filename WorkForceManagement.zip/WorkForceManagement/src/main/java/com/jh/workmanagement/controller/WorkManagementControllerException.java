package com.jh.workmanagement.controller;


import com.jh.workmanagement.exception.ExceptionResponse;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import javax.ws.rs.NotFoundException;


/**
 * The type Work management controller exception.
 */
@ControllerAdvice
public class WorkManagementControllerException extends ResponseEntityExceptionHandler{

    /**
     * Handle all exceptions response entity.
     *
     * @param ex      the ex
     * @param request the request
     *
     * @return the response entity
     */
    @ExceptionHandler(Exception.class)
	public final ResponseEntity<Object> handleAllExceptions(Exception ex, WebRequest request) {
		ExceptionResponse exceptionResponse = new ExceptionResponse("500", ex.getMessage(),
				request.getDescription(false));
		return new ResponseEntity(exceptionResponse, HttpStatus.INTERNAL_SERVER_ERROR);
		
	}

    /**
     * Handle not found exception response entity.
     *
     * @param ex      the ex
     * @param request the request
     *
     * @return the response entity
     */
    @ExceptionHandler(NotFoundException.class)
	@ResponseStatus(HttpStatus.OK)
	@ResponseBody
	public final ResponseEntity handleNotFoundException(NotFoundException ex, WebRequest request) {
		ExceptionResponse exceptionResponse = new ExceptionResponse("200", ex.getMessage(),
				request.getDescription(false));
/*		CreateObjectResponseOutput createObjectResponseOutput = new CreateObjectResponseOutput();
		createObjectResponseOutput = new CreateObjectResponseOutput();
		ExceptionRES exceptionRES =  new ExceptionRES();
		//createObjectResponseOutput.getExceptionRES();
		exceptionRES.setMessage(ex.getMessage());
		createObjectResponseOutput.setException(exceptionRES);
		
		return new ResponseEntity(createObjectResponseOutput, HttpStatus.NO_CONTENT);*/
		return new ResponseEntity(exceptionResponse, HttpStatus.OK);
	}
	
	@Override
	protected ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException ex,
			HttpHeaders headers, HttpStatus status, WebRequest request) {
		ExceptionResponse exceptionResponse = new ExceptionResponse("400", "Validation Failed",
				ex.getBindingResult().toString());
		return new ResponseEntity(exceptionResponse, HttpStatus.BAD_REQUEST);
	}	
	
	
	
}

