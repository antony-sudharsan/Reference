package com.jh.workmanagement.model;

import com.manulife.esb.xsd.common.jh.header.JHHeader;
import com.manulife.esb.xsd.jh.workmanagement.UpdateObjects;
import com.manulife.esb.xsd.jh.workmanagement.UpdateObjectsResponse;

public class UpdateObjectsResponseWrapper {
    private JHHeader header;
    private UpdateObjectsResponse updateObjects;

    public JHHeader getHeader() {
        return header;
    }

    public void setHeader(JHHeader header) {
        this.header = header;
    }

    public UpdateObjectsResponse getUpdateObjects() {
        return updateObjects;
    }

    public void setUpdateObjects(UpdateObjectsResponse updateObjects) {
        this.updateObjects = updateObjects;
    }
}
