package com.jh.workmanagement.service;


import com.dstawd.processing.ws.*;
import com.jh.workmanagement.config.SecurityHeader;
import com.jh.workmanagement.exception.TechnicalErrorException;
import com.jh.workmanagement.utils.LoggerUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;
import org.springframework.ws.client.core.support.WebServiceGatewaySupport;

import javax.xml.bind.JAXBElement;
import java.lang.Exception;
import java.util.ArrayList;
import java.util.List;

/**
 * The type Work management web service client.
 */
@Component
public class WorkManagementWebServiceClient extends WebServiceGatewaySupport {

    @Autowired
    private Environment env;

    @Autowired
    private LoggerUtils loggerUtils;

    /**
     * Invoke create web service create objects response.
     *
     * @param businessAreaStr  the business area str
     * @param messageUUID      the message uuid
     * @param sourceSystemName the source system name
     * @param createObjects    the create objects
     *
     * @return the create objects response
     */
    public CreateObjectsResponse invokeCreateWebService(String businessAreaStr, String messageUUID, String sourceSystemName, CreateObjects createObjects) {

        // Code to create the Input for the AWD service - Starts
       // CreateObjects createObjects = parseRequestToModel();

        // System.out.println("######################### Value of the Create Objects >>"+loggerUtils.writeAsJson(createObjects));

        // Code to create the Input for the AWD service - Ends

        System.out.println("######################### Value of the Create Objects businessAreaStr >>" + businessAreaStr);


        String userId = env.getProperty(businessAreaStr+".UserID");
        String endUrl = env.getProperty(businessAreaStr+".endpointURL");

        System.out.println("######################### Value of the Create Objects endUrl >>" + endUrl);
        System.out.println("######################### Value of the Create Objects userId >>" + userId);

        System.out.println("######################### Value of the Create Objects Request >>" + loggerUtils.writeAsJson(createObjects));

        CreateObjectsResponse createObjectsResponse = null;

        Object createResponseObj = null;

        AuthorizationInfo authorizationInfo = new AuthorizationInfo();
        authorizationInfo.setUserId(userId);
        JAXBElement<CreateObjectsResponse> root = null;
        try {
            /*root = (JAXBElement<CreateObjectsResponse>) getWebServiceTemplate()
                    .marshalSendAndReceive("http://awdjhann-np.dstcorp.net/modelapp/awdServer/AWDProcessingService", createObjects, new SecurityHeader(authorizationInfo));*/
            root = (JAXBElement<CreateObjectsResponse>) getWebServiceTemplate()
                    .marshalSendAndReceive(endUrl, createObjects, new SecurityHeader(authorizationInfo));

            System.out.println("######################### Value of the Create Objects Response >>" + loggerUtils.writeAsJson(root));
        } catch (Exception e) {
            e.printStackTrace();
            throw new TechnicalErrorException("Technical Error",e.getCause());
        }

        return root.getValue();
    }


    /**
     * Invoke update web service update objects response.
     *
     * @param businessAreaStr      the business area str
     * @param messageUUID          the message uuid
     * @param sourceSystemName     the source system name
     * @param updateObjectsRequest the update objects request
     *
     * @return the update objects response
     */
    public UpdateObjectsResponse invokeUpdateWebService(String businessAreaStr, String messageUUID, String sourceSystemName, UpdateObjects updateObjectsRequest) {

        // Code to create the Input for the AWD service - Starts
      //  CreateObjects createObjects = parseRequestToModel();

        // System.out.println("######################### Value of the Create Objects >>"+loggerUtils.writeAsJson(createObjects));

        // Code to create the Input for the AWD service - Ends

        UpdateObjectsResponse updateObjectsResponse = null;
        System.out.println("######################### Value of the Create Objects businessAreaStr >>" + businessAreaStr);
        Object updateResponseObj = null;
        String userId = env.getProperty(businessAreaStr+".UserID");
        String endUrl = env.getProperty(businessAreaStr+".endpointURL");

        System.out.println("######################### Value of the Create Objects endUrl >>" + endUrl);
        System.out.println("######################### Value of the Create Objects userId >>" + userId);

        System.out.println("######################### Value of the Create Objects Request >>" + loggerUtils.writeAsJson(updateObjectsRequest));

        AuthorizationInfo authorizationInfo = new AuthorizationInfo();
        authorizationInfo.setUserId("JHSFDC02");
        JAXBElement<UpdateObjectsResponse> root = null;
        try {
            root = (JAXBElement<UpdateObjectsResponse>) getWebServiceTemplate()
                    .marshalSendAndReceive("http://awdjhann-np.dstcorp.net/modelapp/awdServer/AWDProcessingService", updateObjectsRequest, new SecurityHeader(authorizationInfo));

            System.out.println("######################### Value of the Update Objects Response >>" + loggerUtils.writeAsJson(root));
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }

        return root.getValue();
    }


    /**
     * Invoke retrieve service update objects response.
     *
     * @param businessAreaStr      the business area str
     * @param messageUUID          the message uuid
     * @param sourceSystemName     the source system name
     * @param updateObjectsRequest the update objects request
     *
     * @return the update objects response
     */
    public UpdateObjectsResponse invokeRetrieveService(String businessAreaStr, String messageUUID, String sourceSystemName, UpdateObjects updateObjectsRequest) {

        // Code to create the Input for the AWD service - Starts
        //  CreateObjects createObjects = parseRequestToModel();

        // System.out.println("######################### Value of the Create Objects >>"+loggerUtils.writeAsJson(createObjects));

        // Code to create the Input for the AWD service - Ends

        UpdateObjectsResponse updateObjectsResponse = null;
        System.out.println("######################### Value of the Create Objects businessAreaStr >>" + businessAreaStr);
        Object updateResponseObj = null;
        String userId = env.getProperty(businessAreaStr+".UserID");
        String endUrl = env.getProperty(businessAreaStr+".endpointURL");

        System.out.println("######################### Value of the Create Objects endUrl >>" + endUrl);
        System.out.println("######################### Value of the Create Objects userId >>" + userId);

        System.out.println("######################### Value of the Create Objects Request >>" + loggerUtils.writeAsJson(updateObjectsRequest));

        AuthorizationInfo authorizationInfo = new AuthorizationInfo();
        authorizationInfo.setUserId("JHSFDC02");
        JAXBElement<UpdateObjectsResponse> root = null;
        try {
            root = (JAXBElement<UpdateObjectsResponse>) getWebServiceTemplate()
                    .marshalSendAndReceive("http://awdjhann-np.dstcorp.net/modelapp/awdServer/AWDProcessingService", updateObjectsRequest, new SecurityHeader(authorizationInfo));

            System.out.println("######################### Value of the Update Objects Response >>" + loggerUtils.writeAsJson(root));
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }

        return root.getValue();
    }


    /**
     * Invoke update lock service update objects response.
     *
     * @param businessAreaStr      the business area str
     * @param messageUUID          the message uuid
     * @param sourceSystemName     the source system name
     * @param updateObjectsRequest the update objects request
     *
     * @return the update objects response
     */
    public UpdateObjectsResponse invokeUpdateLockService(String businessAreaStr, String messageUUID, String sourceSystemName, UpdateObjects updateObjectsRequest) {

        // Code to create the Input for the AWD service - Starts
        //  CreateObjects createObjects = parseRequestToModel();

        // System.out.println("######################### Value of the Create Objects >>"+loggerUtils.writeAsJson(createObjects));

        // Code to create the Input for the AWD service - Ends

        UpdateObjectsResponse updateObjectsResponse = null;
        System.out.println("######################### Value of the Create Objects businessAreaStr >>" + businessAreaStr);
        Object updateResponseObj = null;
        String userId = env.getProperty(businessAreaStr+".UserID");
        String endUrl = env.getProperty(businessAreaStr+".endpointURL");

        System.out.println("######################### Value of the Create Objects endUrl >>" + endUrl);
        System.out.println("######################### Value of the Create Objects userId >>" + userId);

        System.out.println("######################### Value of the Create Objects Request >>" + loggerUtils.writeAsJson(updateObjectsRequest));

        AuthorizationInfo authorizationInfo = new AuthorizationInfo();
        authorizationInfo.setUserId("JHSFDC02");
        JAXBElement<UpdateObjectsResponse> root = null;
        try {
            root = (JAXBElement<UpdateObjectsResponse>) getWebServiceTemplate()
                    .marshalSendAndReceive("http://awdjhann-np.dstcorp.net/modelapp/awdServer/AWDProcessingService", updateObjectsRequest, new SecurityHeader(authorizationInfo));

            System.out.println("######################### Value of the Update Objects Response >>" + loggerUtils.writeAsJson(root));
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }

        return root.getValue();
    }

    /**
     * Parse request to model create objects.
     *
     * @return the create objects
     */
    public CreateObjects parseRequestToModel() {


        // Code to create the Input for the AWD service - Starts
        CreateObjects createObjects = new CreateObjects();
        CreateObjectRequest createObjectRequest = new CreateObjectRequest();

        List<CreateAWDInstance> createWorkInstList = new ArrayList<>();
        com.dstawd.processing.ws.ResponseDetails responseDetails = new com.dstawd.processing.ws.ResponseDetails();

        CreateObjectRequest.Relationships relationships = new CreateObjectRequest.Relationships();


        List<com.dstawd.processing.ws.RelateObjects> relateObjectsList = new ArrayList<com.dstawd.processing.ws.RelateObjects>();


        CreateAWDInstance createWorkInstance1 = new CreateWorkInstance();

        CreateAWDInstance.FieldValues fieldValuesWork = new CreateAWDInstance.FieldValues();
        List<FieldValue> fieldValueList = new ArrayList<FieldValue>();

        FieldValue fieldValue1 = new FieldValue("0019", "CYPC", "1");
        FieldValue fieldValue2 = new FieldValue(null, "COLI", "2");
        FieldValue fieldValue3 = new FieldValue("4", "PLCC", "3");
        FieldValue fieldValue4 = new FieldValue("007040633", "ACCT", "4");
        FieldValue fieldValue5 = new FieldValue("AUTO", "ROUT", "5");
        FieldValue fieldValue6 = new FieldValue("198743521111592354", "JHIM", "6");

        fieldValueList.add(fieldValue1);
//        fieldValueList.add(fieldValue2);
        fieldValueList.add(fieldValue3);
        fieldValueList.add(fieldValue4);
        fieldValueList.add(fieldValue5);
        fieldValueList.add(fieldValue6);

        fieldValuesWork.setFieldValue(fieldValueList);

        createWorkInstance1.setFieldValues(fieldValuesWork);
        createWorkInstance1.setBusinessArea("LIFE");
        createWorkInstance1.setType("VALUEQUOTE");
        ((CreateWorkInstance) createWorkInstance1).setStatus("CREATED");
        ((CreateWorkInstance) createWorkInstance1).setPriorityIncrease("0");

//// Second instance

        CreateAWDInstance createWorkInstance2 = new CreateWorkInstance();


        CreateAWDInstance.FieldValues fieldValuesWork2 = new CreateAWDInstance.FieldValues();
        List<FieldValue> fieldValueList2 = new ArrayList<FieldValue>();

        FieldValue fieldValue21 = new FieldValue("0019", "CYPC", "1");
        FieldValue fieldValue22 = new FieldValue(null, "COLI", "2");
        FieldValue fieldValue23 = new FieldValue("4", "PLCC", "3");
        FieldValue fieldValue24 = new FieldValue("003372654", "ACCT", "4");
        FieldValue fieldValue25 = new FieldValue("AUTO", "ROUT", "5");
        FieldValue fieldValue26 = new FieldValue("689643521100865082", "JHIM", "6");

        fieldValueList2.add(fieldValue21);
//        fieldValueList2.add(fieldValue22);
        fieldValueList2.add(fieldValue23);
        fieldValueList2.add(fieldValue24);
        fieldValueList2.add(fieldValue25);
        fieldValueList2.add(fieldValue26);

        fieldValuesWork2.setFieldValue(fieldValueList2);

        createWorkInstance2.setFieldValues(fieldValuesWork2);
        createWorkInstance2.setBusinessArea("LIFE");
        createWorkInstance2.setType("FINHISTORY");
        ((CreateWorkInstance) createWorkInstance2).setStatus("CREATED");
        ((CreateWorkInstance) createWorkInstance2).setPriorityIncrease("0");

/// Third Instance


        CreateAWDInstance createWorkInstance3 = new CreateWorkInstance();


        CreateAWDInstance.FieldValues fieldValuesWork3 = new CreateAWDInstance.FieldValues();
        List<FieldValue> fieldValueList3 = new ArrayList<FieldValue>();

        FieldValue fieldValue31 = new FieldValue("0019", "CYPC", "1");
        FieldValue fieldValue32 = new FieldValue(null, "COLI", "2");
        FieldValue fieldValue33 = new FieldValue("4", "PLCC", "3");
        FieldValue fieldValue34 = new FieldValue("007031355", "ACCT", "4");
        FieldValue fieldValue35 = new FieldValue("AUTO", "ROUT", "5");
        FieldValue fieldValue36 = new FieldValue("338643521109538857", "JHIM", "6");

        fieldValueList3.add(fieldValue31);
//        fieldValueList3.add(fieldValue32);
        fieldValueList3.add(fieldValue33);
        fieldValueList3.add(fieldValue34);
        fieldValueList3.add(fieldValue35);
        fieldValueList3.add(fieldValue36);

        fieldValuesWork3.setFieldValue(fieldValueList3);

        createWorkInstance3.setFieldValues(fieldValuesWork3);
        createWorkInstance3.setBusinessArea("LIFE");
        createWorkInstance3.setType("DUPSTMNT");
        ((CreateWorkInstance) createWorkInstance3).setStatus("CREATED");
        ((CreateWorkInstance) createWorkInstance3).setPriorityIncrease("0");

/// Fourth Instance


        CreateAWDInstance createWorkInstance4 = new CreateWorkInstance();


        CreateAWDInstance.FieldValues fieldValuesWork4 = new CreateAWDInstance.FieldValues();
        List<FieldValue> fieldValueList4 = new ArrayList<FieldValue>();

        FieldValue fieldValue41 = new FieldValue("0019", "CYPC", "1");
        FieldValue fieldValue42 = new FieldValue(null, "COLI", "2");
        FieldValue fieldValue43 = new FieldValue("4", "PLCC", "3");
        FieldValue fieldValue44 = new FieldValue("003372654", "ACCT", "4");
        FieldValue fieldValue45 = new FieldValue("AUTO", "ROUT", "5");
        FieldValue fieldValue46 = new FieldValue("689643521100865082", "JHIM", "6");

        fieldValueList4.add(fieldValue41);
//        fieldValueList4.add(fieldValue42);
        fieldValueList4.add(fieldValue43);
        fieldValueList4.add(fieldValue44);
        fieldValueList4.add(fieldValue45);
        fieldValueList4.add(fieldValue46);

        fieldValuesWork4.setFieldValue(fieldValueList4);

        createWorkInstance4.setFieldValues(fieldValuesWork4);
        createWorkInstance4.setBusinessArea("LIFE");
        createWorkInstance4.setType("VALUEQUOTE");
        ((CreateWorkInstance) createWorkInstance4).setStatus("CREATED");
        ((CreateWorkInstance) createWorkInstance4).setPriorityIncrease("0");

        createWorkInstList.add(createWorkInstance1);
        createWorkInstList.add(createWorkInstance2);
        createWorkInstList.add(createWorkInstance3);
        createWorkInstList.add(createWorkInstance4);
        createObjectRequest.setCreateWorkInstanceOrCreateFolderInstanceOrCreateSourceInstance(createWorkInstList);
        createObjects.setCreateObjectRequest(createObjectRequest);


        //end
        return createObjects;
    }


}
