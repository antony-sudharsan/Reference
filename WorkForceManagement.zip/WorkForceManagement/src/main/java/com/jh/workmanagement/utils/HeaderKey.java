package com.jh.workmanagement.utils;

/**
 * Holds any custom header keys.
 */
public enum HeaderKey {
    /**
     * Custom Header Key
     */
    JH_HEADER_KEY("X-JH-Header");
	
	private String value;
	
	HeaderKey(final String value) {
		this.value = value;
	}

    /**
     * Gets value.
     *
     * @return the value
     */
    public String getValue() {
		return value;
	}

}
