package com.jh.workmanagement.utils;

import com.manulife.esb.xsd.common.jh.header.JHHeader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.ws.soap.SoapHeaderElement;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import javax.xml.transform.Result;

/**
 * WorkManagementUtils class to marshall and unmarshall various forms of the JHHeader.
 */
@Component
public class JHHeaderJaxbUtils {

	private static final Logger logger = LoggerFactory.getLogger(JHHeaderJaxbUtils.class);

	// JAXBContext is thread safe so for performance reasons create once.
	private final JAXBContext context;

    /**
     * Instantiates a new Jh header jaxb utils.
     */
    public JHHeaderJaxbUtils() {
		try {
			context = JAXBContext.newInstance(JHHeader.class);
		} catch (final JAXBException e) {
			logger.error("Failed Creating JAXBContext for JHHeader ", e);
			throw new RuntimeException(e);
		}
	}

    /**
     * Marshall jh header to result.
     *
     * @param jhHeader the jh header
     * @param result   the result
     */
    public void marshallJHHeaderToResult(final JHHeader jhHeader, final Result result) {
		try {
			final Marshaller marshaller = context.createMarshaller();
			marshaller.marshal(jhHeader, result);

		} catch (final JAXBException e) {
			logger.error("Failed marshalling JHHeader to Result", e);
			throw new RuntimeException(e);
		}
	}

    /**
     * Unmarshall jh header jh header.
     *
     * @param headerElement the header element
     *
     * @return the jh header
     */
    public JHHeader unmarshallJHHeader(final SoapHeaderElement headerElement) {
		JHHeader jhHeader = null;
		try {
			final Unmarshaller unmarshaller = context.createUnmarshaller();
			jhHeader = (JHHeader) unmarshaller.unmarshal(headerElement.getSource());

		} catch (final JAXBException e) {
			logger.error("Failed unmarshalling JHHeader ", e);
			throw new RuntimeException(e);
		}

		return jhHeader;
	}

}
