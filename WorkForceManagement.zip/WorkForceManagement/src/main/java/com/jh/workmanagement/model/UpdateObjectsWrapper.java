package com.jh.workmanagement.model;

import com.manulife.esb.xsd.common.jh.header.JHHeader;
import com.manulife.esb.xsd.jh.workmanagement.UpdateObjects;

public class UpdateObjectsWrapper {
    private JHHeader header;
    private UpdateObjects updateObjects;

    public JHHeader getHeader() {
        return header;
    }

    public void setHeader(JHHeader header) {
        this.header = header;
    }

    public UpdateObjects getUpdateObjects() {
        return updateObjects;
    }

    public void setUpdateObjects(UpdateObjects updateObjects) {
        this.updateObjects = updateObjects;
    }
}
