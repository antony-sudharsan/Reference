package com.jh.workmanagement.endpoint;

import com.jh.common.logging.LoggerHandler;
import com.jh.workmanagement.constants.WorkManagementContants;
import com.jh.workmanagement.exception.BadRequestException;
import com.jh.workmanagement.orchestration.CreateWorkManagementOrchestration;
import com.jh.workmanagement.orchestration.UpdateWorkManagementOrchestration;
import com.jh.workmanagement.utils.HeaderKey;
import com.jh.workmanagement.utils.JHHeaderJaxbUtils;
import com.jh.workmanagement.utils.LoggerUtils;
import com.jh.workmanagement.utils.LoggingContextHolder;
import com.manulife.esb.wsdl.wealth.pfs.workmanagement_1.WorkManagementFault;
import com.manulife.esb.xsd.common.jh.commonmessage.FaultType;
import com.manulife.esb.xsd.common.jh.header.JHHeader;
import com.manulife.esb.xsd.jh.workmanagement.CreateObjects;
import com.manulife.esb.xsd.jh.workmanagement.CreateObjectsResponse;
import com.manulife.esb.xsd.jh.workmanagement.UpdateObjects;
import com.manulife.esb.xsd.jh.workmanagement.UpdateObjectsResponse;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ws.context.MessageContext;
import org.springframework.ws.server.endpoint.annotation.Endpoint;
import org.springframework.ws.server.endpoint.annotation.PayloadRoot;
import org.springframework.ws.server.endpoint.annotation.RequestPayload;
import org.springframework.ws.server.endpoint.annotation.ResponsePayload;
import org.springframework.ws.soap.SoapHeaderElement;
import org.springframework.ws.soap.server.endpoint.annotation.SoapHeader;

/**
 * The type Work management endpoint.
 */
@Endpoint
public class WorkManagementEndpoint {

    private static final String NAMESPACE_URI = "http://www.esb.manulife.com/xsd/jh/WorkManagement";


    private static final String JH_HEADER_NS = "http://www.esb.manulife.com/xsd/common/jh/header";

    @Autowired
    private CreateWorkManagementOrchestration createWorkManagementOrchestration;
    @Autowired
    private UpdateWorkManagementOrchestration updateWorkManagementOrchestration;


    @Autowired
    private JHHeaderJaxbUtils jhHeaderJaxbUtils;
    @Autowired
    private LoggerUtils loggerUtils;

    /**
     * Instantiates a new Work management endpoint.
     *
     * @param createWorkManagementOrchestration the create work management orchestration
     * @param updateWorkManagementOrchestration the update work management orchestration
     * @param jhHeaderJaxbUtils                 the jh header jaxb utils
     * @param loggerUtils                       the logger utils
     */
    @Autowired
    public WorkManagementEndpoint(CreateWorkManagementOrchestration createWorkManagementOrchestration, UpdateWorkManagementOrchestration updateWorkManagementOrchestration, JHHeaderJaxbUtils jhHeaderJaxbUtils, LoggerUtils loggerUtils) {
        this.createWorkManagementOrchestration = createWorkManagementOrchestration;
        this.updateWorkManagementOrchestration = updateWorkManagementOrchestration;
        this.jhHeaderJaxbUtils = jhHeaderJaxbUtils;
        this.loggerUtils = loggerUtils;
    }


    /**
     * Create objects create objects response.
     *
     * @param request         the request
     * @param jhHeaderElement the jh header element
     * @param messageContext  the message context
     *
     * @return create objects response
     *
     * @throws WorkManagementFault the work management fault
     * @throws Exception           http://localhost:9000/wealth/pfs/WorkManagement
     */
    @PayloadRoot(namespace = NAMESPACE_URI, localPart = "createObjects")
    @ResponsePayload
    public CreateObjectsResponse createObjects(
            @RequestPayload CreateObjects request,
            @SoapHeader("{" + JH_HEADER_NS + "}JHHeader") SoapHeaderElement jhHeaderElement,
            MessageContext messageContext) throws WorkManagementFault,Exception {

        CreateObjectsResponse reply = null;
        JHHeader header = parseHeader(jhHeaderElement);
        validateHeader(header);

        String messageUUID = header.getMessageUID();
        String sourceSystemName = header.getMessageSource().getApplicationName();
        String userId = header.getMessageSource().getUserID();
        LoggerHandler.LogOut("INFO", "1", "messageUUID", "sourceSystemName", this.getClass().getName(),
                "Entering Create Objects " + loggerUtils.writeAsJson(request));
        try {

            reply = createWorkManagementOrchestration.createWorkManagement(header, request).getCreateObjectsResponse();

            LoggerHandler.LogOut("INFO", "6", messageUUID, sourceSystemName, this.getClass().getName(),
                    "Exiting Create Objects EndPoint " + loggerUtils.writeAsJson(reply));

        }catch ( Exception e) {
            LoggerHandler.ErrorOut(e, messageUUID, sourceSystemName, this.getClass().getName(), e.getMessage());

            throw e;
        }
        // add response header as a property to be used by EndpointInterceptor
        // Current service does not modify header on response
        messageContext.setProperty(HeaderKey.JH_HEADER_KEY.getValue(), header);
        LoggingContextHolder.getLoggingContext().clear();

        return reply;
    }


    /**
     * Update objects update objects response.
     *
     * @param request         the request
     * @param jhHeaderElement the jh header element
     * @param messageContext  the message context
     *
     * @return update objects response
     *
     * @throws WorkManagementFault the work management fault
     */
    @PayloadRoot(namespace = NAMESPACE_URI, localPart = "updateObjects")
    @ResponsePayload
    public UpdateObjectsResponse updateObjects(
            @RequestPayload UpdateObjects request,
            @SoapHeader("{" + JH_HEADER_NS + "}JHHeader") SoapHeaderElement jhHeaderElement,
            MessageContext messageContext) throws WorkManagementFault,Exception {

        UpdateObjectsResponse reply = null;
        JHHeader header = parseHeader(jhHeaderElement);
        validateHeader(header);

        String messageUUID = header.getMessageUID();
        String sourceSystemName = header.getMessageSource().getApplicationName();
        String userId = header.getMessageSource().getUserID();
        LoggerHandler.LogOut("INFO", "1", "messageUUID", "sourceSystemName", this.getClass().getName(),
                "Entering Update Endpoint Request " + loggerUtils.writeAsJson(request));
        try {
            LoggerHandler.LogOut("INFO", "1", messageUUID, sourceSystemName, this.getClass().getName(),
                    "Entering updateObjects EndPoint " + loggerUtils.writeAsJson(request));


            reply = updateWorkManagementOrchestration.updateWorkManagement(header, request).getUpdateObjects();

            LoggerHandler.LogOut("INFO", "6", messageUUID, sourceSystemName, this.getClass().getName(),
                    "Exiting updateObjects EndPoint " + loggerUtils.writeAsJson(reply));

        }catch (final Exception e) {
            LoggerHandler.ErrorOut(e, messageUUID, sourceSystemName, this.getClass().getName(), e.getMessage());
            throw e;
        }

        // add response header as a property to be used by EndpointInterceptor
        // Current service does not modify header on response

        messageContext.setProperty(HeaderKey.JH_HEADER_KEY.getValue(), header);
        LoggingContextHolder.getLoggingContext().clear();
        return reply;
    }


    /**
     * @param jhHeaderElement
     * @return
     */
    private JHHeader parseHeader(final SoapHeaderElement jhHeaderElement) {
        // parse JH Header if present
        JHHeader header = null;
        if (null != jhHeaderElement) {
            header = jhHeaderJaxbUtils.unmarshallJHHeader(jhHeaderElement);
        } else {
            throw new BadRequestException("Missing Header");
        }

        return header;
    }

    /**
     * @param header
     */
    private void validateHeader(final JHHeader header) {
        if ((header == null) || (header.getMessageSource() == null)
                || StringUtils.isEmpty(header.getMessageSource().getApplicationName())) {
            throw new BadRequestException("Invalid Header Sent");
        }
    }
}
