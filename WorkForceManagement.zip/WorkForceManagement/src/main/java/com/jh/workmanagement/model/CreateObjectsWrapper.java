package com.jh.workmanagement.model;

import com.manulife.esb.xsd.common.jh.header.JHHeader;
import com.manulife.esb.xsd.jh.workmanagement.CreateObjects;

public class CreateObjectsWrapper {
    private CreateObjects createObjects;
    private JHHeader header;

    public CreateObjects getCreateObjects() {
        return createObjects;
    }

    public void setCreateObjects(CreateObjects createObjects) {
        this.createObjects = createObjects;
    }

    public JHHeader getHeader() {
        return header;
    }

    public void setHeader(JHHeader header) {
        this.header = header;
    }
}
