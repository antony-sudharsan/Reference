/**
 * 
 */
package com.jh.workmanagement.controller;

import com.jh.common.logging.LoggerHandler;
import com.jh.workmanagement.model.CreateObjectsResponseWrapper;
import com.jh.workmanagement.model.CreateObjectsWrapper;
import com.jh.workmanagement.model.UpdateObjectsResponseWrapper;
import com.jh.workmanagement.model.UpdateObjectsWrapper;
import com.jh.workmanagement.orchestration.CreateWorkManagementOrchestration;
import com.jh.workmanagement.orchestration.UpdateWorkManagementOrchestration;
import com.jh.workmanagement.utils.JHHeaderUtils;
import com.jh.workmanagement.utils.LoggerUtils;
import com.jh.workmanagement.utils.LoggingContextHolder;
import com.manulife.esb.xsd.jh.workmanagement.CreateObjectsResponse;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.DataBinder;
import org.springframework.web.bind.annotation.*;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

/**
 * The type Work management controller.
 *
 * @author jaiswra
 */
@RestController
@EnableSwagger2
public class WorkManagementController {

    @Autowired
    CreateWorkManagementOrchestration createWorkManagementOrchestration;

    @Autowired
    UpdateWorkManagementOrchestration updateWorkManagementOrchestration;

    private LoggerUtils loggerUtils;
    /**
     * Activate direct field access.
     *
     * @param dataBinder the data binder
     */
    @InitBinder
    public void activateDirectFieldAccess(final DataBinder dataBinder) {
        dataBinder.initDirectFieldAccess();
    }


    public WorkManagementController(CreateWorkManagementOrchestration createWorkManagementOrchestration, UpdateWorkManagementOrchestration updateWorkManagementOrchestration, LoggerUtils loggerUtils) {
        this.createWorkManagementOrchestration = createWorkManagementOrchestration;
        this.updateWorkManagementOrchestration = updateWorkManagementOrchestration;
        this.loggerUtils = loggerUtils;
    }

    @ApiOperation(
            value = "Create Objects",
            notes = "Service will Create objects",
            response = CreateObjectsResponseWrapper.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Success"),
            @ApiResponse(code = 406, message = "Service Processing Error"),
            @ApiResponse(code = 408, message = "Request Timeout"),
            @ApiResponse(code = 500, message = "SQL Server Backend returned an error"),
            @ApiResponse(code = 400, message = "Validation Failed"),
            @ApiResponse(code = 404, message = "Auth data Record not found "),
            @ApiResponse(code = 401, message = "Unauthorized to perform operation")
    })
    @RequestMapping(value = "/createObjects", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CreateObjectsResponseWrapper> createWorkManagement(@RequestBody CreateObjectsWrapper request) throws Exception {
        final String messageUUID = JHHeaderUtils.retrieveOrDefaultMessageUID(request.getHeader(),
                "createObjects");
        final String sourceSystemName = JHHeaderUtils.retrieveOrDefaultSourceSystemName(request.getHeader());

        CreateObjectsResponseWrapper createObjectsResponseWrapper;
        try {
            LoggingContextHolder.getLoggingContext().setContext(messageUUID, sourceSystemName);

            JHHeaderUtils.validateHeader(request.getHeader());
            LoggerHandler.LogOut("INFO", "1", messageUUID, sourceSystemName, this.getClass().getName(), "Entering createWorkManagement Controller");
            createObjectsResponseWrapper = createWorkManagementOrchestration.createWorkManagement(request.getHeader(), request.getCreateObjects());

            LoggerHandler.LogOut("INFO", "6", messageUUID, sourceSystemName, this.getClass().getName(), "Exiting createWorkManagement Controller");
            LoggerHandler.LogOut("DEBUG", "6", messageUUID, sourceSystemName, this.getClass().getName(), "Controller createWorkManagement Success");

        } catch (final Exception e) {
            LoggerHandler.ErrorOut(e, messageUUID, sourceSystemName, this.getClass().getName(), e.getMessage());
            throw e;
        }

        return new ResponseEntity(createObjectsResponseWrapper, new HttpHeaders(), HttpStatus.OK);

    }

    @ApiOperation(
            value = "Update Objects",
            notes = "Service will Update objects",
            response = CreateObjectsResponseWrapper.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Success"),
            @ApiResponse(code = 406, message = "Service Processing Error"),
            @ApiResponse(code = 408, message = "Request Timeout"),
            @ApiResponse(code = 500, message = "SQL Server Backend returned an error"),
            @ApiResponse(code = 400, message = "Validation Failed"),
            @ApiResponse(code = 404, message = "Auth data Record not found "),
            @ApiResponse(code = 401, message = "Unauthorized to perform operation")
    })
    @RequestMapping(value = "/updateObjects", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<UpdateObjectsResponseWrapper> updateWorkManagement(@RequestBody UpdateObjectsWrapper request) throws Exception {
        final String messageUUID = JHHeaderUtils.retrieveOrDefaultMessageUID(request.getHeader(),
                "updateObjects");
        final String sourceSystemName = JHHeaderUtils.retrieveOrDefaultSourceSystemName(request.getHeader());

        UpdateObjectsResponseWrapper updateObjectsResponseWrapper;
        try {
            LoggingContextHolder.getLoggingContext().setContext(messageUUID, sourceSystemName);

            JHHeaderUtils.validateHeader(request.getHeader());
            LoggerHandler.LogOut("INFO", "1", messageUUID, sourceSystemName, this.getClass().getName(), "Entering updateWorkManagement Controller");
            updateObjectsResponseWrapper = updateWorkManagementOrchestration.updateWorkManagement(request.getHeader(), request.getUpdateObjects());

            LoggerHandler.LogOut("INFO", "6", messageUUID, sourceSystemName, this.getClass().getName(), "Exiting updateWorkManagement Controller");
            LoggerHandler.LogOut("DEBUG", "6", messageUUID, sourceSystemName, this.getClass().getName(), "Controller updateWorkManagement Success");


        } catch (final Exception e) {
            LoggerHandler.ErrorOut(e, messageUUID, sourceSystemName, this.getClass().getName(), e.getMessage());
            throw e;
        }

        return new ResponseEntity(updateObjectsResponseWrapper, new HttpHeaders(), HttpStatus.OK);

    }
/*@Autowired
	private ICreateServiceWM createServiceWM;
	@Autowired
	private IUpdateServiceWM updateServiceWM;
	@Autowired
	private CreateObjectResponseOutput createObjectResponseOutput;
	@Autowired
	private UpdateObjectResponseOutput updateObjectResponseOutput;

	
	@RequestMapping(value ="/CreateObjects", method = RequestMethod.POST,produces = MediaType.APPLICATION_XML_VALUE)
	public @ResponseBody CreateObjectResponseOutput  createObjects(@RequestBody CreateObjectRequestInput createObjectRequestInput,@RequestHeader("userId") String userID,@RequestHeader("MessageUUID") String messageUUID, @RequestHeader("SourceSystemName") String sourceSystemName)
			throws Exception{
		
			LoggerHandler.LogOut("INFO", "1", messageUUID, sourceSystemName, this.getClass().getName(), userID);	
			LoggerHandler.LogOut("DEBUG", "1", messageUUID, sourceSystemName, this.getClass().getName(), userID);
			
			createObjectResponseOutput = createServiceWM.createObjects(createObjectRequestInput, userID,messageUUID,sourceSystemName);
			
			LoggerHandler.LogOut("INFO", "4", messageUUID, sourceSystemName, this.getClass().getName(), userID);	
			LoggerHandler.LogOut("DEBUG", "4", messageUUID, sourceSystemName, this.getClass().getName(), userID);

*//*		}catch(Exception e) {
			
			createObjectResponseOutput = new CreateObjectResponseOutput();
			ExceptionRES exceptionRES =  new ExceptionRES();
			//createObjectResponseOutput.getExceptionRES();
			exceptionRES.setMessage(e.getMessage());
			createObjectResponseOutput.setException(exceptionRES);
			
		}*//*


		return createObjectResponseOutput;


	}


	@RequestMapping(value ="/UpdateObjects", method = RequestMethod.PUT,produces = MediaType.APPLICATION_XML_VALUE)
	public @ResponseBody UpdateObjectResponseOutput  updateObjects(@RequestBody UpdateObjectRequestInput updateObjectRequestInput,@RequestHeader("userId") String userID ,@RequestHeader("MessageUUID") String messageUUID, @RequestHeader("SourceSystemName") String sourceSystemName) {

		try {

			LoggerHandler.LogOut("INFO", "1", messageUUID, sourceSystemName, this.getClass().getName(), userID);	
			LoggerHandler.LogOut("DEBUG", "1", messageUUID, sourceSystemName, this.getClass().getName(), userID);
			
			updateObjectResponseOutput = updateServiceWM.updateObjects(updateObjectRequestInput, userID,messageUUID,sourceSystemName);
			
			LoggerHandler.LogOut("INFO", "4", messageUUID, sourceSystemName, this.getClass().getName(), userID);	
			LoggerHandler.LogOut("DEBUG", "4", messageUUID, sourceSystemName, this.getClass().getName(), userID);


		}catch(Exception e) {
			
			updateObjectResponseOutput = new UpdateObjectResponseOutput();
			ExceptionREU exceptionREU =  new ExceptionREU();
			//createObjectResponseOutput.getExceptionRES();
			exceptionREU.setMessage(e.getMessage());
			updateObjectResponseOutput.setException(exceptionREU);
		}


		return updateObjectResponseOutput;


	}*/

}





