
package com.manulife.esb.xsd.jh.workmanagement;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for suspend complex type.
 *
 * <p>The following schema fragment specifies the expected content contained within this class.
 *
 * <pre>
 * &lt;complexType name="suspend">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;attribute name="activationDate" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="activationRoutingStatus" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="duration" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="reasonCode" type="{http://www.w3.org/2001/XMLSchema}string" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "suspend")
public class Suspend {

    /**
     * The Activation date.
     */
    @XmlAttribute(name = "activationDate")
    protected String activationDate;
    /**
     * The Activation routing status.
     */
    @XmlAttribute(name = "activationRoutingStatus")
    protected String activationRoutingStatus;
    /**
     * The Duration.
     */
    @XmlAttribute(name = "duration")
    protected String duration;
    /**
     * The Reason code.
     */
    @XmlAttribute(name = "reasonCode")
    protected String reasonCode;

    /**
     * Gets the value of the activationDate property.
     *
     * @return possible      object is     {@link String }
     */
    public String getActivationDate() {
        return activationDate;
    }

    /**
     * Sets the value of the activationDate property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setActivationDate(String value) {
        this.activationDate = value;
    }

    /**
     * Gets the value of the activationRoutingStatus property.
     *
     * @return possible      object is     {@link String }
     */
    public String getActivationRoutingStatus() {
        return activationRoutingStatus;
    }

    /**
     * Sets the value of the activationRoutingStatus property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setActivationRoutingStatus(String value) {
        this.activationRoutingStatus = value;
    }

    /**
     * Gets the value of the duration property.
     *
     * @return possible      object is     {@link String }
     */
    public String getDuration() {
        return duration;
    }

    /**
     * Sets the value of the duration property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setDuration(String value) {
        this.duration = value;
    }

    /**
     * Gets the value of the reasonCode property.
     *
     * @return possible      object is     {@link String }
     */
    public String getReasonCode() {
        return reasonCode;
    }

    /**
     * Sets the value of the reasonCode property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setReasonCode(String value) {
        this.reasonCode = value;
    }

}
