
package com.manulife.esb.xsd.jh.workmanagement;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElements;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for GetObjectsResponse complex type.
 *
 * <p>The following schema fragment specifies the expected content contained within this class.
 *
 * <pre>
 * &lt;complexType name="GetObjectsResponse">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;choice maxOccurs="unbounded" minOccurs="0">
 *           &lt;element ref="{http://www.esb.manulife.com/xsd/jh/WorkManagement}folderInstance"/>
 *           &lt;element ref="{http://www.esb.manulife.com/xsd/jh/WorkManagement}sourceInstance"/>
 *           &lt;element ref="{http://www.esb.manulife.com/xsd/jh/WorkManagement}workInstance"/>
 *         &lt;/choice>
 *         &lt;element name="immediateRelationships" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="relateObjects" type="{http://www.esb.manulife.com/xsd/jh/WorkManagement}relateOnlyExistingObjects" maxOccurs="unbounded" minOccurs="0"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "GetObjectsResponse", propOrder = {
    "folderInstanceOrSourceInstanceOrWorkInstance",
    "immediateRelationships"
})
public class GetObjectsResponse {


    /**
     * The Folder instance or source instance or work instance.
     */
    @XmlElements({
        @XmlElement(name = "folderInstance", type = FolderInstance.class),
        @XmlElement(name = "sourceInstance", type = SourceInstance.class),
        @XmlElement(name = "workInstance", type = WorkInstance.class)
    })
    protected List<Object> folderInstanceOrSourceInstanceOrWorkInstance;

    /**
     * Sets folder instance or source instance or work instance.
     *
     * @param folderInstanceOrSourceInstanceOrWorkInstance the folder instance or source instance or work instance
     */
    public void setFolderInstanceOrSourceInstanceOrWorkInstance(List<Object> folderInstanceOrSourceInstanceOrWorkInstance) {
        this.folderInstanceOrSourceInstanceOrWorkInstance = folderInstanceOrSourceInstanceOrWorkInstance;
    }


    /**
     * The Immediate relationships.
     */
    protected ImmediateRelationships immediateRelationships;

    /**
     * Gets the value of the folderInstanceOrSourceInstanceOrWorkInstance property.
     * <p>
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the folderInstanceOrSourceInstanceOrWorkInstance property.
     * <p>
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getFolderInstanceOrSourceInstanceOrWorkInstance().add(newItem);
     * </pre>
     * <p>
     * <p>
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link FolderInstance }
     * {@link SourceInstance }
     * {@link WorkInstance }
     *
     * @return the folder instance or source instance or work instance
     */
    public List<Object> getFolderInstanceOrSourceInstanceOrWorkInstance() {
        if (folderInstanceOrSourceInstanceOrWorkInstance == null) {
            folderInstanceOrSourceInstanceOrWorkInstance = new ArrayList<Object>();
        }
        return this.folderInstanceOrSourceInstanceOrWorkInstance;
    }

    /**
     * Gets the value of the immediateRelationships property.
     *
     * @return possible      object is     {@link ImmediateRelationships }
     */
    public ImmediateRelationships getImmediateRelationships() {
        return immediateRelationships;
    }

    /**
     * Sets the value of the immediateRelationships property.
     *
     * @param value allowed object is     {@link ImmediateRelationships }
     */
    public void setImmediateRelationships(ImmediateRelationships value) {
        this.immediateRelationships = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     *
     * <p>The following schema fragment specifies the expected content contained within this class.
     *
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="relateObjects" type="{http://www.esb.manulife.com/xsd/jh/WorkManagement}relateOnlyExistingObjects" maxOccurs="unbounded" minOccurs="0"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "relateObjects"
    })
    public static class ImmediateRelationships {

        /**
         * Sets relate objects.
         *
         * @param relateObjects the relate objects
         */
        public void setRelateObjects(List<RelateOnlyExistingObjects> relateObjects) {
            this.relateObjects = relateObjects;
        }

        /**
         * The Relate objects.
         */
        protected List<RelateOnlyExistingObjects> relateObjects;

        /**
         * Gets the value of the relateObjects property.
         * <p>
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the relateObjects property.
         * <p>
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getRelateObjects().add(newItem);
         * </pre>
         * <p>
         * <p>
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link RelateOnlyExistingObjects }
         *
         * @return the relate objects
         */
        public List<RelateOnlyExistingObjects> getRelateObjects() {
            if (relateObjects == null) {
                relateObjects = new ArrayList<RelateOnlyExistingObjects>();
            }
            return this.relateObjects;
        }

    }

}
