
package com.manulife.esb.xsd.jh.workmanagement;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElements;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for updateObjectRequest complex type.
 *
 * <p>The following schema fragment specifies the expected content contained within this class.
 *
 * <pre>
 * &lt;complexType name="updateObjectRequest">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="responseDetails" type="{http://www.esb.manulife.com/xsd/jh/WorkManagement}responseDetails" minOccurs="0"/>
 *         &lt;choice maxOccurs="unbounded" minOccurs="0">
 *           &lt;element ref="{http://www.esb.manulife.com/xsd/jh/WorkManagement}updateFolderInstance"/>
 *           &lt;element ref="{http://www.esb.manulife.com/xsd/jh/WorkManagement}updateSourceInstance"/>
 *           &lt;element ref="{http://www.esb.manulife.com/xsd/jh/WorkManagement}updateWorkInstance"/>
 *         &lt;/choice>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "updateObjectRequest", propOrder = {
    "responseDetails",
    "updateFolderInstanceOrUpdateSourceInstanceOrUpdateWorkInstance"
})
public class UpdateObjectRequest {

    /**
     * The Response details.
     */
    protected ResponseDetails responseDetails;
    /**
     * The Update folder instance or update source instance or update work instance.
     */
    @XmlElements({
        @XmlElement(name = "updateFolderInstance", type = UpdateFolderInstance.class),
        @XmlElement(name = "updateSourceInstance", type = UpdateSourceInstance.class),
        @XmlElement(name = "updateWorkInstance", type = UpdateWorkInstance.class)
    })
    protected List<Object> updateFolderInstanceOrUpdateSourceInstanceOrUpdateWorkInstance;

    /**
     * Gets the value of the responseDetails property.
     *
     * @return possible      object is     {@link ResponseDetails }
     */
    public ResponseDetails getResponseDetails() {
        return responseDetails;
    }

    /**
     * Sets the value of the responseDetails property.
     *
     * @param value allowed object is     {@link ResponseDetails }
     */
    public void setResponseDetails(ResponseDetails value) {
        this.responseDetails = value;
    }

    /**
     * Gets the value of the updateFolderInstanceOrUpdateSourceInstanceOrUpdateWorkInstance property.
     * <p>
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the updateFolderInstanceOrUpdateSourceInstanceOrUpdateWorkInstance property.
     * <p>
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getUpdateFolderInstanceOrUpdateSourceInstanceOrUpdateWorkInstance().add(newItem);
     * </pre>
     * <p>
     * <p>
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link UpdateFolderInstance }
     * {@link UpdateSourceInstance }
     * {@link UpdateWorkInstance }
     *
     * @return the update folder instance or update source instance or update work instance
     */
    public List<Object> getUpdateFolderInstanceOrUpdateSourceInstanceOrUpdateWorkInstance() {
        if (updateFolderInstanceOrUpdateSourceInstanceOrUpdateWorkInstance == null) {
            updateFolderInstanceOrUpdateSourceInstanceOrUpdateWorkInstance = new ArrayList<Object>();
        }
        return this.updateFolderInstanceOrUpdateSourceInstanceOrUpdateWorkInstance;
    }

}
