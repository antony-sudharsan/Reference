
package com.manulife.esb.xsd.jh.workmanagement;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for getNewAssignmentRequest complex type.
 *
 * <p>The following schema fragment specifies the expected content contained within this class.
 *
 * <pre>
 * &lt;complexType name="getNewAssignmentRequest">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/jh/WorkManagement}responseDetails" minOccurs="0"/>
 *       &lt;/sequence>
 *       &lt;attribute name="maxSelectedItems" use="required" type="{http://www.w3.org/2001/XMLSchema}int" />
 *       &lt;attribute name="maxWorkItems" use="required" type="{http://www.w3.org/2001/XMLSchema}int" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "getNewAssignmentRequest", propOrder = {
    "responseDetails"
})
public class GetNewAssignmentRequest {

    /**
     * The Response details.
     */
    protected ResponseDetails responseDetails;
    /**
     * The Max selected items.
     */
    @XmlAttribute(name = "maxSelectedItems", required = true)
    protected int maxSelectedItems;
    /**
     * The Max work items.
     */
    @XmlAttribute(name = "maxWorkItems", required = true)
    protected int maxWorkItems;

    /**
     * Gets the value of the responseDetails property.
     *
     * @return possible      object is     {@link ResponseDetails }
     */
    public ResponseDetails getResponseDetails() {
        return responseDetails;
    }

    /**
     * Sets the value of the responseDetails property.
     *
     * @param value allowed object is     {@link ResponseDetails }
     */
    public void setResponseDetails(ResponseDetails value) {
        this.responseDetails = value;
    }

    /**
     * Gets the value of the maxSelectedItems property.
     *
     * @return the max selected items
     */
    public int getMaxSelectedItems() {
        return maxSelectedItems;
    }

    /**
     * Sets the value of the maxSelectedItems property.
     *
     * @param value the value
     */
    public void setMaxSelectedItems(int value) {
        this.maxSelectedItems = value;
    }

    /**
     * Gets the value of the maxWorkItems property.
     *
     * @return the max work items
     */
    public int getMaxWorkItems() {
        return maxWorkItems;
    }

    /**
     * Sets the value of the maxWorkItems property.
     *
     * @param value the value
     */
    public void setMaxWorkItems(int value) {
        this.maxWorkItems = value;
    }

}
