
package com.manulife.esb.xsd.jh.workmanagement;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for lookupObjectsResponse complex type.
 *
 * <p>The following schema fragment specifies the expected content contained within this class.
 *
 * <pre>
 * &lt;complexType name="lookupObjectsResponse">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="lookupObjectsResponse" type="{http://www.esb.manulife.com/xsd/jh/WorkManagement}GetObjectsResponse" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "lookupObjectsResponse", propOrder = {
    "lookupObjectsResponse"
})
public class LookupObjectsResponse {

    /**
     * The Lookup objects response.
     */
    protected GetObjectsResponse lookupObjectsResponse;

    /**
     * Gets the value of the lookupObjectsResponse property.
     *
     * @return possible      object is     {@link GetObjectsResponse }
     */
    public GetObjectsResponse getLookupObjectsResponse() {
        return lookupObjectsResponse;
    }

    /**
     * Sets the value of the lookupObjectsResponse property.
     *
     * @param value allowed object is     {@link GetObjectsResponse }
     */
    public void setLookupObjectsResponse(GetObjectsResponse value) {
        this.lookupObjectsResponse = value;
    }

}
