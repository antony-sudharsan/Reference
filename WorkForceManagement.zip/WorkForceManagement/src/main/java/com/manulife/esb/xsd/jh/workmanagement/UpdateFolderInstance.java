
package com.manulife.esb.xsd.jh.workmanagement;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for updateFolderInstance complex type.
 *
 * <p>The following schema fragment specifies the expected content contained within this class.
 *
 * <pre>
 * &lt;complexType name="updateFolderInstance">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/jh/WorkManagement}updateAWDInstance"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "updateFolderInstance", propOrder = {
    "updateAWDInstance"
})
public class UpdateFolderInstance {

    /**
     * The Update awd instance.
     */
    @XmlElement(required = true)
    protected UpdateAWDInstance updateAWDInstance;

    /**
     * Gets the value of the updateAWDInstance property.
     *
     * @return possible      object is     {@link UpdateAWDInstance }
     */
    public UpdateAWDInstance getUpdateAWDInstance() {
        return updateAWDInstance;
    }

    /**
     * Sets the value of the updateAWDInstance property.
     *
     * @param value allowed object is     {@link UpdateAWDInstance }
     */
    public void setUpdateAWDInstance(UpdateAWDInstance value) {
        this.updateAWDInstance = value;
    }

}
