
package com.manulife.esb.xsd.jh.workmanagement;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for workInstance complex type.
 *
 * <p>The following schema fragment specifies the expected content contained within this class.
 *
 * <pre>
 * &lt;complexType name="workInstance">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/jh/WorkManagement}awdInstance"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/jh/WorkManagement}status" minOccurs="0"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/jh/WorkManagement}workFlow" minOccurs="0"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/jh/WorkManagement}queue" minOccurs="0"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/jh/WorkManagement}priority" minOccurs="0"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/jh/WorkManagement}priorityIncrease" minOccurs="0"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/jh/WorkManagement}suspended" minOccurs="0"/>
 *       &lt;/sequence>
 *       &lt;attribute name="assignedTo" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="instanceType" use="required" type="{http://www.w3.org/2001/XMLSchema}string" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "workInstance", propOrder = {
    "awdInstance",
    "status",
    "workFlow",
    "queue",
    "priority",
    "priorityIncrease",
    "suspended"
})
public class WorkInstance {

    /**
     * The Awd instance.
     */
    @XmlElement(required = true)
    protected AwdInstance awdInstance;
    /**
     * The Status.
     */
    protected String status;
    /**
     * The Work flow.
     */
    protected WorkFlow workFlow;
    /**
     * The Queue.
     */
    protected String queue;
    /**
     * The Priority.
     */
    protected String priority;
    /**
     * The Priority increase.
     */
    protected String priorityIncrease;
    /**
     * The Suspended.
     */
    protected Suspended suspended;
    /**
     * The Assigned to.
     */
    @XmlAttribute(name = "assignedTo")
    protected String assignedTo;
    /**
     * The Instance type.
     */
    @XmlAttribute(name = "instanceType", required = true)
    protected String instanceType;

    /**
     * Gets the value of the awdInstance property.
     *
     * @return possible      object is     {@link AwdInstance }
     */
    public AwdInstance getAwdInstance() {
        return awdInstance;
    }

    /**
     * Sets the value of the awdInstance property.
     *
     * @param value allowed object is     {@link AwdInstance }
     */
    public void setAwdInstance(AwdInstance value) {
        this.awdInstance = value;
    }

    /**
     * Gets the value of the status property.
     *
     * @return possible      object is     {@link String }
     */
    public String getStatus() {
        return status;
    }

    /**
     * Sets the value of the status property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setStatus(String value) {
        this.status = value;
    }

    /**
     * Gets the value of the workFlow property.
     *
     * @return possible      object is     {@link WorkFlow }
     */
    public WorkFlow getWorkFlow() {
        return workFlow;
    }

    /**
     * Sets the value of the workFlow property.
     *
     * @param value allowed object is     {@link WorkFlow }
     */
    public void setWorkFlow(WorkFlow value) {
        this.workFlow = value;
    }

    /**
     * Gets the value of the queue property.
     *
     * @return possible      object is     {@link String }
     */
    public String getQueue() {
        return queue;
    }

    /**
     * Sets the value of the queue property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setQueue(String value) {
        this.queue = value;
    }

    /**
     * Gets the value of the priority property.
     *
     * @return possible      object is     {@link String }
     */
    public String getPriority() {
        return priority;
    }

    /**
     * Sets the value of the priority property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setPriority(String value) {
        this.priority = value;
    }

    /**
     * Gets the value of the priorityIncrease property.
     *
     * @return possible      object is     {@link String }
     */
    public String getPriorityIncrease() {
        return priorityIncrease;
    }

    /**
     * Sets the value of the priorityIncrease property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setPriorityIncrease(String value) {
        this.priorityIncrease = value;
    }

    /**
     * Gets the value of the suspended property.
     *
     * @return possible      object is     {@link Suspended }
     */
    public Suspended getSuspended() {
        return suspended;
    }

    /**
     * Sets the value of the suspended property.
     *
     * @param value allowed object is     {@link Suspended }
     */
    public void setSuspended(Suspended value) {
        this.suspended = value;
    }

    /**
     * Gets the value of the assignedTo property.
     *
     * @return possible      object is     {@link String }
     */
    public String getAssignedTo() {
        return assignedTo;
    }

    /**
     * Sets the value of the assignedTo property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setAssignedTo(String value) {
        this.assignedTo = value;
    }

    /**
     * Gets the value of the instanceType property.
     *
     * @return possible      object is     {@link String }
     */
    public String getInstanceType() {
        return instanceType;
    }

    /**
     * Sets the value of the instanceType property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setInstanceType(String value) {
        this.instanceType = value;
    }

}
