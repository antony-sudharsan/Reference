
package com.manulife.esb.xsd.jh.workmanagement;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for workSteps complex type.
 *
 * <p>The following schema fragment specifies the expected content contained within this class.
 *
 * <pre>
 * &lt;complexType name="workSteps">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/jh/WorkManagement}workStep"/>
 *       &lt;/sequence>
 *       &lt;attribute name="businessArea" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="next" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="status" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="workType" type="{http://www.w3.org/2001/XMLSchema}string" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "workSteps", propOrder = {
    "workStep"
})
public class WorkSteps {

    /**
     * The Work step.
     */
    @XmlElement(required = true)
    protected String workStep;
    /**
     * The Business area.
     */
    @XmlAttribute(name = "businessArea")
    protected String businessArea;
    /**
     * The Next.
     */
    @XmlAttribute(name = "next")
    protected String next;
    /**
     * The Status.
     */
    @XmlAttribute(name = "status")
    protected String status;
    /**
     * The Work type.
     */
    @XmlAttribute(name = "workType")
    protected String workType;

    /**
     * Gets the value of the workStep property.
     *
     * @return possible      object is     {@link String }
     */
    public String getWorkStep() {
        return workStep;
    }

    /**
     * Sets the value of the workStep property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setWorkStep(String value) {
        this.workStep = value;
    }

    /**
     * Gets the value of the businessArea property.
     *
     * @return possible      object is     {@link String }
     */
    public String getBusinessArea() {
        return businessArea;
    }

    /**
     * Sets the value of the businessArea property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setBusinessArea(String value) {
        this.businessArea = value;
    }

    /**
     * Gets the value of the next property.
     *
     * @return possible      object is     {@link String }
     */
    public String getNext() {
        return next;
    }

    /**
     * Sets the value of the next property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setNext(String value) {
        this.next = value;
    }

    /**
     * Gets the value of the status property.
     *
     * @return possible      object is     {@link String }
     */
    public String getStatus() {
        return status;
    }

    /**
     * Sets the value of the status property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setStatus(String value) {
        this.status = value;
    }

    /**
     * Gets the value of the workType property.
     *
     * @return possible      object is     {@link String }
     */
    public String getWorkType() {
        return workType;
    }

    /**
     * Sets the value of the workType property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setWorkType(String value) {
        this.workType = value;
    }

}
