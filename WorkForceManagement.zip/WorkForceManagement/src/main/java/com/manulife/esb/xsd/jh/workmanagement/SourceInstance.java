
package com.manulife.esb.xsd.jh.workmanagement;

import java.math.BigInteger;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for sourceInstance complex type.
 *
 * <p>The following schema fragment specifies the expected content contained within this class.
 *
 * <pre>
 * &lt;complexType name="sourceInstance">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/jh/WorkManagement}awdInstance"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/jh/WorkManagement}accessMethod" minOccurs="0"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/jh/WorkManagement}annotationBlob" minOccurs="0"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/jh/WorkManagement}archiveBox" minOccurs="0"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/jh/WorkManagement}archiveStartPage" minOccurs="0"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/jh/WorkManagement}commentsExist" minOccurs="0"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/jh/WorkManagement}format" minOccurs="0"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/jh/WorkManagement}mailType" minOccurs="0"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/jh/WorkManagement}contentId" minOccurs="0"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/jh/WorkManagement}opticalStatus" minOccurs="0"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/jh/WorkManagement}pageCount" minOccurs="0"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/jh/WorkManagement}path" minOccurs="0"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/jh/WorkManagement}receiveTime" minOccurs="0"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/jh/WorkManagement}revisable" minOccurs="0"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/jh/WorkManagement}securityLevel" minOccurs="0"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/jh/WorkManagement}createUser" minOccurs="0"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/jh/WorkManagement}createStation" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "sourceInstance", propOrder = {
    "awdInstance",
    "accessMethod",
    "annotationBlob",
    "archiveBox",
    "archiveStartPage",
    "commentsExist",
    "format",
    "mailType",
    "contentId",
    "opticalStatus",
    "pageCount",
    "path",
    "receiveTime",
    "revisable",
    "securityLevel",
    "createUser",
    "createStation"
})
public class SourceInstance {

    /**
     * The Awd instance.
     */
    @XmlElement(required = true)
    protected AwdInstance awdInstance;
    /**
     * The Access method.
     */
    protected String accessMethod;
    /**
     * The Annotation blob.
     */
    protected String annotationBlob;
    /**
     * The Archive box.
     */
    protected String archiveBox;
    /**
     * The Archive start page.
     */
    protected String archiveStartPage;
    /**
     * The Comments exist.
     */
    protected String commentsExist;
    /**
     * The Format.
     */
    protected String format;
    /**
     * The Mail type.
     */
    protected String mailType;
    /**
     * The Content id.
     */
    protected String contentId;
    /**
     * The Optical status.
     */
    protected String opticalStatus;
    /**
     * The Page count.
     */
    @XmlSchemaType(name = "nonNegativeInteger")
    protected BigInteger pageCount;
    /**
     * The Path.
     */
    protected String path;
    /**
     * The Receive time.
     */
    protected String receiveTime;
    /**
     * The Revisable.
     */
    protected String revisable;
    /**
     * The Security level.
     */
    protected String securityLevel;
    /**
     * The Create user.
     */
    protected String createUser;
    /**
     * The Create station.
     */
    protected String createStation;

    /**
     * Gets the value of the awdInstance property.
     *
     * @return possible      object is     {@link AwdInstance }
     */
    public AwdInstance getAwdInstance() {
        return awdInstance;
    }

    /**
     * Sets the value of the awdInstance property.
     *
     * @param value allowed object is     {@link AwdInstance }
     */
    public void setAwdInstance(AwdInstance value) {
        this.awdInstance = value;
    }

    /**
     * Gets the value of the accessMethod property.
     *
     * @return possible      object is     {@link String }
     */
    public String getAccessMethod() {
        return accessMethod;
    }

    /**
     * Sets the value of the accessMethod property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setAccessMethod(String value) {
        this.accessMethod = value;
    }

    /**
     * Gets the value of the annotationBlob property.
     *
     * @return possible      object is     {@link String }
     */
    public String getAnnotationBlob() {
        return annotationBlob;
    }

    /**
     * Sets the value of the annotationBlob property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setAnnotationBlob(String value) {
        this.annotationBlob = value;
    }

    /**
     * Gets the value of the archiveBox property.
     *
     * @return possible      object is     {@link String }
     */
    public String getArchiveBox() {
        return archiveBox;
    }

    /**
     * Sets the value of the archiveBox property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setArchiveBox(String value) {
        this.archiveBox = value;
    }

    /**
     * Gets the value of the archiveStartPage property.
     *
     * @return possible      object is     {@link String }
     */
    public String getArchiveStartPage() {
        return archiveStartPage;
    }

    /**
     * Sets the value of the archiveStartPage property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setArchiveStartPage(String value) {
        this.archiveStartPage = value;
    }

    /**
     * Gets the value of the commentsExist property.
     *
     * @return possible      object is     {@link String }
     */
    public String getCommentsExist() {
        return commentsExist;
    }

    /**
     * Sets the value of the commentsExist property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setCommentsExist(String value) {
        this.commentsExist = value;
    }

    /**
     * Gets the value of the format property.
     *
     * @return possible      object is     {@link String }
     */
    public String getFormat() {
        return format;
    }

    /**
     * Sets the value of the format property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setFormat(String value) {
        this.format = value;
    }

    /**
     * Gets the value of the mailType property.
     *
     * @return possible      object is     {@link String }
     */
    public String getMailType() {
        return mailType;
    }

    /**
     * Sets the value of the mailType property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setMailType(String value) {
        this.mailType = value;
    }

    /**
     * Gets the value of the contentId property.
     *
     * @return possible      object is     {@link String }
     */
    public String getContentId() {
        return contentId;
    }

    /**
     * Sets the value of the contentId property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setContentId(String value) {
        this.contentId = value;
    }

    /**
     * Gets the value of the opticalStatus property.
     *
     * @return possible      object is     {@link String }
     */
    public String getOpticalStatus() {
        return opticalStatus;
    }

    /**
     * Sets the value of the opticalStatus property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setOpticalStatus(String value) {
        this.opticalStatus = value;
    }

    /**
     * Gets the value of the pageCount property.
     *
     * @return possible      object is     {@link BigInteger }
     */
    public BigInteger getPageCount() {
        return pageCount;
    }

    /**
     * Sets the value of the pageCount property.
     *
     * @param value allowed object is     {@link BigInteger }
     */
    public void setPageCount(BigInteger value) {
        this.pageCount = value;
    }

    /**
     * Gets the value of the path property.
     *
     * @return possible      object is     {@link String }
     */
    public String getPath() {
        return path;
    }

    /**
     * Sets the value of the path property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setPath(String value) {
        this.path = value;
    }

    /**
     * Gets the value of the receiveTime property.
     *
     * @return possible      object is     {@link String }
     */
    public String getReceiveTime() {
        return receiveTime;
    }

    /**
     * Sets the value of the receiveTime property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setReceiveTime(String value) {
        this.receiveTime = value;
    }

    /**
     * Gets the value of the revisable property.
     *
     * @return possible      object is     {@link String }
     */
    public String getRevisable() {
        return revisable;
    }

    /**
     * Sets the value of the revisable property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setRevisable(String value) {
        this.revisable = value;
    }

    /**
     * Gets the value of the securityLevel property.
     *
     * @return possible      object is     {@link String }
     */
    public String getSecurityLevel() {
        return securityLevel;
    }

    /**
     * Sets the value of the securityLevel property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setSecurityLevel(String value) {
        this.securityLevel = value;
    }

    /**
     * Gets the value of the createUser property.
     *
     * @return possible      object is     {@link String }
     */
    public String getCreateUser() {
        return createUser;
    }

    /**
     * Sets the value of the createUser property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setCreateUser(String value) {
        this.createUser = value;
    }

    /**
     * Gets the value of the createStation property.
     *
     * @return possible      object is     {@link String }
     */
    public String getCreateStation() {
        return createStation;
    }

    /**
     * Sets the value of the createStation property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setCreateStation(String value) {
        this.createStation = value;
    }

}
