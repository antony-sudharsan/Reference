
package com.manulife.esb.xsd.jh.workmanagement;

import javax.xml.bind.annotation.*;


/**
 * <p>Java class for createObjectsResponse complex type.
 *
 * <p>The following schema fragment specifies the expected content contained within this class.
 *
 * <pre>
 * &lt;complexType name="createObjectsResponse">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="ObjectsResponse" type="{http://www.esb.manulife.com/xsd/jh/WorkManagement}GetObjectsResponse" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "createObjectsResponse", propOrder = {
    "objectsResponse"
})
@XmlRootElement(name = "createObjectsResponse")
public class CreateObjectsResponse {

    /**
     * The Objects response.
     */
    @XmlElement(name = "ObjectsResponse")
    protected GetObjectsResponse objectsResponse;

    /**
     * Gets the value of the objectsResponse property.
     *
     * @return possible      object is     {@link GetObjectsResponse }
     */
    public GetObjectsResponse getObjectsResponse() {
        return objectsResponse;
    }

    /**
     * Sets the value of the objectsResponse property.
     *
     * @param value allowed object is     {@link GetObjectsResponse }
     */
    public void setObjectsResponse(GetObjectsResponse value) {
        this.objectsResponse = value;
    }

}
