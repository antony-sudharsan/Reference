
package com.manulife.esb.xsd.jh.workmanagement;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for awdEvent complex type.
 *
 * <p>The following schema fragment specifies the expected content contained within this class.
 *
 * <pre>
 * &lt;complexType name="awdEvent">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/jh/WorkManagement}event"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/jh/WorkManagement}userId" minOccurs="0"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/jh/WorkManagement}userName" minOccurs="0"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/jh/WorkManagement}businessArea" minOccurs="0"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/jh/WorkManagement}type" minOccurs="0"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/jh/WorkManagement}workStep" minOccurs="0"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/jh/WorkManagement}queue" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "awdEvent", propOrder = {
    "event",
    "userId",
    "userName",
    "businessArea",
    "type",
    "workStep",
    "queue"
})
public class AwdEvent {

    /**
     * The Event.
     */
    @XmlElement(required = true)
    protected Event event;
    /**
     * The User id.
     */
    @XmlElement(nillable = true)
    protected String userId;
    /**
     * The User name.
     */
    protected String userName;
    /**
     * The Business area.
     */
    protected String businessArea;
    /**
     * The Type.
     */
    protected String type;
    /**
     * The Work step.
     */
    protected String workStep;
    /**
     * The Queue.
     */
    protected String queue;

    /**
     * Gets the value of the event property.
     *
     * @return possible      object is     {@link Event }
     */
    public Event getEvent() {
        return event;
    }

    /**
     * Sets the value of the event property.
     *
     * @param value allowed object is     {@link Event }
     */
    public void setEvent(Event value) {
        this.event = value;
    }

    /**
     * Gets the value of the userId property.
     *
     * @return possible      object is     {@link String }
     */
    public String getUserId() {
        return userId;
    }

    /**
     * Sets the value of the userId property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setUserId(String value) {
        this.userId = value;
    }

    /**
     * Gets the value of the userName property.
     *
     * @return possible      object is     {@link String }
     */
    public String getUserName() {
        return userName;
    }

    /**
     * Sets the value of the userName property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setUserName(String value) {
        this.userName = value;
    }

    /**
     * Gets the value of the businessArea property.
     *
     * @return possible      object is     {@link String }
     */
    public String getBusinessArea() {
        return businessArea;
    }

    /**
     * Sets the value of the businessArea property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setBusinessArea(String value) {
        this.businessArea = value;
    }

    /**
     * Gets the value of the type property.
     *
     * @return possible      object is     {@link String }
     */
    public String getType() {
        return type;
    }

    /**
     * Sets the value of the type property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setType(String value) {
        this.type = value;
    }

    /**
     * Gets the value of the workStep property.
     *
     * @return possible      object is     {@link String }
     */
    public String getWorkStep() {
        return workStep;
    }

    /**
     * Sets the value of the workStep property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setWorkStep(String value) {
        this.workStep = value;
    }

    /**
     * Gets the value of the queue property.
     *
     * @return possible      object is     {@link String }
     */
    public String getQueue() {
        return queue;
    }

    /**
     * Sets the value of the queue property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setQueue(String value) {
        this.queue = value;
    }

}
