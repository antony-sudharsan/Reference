
package com.manulife.esb.xsd.jh.workmanagement;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for getObjectsRequest complex type.
 *
 * <p>The following schema fragment specifies the expected content contained within this class.
 *
 * <pre>
 * &lt;complexType name="getObjectsRequest">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="objectRequests" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="objectRequest" type="{http://www.esb.manulife.com/xsd/jh/WorkManagement}getObjectRequest" maxOccurs="unbounded" minOccurs="0"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/jh/WorkManagement}responseDetails" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "getObjectsRequest", propOrder = {
    "objectRequests",
    "responseDetails"
})
public class GetObjectsRequest {

    /**
     * The Object requests.
     */
    protected ObjectRequests objectRequests;
    /**
     * The Response details.
     */
    protected ResponseDetails responseDetails;

    /**
     * Gets the value of the objectRequests property.
     *
     * @return possible      object is     {@link ObjectRequests }
     */
    public ObjectRequests getObjectRequests() {
        return objectRequests;
    }

    /**
     * Sets the value of the objectRequests property.
     *
     * @param value allowed object is     {@link ObjectRequests }
     */
    public void setObjectRequests(ObjectRequests value) {
        this.objectRequests = value;
    }

    /**
     * Gets the value of the responseDetails property.
     *
     * @return possible      object is     {@link ResponseDetails }
     */
    public ResponseDetails getResponseDetails() {
        return responseDetails;
    }

    /**
     * Sets the value of the responseDetails property.
     *
     * @param value allowed object is     {@link ResponseDetails }
     */
    public void setResponseDetails(ResponseDetails value) {
        this.responseDetails = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     *
     * <p>The following schema fragment specifies the expected content contained within this class.
     *
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="objectRequest" type="{http://www.esb.manulife.com/xsd/jh/WorkManagement}getObjectRequest" maxOccurs="unbounded" minOccurs="0"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "objectRequest"
    })
    public static class ObjectRequests {

        /**
         * The Object request.
         */
        protected List<GetObjectRequest> objectRequest;

        /**
         * Gets the value of the objectRequest property.
         * <p>
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the objectRequest property.
         * <p>
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getObjectRequest().add(newItem);
         * </pre>
         * <p>
         * <p>
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link GetObjectRequest }
         *
         * @return the object request
         */
        public List<GetObjectRequest> getObjectRequest() {
            if (objectRequest == null) {
                objectRequest = new ArrayList<GetObjectRequest>();
            }
            return this.objectRequest;
        }

    }

}
