
package com.manulife.esb.xsd.jh.workmanagement;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for externalSystem complex type.
 *
 * <p>The following schema fragment specifies the expected content contained within this class.
 *
 * <pre>
 * &lt;complexType name="externalSystem">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/jh/WorkManagement}externalDLL" minOccurs="0"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/jh/WorkManagement}externalHost" minOccurs="0"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/jh/WorkManagement}externalParameter" minOccurs="0"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/jh/WorkManagement}externalProcedure" minOccurs="0"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/jh/WorkManagement}order"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "externalSystem", propOrder = {
    "externalDLL",
    "externalHost",
    "externalParameter",
    "externalProcedure",
    "order"
})
public class ExternalSystem {

    /**
     * The External dll.
     */
    protected String externalDLL;
    /**
     * The External host.
     */
    protected String externalHost;
    /**
     * The External parameter.
     */
    protected String externalParameter;
    /**
     * The External procedure.
     */
    protected String externalProcedure;
    /**
     * The Order.
     */
    protected int order;

    /**
     * Gets the value of the externalDLL property.
     *
     * @return possible      object is     {@link String }
     */
    public String getExternalDLL() {
        return externalDLL;
    }

    /**
     * Sets the value of the externalDLL property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setExternalDLL(String value) {
        this.externalDLL = value;
    }

    /**
     * Gets the value of the externalHost property.
     *
     * @return possible      object is     {@link String }
     */
    public String getExternalHost() {
        return externalHost;
    }

    /**
     * Sets the value of the externalHost property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setExternalHost(String value) {
        this.externalHost = value;
    }

    /**
     * Gets the value of the externalParameter property.
     *
     * @return possible      object is     {@link String }
     */
    public String getExternalParameter() {
        return externalParameter;
    }

    /**
     * Sets the value of the externalParameter property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setExternalParameter(String value) {
        this.externalParameter = value;
    }

    /**
     * Gets the value of the externalProcedure property.
     *
     * @return possible      object is     {@link String }
     */
    public String getExternalProcedure() {
        return externalProcedure;
    }

    /**
     * Sets the value of the externalProcedure property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setExternalProcedure(String value) {
        this.externalProcedure = value;
    }

    /**
     * Gets the value of the order property.
     *
     * @return the order
     */
    public int getOrder() {
        return order;
    }

    /**
     * Sets the value of the order property.
     *
     * @param value the value
     */
    public void setOrder(int value) {
        this.order = value;
    }

}
