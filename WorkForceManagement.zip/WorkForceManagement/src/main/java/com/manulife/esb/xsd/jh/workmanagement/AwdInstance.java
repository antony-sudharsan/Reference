
package com.manulife.esb.xsd.jh.workmanagement;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElements;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for awdInstance complex type.
 *
 * <p>The following schema fragment specifies the expected content contained within this class.
 *
 * <pre>
 * &lt;complexType name="awdInstance">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/jh/WorkManagement}createTime" minOccurs="0"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/jh/WorkManagement}comments" minOccurs="0"/>
 *         &lt;choice maxOccurs="unbounded" minOccurs="0">
 *           &lt;element ref="{http://www.esb.manulife.com/xsd/jh/WorkManagement}keEvent"/>
 *           &lt;element ref="{http://www.esb.manulife.com/xsd/jh/WorkManagement}qualityEvent"/>
 *           &lt;element ref="{http://www.esb.manulife.com/xsd/jh/WorkManagement}systemEvent"/>
 *         &lt;/choice>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/jh/WorkManagement}fieldValues" minOccurs="0"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/jh/WorkManagement}businessArea" minOccurs="0"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/jh/WorkManagement}type" minOccurs="0"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/jh/WorkManagement}customScreen" minOccurs="0"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/jh/WorkManagement}iconName" minOccurs="0"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/jh/WorkManagement}tagLine" minOccurs="0"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/jh/WorkManagement}externalSystems" minOccurs="0"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/jh/WorkManagement}lockedBy" minOccurs="0"/>
 *       &lt;/sequence>
 *       &lt;attribute name="id" use="required" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="permission" type="{http://www.w3.org/2001/XMLSchema}string" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "awdInstance", propOrder = {
    "createTime",
    "comments",
    "keEventOrQualityEventOrSystemEvent",
    "fieldValues",
    "businessArea",
    "type",
    "customScreen",
    "iconName",
    "tagLine",
    "externalSystems",
    "lockedBy"
})
public class AwdInstance {

    /**
     * The Create time.
     */
    protected String createTime;
    /**
     * The Comments.
     */
    protected Comments comments;


    /**
     * The Ke event or quality event or system event.
     */
    @XmlElements({
        @XmlElement(name = "keEvent", type = KeEvent.class),
        @XmlElement(name = "qualityEvent", type = QualityEvent.class),
        @XmlElement(name = "systemEvent", type = SystemEvent.class)
    })
    protected List<Object> keEventOrQualityEventOrSystemEvent;

    /**
     * Sets ke event or quality event or system event.
     *
     * @param keEventOrQualityEventOrSystemEvent the ke event or quality event or system event
     */
    public void setKeEventOrQualityEventOrSystemEvent(List<Object> keEventOrQualityEventOrSystemEvent) {
        this.keEventOrQualityEventOrSystemEvent = keEventOrQualityEventOrSystemEvent;
    }

    /**
     * The Field values.
     */
    protected FieldValues fieldValues;
    /**
     * The Business area.
     */
    protected String businessArea;
    /**
     * The Type.
     */
    protected String type;
    /**
     * The Custom screen.
     */
    protected String customScreen;
    /**
     * The Icon name.
     */
    protected String iconName;
    /**
     * The Tag line.
     */
    protected String tagLine;
    /**
     * The External systems.
     */
    protected ExternalSystems externalSystems;
    /**
     * The Locked by.
     */
    protected String lockedBy;
    /**
     * The Id.
     */
    @XmlAttribute(name = "id", required = true)
    protected String id;
    /**
     * The Permission.
     */
    @XmlAttribute(name = "permission")
    protected String permission;

    /**
     * Gets the value of the createTime property.
     *
     * @return possible      object is     {@link String }
     */
    public String getCreateTime() {
        return createTime;
    }

    /**
     * Sets the value of the createTime property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setCreateTime(String value) {
        this.createTime = value;
    }

    /**
     * Gets the value of the comments property.
     *
     * @return possible      object is     {@link Comments }
     */
    public Comments getComments() {
        return comments;
    }

    /**
     * Sets the value of the comments property.
     *
     * @param value allowed object is     {@link Comments }
     */
    public void setComments(Comments value) {
        this.comments = value;
    }

    /**
     * Gets the value of the keEventOrQualityEventOrSystemEvent property.
     * <p>
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the keEventOrQualityEventOrSystemEvent property.
     * <p>
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getKeEventOrQualityEventOrSystemEvent().add(newItem);
     * </pre>
     * <p>
     * <p>
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link KeEvent }
     * {@link QualityEvent }
     * {@link SystemEvent }
     *
     * @return the ke event or quality event or system event
     */
    public List<Object> getKeEventOrQualityEventOrSystemEvent() {
        if (keEventOrQualityEventOrSystemEvent == null) {
            keEventOrQualityEventOrSystemEvent = new ArrayList<Object>();
        }
        return this.keEventOrQualityEventOrSystemEvent;
    }

    /**
     * Gets the value of the fieldValues property.
     *
     * @return possible      object is     {@link FieldValues }
     */
    public FieldValues getFieldValues() {
        return fieldValues;
    }

    /**
     * Sets the value of the fieldValues property.
     *
     * @param value allowed object is     {@link FieldValues }
     */
    public void setFieldValues(FieldValues value) {
        this.fieldValues = value;
    }

    /**
     * Gets the value of the businessArea property.
     *
     * @return possible      object is     {@link String }
     */
    public String getBusinessArea() {
        return businessArea;
    }

    /**
     * Sets the value of the businessArea property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setBusinessArea(String value) {
        this.businessArea = value;
    }

    /**
     * Gets the value of the type property.
     *
     * @return possible      object is     {@link String }
     */
    public String getType() {
        return type;
    }

    /**
     * Sets the value of the type property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setType(String value) {
        this.type = value;
    }

    /**
     * Gets the value of the customScreen property.
     *
     * @return possible      object is     {@link String }
     */
    public String getCustomScreen() {
        return customScreen;
    }

    /**
     * Sets the value of the customScreen property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setCustomScreen(String value) {
        this.customScreen = value;
    }

    /**
     * Gets the value of the iconName property.
     *
     * @return possible      object is     {@link String }
     */
    public String getIconName() {
        return iconName;
    }

    /**
     * Sets the value of the iconName property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setIconName(String value) {
        this.iconName = value;
    }

    /**
     * Gets the value of the tagLine property.
     *
     * @return possible      object is     {@link String }
     */
    public String getTagLine() {
        return tagLine;
    }

    /**
     * Sets the value of the tagLine property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setTagLine(String value) {
        this.tagLine = value;
    }

    /**
     * Gets the value of the externalSystems property.
     *
     * @return possible      object is     {@link ExternalSystems }
     */
    public ExternalSystems getExternalSystems() {
        return externalSystems;
    }

    /**
     * Sets the value of the externalSystems property.
     *
     * @param value allowed object is     {@link ExternalSystems }
     */
    public void setExternalSystems(ExternalSystems value) {
        this.externalSystems = value;
    }

    /**
     * Gets the value of the lockedBy property.
     *
     * @return possible      object is     {@link String }
     */
    public String getLockedBy() {
        return lockedBy;
    }

    /**
     * Sets the value of the lockedBy property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setLockedBy(String value) {
        this.lockedBy = value;
    }

    /**
     * Gets the value of the id property.
     *
     * @return possible      object is     {@link String }
     */
    public String getId() {
        return id;
    }

    /**
     * Sets the value of the id property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setId(String value) {
        this.id = value;
    }

    /**
     * Gets the value of the permission property.
     *
     * @return possible      object is     {@link String }
     */
    public String getPermission() {
        return permission;
    }

    /**
     * Sets the value of the permission property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setPermission(String value) {
        this.permission = value;
    }

}
