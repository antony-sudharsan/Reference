
package com.manulife.esb.xsd.jh.workmanagement;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for folderInstance complex type.
 *
 * <p>The following schema fragment specifies the expected content contained within this class.
 *
 * <pre>
 * &lt;complexType name="folderInstance">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/jh/WorkManagement}awdInstance"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/jh/WorkManagement}createUser" minOccurs="0"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/jh/WorkManagement}createStation" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "folderInstance", propOrder = {
    "awdInstance",
    "createUser",
    "createStation"
})
public class FolderInstance {

    /**
     * The Awd instance.
     */
    @XmlElement(required = true)
    protected AwdInstance awdInstance;
    /**
     * The Create user.
     */
    protected String createUser;
    /**
     * The Create station.
     */
    protected String createStation;

    /**
     * Gets the value of the awdInstance property.
     *
     * @return possible      object is     {@link AwdInstance }
     */
    public AwdInstance getAwdInstance() {
        return awdInstance;
    }

    /**
     * Sets the value of the awdInstance property.
     *
     * @param value allowed object is     {@link AwdInstance }
     */
    public void setAwdInstance(AwdInstance value) {
        this.awdInstance = value;
    }

    /**
     * Gets the value of the createUser property.
     *
     * @return possible      object is     {@link String }
     */
    public String getCreateUser() {
        return createUser;
    }

    /**
     * Sets the value of the createUser property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setCreateUser(String value) {
        this.createUser = value;
    }

    /**
     * Gets the value of the createStation property.
     *
     * @return possible      object is     {@link String }
     */
    public String getCreateStation() {
        return createStation;
    }

    /**
     * Sets the value of the createStation property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setCreateStation(String value) {
        this.createStation = value;
    }

}
