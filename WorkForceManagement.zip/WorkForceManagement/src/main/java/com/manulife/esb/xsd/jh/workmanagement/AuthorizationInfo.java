
package com.manulife.esb.xsd.jh.workmanagement;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for authorizationInfo complex type.
 *
 * <p>The following schema fragment specifies the expected content contained within this class.
 *
 * <pre>
 * &lt;complexType name="authorizationInfo">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/jh/WorkManagement}czValue" minOccurs="0"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/jh/WorkManagement}userId"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/jh/WorkManagement}userStation" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "authorizationInfo", propOrder = {
    "czValue",
    "userId",
    "userStation"
})
public class AuthorizationInfo {

    /**
     * The Cz value.
     */
    protected String czValue;
    /**
     * The User id.
     */
    @XmlElement(required = true, nillable = true)
    protected String userId;
    /**
     * The User station.
     */
    protected String userStation;

    /**
     * Gets the value of the czValue property.
     *
     * @return possible      object is     {@link String }
     */
    public String getCzValue() {
        return czValue;
    }

    /**
     * Sets the value of the czValue property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setCzValue(String value) {
        this.czValue = value;
    }

    /**
     * Gets the value of the userId property.
     *
     * @return possible      object is     {@link String }
     */
    public String getUserId() {
        return userId;
    }

    /**
     * Sets the value of the userId property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setUserId(String value) {
        this.userId = value;
    }

    /**
     * Gets the value of the userStation property.
     *
     * @return possible      object is     {@link String }
     */
    public String getUserStation() {
        return userStation;
    }

    /**
     * Sets the value of the userStation property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setUserStation(String value) {
        this.userStation = value;
    }

    /**
     * Instantiates a new Authorization info.
     *
     * @param czValue the cz value
     * @param userId  the user id
     */
    public AuthorizationInfo(String czValue, String userId) {
        this.czValue = czValue;
        this.userId = userId;
    }

    /**
     * Instantiates a new Authorization info.
     */
    public AuthorizationInfo() {
    }
}
