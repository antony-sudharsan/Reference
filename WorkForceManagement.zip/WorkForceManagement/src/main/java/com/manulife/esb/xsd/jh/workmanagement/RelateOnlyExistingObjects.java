
package com.manulife.esb.xsd.jh.workmanagement;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for relateOnlyExistingObjects complex type.
 *
 * <p>The following schema fragment specifies the expected content contained within this class.
 *
 * <pre>
 * &lt;complexType name="relateOnlyExistingObjects">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/jh/WorkManagement}parentId"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/jh/WorkManagement}childId"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "relateOnlyExistingObjects", propOrder = {
    "parentId",
    "childId"
})
public class RelateOnlyExistingObjects {

    /**
     * The Parent id.
     */
    @XmlElement(required = true)
    protected String parentId;
    /**
     * The Child id.
     */
    @XmlElement(required = true)
    protected String childId;

    /**
     * Gets the value of the parentId property.
     *
     * @return possible      object is     {@link String }
     */
    public String getParentId() {
        return parentId;
    }

    /**
     * Sets the value of the parentId property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setParentId(String value) {
        this.parentId = value;
    }

    /**
     * Gets the value of the childId property.
     *
     * @return possible      object is     {@link String }
     */
    public String getChildId() {
        return childId;
    }

    /**
     * Sets the value of the childId property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setChildId(String value) {
        this.childId = value;
    }

}
