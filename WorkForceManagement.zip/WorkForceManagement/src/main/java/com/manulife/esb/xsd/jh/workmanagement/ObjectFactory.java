
package com.manulife.esb.xsd.jh.workmanagement;

import java.math.BigInteger;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each
 * Java content interface and Java element interface
 * generated in the com.manulife.esb.xsd.jh.workmanagement package.
 * <p>An ObjectFactory allows you to programatically
 * construct new instances of the Java representation
 * for XML content. The Java representation of XML
 * content can consist of schema derived interfaces
 * and classes representing the binding of schema
 * type definitions, element declarations and model
 * groups.  Factory methods for each of these are
 * provided in this class.
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _WorkFlow_QNAME = new QName("http://www.esb.manulife.com/xsd/jh/WorkManagement", "workFlow");
    private final static QName _SecurityLevel_QNAME = new QName("http://www.esb.manulife.com/xsd/jh/WorkManagement", "securityLevel");
    private final static QName _ChildRelationshipId_QNAME = new QName("http://www.esb.manulife.com/xsd/jh/WorkManagement", "childRelationshipId");
    private final static QName _UpdateAWDInstance_QNAME = new QName("http://www.esb.manulife.com/xsd/jh/WorkManagement", "updateAWDInstance");
    private final static QName _Attachment_QNAME = new QName("http://www.esb.manulife.com/xsd/jh/WorkManagement", "attachment");
    private final static QName _AwdInstance_QNAME = new QName("http://www.esb.manulife.com/xsd/jh/WorkManagement", "awdInstance");
    private final static QName _LockedBy_QNAME = new QName("http://www.esb.manulife.com/xsd/jh/WorkManagement", "lockedBy");
    private final static QName _GetNewAssignment_QNAME = new QName("http://www.esb.manulife.com/xsd/jh/WorkManagement", "getNewAssignment");
    private final static QName _DeleteUserId_QNAME = new QName("http://www.esb.manulife.com/xsd/jh/WorkManagement", "deleteUserId");
    private final static QName _CreateAWDInstance_QNAME = new QName("http://www.esb.manulife.com/xsd/jh/WorkManagement", "createAWDInstance");
    private final static QName _ContentId_QNAME = new QName("http://www.esb.manulife.com/xsd/jh/WorkManagement", "contentId");
    private final static QName _Description_QNAME = new QName("http://www.esb.manulife.com/xsd/jh/WorkManagement", "description");
    private final static QName _CommentsExist_QNAME = new QName("http://www.esb.manulife.com/xsd/jh/WorkManagement", "commentsExist");
    private final static QName _CreateSourceInstance_QNAME = new QName("http://www.esb.manulife.com/xsd/jh/WorkManagement", "createSourceInstance");
    private final static QName _DeleteErrorTime_QNAME = new QName("http://www.esb.manulife.com/xsd/jh/WorkManagement", "deleteErrorTime");
    private final static QName _ReferenceId_QNAME = new QName("http://www.esb.manulife.com/xsd/jh/WorkManagement", "referenceId");
    private final static QName _MailType_QNAME = new QName("http://www.esb.manulife.com/xsd/jh/WorkManagement", "mailType");
    private final static QName _ReceiveTime_QNAME = new QName("http://www.esb.manulife.com/xsd/jh/WorkManagement", "receiveTime");
    private final static QName _KeEvent_QNAME = new QName("http://www.esb.manulife.com/xsd/jh/WorkManagement", "keEvent");
    private final static QName _Comment_QNAME = new QName("http://www.esb.manulife.com/xsd/jh/WorkManagement", "comment");
    private final static QName _FolderInstance_QNAME = new QName("http://www.esb.manulife.com/xsd/jh/WorkManagement", "folderInstance");
    private final static QName _Revisable_QNAME = new QName("http://www.esb.manulife.com/xsd/jh/WorkManagement", "revisable");
    private final static QName _VIP_QNAME = new QName("http://www.esb.manulife.com/xsd/jh/WorkManagement", "VIP");
    private final static QName _PageCount_QNAME = new QName("http://www.esb.manulife.com/xsd/jh/WorkManagement", "pageCount");
    private final static QName _UpdateObjects_QNAME = new QName("http://www.esb.manulife.com/xsd/jh/WorkManagement", "updateObjects");
    private final static QName _CreateObjectsResponse_QNAME = new QName("http://www.esb.manulife.com/xsd/jh/WorkManagement", "createObjectsResponse");
    private final static QName _GetNewAssignmentResponse_QNAME = new QName("http://www.esb.manulife.com/xsd/jh/WorkManagement", "getNewAssignmentResponse");
    private final static QName _RetrieveObjectsResponse_QNAME = new QName("http://www.esb.manulife.com/xsd/jh/WorkManagement", "retrieveObjectsResponse");
    private final static QName _ResponseDetails_QNAME = new QName("http://www.esb.manulife.com/xsd/jh/WorkManagement", "responseDetails");
    private final static QName _UpdateFolderInstance_QNAME = new QName("http://www.esb.manulife.com/xsd/jh/WorkManagement", "updateFolderInstance");
    private final static QName _Exception_QNAME = new QName("http://www.esb.manulife.com/xsd/jh/WorkManagement", "Exception");
    private final static QName _Message_QNAME = new QName("http://www.esb.manulife.com/xsd/jh/WorkManagement", "message");
    private final static QName _UserName_QNAME = new QName("http://www.esb.manulife.com/xsd/jh/WorkManagement", "userName");
    private final static QName _ReturnCode_QNAME = new QName("http://www.esb.manulife.com/xsd/jh/WorkManagement", "returnCode");
    private final static QName _AuthorizationInfo_QNAME = new QName("http://www.esb.manulife.com/xsd/jh/WorkManagement", "authorizationInfo");
    private final static QName _CreateObjects_QNAME = new QName("http://www.esb.manulife.com/xsd/jh/WorkManagement", "createObjects");
    private final static QName _AccessMethod_QNAME = new QName("http://www.esb.manulife.com/xsd/jh/WorkManagement", "accessMethod");
    private final static QName _CreateObjectRequest_QNAME = new QName("http://www.esb.manulife.com/xsd/jh/WorkManagement", "createObjectRequest");
    private final static QName _ExternalProcedure_QNAME = new QName("http://www.esb.manulife.com/xsd/jh/WorkManagement", "externalProcedure");
    private final static QName _ExternalParameter_QNAME = new QName("http://www.esb.manulife.com/xsd/jh/WorkManagement", "externalParameter");
    private final static QName _ReviewUserName_QNAME = new QName("http://www.esb.manulife.com/xsd/jh/WorkManagement", "reviewUserName");
    private final static QName _UserExperienceLevel_QNAME = new QName("http://www.esb.manulife.com/xsd/jh/WorkManagement", "userExperienceLevel");
    private final static QName _AwdEvent_QNAME = new QName("http://www.esb.manulife.com/xsd/jh/WorkManagement", "awdEvent");
    private final static QName _BusinessArea_QNAME = new QName("http://www.esb.manulife.com/xsd/jh/WorkManagement", "businessArea");
    private final static QName _SystemEvent_QNAME = new QName("http://www.esb.manulife.com/xsd/jh/WorkManagement", "systemEvent");
    private final static QName _ReviewTime_QNAME = new QName("http://www.esb.manulife.com/xsd/jh/WorkManagement", "reviewTime");
    private final static QName _JobName_QNAME = new QName("http://www.esb.manulife.com/xsd/jh/WorkManagement", "jobName");
    private final static QName _Suspend_QNAME = new QName("http://www.esb.manulife.com/xsd/jh/WorkManagement", "suspend");
    private final static QName _NextTaskName_QNAME = new QName("http://www.esb.manulife.com/xsd/jh/WorkManagement", "nextTaskName");
    private final static QName _IconName_QNAME = new QName("http://www.esb.manulife.com/xsd/jh/WorkManagement", "iconName");
    private final static QName _Format_QNAME = new QName("http://www.esb.manulife.com/xsd/jh/WorkManagement", "format");
    private final static QName _ArchiveStartPage_QNAME = new QName("http://www.esb.manulife.com/xsd/jh/WorkManagement", "archiveStartPage");
    private final static QName _Routing_QNAME = new QName("http://www.esb.manulife.com/xsd/jh/WorkManagement", "routing");
    private final static QName _CreateWorkInstance_QNAME = new QName("http://www.esb.manulife.com/xsd/jh/WorkManagement", "createWorkInstance");
    private final static QName _AWDProcessingError_QNAME = new QName("http://www.esb.manulife.com/xsd/jh/WorkManagement", "AWDProcessingError");
    private final static QName _PriorityIncrease_QNAME = new QName("http://www.esb.manulife.com/xsd/jh/WorkManagement", "priorityIncrease");
    private final static QName _Event_QNAME = new QName("http://www.esb.manulife.com/xsd/jh/WorkManagement", "event");
    private final static QName _ExternalDLL_QNAME = new QName("http://www.esb.manulife.com/xsd/jh/WorkManagement", "externalDLL");
    private final static QName _ReviewDay_QNAME = new QName("http://www.esb.manulife.com/xsd/jh/WorkManagement", "reviewDay");
    private final static QName _CreateStation_QNAME = new QName("http://www.esb.manulife.com/xsd/jh/WorkManagement", "createStation");
    private final static QName _ExternalHost_QNAME = new QName("http://www.esb.manulife.com/xsd/jh/WorkManagement", "externalHost");
    private final static QName _FieldValue_QNAME = new QName("http://www.esb.manulife.com/xsd/jh/WorkManagement", "fieldValue");
    private final static QName _AnnotationBlob_QNAME = new QName("http://www.esb.manulife.com/xsd/jh/WorkManagement", "annotationBlob");
    private final static QName _CreateTime_QNAME = new QName("http://www.esb.manulife.com/xsd/jh/WorkManagement", "createTime");
    private final static QName _CreateUser_QNAME = new QName("http://www.esb.manulife.com/xsd/jh/WorkManagement", "createUser");
    private final static QName _EndTime_QNAME = new QName("http://www.esb.manulife.com/xsd/jh/WorkManagement", "endTime");
    private final static QName _QualitySampled_QNAME = new QName("http://www.esb.manulife.com/xsd/jh/WorkManagement", "qualitySampled");
    private final static QName _Queue_QNAME = new QName("http://www.esb.manulife.com/xsd/jh/WorkManagement", "queue");
    private final static QName _LookupObjectsResponse_QNAME = new QName("http://www.esb.manulife.com/xsd/jh/WorkManagement", "lookupObjectsResponse");
    private final static QName _UpdateObjectsResponse_QNAME = new QName("http://www.esb.manulife.com/xsd/jh/WorkManagement", "updateObjectsResponse");
    private final static QName _ParentRelationshipId_QNAME = new QName("http://www.esb.manulife.com/xsd/jh/WorkManagement", "parentRelationshipId");
    private final static QName _UpdateSourceInstance_QNAME = new QName("http://www.esb.manulife.com/xsd/jh/WorkManagement", "updateSourceInstance");
    private final static QName _ErrorMessage_QNAME = new QName("http://www.esb.manulife.com/xsd/jh/WorkManagement", "errorMessage");
    private final static QName _AddManualComment_QNAME = new QName("http://www.esb.manulife.com/xsd/jh/WorkManagement", "addManualComment");
    private final static QName _ParentId_QNAME = new QName("http://www.esb.manulife.com/xsd/jh/WorkManagement", "parentId");
    private final static QName _WorkStep_QNAME = new QName("http://www.esb.manulife.com/xsd/jh/WorkManagement", "workStep");
    private final static QName _ExternalSystem_QNAME = new QName("http://www.esb.manulife.com/xsd/jh/WorkManagement", "externalSystem");
    private final static QName _OpticalStatus_QNAME = new QName("http://www.esb.manulife.com/xsd/jh/WorkManagement", "opticalStatus");
    private final static QName _ArchiveBox_QNAME = new QName("http://www.esb.manulife.com/xsd/jh/WorkManagement", "archiveBox");
    private final static QName _UserId_QNAME = new QName("http://www.esb.manulife.com/xsd/jh/WorkManagement", "userId");
    private final static QName _CustomScreen_QNAME = new QName("http://www.esb.manulife.com/xsd/jh/WorkManagement", "customScreen");
    private final static QName _ReviewUserId_QNAME = new QName("http://www.esb.manulife.com/xsd/jh/WorkManagement", "reviewUserId");
    private final static QName _Path_QNAME = new QName("http://www.esb.manulife.com/xsd/jh/WorkManagement", "path");
    private final static QName _CreateFolderInstance_QNAME = new QName("http://www.esb.manulife.com/xsd/jh/WorkManagement", "createFolderInstance");
    private final static QName _QualityEvent_QNAME = new QName("http://www.esb.manulife.com/xsd/jh/WorkManagement", "qualityEvent");
    private final static QName _BeginTime_QNAME = new QName("http://www.esb.manulife.com/xsd/jh/WorkManagement", "beginTime");
    private final static QName _CzValue_QNAME = new QName("http://www.esb.manulife.com/xsd/jh/WorkManagement", "czValue");
    private final static QName _Text_QNAME = new QName("http://www.esb.manulife.com/xsd/jh/WorkManagement", "text");
    private final static QName _Order_QNAME = new QName("http://www.esb.manulife.com/xsd/jh/WorkManagement", "order");
    private final static QName _RetrieveObjects_QNAME = new QName("http://www.esb.manulife.com/xsd/jh/WorkManagement", "retrieveObjects");
    private final static QName _SourceInstance_QNAME = new QName("http://www.esb.manulife.com/xsd/jh/WorkManagement", "sourceInstance");
    private final static QName _TagLine_QNAME = new QName("http://www.esb.manulife.com/xsd/jh/WorkManagement", "tagLine");
    private final static QName _UserStation_QNAME = new QName("http://www.esb.manulife.com/xsd/jh/WorkManagement", "userStation");
    private final static QName _LookupObjects_QNAME = new QName("http://www.esb.manulife.com/xsd/jh/WorkManagement", "lookupObjects");
    private final static QName _Type_QNAME = new QName("http://www.esb.manulife.com/xsd/jh/WorkManagement", "type");
    private final static QName _TaskName_QNAME = new QName("http://www.esb.manulife.com/xsd/jh/WorkManagement", "taskName");
    private final static QName _SamplingMethod_QNAME = new QName("http://www.esb.manulife.com/xsd/jh/WorkManagement", "samplingMethod");
    private final static QName _UpdateWorkInstance_QNAME = new QName("http://www.esb.manulife.com/xsd/jh/WorkManagement", "updateWorkInstance");
    private final static QName _WorkInstance_QNAME = new QName("http://www.esb.manulife.com/xsd/jh/WorkManagement", "workInstance");
    private final static QName _Status_QNAME = new QName("http://www.esb.manulife.com/xsd/jh/WorkManagement", "status");
    private final static QName _Suspended_QNAME = new QName("http://www.esb.manulife.com/xsd/jh/WorkManagement", "suspended");
    private final static QName _ChildId_QNAME = new QName("http://www.esb.manulife.com/xsd/jh/WorkManagement", "childId");
    private final static QName _Priority_QNAME = new QName("http://www.esb.manulife.com/xsd/jh/WorkManagement", "priority");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.manulife.esb.xsd.jh.workmanagement
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link LookupObjectsRequest }
     *
     * @return the lookup objects request
     */
    public LookupObjectsRequest createLookupObjectsRequest() {
        return new LookupObjectsRequest();
    }

    /**
     * Create an instance of {@link GetObjectsResponse }
     *
     * @return the get objects response
     */
    public GetObjectsResponse createGetObjectsResponse() {
        return new GetObjectsResponse();
    }

    /**
     * Create an instance of {@link GetObjectsRequest }
     *
     * @return the get objects request
     */
    public GetObjectsRequest createGetObjectsRequest() {
        return new GetObjectsRequest();
    }

    /**
     * Create an instance of {@link UpdateAWDInstance }
     *
     * @return the update awd instance
     */
    public UpdateAWDInstance createUpdateAWDInstance() {
        return new UpdateAWDInstance();
    }

    /**
     * Create an instance of {@link SourceInstance }
     *
     * @return the source instance
     */
    public SourceInstance createSourceInstance() {
        return new SourceInstance();
    }

    /**
     * Create an instance of {@link LookupObjects }
     *
     * @return the lookup objects
     */
    public LookupObjects createLookupObjects() {
        return new LookupObjects();
    }

    /**
     * Create an instance of {@link Relationships }
     *
     * @return the relationships
     */
    public Relationships createRelationships() {
        return new Relationships();
    }

    /**
     * Create an instance of {@link RelateObjects }
     *
     * @return the relate objects
     */
    public RelateObjects createRelateObjects() {
        return new RelateObjects();
    }

    /**
     * Create an instance of {@link CreateFolderInstance }
     *
     * @return the create folder instance
     */
    public CreateFolderInstance createCreateFolderInstance() {
        return new CreateFolderInstance();
    }

    /**
     * Create an instance of {@link QualityEvent }
     *
     * @return the quality event
     */
    public QualityEvent createQualityEvent() {
        return new QualityEvent();
    }

    /**
     * Create an instance of {@link RetrieveObjects }
     *
     * @return the retrieve objects
     */
    public RetrieveObjects createRetrieveObjects() {
        return new RetrieveObjects();
    }

    /**
     * Create an instance of {@link ExternalSystems }
     *
     * @return the external systems
     */
    public ExternalSystems createExternalSystems() {
        return new ExternalSystems();
    }

    /**
     * Create an instance of {@link ExternalSystem }
     *
     * @return the external system
     */
    public ExternalSystem createExternalSystem() {
        return new ExternalSystem();
    }

    /**
     * Create an instance of {@link Suspended }
     *
     * @return the suspended
     */
    public Suspended createSuspended() {
        return new Suspended();
    }

    /**
     * Create an instance of {@link UpdateWorkInstance }
     *
     * @return the update work instance
     */
    public UpdateWorkInstance createUpdateWorkInstance() {
        return new UpdateWorkInstance();
    }

    /**
     * Create an instance of {@link WorkInstance }
     *
     * @return the work instance
     */
    public WorkInstance createWorkInstance() {
        return new WorkInstance();
    }

    /**
     * Create an instance of {@link FieldValue }
     *
     * @return the field value
     */
    public FieldValue createFieldValue() {
        return new FieldValue();
    }

    /**
     * Create an instance of {@link Routing }
     *
     * @return the routing
     */
    public Routing createRouting() {
        return new Routing();
    }

    /**
     * Create an instance of {@link AWDProcessingError }
     *
     * @return the awd processing error
     */
    public AWDProcessingError createAWDProcessingError() {
        return new AWDProcessingError();
    }

    /**
     * Create an instance of {@link CreateWorkInstance }
     *
     * @return the create work instance
     */
    public CreateWorkInstance createCreateWorkInstance() {
        return new CreateWorkInstance();
    }

    /**
     * Create an instance of {@link Event }
     *
     * @return the event
     */
    public Event createEvent() {
        return new Event();
    }

    /**
     * Create an instance of {@link UpdateSourceInstance }
     *
     * @return the update source instance
     */
    public UpdateSourceInstance createUpdateSourceInstance() {
        return new UpdateSourceInstance();
    }

    /**
     * Create an instance of {@link LookupObjectsResponse }
     *
     * @return the lookup objects response
     */
    public LookupObjectsResponse createLookupObjectsResponse() {
        return new LookupObjectsResponse();
    }

    /**
     * Create an instance of {@link UpdateObjectsResponse }
     *
     * @return the update objects response
     */
    public UpdateObjectsResponse createUpdateObjectsResponse() {
        return new UpdateObjectsResponse();
    }

    /**
     * Create an instance of {@link AuthorizationInfo }
     *
     * @return the authorization info
     */
    public AuthorizationInfo createAuthorizationInfo() {
        return new AuthorizationInfo();
    }

    /**
     * Create an instance of {@link CreateObjects }
     *
     * @return the create objects
     */
    public CreateObjects createCreateObjects() {
        return new CreateObjects();
    }

    /**
     * Create an instance of {@link CreateObjectRequest }
     *
     * @return the create object request
     */
    public CreateObjectRequest createCreateObjectRequest() {
        return new CreateObjectRequest();
    }

    /**
     * Create an instance of {@link Suspend }
     *
     * @return the suspend
     */
    public Suspend createSuspend() {
        return new Suspend();
    }

    /**
     * Create an instance of {@link AwdEvent }
     *
     * @return the awd event
     */
    public AwdEvent createAwdEvent() {
        return new AwdEvent();
    }

    /**
     * Create an instance of {@link SystemEvent }
     *
     * @return the system event
     */
    public SystemEvent createSystemEvent() {
        return new SystemEvent();
    }

    /**
     * Create an instance of {@link FieldValues }
     *
     * @return the field values
     */
    public FieldValues createFieldValues() {
        return new FieldValues();
    }

    /**
     * Create an instance of {@link CreateSourceInstance }
     *
     * @return the create source instance
     */
    public CreateSourceInstance createCreateSourceInstance() {
        return new CreateSourceInstance();
    }

    /**
     * Create an instance of {@link WorkFlow }
     *
     * @return the work flow
     */
    public WorkFlow createWorkFlow() {
        return new WorkFlow();
    }

    /**
     * Create an instance of {@link Attachment }
     *
     * @return the attachment
     */
    public Attachment createAttachment() {
        return new Attachment();
    }

    /**
     * Create an instance of {@link AwdInstance }
     *
     * @return the awd instance
     */
    public AwdInstance createAwdInstance() {
        return new AwdInstance();
    }

    /**
     * Create an instance of {@link AttachmentList }
     *
     * @return the attachment list
     */
    public AttachmentList createAttachmentList() {
        return new AttachmentList();
    }

    /**
     * Create an instance of {@link GetNewAssignment }
     *
     * @return the get new assignment
     */
    public GetNewAssignment createGetNewAssignment() {
        return new GetNewAssignment();
    }

    /**
     * Create an instance of {@link CreateAWDInstance }
     *
     * @return the create awd instance
     */
    public CreateAWDInstance createCreateAWDInstance() {
        return new CreateAWDInstance();
    }

    /**
     * Create an instance of {@link CreateObjectsResponse }
     *
     * @return the create objects response
     */
    public CreateObjectsResponse createCreateObjectsResponse() {
        return new CreateObjectsResponse();
    }

    /**
     * Create an instance of {@link GetNewAssignmentResponse }
     *
     * @return the get new assignment response
     */
    public GetNewAssignmentResponse createGetNewAssignmentResponse() {
        return new GetNewAssignmentResponse();
    }

    /**
     * Create an instance of {@link UpdateObjects }
     *
     * @return the update objects
     */
    public UpdateObjects createUpdateObjects() {
        return new UpdateObjects();
    }

    /**
     * Create an instance of {@link Comments }
     *
     * @return the comments
     */
    public Comments createComments() {
        return new Comments();
    }

    /**
     * Create an instance of {@link Comment }
     *
     * @return the comment
     */
    public Comment createComment() {
        return new Comment();
    }

    /**
     * Create an instance of {@link RetrieveObjectsResponse }
     *
     * @return the retrieve objects response
     */
    public RetrieveObjectsResponse createRetrieveObjectsResponse() {
        return new RetrieveObjectsResponse();
    }

    /**
     * Create an instance of {@link ResponseDetails }
     *
     * @return the response details
     */
    public ResponseDetails createResponseDetails() {
        return new ResponseDetails();
    }

    /**
     * Create an instance of {@link UpdateFolderInstance }
     *
     * @return the update folder instance
     */
    public UpdateFolderInstance createUpdateFolderInstance() {
        return new UpdateFolderInstance();
    }

    /**
     * Create an instance of {@link Exception }
     *
     * @return the exception
     */
    public Exception createException() {
        return new Exception();
    }

    /**
     * Create an instance of {@link KeEvent }
     *
     * @return the ke event
     */
    public KeEvent createKeEvent() {
        return new KeEvent();
    }

    /**
     * Create an instance of {@link FolderInstance }
     *
     * @return the folder instance
     */
    public FolderInstance createFolderInstance() {
        return new FolderInstance();
    }

    /**
     * Create an instance of {@link DeleteFieldValue }
     *
     * @return the delete field value
     */
    public DeleteFieldValue createDeleteFieldValue() {
        return new DeleteFieldValue();
    }

    /**
     * Create an instance of {@link LookupParameter }
     *
     * @return the lookup parameter
     */
    public LookupParameter createLookupParameter() {
        return new LookupParameter();
    }

    /**
     * Create an instance of {@link WorkSteps }
     *
     * @return the work steps
     */
    public WorkSteps createWorkSteps() {
        return new WorkSteps();
    }

    /**
     * Create an instance of {@link GetNewAssignmentRequest }
     *
     * @return the get new assignment request
     */
    public GetNewAssignmentRequest createGetNewAssignmentRequest() {
        return new GetNewAssignmentRequest();
    }

    /**
     * Create an instance of {@link RelateOnlyExistingObjects }
     *
     * @return the relate only existing objects
     */
    public RelateOnlyExistingObjects createRelateOnlyExistingObjects() {
        return new RelateOnlyExistingObjects();
    }

    /**
     * Create an instance of {@link UpdateObjectRequest }
     *
     * @return the update object request
     */
    public UpdateObjectRequest createUpdateObjectRequest() {
        return new UpdateObjectRequest();
    }

    /**
     * Create an instance of {@link GetObjectRequest }
     *
     * @return the get object request
     */
    public GetObjectRequest createGetObjectRequest() {
        return new GetObjectRequest();
    }

    /**
     * Create an instance of {@link LookupObjectsRequest.LookupParameters }
     *
     * @return the lookup objects request . lookup parameters
     */
    public LookupObjectsRequest.LookupParameters createLookupObjectsRequestLookupParameters() {
        return new LookupObjectsRequest.LookupParameters();
    }

    /**
     * Create an instance of {@link GetObjectsResponse.ImmediateRelationships }
     *
     * @return the get objects response . immediate relationships
     */
    public GetObjectsResponse.ImmediateRelationships createGetObjectsResponseImmediateRelationships() {
        return new GetObjectsResponse.ImmediateRelationships();
    }

    /**
     * Create an instance of {@link GetObjectsRequest.ObjectRequests }
     *
     * @return the get objects request . object requests
     */
    public GetObjectsRequest.ObjectRequests createGetObjectsRequestObjectRequests() {
        return new GetObjectsRequest.ObjectRequests();
    }

    /**
     * Create an instance of {@link UpdateAWDInstance.FieldValues }
     *
     * @return the update awd instance . field values
     */
    public UpdateAWDInstance.FieldValues createUpdateAWDInstanceFieldValues() {
        return new UpdateAWDInstance.FieldValues();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link WorkFlow }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/jh/WorkManagement", name = "workFlow")
    public JAXBElement<WorkFlow> createWorkFlow(WorkFlow value) {
        return new JAXBElement<WorkFlow>(_WorkFlow_QNAME, WorkFlow.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/jh/WorkManagement", name = "securityLevel")
    public JAXBElement<String> createSecurityLevel(String value) {
        return new JAXBElement<String>(_SecurityLevel_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/jh/WorkManagement", name = "childRelationshipId")
    public JAXBElement<String> createChildRelationshipId(String value) {
        return new JAXBElement<String>(_ChildRelationshipId_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UpdateAWDInstance }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/jh/WorkManagement", name = "updateAWDInstance")
    public JAXBElement<UpdateAWDInstance> createUpdateAWDInstance(UpdateAWDInstance value) {
        return new JAXBElement<UpdateAWDInstance>(_UpdateAWDInstance_QNAME, UpdateAWDInstance.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Attachment }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/jh/WorkManagement", name = "attachment")
    public JAXBElement<Attachment> createAttachment(Attachment value) {
        return new JAXBElement<Attachment>(_Attachment_QNAME, Attachment.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AwdInstance }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/jh/WorkManagement", name = "awdInstance")
    public JAXBElement<AwdInstance> createAwdInstance(AwdInstance value) {
        return new JAXBElement<AwdInstance>(_AwdInstance_QNAME, AwdInstance.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/jh/WorkManagement", name = "lockedBy")
    public JAXBElement<String> createLockedBy(String value) {
        return new JAXBElement<String>(_LockedBy_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetNewAssignment }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/jh/WorkManagement", name = "getNewAssignment")
    public JAXBElement<GetNewAssignment> createGetNewAssignment(GetNewAssignment value) {
        return new JAXBElement<GetNewAssignment>(_GetNewAssignment_QNAME, GetNewAssignment.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/jh/WorkManagement", name = "deleteUserId")
    public JAXBElement<String> createDeleteUserId(String value) {
        return new JAXBElement<String>(_DeleteUserId_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CreateAWDInstance }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/jh/WorkManagement", name = "createAWDInstance")
    public JAXBElement<CreateAWDInstance> createCreateAWDInstance(CreateAWDInstance value) {
        return new JAXBElement<CreateAWDInstance>(_CreateAWDInstance_QNAME, CreateAWDInstance.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/jh/WorkManagement", name = "contentId")
    public JAXBElement<String> createContentId(String value) {
        return new JAXBElement<String>(_ContentId_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/jh/WorkManagement", name = "description")
    public JAXBElement<String> createDescription(String value) {
        return new JAXBElement<String>(_Description_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/jh/WorkManagement", name = "commentsExist")
    public JAXBElement<String> createCommentsExist(String value) {
        return new JAXBElement<String>(_CommentsExist_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CreateSourceInstance }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/jh/WorkManagement", name = "createSourceInstance")
    public JAXBElement<CreateSourceInstance> createCreateSourceInstance(CreateSourceInstance value) {
        return new JAXBElement<CreateSourceInstance>(_CreateSourceInstance_QNAME, CreateSourceInstance.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/jh/WorkManagement", name = "deleteErrorTime")
    public JAXBElement<String> createDeleteErrorTime(String value) {
        return new JAXBElement<String>(_DeleteErrorTime_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/jh/WorkManagement", name = "referenceId")
    public JAXBElement<String> createReferenceId(String value) {
        return new JAXBElement<String>(_ReferenceId_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/jh/WorkManagement", name = "mailType")
    public JAXBElement<String> createMailType(String value) {
        return new JAXBElement<String>(_MailType_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/jh/WorkManagement", name = "receiveTime")
    public JAXBElement<String> createReceiveTime(String value) {
        return new JAXBElement<String>(_ReceiveTime_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link KeEvent }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/jh/WorkManagement", name = "keEvent")
    public JAXBElement<KeEvent> createKeEvent(KeEvent value) {
        return new JAXBElement<KeEvent>(_KeEvent_QNAME, KeEvent.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Comment }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/jh/WorkManagement", name = "comment")
    public JAXBElement<Comment> createComment(Comment value) {
        return new JAXBElement<Comment>(_Comment_QNAME, Comment.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link FolderInstance }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/jh/WorkManagement", name = "folderInstance")
    public JAXBElement<FolderInstance> createFolderInstance(FolderInstance value) {
        return new JAXBElement<FolderInstance>(_FolderInstance_QNAME, FolderInstance.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/jh/WorkManagement", name = "revisable")
    public JAXBElement<String> createRevisable(String value) {
        return new JAXBElement<String>(_Revisable_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/jh/WorkManagement", name = "VIP")
    public JAXBElement<String> createVIP(String value) {
        return new JAXBElement<String>(_VIP_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigInteger }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/jh/WorkManagement", name = "pageCount")
    public JAXBElement<BigInteger> createPageCount(BigInteger value) {
        return new JAXBElement<BigInteger>(_PageCount_QNAME, BigInteger.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UpdateObjects }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/jh/WorkManagement", name = "updateObjects")
    public JAXBElement<UpdateObjects> createUpdateObjects(UpdateObjects value) {
        return new JAXBElement<UpdateObjects>(_UpdateObjects_QNAME, UpdateObjects.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CreateObjectsResponse }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/jh/WorkManagement", name = "createObjectsResponse")
    public JAXBElement<CreateObjectsResponse> createCreateObjectsResponse(CreateObjectsResponse value) {
        return new JAXBElement<CreateObjectsResponse>(_CreateObjectsResponse_QNAME, CreateObjectsResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetNewAssignmentResponse }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/jh/WorkManagement", name = "getNewAssignmentResponse")
    public JAXBElement<GetNewAssignmentResponse> createGetNewAssignmentResponse(GetNewAssignmentResponse value) {
        return new JAXBElement<GetNewAssignmentResponse>(_GetNewAssignmentResponse_QNAME, GetNewAssignmentResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RetrieveObjectsResponse }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/jh/WorkManagement", name = "retrieveObjectsResponse")
    public JAXBElement<RetrieveObjectsResponse> createRetrieveObjectsResponse(RetrieveObjectsResponse value) {
        return new JAXBElement<RetrieveObjectsResponse>(_RetrieveObjectsResponse_QNAME, RetrieveObjectsResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ResponseDetails }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/jh/WorkManagement", name = "responseDetails")
    public JAXBElement<ResponseDetails> createResponseDetails(ResponseDetails value) {
        return new JAXBElement<ResponseDetails>(_ResponseDetails_QNAME, ResponseDetails.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UpdateFolderInstance }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/jh/WorkManagement", name = "updateFolderInstance")
    public JAXBElement<UpdateFolderInstance> createUpdateFolderInstance(UpdateFolderInstance value) {
        return new JAXBElement<UpdateFolderInstance>(_UpdateFolderInstance_QNAME, UpdateFolderInstance.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Exception }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/jh/WorkManagement", name = "Exception")
    public JAXBElement<Exception> createException(Exception value) {
        return new JAXBElement<Exception>(_Exception_QNAME, Exception.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/jh/WorkManagement", name = "message")
    public JAXBElement<String> createMessage(String value) {
        return new JAXBElement<String>(_Message_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/jh/WorkManagement", name = "userName")
    public JAXBElement<String> createUserName(String value) {
        return new JAXBElement<String>(_UserName_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/jh/WorkManagement", name = "returnCode")
    public JAXBElement<String> createReturnCode(String value) {
        return new JAXBElement<String>(_ReturnCode_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AuthorizationInfo }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/jh/WorkManagement", name = "authorizationInfo")
    public JAXBElement<AuthorizationInfo> createAuthorizationInfo(AuthorizationInfo value) {
        return new JAXBElement<AuthorizationInfo>(_AuthorizationInfo_QNAME, AuthorizationInfo.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CreateObjects }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/jh/WorkManagement", name = "createObjects")
    public JAXBElement<CreateObjects> createCreateObjects(CreateObjects value) {
        return new JAXBElement<CreateObjects>(_CreateObjects_QNAME, CreateObjects.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/jh/WorkManagement", name = "accessMethod")
    public JAXBElement<String> createAccessMethod(String value) {
        return new JAXBElement<String>(_AccessMethod_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CreateObjectRequest }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/jh/WorkManagement", name = "createObjectRequest")
    public JAXBElement<CreateObjectRequest> createCreateObjectRequest(CreateObjectRequest value) {
        return new JAXBElement<CreateObjectRequest>(_CreateObjectRequest_QNAME, CreateObjectRequest.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/jh/WorkManagement", name = "externalProcedure")
    public JAXBElement<String> createExternalProcedure(String value) {
        return new JAXBElement<String>(_ExternalProcedure_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/jh/WorkManagement", name = "externalParameter")
    public JAXBElement<String> createExternalParameter(String value) {
        return new JAXBElement<String>(_ExternalParameter_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/jh/WorkManagement", name = "reviewUserName")
    public JAXBElement<String> createReviewUserName(String value) {
        return new JAXBElement<String>(_ReviewUserName_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/jh/WorkManagement", name = "userExperienceLevel")
    public JAXBElement<String> createUserExperienceLevel(String value) {
        return new JAXBElement<String>(_UserExperienceLevel_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AwdEvent }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/jh/WorkManagement", name = "awdEvent")
    public JAXBElement<AwdEvent> createAwdEvent(AwdEvent value) {
        return new JAXBElement<AwdEvent>(_AwdEvent_QNAME, AwdEvent.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/jh/WorkManagement", name = "businessArea")
    public JAXBElement<String> createBusinessArea(String value) {
        return new JAXBElement<String>(_BusinessArea_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SystemEvent }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/jh/WorkManagement", name = "systemEvent")
    public JAXBElement<SystemEvent> createSystemEvent(SystemEvent value) {
        return new JAXBElement<SystemEvent>(_SystemEvent_QNAME, SystemEvent.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/jh/WorkManagement", name = "reviewTime")
    public JAXBElement<String> createReviewTime(String value) {
        return new JAXBElement<String>(_ReviewTime_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/jh/WorkManagement", name = "jobName")
    public JAXBElement<String> createJobName(String value) {
        return new JAXBElement<String>(_JobName_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Suspend }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/jh/WorkManagement", name = "suspend")
    public JAXBElement<Suspend> createSuspend(Suspend value) {
        return new JAXBElement<Suspend>(_Suspend_QNAME, Suspend.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/jh/WorkManagement", name = "nextTaskName")
    public JAXBElement<String> createNextTaskName(String value) {
        return new JAXBElement<String>(_NextTaskName_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/jh/WorkManagement", name = "iconName")
    public JAXBElement<String> createIconName(String value) {
        return new JAXBElement<String>(_IconName_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/jh/WorkManagement", name = "format")
    public JAXBElement<String> createFormat(String value) {
        return new JAXBElement<String>(_Format_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/jh/WorkManagement", name = "archiveStartPage")
    public JAXBElement<String> createArchiveStartPage(String value) {
        return new JAXBElement<String>(_ArchiveStartPage_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Routing }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/jh/WorkManagement", name = "routing")
    public JAXBElement<Routing> createRouting(Routing value) {
        return new JAXBElement<Routing>(_Routing_QNAME, Routing.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CreateWorkInstance }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/jh/WorkManagement", name = "createWorkInstance")
    public JAXBElement<CreateWorkInstance> createCreateWorkInstance(CreateWorkInstance value) {
        return new JAXBElement<CreateWorkInstance>(_CreateWorkInstance_QNAME, CreateWorkInstance.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AWDProcessingError }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/jh/WorkManagement", name = "AWDProcessingError")
    public JAXBElement<AWDProcessingError> createAWDProcessingError(AWDProcessingError value) {
        return new JAXBElement<AWDProcessingError>(_AWDProcessingError_QNAME, AWDProcessingError.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/jh/WorkManagement", name = "priorityIncrease")
    public JAXBElement<String> createPriorityIncrease(String value) {
        return new JAXBElement<String>(_PriorityIncrease_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Event }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/jh/WorkManagement", name = "event")
    public JAXBElement<Event> createEvent(Event value) {
        return new JAXBElement<Event>(_Event_QNAME, Event.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/jh/WorkManagement", name = "externalDLL")
    public JAXBElement<String> createExternalDLL(String value) {
        return new JAXBElement<String>(_ExternalDLL_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/jh/WorkManagement", name = "reviewDay")
    public JAXBElement<String> createReviewDay(String value) {
        return new JAXBElement<String>(_ReviewDay_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/jh/WorkManagement", name = "createStation")
    public JAXBElement<String> createCreateStation(String value) {
        return new JAXBElement<String>(_CreateStation_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/jh/WorkManagement", name = "externalHost")
    public JAXBElement<String> createExternalHost(String value) {
        return new JAXBElement<String>(_ExternalHost_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link FieldValue }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/jh/WorkManagement", name = "fieldValue")
    public JAXBElement<FieldValue> createFieldValue(FieldValue value) {
        return new JAXBElement<FieldValue>(_FieldValue_QNAME, FieldValue.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/jh/WorkManagement", name = "annotationBlob")
    public JAXBElement<String> createAnnotationBlob(String value) {
        return new JAXBElement<String>(_AnnotationBlob_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/jh/WorkManagement", name = "createTime")
    public JAXBElement<String> createCreateTime(String value) {
        return new JAXBElement<String>(_CreateTime_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/jh/WorkManagement", name = "createUser")
    public JAXBElement<String> createCreateUser(String value) {
        return new JAXBElement<String>(_CreateUser_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/jh/WorkManagement", name = "endTime")
    public JAXBElement<String> createEndTime(String value) {
        return new JAXBElement<String>(_EndTime_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/jh/WorkManagement", name = "qualitySampled")
    public JAXBElement<String> createQualitySampled(String value) {
        return new JAXBElement<String>(_QualitySampled_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/jh/WorkManagement", name = "queue")
    public JAXBElement<String> createQueue(String value) {
        return new JAXBElement<String>(_Queue_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link LookupObjectsResponse }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/jh/WorkManagement", name = "lookupObjectsResponse")
    public JAXBElement<LookupObjectsResponse> createLookupObjectsResponse(LookupObjectsResponse value) {
        return new JAXBElement<LookupObjectsResponse>(_LookupObjectsResponse_QNAME, LookupObjectsResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UpdateObjectsResponse }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/jh/WorkManagement", name = "updateObjectsResponse")
    public JAXBElement<UpdateObjectsResponse> createUpdateObjectsResponse(UpdateObjectsResponse value) {
        return new JAXBElement<UpdateObjectsResponse>(_UpdateObjectsResponse_QNAME, UpdateObjectsResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/jh/WorkManagement", name = "parentRelationshipId")
    public JAXBElement<String> createParentRelationshipId(String value) {
        return new JAXBElement<String>(_ParentRelationshipId_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UpdateSourceInstance }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/jh/WorkManagement", name = "updateSourceInstance")
    public JAXBElement<UpdateSourceInstance> createUpdateSourceInstance(UpdateSourceInstance value) {
        return new JAXBElement<UpdateSourceInstance>(_UpdateSourceInstance_QNAME, UpdateSourceInstance.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/jh/WorkManagement", name = "errorMessage")
    public JAXBElement<String> createErrorMessage(String value) {
        return new JAXBElement<String>(_ErrorMessage_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/jh/WorkManagement", name = "addManualComment")
    public JAXBElement<String> createAddManualComment(String value) {
        return new JAXBElement<String>(_AddManualComment_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/jh/WorkManagement", name = "parentId")
    public JAXBElement<String> createParentId(String value) {
        return new JAXBElement<String>(_ParentId_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/jh/WorkManagement", name = "workStep")
    public JAXBElement<String> createWorkStep(String value) {
        return new JAXBElement<String>(_WorkStep_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ExternalSystem }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/jh/WorkManagement", name = "externalSystem")
    public JAXBElement<ExternalSystem> createExternalSystem(ExternalSystem value) {
        return new JAXBElement<ExternalSystem>(_ExternalSystem_QNAME, ExternalSystem.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/jh/WorkManagement", name = "opticalStatus")
    public JAXBElement<String> createOpticalStatus(String value) {
        return new JAXBElement<String>(_OpticalStatus_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/jh/WorkManagement", name = "archiveBox")
    public JAXBElement<String> createArchiveBox(String value) {
        return new JAXBElement<String>(_ArchiveBox_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/jh/WorkManagement", name = "userId")
    public JAXBElement<String> createUserId(String value) {
        return new JAXBElement<String>(_UserId_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/jh/WorkManagement", name = "customScreen")
    public JAXBElement<String> createCustomScreen(String value) {
        return new JAXBElement<String>(_CustomScreen_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/jh/WorkManagement", name = "reviewUserId")
    public JAXBElement<String> createReviewUserId(String value) {
        return new JAXBElement<String>(_ReviewUserId_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/jh/WorkManagement", name = "path")
    public JAXBElement<String> createPath(String value) {
        return new JAXBElement<String>(_Path_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CreateFolderInstance }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/jh/WorkManagement", name = "createFolderInstance")
    public JAXBElement<CreateFolderInstance> createCreateFolderInstance(CreateFolderInstance value) {
        return new JAXBElement<CreateFolderInstance>(_CreateFolderInstance_QNAME, CreateFolderInstance.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link QualityEvent }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/jh/WorkManagement", name = "qualityEvent")
    public JAXBElement<QualityEvent> createQualityEvent(QualityEvent value) {
        return new JAXBElement<QualityEvent>(_QualityEvent_QNAME, QualityEvent.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/jh/WorkManagement", name = "beginTime")
    public JAXBElement<String> createBeginTime(String value) {
        return new JAXBElement<String>(_BeginTime_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/jh/WorkManagement", name = "czValue")
    public JAXBElement<String> createCzValue(String value) {
        return new JAXBElement<String>(_CzValue_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/jh/WorkManagement", name = "text")
    public JAXBElement<String> createText(String value) {
        return new JAXBElement<String>(_Text_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Integer }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/jh/WorkManagement", name = "order")
    public JAXBElement<Integer> createOrder(Integer value) {
        return new JAXBElement<Integer>(_Order_QNAME, Integer.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RetrieveObjects }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/jh/WorkManagement", name = "retrieveObjects")
    public JAXBElement<RetrieveObjects> createRetrieveObjects(RetrieveObjects value) {
        return new JAXBElement<RetrieveObjects>(_RetrieveObjects_QNAME, RetrieveObjects.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SourceInstance }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/jh/WorkManagement", name = "sourceInstance")
    public JAXBElement<SourceInstance> createSourceInstance(SourceInstance value) {
        return new JAXBElement<SourceInstance>(_SourceInstance_QNAME, SourceInstance.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/jh/WorkManagement", name = "tagLine")
    public JAXBElement<String> createTagLine(String value) {
        return new JAXBElement<String>(_TagLine_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/jh/WorkManagement", name = "userStation")
    public JAXBElement<String> createUserStation(String value) {
        return new JAXBElement<String>(_UserStation_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link LookupObjects }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/jh/WorkManagement", name = "lookupObjects")
    public JAXBElement<LookupObjects> createLookupObjects(LookupObjects value) {
        return new JAXBElement<LookupObjects>(_LookupObjects_QNAME, LookupObjects.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/jh/WorkManagement", name = "type")
    public JAXBElement<String> createType(String value) {
        return new JAXBElement<String>(_Type_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/jh/WorkManagement", name = "taskName")
    public JAXBElement<String> createTaskName(String value) {
        return new JAXBElement<String>(_TaskName_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/jh/WorkManagement", name = "samplingMethod")
    public JAXBElement<String> createSamplingMethod(String value) {
        return new JAXBElement<String>(_SamplingMethod_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UpdateWorkInstance }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/jh/WorkManagement", name = "updateWorkInstance")
    public JAXBElement<UpdateWorkInstance> createUpdateWorkInstance(UpdateWorkInstance value) {
        return new JAXBElement<UpdateWorkInstance>(_UpdateWorkInstance_QNAME, UpdateWorkInstance.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link WorkInstance }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/jh/WorkManagement", name = "workInstance")
    public JAXBElement<WorkInstance> createWorkInstance(WorkInstance value) {
        return new JAXBElement<WorkInstance>(_WorkInstance_QNAME, WorkInstance.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/jh/WorkManagement", name = "status")
    public JAXBElement<String> createStatus(String value) {
        return new JAXBElement<String>(_Status_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Suspended }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/jh/WorkManagement", name = "suspended")
    public JAXBElement<Suspended> createSuspended(Suspended value) {
        return new JAXBElement<Suspended>(_Suspended_QNAME, Suspended.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/jh/WorkManagement", name = "childId")
    public JAXBElement<String> createChildId(String value) {
        return new JAXBElement<String>(_ChildId_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/jh/WorkManagement", name = "priority")
    public JAXBElement<String> createPriority(String value) {
        return new JAXBElement<String>(_Priority_QNAME, String.class, null, value);
    }

}
