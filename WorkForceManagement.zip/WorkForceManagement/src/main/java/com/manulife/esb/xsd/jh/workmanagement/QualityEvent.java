
package com.manulife.esb.xsd.jh.workmanagement;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for qualityEvent complex type.
 *
 * <p>The following schema fragment specifies the expected content contained within this class.
 *
 * <pre>
 * &lt;complexType name="qualityEvent">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/jh/WorkManagement}awdEvent"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/jh/WorkManagement}VIP" minOccurs="0"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/jh/WorkManagement}reviewTime" minOccurs="0"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/jh/WorkManagement}reviewUserId" minOccurs="0"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/jh/WorkManagement}reviewUserName" minOccurs="0"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/jh/WorkManagement}reviewDay" minOccurs="0"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/jh/WorkManagement}deleteErrorTime" minOccurs="0"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/jh/WorkManagement}deleteUserId" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "qualityEvent", propOrder = {
    "awdEvent",
    "vip",
    "reviewTime",
    "reviewUserId",
    "reviewUserName",
    "reviewDay",
    "deleteErrorTime",
    "deleteUserId"
})
public class QualityEvent {

    /**
     * The Awd event.
     */
    @XmlElement(required = true)
    protected AwdEvent awdEvent;
    /**
     * The Vip.
     */
    @XmlElement(name = "VIP")
    protected String vip;
    /**
     * The Review time.
     */
    protected String reviewTime;
    /**
     * The Review user id.
     */
    protected String reviewUserId;
    /**
     * The Review user name.
     */
    protected String reviewUserName;
    /**
     * The Review day.
     */
    protected String reviewDay;
    /**
     * The Delete error time.
     */
    protected String deleteErrorTime;
    /**
     * The Delete user id.
     */
    protected String deleteUserId;

    /**
     * Gets the value of the awdEvent property.
     *
     * @return possible      object is     {@link AwdEvent }
     */
    public AwdEvent getAwdEvent() {
        return awdEvent;
    }

    /**
     * Sets the value of the awdEvent property.
     *
     * @param value allowed object is     {@link AwdEvent }
     */
    public void setAwdEvent(AwdEvent value) {
        this.awdEvent = value;
    }

    /**
     * Gets the value of the vip property.
     *
     * @return possible      object is     {@link String }
     */
    public String getVIP() {
        return vip;
    }

    /**
     * Sets the value of the vip property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setVIP(String value) {
        this.vip = value;
    }

    /**
     * Gets the value of the reviewTime property.
     *
     * @return possible      object is     {@link String }
     */
    public String getReviewTime() {
        return reviewTime;
    }

    /**
     * Sets the value of the reviewTime property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setReviewTime(String value) {
        this.reviewTime = value;
    }

    /**
     * Gets the value of the reviewUserId property.
     *
     * @return possible      object is     {@link String }
     */
    public String getReviewUserId() {
        return reviewUserId;
    }

    /**
     * Sets the value of the reviewUserId property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setReviewUserId(String value) {
        this.reviewUserId = value;
    }

    /**
     * Gets the value of the reviewUserName property.
     *
     * @return possible      object is     {@link String }
     */
    public String getReviewUserName() {
        return reviewUserName;
    }

    /**
     * Sets the value of the reviewUserName property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setReviewUserName(String value) {
        this.reviewUserName = value;
    }

    /**
     * Gets the value of the reviewDay property.
     *
     * @return possible      object is     {@link String }
     */
    public String getReviewDay() {
        return reviewDay;
    }

    /**
     * Sets the value of the reviewDay property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setReviewDay(String value) {
        this.reviewDay = value;
    }

    /**
     * Gets the value of the deleteErrorTime property.
     *
     * @return possible      object is     {@link String }
     */
    public String getDeleteErrorTime() {
        return deleteErrorTime;
    }

    /**
     * Sets the value of the deleteErrorTime property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setDeleteErrorTime(String value) {
        this.deleteErrorTime = value;
    }

    /**
     * Gets the value of the deleteUserId property.
     *
     * @return possible      object is     {@link String }
     */
    public String getDeleteUserId() {
        return deleteUserId;
    }

    /**
     * Sets the value of the deleteUserId property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setDeleteUserId(String value) {
        this.deleteUserId = value;
    }

}
