
package com.manulife.esb.xsd.jh.workmanagement;

import java.math.BigInteger;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for createSourceInstance complex type.
 *
 * <p>The following schema fragment specifies the expected content contained within this class.
 *
 * <pre>
 * &lt;complexType name="createSourceInstance">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/jh/WorkManagement}createAWDInstance"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/jh/WorkManagement}receiveTime" minOccurs="0"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/jh/WorkManagement}format" minOccurs="0"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/jh/WorkManagement}archiveBox" minOccurs="0"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/jh/WorkManagement}archiveStartPage" minOccurs="0"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/jh/WorkManagement}contentId" minOccurs="0"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/jh/WorkManagement}securityLevel" minOccurs="0"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/jh/WorkManagement}mailType" minOccurs="0"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/jh/WorkManagement}accessMethod" minOccurs="0"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/jh/WorkManagement}pageCount" minOccurs="0"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/jh/WorkManagement}annotationBlob" minOccurs="0"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/jh/WorkManagement}createStation" minOccurs="0"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/jh/WorkManagement}attachmentList" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "createSourceInstance", propOrder = {
    "createAWDInstance",
    "receiveTime",
    "format",
    "archiveBox",
    "archiveStartPage",
    "contentId",
    "securityLevel",
    "mailType",
    "accessMethod",
    "pageCount",
    "annotationBlob",
    "createStation",
    "attachmentList"
})
public class CreateSourceInstance {

    /**
     * The Create awd instance.
     */
    @XmlElement(required = true)
    protected CreateAWDInstance createAWDInstance;
    /**
     * The Receive time.
     */
    protected String receiveTime;
    /**
     * The Format.
     */
    protected String format;
    /**
     * The Archive box.
     */
    protected String archiveBox;
    /**
     * The Archive start page.
     */
    protected String archiveStartPage;
    /**
     * The Content id.
     */
    protected String contentId;
    /**
     * The Security level.
     */
    protected String securityLevel;
    /**
     * The Mail type.
     */
    protected String mailType;
    /**
     * The Access method.
     */
    protected String accessMethod;
    /**
     * The Page count.
     */
    @XmlSchemaType(name = "nonNegativeInteger")
    protected BigInteger pageCount;
    /**
     * The Annotation blob.
     */
    protected String annotationBlob;
    /**
     * The Create station.
     */
    protected String createStation;
    /**
     * The Attachment list.
     */
    protected AttachmentList attachmentList;

    /**
     * Gets the value of the createAWDInstance property.
     *
     * @return possible      object is     {@link CreateAWDInstance }
     */
    public CreateAWDInstance getCreateAWDInstance() {
        return createAWDInstance;
    }

    /**
     * Sets the value of the createAWDInstance property.
     *
     * @param value allowed object is     {@link CreateAWDInstance }
     */
    public void setCreateAWDInstance(CreateAWDInstance value) {
        this.createAWDInstance = value;
    }

    /**
     * Gets the value of the receiveTime property.
     *
     * @return possible      object is     {@link String }
     */
    public String getReceiveTime() {
        return receiveTime;
    }

    /**
     * Sets the value of the receiveTime property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setReceiveTime(String value) {
        this.receiveTime = value;
    }

    /**
     * Gets the value of the format property.
     *
     * @return possible      object is     {@link String }
     */
    public String getFormat() {
        return format;
    }

    /**
     * Sets the value of the format property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setFormat(String value) {
        this.format = value;
    }

    /**
     * Gets the value of the archiveBox property.
     *
     * @return possible      object is     {@link String }
     */
    public String getArchiveBox() {
        return archiveBox;
    }

    /**
     * Sets the value of the archiveBox property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setArchiveBox(String value) {
        this.archiveBox = value;
    }

    /**
     * Gets the value of the archiveStartPage property.
     *
     * @return possible      object is     {@link String }
     */
    public String getArchiveStartPage() {
        return archiveStartPage;
    }

    /**
     * Sets the value of the archiveStartPage property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setArchiveStartPage(String value) {
        this.archiveStartPage = value;
    }

    /**
     * Gets the value of the contentId property.
     *
     * @return possible      object is     {@link String }
     */
    public String getContentId() {
        return contentId;
    }

    /**
     * Sets the value of the contentId property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setContentId(String value) {
        this.contentId = value;
    }

    /**
     * Gets the value of the securityLevel property.
     *
     * @return possible      object is     {@link String }
     */
    public String getSecurityLevel() {
        return securityLevel;
    }

    /**
     * Sets the value of the securityLevel property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setSecurityLevel(String value) {
        this.securityLevel = value;
    }

    /**
     * Gets the value of the mailType property.
     *
     * @return possible      object is     {@link String }
     */
    public String getMailType() {
        return mailType;
    }

    /**
     * Sets the value of the mailType property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setMailType(String value) {
        this.mailType = value;
    }

    /**
     * Gets the value of the accessMethod property.
     *
     * @return possible      object is     {@link String }
     */
    public String getAccessMethod() {
        return accessMethod;
    }

    /**
     * Sets the value of the accessMethod property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setAccessMethod(String value) {
        this.accessMethod = value;
    }

    /**
     * Gets the value of the pageCount property.
     *
     * @return possible      object is     {@link BigInteger }
     */
    public BigInteger getPageCount() {
        return pageCount;
    }

    /**
     * Sets the value of the pageCount property.
     *
     * @param value allowed object is     {@link BigInteger }
     */
    public void setPageCount(BigInteger value) {
        this.pageCount = value;
    }

    /**
     * Gets the value of the annotationBlob property.
     *
     * @return possible      object is     {@link String }
     */
    public String getAnnotationBlob() {
        return annotationBlob;
    }

    /**
     * Sets the value of the annotationBlob property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setAnnotationBlob(String value) {
        this.annotationBlob = value;
    }

    /**
     * Gets the value of the createStation property.
     *
     * @return possible      object is     {@link String }
     */
    public String getCreateStation() {
        return createStation;
    }

    /**
     * Sets the value of the createStation property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setCreateStation(String value) {
        this.createStation = value;
    }

    /**
     * Gets the value of the attachmentList property.
     *
     * @return possible      object is     {@link AttachmentList }
     */
    public AttachmentList getAttachmentList() {
        return attachmentList;
    }

    /**
     * Sets the value of the attachmentList property.
     *
     * @param value allowed object is     {@link AttachmentList }
     */
    public void setAttachmentList(AttachmentList value) {
        this.attachmentList = value;
    }

}
