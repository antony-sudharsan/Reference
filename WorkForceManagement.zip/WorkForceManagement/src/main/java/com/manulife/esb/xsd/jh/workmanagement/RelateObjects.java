
package com.manulife.esb.xsd.jh.workmanagement;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for relateObjects complex type.
 *
 * <p>The following schema fragment specifies the expected content contained within this class.
 *
 * <pre>
 * &lt;complexType name="relateObjects">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/jh/WorkManagement}parentId" minOccurs="0"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/jh/WorkManagement}childId" minOccurs="0"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/jh/WorkManagement}parentRelationshipId" minOccurs="0"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/jh/WorkManagement}childRelationshipId" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "relateObjects", propOrder = {
    "parentId",
    "childId",
    "parentRelationshipId",
    "childRelationshipId"
})
public class RelateObjects {

    /**
     * The Parent id.
     */
    protected String parentId;
    /**
     * The Child id.
     */
    protected String childId;
    /**
     * The Parent relationship id.
     */
    protected String parentRelationshipId;
    /**
     * The Child relationship id.
     */
    protected String childRelationshipId;

    /**
     * Gets the value of the parentId property.
     *
     * @return possible      object is     {@link String }
     */
    public String getParentId() {
        return parentId;
    }

    /**
     * Sets the value of the parentId property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setParentId(String value) {
        this.parentId = value;
    }

    /**
     * Gets the value of the childId property.
     *
     * @return possible      object is     {@link String }
     */
    public String getChildId() {
        return childId;
    }

    /**
     * Sets the value of the childId property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setChildId(String value) {
        this.childId = value;
    }

    /**
     * Gets the value of the parentRelationshipId property.
     *
     * @return possible      object is     {@link String }
     */
    public String getParentRelationshipId() {
        return parentRelationshipId;
    }

    /**
     * Sets the value of the parentRelationshipId property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setParentRelationshipId(String value) {
        this.parentRelationshipId = value;
    }

    /**
     * Gets the value of the childRelationshipId property.
     *
     * @return possible      object is     {@link String }
     */
    public String getChildRelationshipId() {
        return childRelationshipId;
    }

    /**
     * Sets the value of the childRelationshipId property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setChildRelationshipId(String value) {
        this.childRelationshipId = value;
    }

}
