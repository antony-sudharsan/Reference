
package com.manulife.esb.xsd.jh.workmanagement;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for keEvent complex type.
 *
 * <p>The following schema fragment specifies the expected content contained within this class.
 *
 * <pre>
 * &lt;complexType name="keEvent">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/jh/WorkManagement}systemEvent"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/jh/WorkManagement}jobName" minOccurs="0"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/jh/WorkManagement}description" minOccurs="0"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/jh/WorkManagement}returnCode" minOccurs="0"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/jh/WorkManagement}taskName" minOccurs="0"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/jh/WorkManagement}nextTaskName" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "keEvent", propOrder = {
    "systemEvent",
    "jobName",
    "description",
    "returnCode",
    "taskName",
    "nextTaskName"
})
public class KeEvent {

    /**
     * The System event.
     */
    @XmlElement(required = true)
    protected SystemEvent systemEvent;
    /**
     * The Job name.
     */
    protected String jobName;
    /**
     * The Description.
     */
    protected String description;
    /**
     * The Return code.
     */
    protected String returnCode;
    /**
     * The Task name.
     */
    protected String taskName;
    /**
     * The Next task name.
     */
    protected String nextTaskName;

    /**
     * Gets the value of the systemEvent property.
     *
     * @return possible      object is     {@link SystemEvent }
     */
    public SystemEvent getSystemEvent() {
        return systemEvent;
    }

    /**
     * Sets the value of the systemEvent property.
     *
     * @param value allowed object is     {@link SystemEvent }
     */
    public void setSystemEvent(SystemEvent value) {
        this.systemEvent = value;
    }

    /**
     * Gets the value of the jobName property.
     *
     * @return possible      object is     {@link String }
     */
    public String getJobName() {
        return jobName;
    }

    /**
     * Sets the value of the jobName property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setJobName(String value) {
        this.jobName = value;
    }

    /**
     * Gets the value of the description property.
     *
     * @return possible      object is     {@link String }
     */
    public String getDescription() {
        return description;
    }

    /**
     * Sets the value of the description property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setDescription(String value) {
        this.description = value;
    }

    /**
     * Gets the value of the returnCode property.
     *
     * @return possible      object is     {@link String }
     */
    public String getReturnCode() {
        return returnCode;
    }

    /**
     * Sets the value of the returnCode property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setReturnCode(String value) {
        this.returnCode = value;
    }

    /**
     * Gets the value of the taskName property.
     *
     * @return possible      object is     {@link String }
     */
    public String getTaskName() {
        return taskName;
    }

    /**
     * Sets the value of the taskName property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setTaskName(String value) {
        this.taskName = value;
    }

    /**
     * Gets the value of the nextTaskName property.
     *
     * @return possible      object is     {@link String }
     */
    public String getNextTaskName() {
        return nextTaskName;
    }

    /**
     * Sets the value of the nextTaskName property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setNextTaskName(String value) {
        this.nextTaskName = value;
    }

}
