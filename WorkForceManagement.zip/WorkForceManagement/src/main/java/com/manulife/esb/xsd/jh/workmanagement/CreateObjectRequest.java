
package com.manulife.esb.xsd.jh.workmanagement;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.*;


/**
 * <p>Java class for createObjectRequest complex type.
 *
 * <p>The following schema fragment specifies the expected content contained within this class.
 *
 * <pre>
 * &lt;complexType name="createObjectRequest">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/jh/WorkManagement}responseDetails" minOccurs="0"/>
 *         &lt;choice maxOccurs="unbounded" minOccurs="0">
 *           &lt;element ref="{http://www.esb.manulife.com/xsd/jh/WorkManagement}createFolderInstance"/>
 *           &lt;element ref="{http://www.esb.manulife.com/xsd/jh/WorkManagement}createSourceInstance"/>
 *           &lt;element ref="{http://www.esb.manulife.com/xsd/jh/WorkManagement}createWorkInstance"/>
 *         &lt;/choice>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/jh/WorkManagement}relationships" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "createObjectRequest", propOrder = {
    "responseDetails",
    "createFolderInstanceOrCreateSourceInstanceOrCreateWorkInstance",
    "relationships"
})

public class CreateObjectRequest {

    /**
     * The Response details.
     */
    protected ResponseDetails responseDetails;
    /**
     * The Create folder instance or create source instance or create work instance.
     */
    @XmlElements({
        @XmlElement(name = "createFolderInstance", type = CreateFolderInstance.class),
        @XmlElement(name = "createSourceInstance", type = CreateSourceInstance.class),
        @XmlElement(name = "createWorkInstance", type = CreateWorkInstance.class)
    })
    protected List<Object> createFolderInstanceOrCreateSourceInstanceOrCreateWorkInstance;
    /**
     * The Relationships.
     */
    protected Relationships relationships;

    /**
     * Gets the value of the responseDetails property.
     *
     * @return possible      object is     {@link ResponseDetails }
     */
    public ResponseDetails getResponseDetails() {
        return responseDetails;
    }

    /**
     * Sets the value of the responseDetails property.
     *
     * @param value allowed object is     {@link ResponseDetails }
     */
    public void setResponseDetails(ResponseDetails value) {
        this.responseDetails = value;
    }

    /**
     * Gets the value of the createFolderInstanceOrCreateSourceInstanceOrCreateWorkInstance property.
     * <p>
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the createFolderInstanceOrCreateSourceInstanceOrCreateWorkInstance property.
     * <p>
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getCreateFolderInstanceOrCreateSourceInstanceOrCreateWorkInstance().add(newItem);
     * </pre>
     * <p>
     * <p>
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link CreateFolderInstance }
     * {@link CreateSourceInstance }
     * {@link CreateWorkInstance }
     *
     * @return the create folder instance or create source instance or create work instance
     */
    public List<Object> getCreateFolderInstanceOrCreateSourceInstanceOrCreateWorkInstance() {
        if (createFolderInstanceOrCreateSourceInstanceOrCreateWorkInstance == null) {
            createFolderInstanceOrCreateSourceInstanceOrCreateWorkInstance = new ArrayList<Object>();
        }
        return this.createFolderInstanceOrCreateSourceInstanceOrCreateWorkInstance;
    }

    /**
     * Gets the value of the relationships property.
     *
     * @return possible      object is     {@link Relationships }
     */
    public Relationships getRelationships() {
        return relationships;
    }

    /**
     * Sets the value of the relationships property.
     *
     * @param value allowed object is     {@link Relationships }
     */
    public void setRelationships(Relationships value) {
        this.relationships = value;
    }

}
