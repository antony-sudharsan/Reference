
package com.manulife.esb.xsd.jh.workmanagement;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for responseDetails complex type.
 *
 * <p>The following schema fragment specifies the expected content contained within this class.
 *
 * <pre>
 * &lt;complexType name="responseDetails">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;attribute name="showAll" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="showComments" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="showEvents" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="showInstanceData" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="showNone" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="showOnlyControlData" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="showRelationships" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="showWorkflow" type="{http://www.w3.org/2001/XMLSchema}string" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "responseDetails")
public class ResponseDetails {

    /**
     * The Show all.
     */
    @XmlAttribute(name = "showAll")
    protected String showAll;
    /**
     * The Show comments.
     */
    @XmlAttribute(name = "showComments")
    protected String showComments;
    /**
     * The Show events.
     */
    @XmlAttribute(name = "showEvents")
    protected String showEvents;
    /**
     * The Show instance data.
     */
    @XmlAttribute(name = "showInstanceData")
    protected String showInstanceData;
    /**
     * The Show none.
     */
    @XmlAttribute(name = "showNone")
    protected String showNone;
    /**
     * The Show only control data.
     */
    @XmlAttribute(name = "showOnlyControlData")
    protected String showOnlyControlData;
    /**
     * The Show relationships.
     */
    @XmlAttribute(name = "showRelationships")
    protected String showRelationships;
    /**
     * The Show workflow.
     */
    @XmlAttribute(name = "showWorkflow")
    protected String showWorkflow;

    /**
     * Gets the value of the showAll property.
     *
     * @return possible      object is     {@link String }
     */
    public String getShowAll() {
        return showAll;
    }

    /**
     * Sets the value of the showAll property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setShowAll(String value) {
        this.showAll = value;
    }

    /**
     * Gets the value of the showComments property.
     *
     * @return possible      object is     {@link String }
     */
    public String getShowComments() {
        return showComments;
    }

    /**
     * Sets the value of the showComments property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setShowComments(String value) {
        this.showComments = value;
    }

    /**
     * Gets the value of the showEvents property.
     *
     * @return possible      object is     {@link String }
     */
    public String getShowEvents() {
        return showEvents;
    }

    /**
     * Sets the value of the showEvents property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setShowEvents(String value) {
        this.showEvents = value;
    }

    /**
     * Gets the value of the showInstanceData property.
     *
     * @return possible      object is     {@link String }
     */
    public String getShowInstanceData() {
        return showInstanceData;
    }

    /**
     * Sets the value of the showInstanceData property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setShowInstanceData(String value) {
        this.showInstanceData = value;
    }

    /**
     * Gets the value of the showNone property.
     *
     * @return possible      object is     {@link String }
     */
    public String getShowNone() {
        return showNone;
    }

    /**
     * Sets the value of the showNone property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setShowNone(String value) {
        this.showNone = value;
    }

    /**
     * Gets the value of the showOnlyControlData property.
     *
     * @return possible      object is     {@link String }
     */
    public String getShowOnlyControlData() {
        return showOnlyControlData;
    }

    /**
     * Sets the value of the showOnlyControlData property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setShowOnlyControlData(String value) {
        this.showOnlyControlData = value;
    }

    /**
     * Gets the value of the showRelationships property.
     *
     * @return possible      object is     {@link String }
     */
    public String getShowRelationships() {
        return showRelationships;
    }

    /**
     * Sets the value of the showRelationships property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setShowRelationships(String value) {
        this.showRelationships = value;
    }

    /**
     * Gets the value of the showWorkflow property.
     *
     * @return possible      object is     {@link String }
     */
    public String getShowWorkflow() {
        return showWorkflow;
    }

    /**
     * Sets the value of the showWorkflow property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setShowWorkflow(String value) {
        this.showWorkflow = value;
    }

}
