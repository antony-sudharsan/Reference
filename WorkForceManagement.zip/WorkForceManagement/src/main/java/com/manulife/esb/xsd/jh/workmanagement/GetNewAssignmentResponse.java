
package com.manulife.esb.xsd.jh.workmanagement;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for getNewAssignmentResponse complex type.
 *
 * <p>The following schema fragment specifies the expected content contained within this class.
 *
 * <pre>
 * &lt;complexType name="getNewAssignmentResponse">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="newAssignmentResponse" type="{http://www.esb.manulife.com/xsd/jh/WorkManagement}GetObjectsResponse" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "getNewAssignmentResponse", propOrder = {
    "newAssignmentResponse"
})
public class GetNewAssignmentResponse {

    /**
     * The New assignment response.
     */
    protected GetObjectsResponse newAssignmentResponse;

    /**
     * Gets the value of the newAssignmentResponse property.
     *
     * @return possible      object is     {@link GetObjectsResponse }
     */
    public GetObjectsResponse getNewAssignmentResponse() {
        return newAssignmentResponse;
    }

    /**
     * Sets the value of the newAssignmentResponse property.
     *
     * @param value allowed object is     {@link GetObjectsResponse }
     */
    public void setNewAssignmentResponse(GetObjectsResponse value) {
        this.newAssignmentResponse = value;
    }

}
