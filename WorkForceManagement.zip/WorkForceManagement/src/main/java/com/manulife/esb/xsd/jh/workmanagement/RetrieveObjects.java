
package com.manulife.esb.xsd.jh.workmanagement;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for retrieveObjects complex type.
 *
 * <p>The following schema fragment specifies the expected content contained within this class.
 *
 * <pre>
 * &lt;complexType name="retrieveObjects">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="getObjectsRequest" type="{http://www.esb.manulife.com/xsd/jh/WorkManagement}getObjectsRequest" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "retrieveObjects", propOrder = {
    "getObjectsRequest"
})
public class RetrieveObjects {

    /**
     * The Get objects request.
     */
    protected GetObjectsRequest getObjectsRequest;

    /**
     * Gets the value of the getObjectsRequest property.
     *
     * @return possible      object is     {@link GetObjectsRequest }
     */
    public GetObjectsRequest getGetObjectsRequest() {
        return getObjectsRequest;
    }

    /**
     * Sets the value of the getObjectsRequest property.
     *
     * @param value allowed object is     {@link GetObjectsRequest }
     */
    public void setGetObjectsRequest(GetObjectsRequest value) {
        this.getObjectsRequest = value;
    }

}
