
package com.manulife.esb.xsd.jh.workmanagement;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for createAWDInstance complex type.
 *
 * <p>The following schema fragment specifies the expected content contained within this class.
 *
 * <pre>
 * &lt;complexType name="createAWDInstance">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/jh/WorkManagement}fieldValues" minOccurs="0"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/jh/WorkManagement}businessArea"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/jh/WorkManagement}type"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/jh/WorkManagement}addManualComment" minOccurs="0"/>
 *       &lt;/sequence>
 *       &lt;attribute name="lock" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="relationshipId" type="{http://www.w3.org/2001/XMLSchema}string" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "createAWDInstance", propOrder = {
    "fieldValues",
    "businessArea",
    "type",
    "addManualComment"
})
public class CreateAWDInstance {

    /**
     * The Field values.
     */
    protected FieldValues fieldValues;
    /**
     * The Business area.
     */
    @XmlElement(required = true)
    protected String businessArea;
    /**
     * The Type.
     */
    @XmlElement(required = true)
    protected String type;
    /**
     * The Add manual comment.
     */
    protected String addManualComment;
    /**
     * The Lock.
     */
    @XmlAttribute(name = "lock")
    protected String lock;
    /**
     * The Relationship id.
     */
    @XmlAttribute(name = "relationshipId")
    protected String relationshipId;

    /**
     * Gets the value of the fieldValues property.
     *
     * @return possible      object is     {@link FieldValues }
     */
    public FieldValues getFieldValues() {
        return fieldValues;
    }

    /**
     * Sets the value of the fieldValues property.
     *
     * @param value allowed object is     {@link FieldValues }
     */
    public void setFieldValues(FieldValues value) {
        this.fieldValues = value;
    }

    /**
     * Gets the value of the businessArea property.
     *
     * @return possible      object is     {@link String }
     */
    public String getBusinessArea() {
        return businessArea;
    }

    /**
     * Sets the value of the businessArea property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setBusinessArea(String value) {
        this.businessArea = value;
    }

    /**
     * Gets the value of the type property.
     *
     * @return possible      object is     {@link String }
     */
    public String getType() {
        return type;
    }

    /**
     * Sets the value of the type property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setType(String value) {
        this.type = value;
    }

    /**
     * Gets the value of the addManualComment property.
     *
     * @return possible      object is     {@link String }
     */
    public String getAddManualComment() {
        return addManualComment;
    }

    /**
     * Sets the value of the addManualComment property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setAddManualComment(String value) {
        this.addManualComment = value;
    }

    /**
     * Gets the value of the lock property.
     *
     * @return possible      object is     {@link String }
     */
    public String getLock() {
        return lock;
    }

    /**
     * Sets the value of the lock property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setLock(String value) {
        this.lock = value;
    }

    /**
     * Gets the value of the relationshipId property.
     *
     * @return possible      object is     {@link String }
     */
    public String getRelationshipId() {
        return relationshipId;
    }

    /**
     * Sets the value of the relationshipId property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setRelationshipId(String value) {
        this.relationshipId = value;
    }

}
