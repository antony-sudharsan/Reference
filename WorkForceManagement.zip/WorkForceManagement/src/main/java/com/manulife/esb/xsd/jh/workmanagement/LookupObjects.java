
package com.manulife.esb.xsd.jh.workmanagement;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for lookupObjects complex type.
 *
 * <p>The following schema fragment specifies the expected content contained within this class.
 *
 * <pre>
 * &lt;complexType name="lookupObjects">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="lookupObjectsRequest" type="{http://www.esb.manulife.com/xsd/jh/WorkManagement}lookupObjectsRequest" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "lookupObjects", propOrder = {
    "lookupObjectsRequest"
})
public class LookupObjects {

    /**
     * The Lookup objects request.
     */
    protected LookupObjectsRequest lookupObjectsRequest;

    /**
     * Gets the value of the lookupObjectsRequest property.
     *
     * @return possible      object is     {@link LookupObjectsRequest }
     */
    public LookupObjectsRequest getLookupObjectsRequest() {
        return lookupObjectsRequest;
    }

    /**
     * Sets the value of the lookupObjectsRequest property.
     *
     * @param value allowed object is     {@link LookupObjectsRequest }
     */
    public void setLookupObjectsRequest(LookupObjectsRequest value) {
        this.lookupObjectsRequest = value;
    }

}
