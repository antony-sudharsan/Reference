
package com.manulife.esb.xsd.jh.workmanagement;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for createFolderInstance complex type.
 *
 * <p>The following schema fragment specifies the expected content contained within this class.
 *
 * <pre>
 * &lt;complexType name="createFolderInstance">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/jh/WorkManagement}createAWDInstance"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/jh/WorkManagement}createStation" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "createFolderInstance", propOrder = {
    "createAWDInstance",
    "createStation"
})
public class CreateFolderInstance {

    /**
     * The Create awd instance.
     */
    @XmlElement(required = true)
    protected CreateAWDInstance createAWDInstance;
    /**
     * The Create station.
     */
    protected String createStation;

    /**
     * Gets the value of the createAWDInstance property.
     *
     * @return possible      object is     {@link CreateAWDInstance }
     */
    public CreateAWDInstance getCreateAWDInstance() {
        return createAWDInstance;
    }

    /**
     * Sets the value of the createAWDInstance property.
     *
     * @param value allowed object is     {@link CreateAWDInstance }
     */
    public void setCreateAWDInstance(CreateAWDInstance value) {
        this.createAWDInstance = value;
    }

    /**
     * Gets the value of the createStation property.
     *
     * @return possible      object is     {@link String }
     */
    public String getCreateStation() {
        return createStation;
    }

    /**
     * Sets the value of the createStation property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setCreateStation(String value) {
        this.createStation = value;
    }

}
