
package com.manulife.esb.xsd.jh.workmanagement;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for getNewAssignment complex type.
 *
 * <p>The following schema fragment specifies the expected content contained within this class.
 *
 * <pre>
 * &lt;complexType name="getNewAssignment">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="getNewAssignmentRequest" type="{http://www.esb.manulife.com/xsd/jh/WorkManagement}getNewAssignmentRequest" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "getNewAssignment", propOrder = {
    "getNewAssignmentRequest"
})
public class GetNewAssignment {

    /**
     * The Get new assignment request.
     */
    protected GetNewAssignmentRequest getNewAssignmentRequest;

    /**
     * Gets the value of the getNewAssignmentRequest property.
     *
     * @return possible      object is     {@link GetNewAssignmentRequest }
     */
    public GetNewAssignmentRequest getGetNewAssignmentRequest() {
        return getNewAssignmentRequest;
    }

    /**
     * Sets the value of the getNewAssignmentRequest property.
     *
     * @param value allowed object is     {@link GetNewAssignmentRequest }
     */
    public void setGetNewAssignmentRequest(GetNewAssignmentRequest value) {
        this.getNewAssignmentRequest = value;
    }

}
