
package com.manulife.esb.xsd.jh.workmanagement;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for suspended complex type.
 *
 * <p>The following schema fragment specifies the expected content contained within this class.
 *
 * <pre>
 * &lt;complexType name="suspended">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;attribute name="activationDate" use="required" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="activationRoutingStatus" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="reasonCode" type="{http://www.w3.org/2001/XMLSchema}string" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "suspended")
public class Suspended {

    /**
     * The Activation date.
     */
    @XmlAttribute(name = "activationDate", required = true)
    protected String activationDate;
    /**
     * The Activation routing status.
     */
    @XmlAttribute(name = "activationRoutingStatus")
    protected String activationRoutingStatus;
    /**
     * The Reason code.
     */
    @XmlAttribute(name = "reasonCode")
    protected String reasonCode;

    /**
     * Gets the value of the activationDate property.
     *
     * @return possible      object is     {@link String }
     */
    public String getActivationDate() {
        return activationDate;
    }

    /**
     * Sets the value of the activationDate property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setActivationDate(String value) {
        this.activationDate = value;
    }

    /**
     * Gets the value of the activationRoutingStatus property.
     *
     * @return possible      object is     {@link String }
     */
    public String getActivationRoutingStatus() {
        return activationRoutingStatus;
    }

    /**
     * Sets the value of the activationRoutingStatus property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setActivationRoutingStatus(String value) {
        this.activationRoutingStatus = value;
    }

    /**
     * Gets the value of the reasonCode property.
     *
     * @return possible      object is     {@link String }
     */
    public String getReasonCode() {
        return reasonCode;
    }

    /**
     * Sets the value of the reasonCode property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setReasonCode(String value) {
        this.reasonCode = value;
    }

}
