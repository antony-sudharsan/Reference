
package com.manulife.esb.xsd.jh.workmanagement;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for lookupObjectsRequest complex type.
 *
 * <p>The following schema fragment specifies the expected content contained within this class.
 *
 * <pre>
 * &lt;complexType name="lookupObjectsRequest">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/jh/WorkManagement}responseDetails" minOccurs="0"/>
 *         &lt;element name="lookupParameters" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="lookupParameter" type="{http://www.esb.manulife.com/xsd/jh/WorkManagement}lookupParameter" maxOccurs="unbounded" minOccurs="0"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *       &lt;/sequence>
 *       &lt;attribute name="lookupName" use="required" type="{http://www.w3.org/2001/XMLSchema}string" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "lookupObjectsRequest", propOrder = {
    "responseDetails",
    "lookupParameters"
})
public class LookupObjectsRequest {

    /**
     * The Response details.
     */
    protected ResponseDetails responseDetails;
    /**
     * The Lookup parameters.
     */
    protected LookupParameters lookupParameters;
    /**
     * The Lookup name.
     */
    @XmlAttribute(name = "lookupName", required = true)
    protected String lookupName;

    /**
     * Gets the value of the responseDetails property.
     *
     * @return possible      object is     {@link ResponseDetails }
     */
    public ResponseDetails getResponseDetails() {
        return responseDetails;
    }

    /**
     * Sets the value of the responseDetails property.
     *
     * @param value allowed object is     {@link ResponseDetails }
     */
    public void setResponseDetails(ResponseDetails value) {
        this.responseDetails = value;
    }

    /**
     * Gets the value of the lookupParameters property.
     *
     * @return possible      object is     {@link LookupParameters }
     */
    public LookupParameters getLookupParameters() {
        return lookupParameters;
    }

    /**
     * Sets the value of the lookupParameters property.
     *
     * @param value allowed object is     {@link LookupParameters }
     */
    public void setLookupParameters(LookupParameters value) {
        this.lookupParameters = value;
    }

    /**
     * Gets the value of the lookupName property.
     *
     * @return possible      object is     {@link String }
     */
    public String getLookupName() {
        return lookupName;
    }

    /**
     * Sets the value of the lookupName property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setLookupName(String value) {
        this.lookupName = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     *
     * <p>The following schema fragment specifies the expected content contained within this class.
     *
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="lookupParameter" type="{http://www.esb.manulife.com/xsd/jh/WorkManagement}lookupParameter" maxOccurs="unbounded" minOccurs="0"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "lookupParameter"
    })
    public static class LookupParameters {

        /**
         * The Lookup parameter.
         */
        protected List<LookupParameter> lookupParameter;

        /**
         * Gets the value of the lookupParameter property.
         * <p>
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the lookupParameter property.
         * <p>
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getLookupParameter().add(newItem);
         * </pre>
         * <p>
         * <p>
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link LookupParameter }
         *
         * @return the lookup parameter
         */
        public List<LookupParameter> getLookupParameter() {
            if (lookupParameter == null) {
                lookupParameter = new ArrayList<LookupParameter>();
            }
            return this.lookupParameter;
        }

    }

}
