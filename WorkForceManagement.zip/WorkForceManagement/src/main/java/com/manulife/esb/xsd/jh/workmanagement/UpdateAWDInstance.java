
package com.manulife.esb.xsd.jh.workmanagement;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElements;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for updateAWDInstance complex type.
 *
 * <p>The following schema fragment specifies the expected content contained within this class.
 *
 * <pre>
 * &lt;complexType name="updateAWDInstance">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="fieldValues" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;choice maxOccurs="unbounded" minOccurs="0">
 *                   &lt;element name="deleteFieldValue" type="{http://www.esb.manulife.com/xsd/jh/WorkManagement}deleteFieldValue"/>
 *                   &lt;element name="fieldValue" type="{http://www.esb.manulife.com/xsd/jh/WorkManagement}fieldValue"/>
 *                 &lt;/choice>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="businessArea" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="type" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="addManualComment" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *       &lt;attribute name="duration" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="id" use="required" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="lock" type="{http://www.w3.org/2001/XMLSchema}string" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "updateAWDInstance", propOrder = {
    "fieldValues",
    "businessArea",
    "type",
    "addManualComment"
})
public class UpdateAWDInstance {

    /**
     * The Field values.
     */
    protected FieldValues fieldValues;
    /**
     * The Business area.
     */
    protected String businessArea;
    /**
     * The Type.
     */
    protected String type;
    /**
     * The Add manual comment.
     */
    protected String addManualComment;
    /**
     * The Duration.
     */
    @XmlAttribute(name = "duration")
    protected String duration;
    /**
     * The Id.
     */
    @XmlAttribute(name = "id", required = true)
    protected String id;
    /**
     * The Lock.
     */
    @XmlAttribute(name = "lock")
    protected String lock;

    /**
     * Gets the value of the fieldValues property.
     *
     * @return possible      object is     {@link FieldValues }
     */
    public FieldValues getFieldValues() {
        return fieldValues;
    }

    /**
     * Sets the value of the fieldValues property.
     *
     * @param value allowed object is     {@link FieldValues }
     */
    public void setFieldValues(FieldValues value) {
        this.fieldValues = value;
    }

    /**
     * Gets the value of the businessArea property.
     *
     * @return possible      object is     {@link String }
     */
    public String getBusinessArea() {
        return businessArea;
    }

    /**
     * Sets the value of the businessArea property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setBusinessArea(String value) {
        this.businessArea = value;
    }

    /**
     * Gets the value of the type property.
     *
     * @return possible      object is     {@link String }
     */
    public String getType() {
        return type;
    }

    /**
     * Sets the value of the type property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setType(String value) {
        this.type = value;
    }

    /**
     * Gets the value of the addManualComment property.
     *
     * @return possible      object is     {@link String }
     */
    public String getAddManualComment() {
        return addManualComment;
    }

    /**
     * Sets the value of the addManualComment property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setAddManualComment(String value) {
        this.addManualComment = value;
    }

    /**
     * Gets the value of the duration property.
     *
     * @return possible      object is     {@link String }
     */
    public String getDuration() {
        return duration;
    }

    /**
     * Sets the value of the duration property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setDuration(String value) {
        this.duration = value;
    }

    /**
     * Gets the value of the id property.
     *
     * @return possible      object is     {@link String }
     */
    public String getId() {
        return id;
    }

    /**
     * Sets the value of the id property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setId(String value) {
        this.id = value;
    }

    /**
     * Gets the value of the lock property.
     *
     * @return possible      object is     {@link String }
     */
    public String getLock() {
        return lock;
    }

    /**
     * Sets the value of the lock property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setLock(String value) {
        this.lock = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     *
     * <p>The following schema fragment specifies the expected content contained within this class.
     *
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;choice maxOccurs="unbounded" minOccurs="0">
     *         &lt;element name="deleteFieldValue" type="{http://www.esb.manulife.com/xsd/jh/WorkManagement}deleteFieldValue"/>
     *         &lt;element name="fieldValue" type="{http://www.esb.manulife.com/xsd/jh/WorkManagement}fieldValue"/>
     *       &lt;/choice>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "deleteFieldValueOrFieldValue"
    })
    public static class FieldValues {

        /**
         * The Delete field value or field value.
         */
        @XmlElements({
            @XmlElement(name = "deleteFieldValue", type = DeleteFieldValue.class),
            @XmlElement(name = "fieldValue", type = FieldValue.class)
        })
        protected List<Object> deleteFieldValueOrFieldValue;

        /**
         * Gets the value of the deleteFieldValueOrFieldValue property.
         * <p>
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the deleteFieldValueOrFieldValue property.
         * <p>
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getDeleteFieldValueOrFieldValue().add(newItem);
         * </pre>
         * <p>
         * <p>
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link DeleteFieldValue }
         * {@link FieldValue }
         *
         * @return the delete field value or field value
         */
        public List<Object> getDeleteFieldValueOrFieldValue() {
            if (deleteFieldValueOrFieldValue == null) {
                deleteFieldValueOrFieldValue = new ArrayList<Object>();
            }
            return this.deleteFieldValueOrFieldValue;
        }

    }

}
