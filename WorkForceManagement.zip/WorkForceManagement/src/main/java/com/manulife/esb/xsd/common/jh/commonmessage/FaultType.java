
package com.manulife.esb.xsd.common.jh.commonmessage;

import javax.xml.bind.annotation.*;


/**
 * <p>Java class for FaultType complex type.
 *
 * <p>The following schema fragment specifies the expected content contained within this class.
 *
 * <pre>
 * &lt;complexType name="FaultType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="ErrorCode" type="{http://www.esb.manulife.com/xsd/common/jh/CommonMessage}ErrorCodeType"/>
 *         &lt;element name="ErrorDescription" type="{http://www.esb.manulife.com/xsd/common/jh/CommonMessage}ErrorDescriptionType"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "FaultType", propOrder = {
    "errorCode",
    "errorDescription"
})
@XmlRootElement(name = "Fault")
public class FaultType {

    /**
     * The Error code.
     */
    @XmlElement(name = "ErrorCode", required = true)
    protected String errorCode;
    /**
     * The Error description.
     */
    @XmlElement(name = "ErrorDescription", required = true)
    protected String errorDescription;

    /**
     * Instantiates a new Fault type.
     *
     * @param technicalErrorCode the technical error code
     * @param message            the message
     */
    public FaultType(String technicalErrorCode, String message) {
        this.errorCode = technicalErrorCode;
        this.errorDescription = message;
    }

    /**
     * Instantiates a new Fault type.
     */
    public FaultType() {
    }

    /**
     * Gets the value of the errorCode property.
     *
     * @return possible      object is     {@link String }
     */
    public String getErrorCode() {
        return errorCode;
    }

    /**
     * Sets the value of the errorCode property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setErrorCode(String value) {
        this.errorCode = value;
    }

    /**
     * Gets the value of the errorDescription property.
     *
     * @return possible      object is     {@link String }
     */
    public String getErrorDescription() {
        return errorDescription;
    }

    /**
     * Sets the value of the errorDescription property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setErrorDescription(String value) {
        this.errorDescription = value;
    }

}
