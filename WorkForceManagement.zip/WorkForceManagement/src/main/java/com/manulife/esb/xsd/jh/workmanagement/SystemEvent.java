
package com.manulife.esb.xsd.jh.workmanagement;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for systemEvent complex type.
 *
 * <p>The following schema fragment specifies the expected content contained within this class.
 *
 * <pre>
 * &lt;complexType name="systemEvent">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/jh/WorkManagement}awdEvent"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/jh/WorkManagement}priority" minOccurs="0"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/jh/WorkManagement}userExperienceLevel" minOccurs="0"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/jh/WorkManagement}samplingMethod" minOccurs="0"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/jh/WorkManagement}qualitySampled" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "systemEvent", propOrder = {
    "awdEvent",
    "priority",
    "userExperienceLevel",
    "samplingMethod",
    "qualitySampled"
})
public class SystemEvent {

    /**
     * The Awd event.
     */
    @XmlElement(required = true)
    protected AwdEvent awdEvent;
    /**
     * The Priority.
     */
    protected String priority;
    /**
     * The User experience level.
     */
    protected String userExperienceLevel;
    /**
     * The Sampling method.
     */
    protected String samplingMethod;
    /**
     * The Quality sampled.
     */
    protected String qualitySampled;

    /**
     * Gets the value of the awdEvent property.
     *
     * @return possible      object is     {@link AwdEvent }
     */
    public AwdEvent getAwdEvent() {
        return awdEvent;
    }

    /**
     * Sets the value of the awdEvent property.
     *
     * @param value allowed object is     {@link AwdEvent }
     */
    public void setAwdEvent(AwdEvent value) {
        this.awdEvent = value;
    }

    /**
     * Gets the value of the priority property.
     *
     * @return possible      object is     {@link String }
     */
    public String getPriority() {
        return priority;
    }

    /**
     * Sets the value of the priority property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setPriority(String value) {
        this.priority = value;
    }

    /**
     * Gets the value of the userExperienceLevel property.
     *
     * @return possible      object is     {@link String }
     */
    public String getUserExperienceLevel() {
        return userExperienceLevel;
    }

    /**
     * Sets the value of the userExperienceLevel property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setUserExperienceLevel(String value) {
        this.userExperienceLevel = value;
    }

    /**
     * Gets the value of the samplingMethod property.
     *
     * @return possible      object is     {@link String }
     */
    public String getSamplingMethod() {
        return samplingMethod;
    }

    /**
     * Sets the value of the samplingMethod property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setSamplingMethod(String value) {
        this.samplingMethod = value;
    }

    /**
     * Gets the value of the qualitySampled property.
     *
     * @return possible      object is     {@link String }
     */
    public String getQualitySampled() {
        return qualitySampled;
    }

    /**
     * Sets the value of the qualitySampled property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setQualitySampled(String value) {
        this.qualitySampled = value;
    }

}
