package com.jh.workmanagement.validator;

import org.junit.Test;

import static org.junit.Assert.*;

/**
 * The type Work management validator test.
 */
public class WorkManagementValidatorTest {

    /**
     * Validate business area.
     */
    @Test
    public void validateBusinessArea() {
    }
}