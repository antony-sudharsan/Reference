package com.jh.workmanagement.controller;

import org.junit.After;
import org.junit.Before;

import static org.junit.Assert.*;

/**
 * The type Work management controller test.
 */
public class WorkManagementControllerTest {

    /**
     * Sets up.
     *
     * @throws Exception the exception
     */
    @Before
    public void setUp() throws Exception {
    }

    /**
     * Tear down.
     *
     * @throws Exception the exception
     */
    @After
    public void tearDown() throws Exception {
    }
}