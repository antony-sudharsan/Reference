
package com.manulife.esb.wsdl.wealth.pfs.workmanagement_1;

import java.net.MalformedURLException;
import java.net.URL;
import javax.xml.namespace.QName;
import javax.xml.ws.Service;
import javax.xml.ws.WebEndpoint;
import javax.xml.ws.WebServiceClient;
import javax.xml.ws.WebServiceException;
import javax.xml.ws.WebServiceFeature;


/**
 * The type Work management 10 service.
 */
@WebServiceClient(name = "WorkManagement_1.0", targetNamespace = "http://www.esb.manulife.com/wsdl/wealth/pfs/WorkManagement_1.0", wsdlLocation = "file:/C:/Tibco2MS/Wave1WSDLs/WorkManagement_TIBCO.WSDL")
public class WorkManagement10_Service
    extends Service
{

    private final static URL WORKMANAGEMENT10_WSDL_LOCATION;
    private final static WebServiceException WORKMANAGEMENT10_EXCEPTION;
    private final static QName WORKMANAGEMENT10_QNAME = new QName("http://www.esb.manulife.com/wsdl/wealth/pfs/WorkManagement_1.0", "WorkManagement_1.0");

    static {
        URL url = null;
        WebServiceException e = null;
        try {
            url = new URL("file:/C:/Tibco2MS/Wave1WSDLs/WorkManagement_TIBCO.WSDL");
        } catch (MalformedURLException ex) {
            e = new WebServiceException(ex);
        }
        WORKMANAGEMENT10_WSDL_LOCATION = url;
        WORKMANAGEMENT10_EXCEPTION = e;
    }

    /**
     * Instantiates a new Work management 10 service.
     */
    public WorkManagement10_Service() {
        super(__getWsdlLocation(), WORKMANAGEMENT10_QNAME);
    }

    /**
     * Instantiates a new Work management 10 service.
     *
     * @param features the features
     */
    public WorkManagement10_Service(WebServiceFeature... features) {
        super(__getWsdlLocation(), WORKMANAGEMENT10_QNAME, features);
    }

    /**
     * Instantiates a new Work management 10 service.
     *
     * @param wsdlLocation the wsdl location
     */
    public WorkManagement10_Service(URL wsdlLocation) {
        super(wsdlLocation, WORKMANAGEMENT10_QNAME);
    }

    /**
     * Instantiates a new Work management 10 service.
     *
     * @param wsdlLocation the wsdl location
     * @param features     the features
     */
    public WorkManagement10_Service(URL wsdlLocation, WebServiceFeature... features) {
        super(wsdlLocation, WORKMANAGEMENT10_QNAME, features);
    }

    /**
     * Instantiates a new Work management 10 service.
     *
     * @param wsdlLocation the wsdl location
     * @param serviceName  the service name
     */
    public WorkManagement10_Service(URL wsdlLocation, QName serviceName) {
        super(wsdlLocation, serviceName);
    }

    /**
     * Instantiates a new Work management 10 service.
     *
     * @param wsdlLocation the wsdl location
     * @param serviceName  the service name
     * @param features     the features
     */
    public WorkManagement10_Service(URL wsdlLocation, QName serviceName, WebServiceFeature... features) {
        super(wsdlLocation, serviceName, features);
    }

    /**
     * Gets work management soap binding.
     *
     * @return the work management soap binding
     */
    @WebEndpoint(name = "WorkManagementSOAPBinding")
    public WorkManagement10 getWorkManagementSOAPBinding() {
        return super.getPort(new QName("http://www.esb.manulife.com/wsdl/wealth/pfs/WorkManagement_1.0", "WorkManagementSOAPBinding"), WorkManagement10.class);
    }

    /**
     * Gets work management soap binding.
     *
     * @param features the features
     *
     * @return the work management soap binding
     */
    @WebEndpoint(name = "WorkManagementSOAPBinding")
    public WorkManagement10 getWorkManagementSOAPBinding(WebServiceFeature... features) {
        return super.getPort(new QName("http://www.esb.manulife.com/wsdl/wealth/pfs/WorkManagement_1.0", "WorkManagementSOAPBinding"), WorkManagement10.class, features);
    }

    private static URL __getWsdlLocation() {
        if (WORKMANAGEMENT10_EXCEPTION!= null) {
            throw WORKMANAGEMENT10_EXCEPTION;
        }
        return WORKMANAGEMENT10_WSDL_LOCATION;
    }

}
