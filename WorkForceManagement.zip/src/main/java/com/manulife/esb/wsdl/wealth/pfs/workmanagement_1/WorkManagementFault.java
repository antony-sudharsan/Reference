
package com.manulife.esb.wsdl.wealth.pfs.workmanagement_1;

import javax.xml.ws.WebFault;
import com.manulife.esb.xsd.common.jh.commonmessage.FaultType;


/**
 * The type Work management fault.
 */
@WebFault(name = "Fault", targetNamespace = "http://www.esb.manulife.com/xsd/common/jh/CommonMessage")
public class WorkManagementFault
    extends Exception
{

    private FaultType faultInfo;

    /**
     * Instantiates a new Work management fault.
     *
     * @param message   the message
     * @param faultInfo the fault info
     */
    public WorkManagementFault(String message, FaultType faultInfo) {
        super(message);
        this.faultInfo = faultInfo;
    }

    /**
     * Instantiates a new Work management fault.
     *
     * @param message   the message
     * @param faultInfo the fault info
     * @param cause     the cause
     */
    public WorkManagementFault(String message, FaultType faultInfo, Throwable cause) {
        super(message, cause);
        this.faultInfo = faultInfo;
    }

    /**
     * Gets fault info.
     *
     * @return the fault info
     */
    public FaultType getFaultInfo() {
        return faultInfo;
    }

}
