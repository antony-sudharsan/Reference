
package com.manulife.esb.wsdl.wealth.pfs.workmanagement_1;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;
import javax.xml.bind.annotation.XmlSeeAlso;
import com.manulife.esb.xsd.jh.workmanagement.CreateObjects;
import com.manulife.esb.xsd.jh.workmanagement.CreateObjectsResponse;
import com.manulife.esb.xsd.jh.workmanagement.UpdateObjects;
import com.manulife.esb.xsd.jh.workmanagement.UpdateObjectsResponse;


/**
 * The interface Work management 10.
 */
@WebService(name = "WorkManagement_1.0", targetNamespace = "http://www.esb.manulife.com/wsdl/wealth/pfs/WorkManagement_1.0")
@SOAPBinding(parameterStyle = SOAPBinding.ParameterStyle.BARE)
@XmlSeeAlso({
    com.manulife.esb.xsd.jh.workmanagement.ObjectFactory.class,
    com.manulife.esb.xsd.common.jh.commonmessage.ObjectFactory.class,
    com.manulife.esb.xsd.common.jh.header.ObjectFactory.class
})
public interface WorkManagement10 {


    /**
     * Create objects create objects response.
     *
     * @param createObjectsIn the create objects in
     *
     * @return the create objects response
     *
     * @throws WorkManagementFault the work management fault
     */
    @WebMethod(operationName = "CreateObjects", action = "CreateObjects")
    @WebResult(name = "createObjectsResponse", targetNamespace = "http://www.esb.manulife.com/xsd/jh/WorkManagement", partName = "createObjectsOut")
    public CreateObjectsResponse createObjects(
            @WebParam(name = "createObjects", targetNamespace = "http://www.esb.manulife.com/xsd/jh/WorkManagement", partName = "createObjectsIn")
                    CreateObjects createObjectsIn)
        throws WorkManagementFault
    ;

    /**
     * Update objects update objects response.
     *
     * @param updateObjectsIn the update objects in
     *
     * @return the update objects response
     *
     * @throws WorkManagementFault the work management fault
     */
    @WebMethod(operationName = "UpdateObjects", action = "UpdateObjects")
    @WebResult(name = "updateObjectsResponse", targetNamespace = "http://www.esb.manulife.com/xsd/jh/WorkManagement", partName = "updateObjectsOut")
    public UpdateObjectsResponse updateObjects(
            @WebParam(name = "updateObjects", targetNamespace = "http://www.esb.manulife.com/xsd/jh/WorkManagement", partName = "updateObjectsIn")
                    UpdateObjects updateObjectsIn)
        throws WorkManagementFault
    ;

}
