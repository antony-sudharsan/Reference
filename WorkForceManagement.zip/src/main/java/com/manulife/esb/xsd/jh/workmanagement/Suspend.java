
package com.manulife.esb.xsd.jh.workmanagement;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlType;


/**
 * The type Suspend.
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "suspend")
public class Suspend {

    /**
     * The Activation date.
     */
    @XmlAttribute(name = "activationDate")
    protected String activationDate;
    /**
     * The Activation routing status.
     */
    @XmlAttribute(name = "activationRoutingStatus")
    protected String activationRoutingStatus;
    /**
     * The Duration.
     */
    @XmlAttribute(name = "duration")
    protected String duration;
    /**
     * The Reason code.
     */
    @XmlAttribute(name = "reasonCode")
    protected String reasonCode;

    /**
     * Gets activation date.
     *
     * @return the activation date
     */
    public String getActivationDate() {
        return activationDate;
    }

    /**
     * Sets activation date.
     *
     * @param value the value
     */
    public void setActivationDate(String value) {
        this.activationDate = value;
    }

    /**
     * Gets activation routing status.
     *
     * @return the activation routing status
     */
    public String getActivationRoutingStatus() {
        return activationRoutingStatus;
    }

    /**
     * Sets activation routing status.
     *
     * @param value the value
     */
    public void setActivationRoutingStatus(String value) {
        this.activationRoutingStatus = value;
    }

    /**
     * Gets duration.
     *
     * @return the duration
     */
    public String getDuration() {
        return duration;
    }

    /**
     * Sets duration.
     *
     * @param value the value
     */
    public void setDuration(String value) {
        this.duration = value;
    }

    /**
     * Gets reason code.
     *
     * @return the reason code
     */
    public String getReasonCode() {
        return reasonCode;
    }

    /**
     * Sets reason code.
     *
     * @param value the value
     */
    public void setReasonCode(String value) {
        this.reasonCode = value;
    }

}
