
package com.manulife.esb.xsd.jh.workmanagement;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * The type Create objects.
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "createObjects", propOrder = {
    "createObjectRequest"
})
@XmlRootElement(name = "createObjects")
public class CreateObjects {

    /**
     * The Create object request.
     */
    protected CreateObjectRequest createObjectRequest;

    /**
     * Gets create object request.
     *
     * @return the create object request
     */
    public CreateObjectRequest getCreateObjectRequest() {
        return createObjectRequest;
    }

    /**
     * Sets create object request.
     *
     * @param value the value
     */
    public void setCreateObjectRequest(CreateObjectRequest value) {
        this.createObjectRequest = value;
    }

}
