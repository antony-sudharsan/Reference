
package com.manulife.esb.xsd.jh.workmanagement;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * The type Routing.
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "routing", propOrder = {
    "value"
})
public class Routing {

    /**
     * The Value.
     */
    @XmlElement(required = true)
    protected String value;
    /**
     * The Business area.
     */
    @XmlAttribute(name = "businessArea")
    protected String businessArea;
    /**
     * The Route.
     */
    @XmlAttribute(name = "route", required = true)
    protected String route;
    /**
     * The Status.
     */
    @XmlAttribute(name = "status")
    protected String status;
    /**
     * The Type.
     */
    @XmlAttribute(name = "type")
    protected String type;

    /**
     * Gets value.
     *
     * @return the value
     */
    public String getValue() {
        return value;
    }

    /**
     * Sets value.
     *
     * @param value the value
     */
    public void setValue(String value) {
        this.value = value;
    }

    /**
     * Gets business area.
     *
     * @return the business area
     */
    public String getBusinessArea() {
        return businessArea;
    }

    /**
     * Sets business area.
     *
     * @param value the value
     */
    public void setBusinessArea(String value) {
        this.businessArea = value;
    }

    /**
     * Gets route.
     *
     * @return the route
     */
    public String getRoute() {
        return route;
    }

    /**
     * Sets route.
     *
     * @param value the value
     */
    public void setRoute(String value) {
        this.route = value;
    }

    /**
     * Gets status.
     *
     * @return the status
     */
    public String getStatus() {
        return status;
    }

    /**
     * Sets status.
     *
     * @param value the value
     */
    public void setStatus(String value) {
        this.status = value;
    }

    /**
     * Gets type.
     *
     * @return the type
     */
    public String getType() {
        return type;
    }

    /**
     * Sets type.
     *
     * @param value the value
     */
    public void setType(String value) {
        this.type = value;
    }

}
