
package com.manulife.esb.xsd.jh.workmanagement;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * The type Relationships.
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "relateObjects"
})
@XmlRootElement(name = "relationships")
public class Relationships {

    /**
     * The Relate objects.
     */
    protected List<RelateObjects> relateObjects;

    /**
     * Gets relate objects.
     *
     * @return the relate objects
     */
    public List<RelateObjects> getRelateObjects() {
        if (relateObjects == null) {
            relateObjects = new ArrayList<RelateObjects>();
        }
        return this.relateObjects;
    }

}
