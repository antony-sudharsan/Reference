
package com.manulife.esb.xsd.jh.workmanagement;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * The type Work steps.
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "workSteps", propOrder = {
    "workStep"
})
public class WorkSteps {

    /**
     * The Work step.
     */
    @XmlElement(required = true)
    protected String workStep;
    /**
     * The Business area.
     */
    @XmlAttribute(name = "businessArea")
    protected String businessArea;
    /**
     * The Next.
     */
    @XmlAttribute(name = "next")
    protected String next;
    /**
     * The Status.
     */
    @XmlAttribute(name = "status")
    protected String status;
    /**
     * The Work type.
     */
    @XmlAttribute(name = "workType")
    protected String workType;

    /**
     * Gets work step.
     *
     * @return the work step
     */
    public String getWorkStep() {
        return workStep;
    }

    /**
     * Sets work step.
     *
     * @param value the value
     */
    public void setWorkStep(String value) {
        this.workStep = value;
    }

    /**
     * Gets business area.
     *
     * @return the business area
     */
    public String getBusinessArea() {
        return businessArea;
    }

    /**
     * Sets business area.
     *
     * @param value the value
     */
    public void setBusinessArea(String value) {
        this.businessArea = value;
    }

    /**
     * Gets next.
     *
     * @return the next
     */
    public String getNext() {
        return next;
    }

    /**
     * Sets next.
     *
     * @param value the value
     */
    public void setNext(String value) {
        this.next = value;
    }

    /**
     * Gets status.
     *
     * @return the status
     */
    public String getStatus() {
        return status;
    }

    /**
     * Sets status.
     *
     * @param value the value
     */
    public void setStatus(String value) {
        this.status = value;
    }

    /**
     * Gets work type.
     *
     * @return the work type
     */
    public String getWorkType() {
        return workType;
    }

    /**
     * Sets work type.
     *
     * @param value the value
     */
    public void setWorkType(String value) {
        this.workType = value;
    }

}
