
package com.manulife.esb.xsd.jh.workmanagement;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElements;
import javax.xml.bind.annotation.XmlType;


/**
 * The type Update object request.
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "updateObjectRequest", propOrder = {
    "responseDetails",
    "updateFolderInstanceOrUpdateSourceInstanceOrUpdateWorkInstance"
})
public class UpdateObjectRequest {

    /**
     * The Response details.
     */
    protected ResponseDetails responseDetails;
    /**
     * The Update folder instance or update source instance or update work instance.
     */
    @XmlElements({
        @XmlElement(name = "updateFolderInstance", type = UpdateFolderInstance.class),
        @XmlElement(name = "updateSourceInstance", type = UpdateSourceInstance.class),
        @XmlElement(name = "updateWorkInstance", type = UpdateWorkInstance.class)
    })
    protected List<Object> updateFolderInstanceOrUpdateSourceInstanceOrUpdateWorkInstance;

    /**
     * Gets response details.
     *
     * @return the response details
     */
    public ResponseDetails getResponseDetails() {
        return responseDetails;
    }

    /**
     * Sets response details.
     *
     * @param value the value
     */
    public void setResponseDetails(ResponseDetails value) {
        this.responseDetails = value;
    }

    /**
     * Gets update folder instance or update source instance or update work instance.
     *
     * @return the update folder instance or update source instance or update work instance
     */
    public List<Object> getUpdateFolderInstanceOrUpdateSourceInstanceOrUpdateWorkInstance() {
        if (updateFolderInstanceOrUpdateSourceInstanceOrUpdateWorkInstance == null) {
            updateFolderInstanceOrUpdateSourceInstanceOrUpdateWorkInstance = new ArrayList<Object>();
        }
        return this.updateFolderInstanceOrUpdateSourceInstanceOrUpdateWorkInstance;
    }

}
