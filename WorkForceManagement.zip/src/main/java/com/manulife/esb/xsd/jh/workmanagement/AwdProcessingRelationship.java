
package com.manulife.esb.xsd.jh.workmanagement;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * The type Awd processing relationship.
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "awdProcessingRelationship")
public abstract class AwdProcessingRelationship {


}
