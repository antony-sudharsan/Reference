
package com.manulife.esb.xsd.jh.workmanagement;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * The type Field values.
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "fieldValue"
})
@XmlRootElement(name = "fieldValues")
public class FieldValues {

    /**
     * Sets field value.
     *
     * @param fieldValue the field value
     */
    public void setFieldValue(List<FieldValue> fieldValue) {
        this.fieldValue = fieldValue;
    }

    /**
     * The Field value.
     */
    protected List<FieldValue> fieldValue;

    /**
     * Gets field value.
     *
     * @return the field value
     */
    public List<FieldValue> getFieldValue() {
        if (fieldValue == null) {
            fieldValue = new ArrayList<FieldValue>();
        }
        return this.fieldValue;
    }

}
