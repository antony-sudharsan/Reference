
package com.manulife.esb.xsd.jh.workmanagement;

import java.math.BigInteger;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * The type Update source instance.
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "updateSourceInstance", propOrder = {
    "updateAWDInstance",
    "receiveTime",
    "format",
    "archiveBox",
    "archiveStartPage",
    "referenceId",
    "securityLevel",
    "mailType",
    "accessMethod",
    "pageCount",
    "annotationBlob"
})
public class UpdateSourceInstance {

    /**
     * The Update awd instance.
     */
    @XmlElement(required = true)
    protected UpdateAWDInstance updateAWDInstance;
    /**
     * The Receive time.
     */
    protected String receiveTime;
    /**
     * The Format.
     */
    protected String format;
    /**
     * The Archive box.
     */
    protected String archiveBox;
    /**
     * The Archive start page.
     */
    protected String archiveStartPage;
    /**
     * The Reference id.
     */
    protected String referenceId;
    /**
     * The Security level.
     */
    protected String securityLevel;
    /**
     * The Mail type.
     */
    protected String mailType;
    /**
     * The Access method.
     */
    protected String accessMethod;
    /**
     * The Page count.
     */
    @XmlSchemaType(name = "nonNegativeInteger")
    protected BigInteger pageCount;
    /**
     * The Annotation blob.
     */
    protected String annotationBlob;

    /**
     * Gets update awd instance.
     *
     * @return the update awd instance
     */
    public UpdateAWDInstance getUpdateAWDInstance() {
        return updateAWDInstance;
    }

    /**
     * Sets update awd instance.
     *
     * @param value the value
     */
    public void setUpdateAWDInstance(UpdateAWDInstance value) {
        this.updateAWDInstance = value;
    }

    /**
     * Gets receive time.
     *
     * @return the receive time
     */
    public String getReceiveTime() {
        return receiveTime;
    }

    /**
     * Sets receive time.
     *
     * @param value the value
     */
    public void setReceiveTime(String value) {
        this.receiveTime = value;
    }

    /**
     * Gets format.
     *
     * @return the format
     */
    public String getFormat() {
        return format;
    }

    /**
     * Sets format.
     *
     * @param value the value
     */
    public void setFormat(String value) {
        this.format = value;
    }

    /**
     * Gets archive box.
     *
     * @return the archive box
     */
    public String getArchiveBox() {
        return archiveBox;
    }

    /**
     * Sets archive box.
     *
     * @param value the value
     */
    public void setArchiveBox(String value) {
        this.archiveBox = value;
    }

    /**
     * Gets archive start page.
     *
     * @return the archive start page
     */
    public String getArchiveStartPage() {
        return archiveStartPage;
    }

    /**
     * Sets archive start page.
     *
     * @param value the value
     */
    public void setArchiveStartPage(String value) {
        this.archiveStartPage = value;
    }

    /**
     * Gets reference id.
     *
     * @return the reference id
     */
    public String getReferenceId() {
        return referenceId;
    }

    /**
     * Sets reference id.
     *
     * @param value the value
     */
    public void setReferenceId(String value) {
        this.referenceId = value;
    }

    /**
     * Gets security level.
     *
     * @return the security level
     */
    public String getSecurityLevel() {
        return securityLevel;
    }

    /**
     * Sets security level.
     *
     * @param value the value
     */
    public void setSecurityLevel(String value) {
        this.securityLevel = value;
    }

    /**
     * Gets mail type.
     *
     * @return the mail type
     */
    public String getMailType() {
        return mailType;
    }

    /**
     * Sets mail type.
     *
     * @param value the value
     */
    public void setMailType(String value) {
        this.mailType = value;
    }

    /**
     * Gets access method.
     *
     * @return the access method
     */
    public String getAccessMethod() {
        return accessMethod;
    }

    /**
     * Sets access method.
     *
     * @param value the value
     */
    public void setAccessMethod(String value) {
        this.accessMethod = value;
    }

    /**
     * Gets page count.
     *
     * @return the page count
     */
    public BigInteger getPageCount() {
        return pageCount;
    }

    /**
     * Sets page count.
     *
     * @param value the value
     */
    public void setPageCount(BigInteger value) {
        this.pageCount = value;
    }

    /**
     * Gets annotation blob.
     *
     * @return the annotation blob
     */
    public String getAnnotationBlob() {
        return annotationBlob;
    }

    /**
     * Sets annotation blob.
     *
     * @param value the value
     */
    public void setAnnotationBlob(String value) {
        this.annotationBlob = value;
    }

}
