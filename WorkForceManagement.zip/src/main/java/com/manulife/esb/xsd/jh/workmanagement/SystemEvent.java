
package com.manulife.esb.xsd.jh.workmanagement;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * The type System event.
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "systemEvent", propOrder = {
    "awdEvent",
    "priority",
    "userExperienceLevel",
    "samplingMethod",
    "qualitySampled"
})
public class SystemEvent {

    /**
     * The Awd event.
     */
    @XmlElement(required = true)
    protected AwdEvent awdEvent;
    /**
     * The Priority.
     */
    protected String priority;
    /**
     * The User experience level.
     */
    protected String userExperienceLevel;
    /**
     * The Sampling method.
     */
    protected String samplingMethod;
    /**
     * The Quality sampled.
     */
    protected String qualitySampled;

    /**
     * Gets awd event.
     *
     * @return the awd event
     */
    public AwdEvent getAwdEvent() {
        return awdEvent;
    }

    /**
     * Sets awd event.
     *
     * @param value the value
     */
    public void setAwdEvent(AwdEvent value) {
        this.awdEvent = value;
    }

    /**
     * Gets priority.
     *
     * @return the priority
     */
    public String getPriority() {
        return priority;
    }

    /**
     * Sets priority.
     *
     * @param value the value
     */
    public void setPriority(String value) {
        this.priority = value;
    }

    /**
     * Gets user experience level.
     *
     * @return the user experience level
     */
    public String getUserExperienceLevel() {
        return userExperienceLevel;
    }

    /**
     * Sets user experience level.
     *
     * @param value the value
     */
    public void setUserExperienceLevel(String value) {
        this.userExperienceLevel = value;
    }

    /**
     * Gets sampling method.
     *
     * @return the sampling method
     */
    public String getSamplingMethod() {
        return samplingMethod;
    }

    /**
     * Sets sampling method.
     *
     * @param value the value
     */
    public void setSamplingMethod(String value) {
        this.samplingMethod = value;
    }

    /**
     * Gets quality sampled.
     *
     * @return the quality sampled
     */
    public String getQualitySampled() {
        return qualitySampled;
    }

    /**
     * Sets quality sampled.
     *
     * @param value the value
     */
    public void setQualitySampled(String value) {
        this.qualitySampled = value;
    }

}
