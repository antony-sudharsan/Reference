
package com.manulife.esb.xsd.jh.workmanagement;

import java.math.BigInteger;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * The type Create source instance.
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "createSourceInstance", propOrder = {
    "createAWDInstance",
    "receiveTime",
    "format",
    "archiveBox",
    "archiveStartPage",
    "contentId",
    "securityLevel",
    "mailType",
    "accessMethod",
    "pageCount",
    "annotationBlob",
    "createStation",
    "attachmentList"
})
public class CreateSourceInstance {

    /**
     * The Create awd instance.
     */
    @XmlElement(required = true)
    protected CreateAWDInstance createAWDInstance;
    /**
     * The Receive time.
     */
    protected String receiveTime;
    /**
     * The Format.
     */
    protected String format;
    /**
     * The Archive box.
     */
    protected String archiveBox;
    /**
     * The Archive start page.
     */
    protected String archiveStartPage;
    /**
     * The Content id.
     */
    protected String contentId;
    /**
     * The Security level.
     */
    protected String securityLevel;
    /**
     * The Mail type.
     */
    protected String mailType;
    /**
     * The Access method.
     */
    protected String accessMethod;
    /**
     * The Page count.
     */
    @XmlSchemaType(name = "nonNegativeInteger")
    protected BigInteger pageCount;
    /**
     * The Annotation blob.
     */
    protected String annotationBlob;
    /**
     * The Create station.
     */
    protected String createStation;
    /**
     * The Attachment list.
     */
    protected AttachmentList attachmentList;

    /**
     * Gets create awd instance.
     *
     * @return the create awd instance
     */
    public CreateAWDInstance getCreateAWDInstance() {
        return createAWDInstance;
    }

    /**
     * Sets create awd instance.
     *
     * @param value the value
     */
    public void setCreateAWDInstance(CreateAWDInstance value) {
        this.createAWDInstance = value;
    }

    /**
     * Gets receive time.
     *
     * @return the receive time
     */
    public String getReceiveTime() {
        return receiveTime;
    }

    /**
     * Sets receive time.
     *
     * @param value the value
     */
    public void setReceiveTime(String value) {
        this.receiveTime = value;
    }

    /**
     * Gets format.
     *
     * @return the format
     */
    public String getFormat() {
        return format;
    }

    /**
     * Sets format.
     *
     * @param value the value
     */
    public void setFormat(String value) {
        this.format = value;
    }

    /**
     * Gets archive box.
     *
     * @return the archive box
     */
    public String getArchiveBox() {
        return archiveBox;
    }

    /**
     * Sets archive box.
     *
     * @param value the value
     */
    public void setArchiveBox(String value) {
        this.archiveBox = value;
    }

    /**
     * Gets archive start page.
     *
     * @return the archive start page
     */
    public String getArchiveStartPage() {
        return archiveStartPage;
    }

    /**
     * Sets archive start page.
     *
     * @param value the value
     */
    public void setArchiveStartPage(String value) {
        this.archiveStartPage = value;
    }

    /**
     * Gets content id.
     *
     * @return the content id
     */
    public String getContentId() {
        return contentId;
    }

    /**
     * Sets content id.
     *
     * @param value the value
     */
    public void setContentId(String value) {
        this.contentId = value;
    }

    /**
     * Gets security level.
     *
     * @return the security level
     */
    public String getSecurityLevel() {
        return securityLevel;
    }

    /**
     * Sets security level.
     *
     * @param value the value
     */
    public void setSecurityLevel(String value) {
        this.securityLevel = value;
    }

    /**
     * Gets mail type.
     *
     * @return the mail type
     */
    public String getMailType() {
        return mailType;
    }

    /**
     * Sets mail type.
     *
     * @param value the value
     */
    public void setMailType(String value) {
        this.mailType = value;
    }

    /**
     * Gets access method.
     *
     * @return the access method
     */
    public String getAccessMethod() {
        return accessMethod;
    }

    /**
     * Sets access method.
     *
     * @param value the value
     */
    public void setAccessMethod(String value) {
        this.accessMethod = value;
    }

    /**
     * Gets page count.
     *
     * @return the page count
     */
    public BigInteger getPageCount() {
        return pageCount;
    }

    /**
     * Sets page count.
     *
     * @param value the value
     */
    public void setPageCount(BigInteger value) {
        this.pageCount = value;
    }

    /**
     * Gets annotation blob.
     *
     * @return the annotation blob
     */
    public String getAnnotationBlob() {
        return annotationBlob;
    }

    /**
     * Sets annotation blob.
     *
     * @param value the value
     */
    public void setAnnotationBlob(String value) {
        this.annotationBlob = value;
    }

    /**
     * Gets create station.
     *
     * @return the create station
     */
    public String getCreateStation() {
        return createStation;
    }

    /**
     * Sets create station.
     *
     * @param value the value
     */
    public void setCreateStation(String value) {
        this.createStation = value;
    }

    /**
     * Gets attachment list.
     *
     * @return the attachment list
     */
    public AttachmentList getAttachmentList() {
        return attachmentList;
    }

    /**
     * Sets attachment list.
     *
     * @param value the value
     */
    public void setAttachmentList(AttachmentList value) {
        this.attachmentList = value;
    }

}
