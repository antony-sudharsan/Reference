
package com.manulife.esb.xsd.jh.workmanagement;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * The type Work instance.
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "workInstance", propOrder = {
    "awdInstance",
    "status",
    "workFlow",
    "queue",
    "priority",
    "priorityIncrease",
    "suspended"
})
public class WorkInstance {

    /**
     * The Awd instance.
     */
    @XmlElement(required = true)
    protected AwdInstance awdInstance;
    /**
     * The Status.
     */
    protected String status;
    /**
     * The Work flow.
     */
    protected WorkFlow workFlow;
    /**
     * The Queue.
     */
    protected String queue;
    /**
     * The Priority.
     */
    protected String priority;
    /**
     * The Priority increase.
     */
    protected String priorityIncrease;
    /**
     * The Suspended.
     */
    protected Suspended suspended;
    /**
     * The Assigned to.
     */
    @XmlAttribute(name = "assignedTo")
    protected String assignedTo;
    /**
     * The Instance type.
     */
    @XmlAttribute(name = "instanceType", required = true)
    protected String instanceType;

    /**
     * Gets awd instance.
     *
     * @return the awd instance
     */
    public AwdInstance getAwdInstance() {
        return awdInstance;
    }

    /**
     * Sets awd instance.
     *
     * @param value the value
     */
    public void setAwdInstance(AwdInstance value) {
        this.awdInstance = value;
    }

    /**
     * Gets status.
     *
     * @return the status
     */
    public String getStatus() {
        return status;
    }

    /**
     * Sets status.
     *
     * @param value the value
     */
    public void setStatus(String value) {
        this.status = value;
    }

    /**
     * Gets work flow.
     *
     * @return the work flow
     */
    public WorkFlow getWorkFlow() {
        return workFlow;
    }

    /**
     * Sets work flow.
     *
     * @param value the value
     */
    public void setWorkFlow(WorkFlow value) {
        this.workFlow = value;
    }

    /**
     * Gets queue.
     *
     * @return the queue
     */
    public String getQueue() {
        return queue;
    }

    /**
     * Sets queue.
     *
     * @param value the value
     */
    public void setQueue(String value) {
        this.queue = value;
    }

    /**
     * Gets priority.
     *
     * @return the priority
     */
    public String getPriority() {
        return priority;
    }

    /**
     * Sets priority.
     *
     * @param value the value
     */
    public void setPriority(String value) {
        this.priority = value;
    }

    /**
     * Gets priority increase.
     *
     * @return the priority increase
     */
    public String getPriorityIncrease() {
        return priorityIncrease;
    }

    /**
     * Sets priority increase.
     *
     * @param value the value
     */
    public void setPriorityIncrease(String value) {
        this.priorityIncrease = value;
    }

    /**
     * Gets suspended.
     *
     * @return the suspended
     */
    public Suspended getSuspended() {
        return suspended;
    }

    /**
     * Sets suspended.
     *
     * @param value the value
     */
    public void setSuspended(Suspended value) {
        this.suspended = value;
    }

    /**
     * Gets assigned to.
     *
     * @return the assigned to
     */
    public String getAssignedTo() {
        return assignedTo;
    }

    /**
     * Sets assigned to.
     *
     * @param value the value
     */
    public void setAssignedTo(String value) {
        this.assignedTo = value;
    }

    /**
     * Gets instance type.
     *
     * @return the instance type
     */
    public String getInstanceType() {
        return instanceType;
    }

    /**
     * Sets instance type.
     *
     * @param value the value
     */
    public void setInstanceType(String value) {
        this.instanceType = value;
    }

}
