
package com.manulife.esb.xsd.jh.workmanagement;

import javax.xml.bind.annotation.*;


/**
 * The type Create objects response.
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "createObjectsResponse", propOrder = {
    "objectsResponse"
})
@XmlRootElement(name = "createObjectsResponse")
public class CreateObjectsResponse {

    /**
     * The Objects response.
     */
    @XmlElement(name = "ObjectsResponse")
    protected GetObjectsResponse objectsResponse;

    /**
     * Gets objects response.
     *
     * @return the objects response
     */
    public GetObjectsResponse getObjectsResponse() {
        return objectsResponse;
    }

    /**
     * Sets objects response.
     *
     * @param value the value
     */
    public void setObjectsResponse(GetObjectsResponse value) {
        this.objectsResponse = value;
    }

}
