
package com.manulife.esb.xsd.jh.workmanagement;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * The type Retrieve objects response.
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "retrieveObjectsResponse", propOrder = {
    "retrieveObjectsResponse"
})
public class RetrieveObjectsResponse {

    /**
     * The Retrieve objects response.
     */
    protected GetObjectsResponse retrieveObjectsResponse;

    /**
     * Gets retrieve objects response.
     *
     * @return the retrieve objects response
     */
    public GetObjectsResponse getRetrieveObjectsResponse() {
        return retrieveObjectsResponse;
    }

    /**
     * Sets retrieve objects response.
     *
     * @param value the value
     */
    public void setRetrieveObjectsResponse(GetObjectsResponse value) {
        this.retrieveObjectsResponse = value;
    }

}
