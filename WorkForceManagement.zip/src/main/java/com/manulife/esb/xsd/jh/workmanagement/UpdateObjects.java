
package com.manulife.esb.xsd.jh.workmanagement;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * The type Update objects.
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "updateObjects", propOrder = {
    "updateObjectRequest"
})
@XmlRootElement(name = "updateObjects")
public class UpdateObjects {

    /**
     * The Update object request.
     */
    protected UpdateObjectRequest updateObjectRequest;

    /**
     * Gets update object request.
     *
     * @return the update object request
     */
    public UpdateObjectRequest getUpdateObjectRequest() {
        return updateObjectRequest;
    }

    /**
     * Sets update object request.
     *
     * @param value the value
     */
    public void setUpdateObjectRequest(UpdateObjectRequest value) {
        this.updateObjectRequest = value;
    }

}
