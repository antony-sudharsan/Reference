
package com.manulife.esb.xsd.jh.workmanagement;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * The type Comment.
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "comment", propOrder = {
    "text",
    "userId",
    "userName"
})
public class Comment {

    /**
     * The Text.
     */
    protected String text;
    /**
     * The User id.
     */
    @XmlElement(nillable = true)
    protected String userId;
    /**
     * The User name.
     */
    protected String userName;
    /**
     * The Time.
     */
    @XmlAttribute(name = "time")
    protected String time;
    /**
     * The Type.
     */
    @XmlAttribute(name = "type")
    protected String type;

    /**
     * Gets text.
     *
     * @return the text
     */
    public String getText() {
        return text;
    }

    /**
     * Sets text.
     *
     * @param value the value
     */
    public void setText(String value) {
        this.text = value;
    }

    /**
     * Gets user id.
     *
     * @return the user id
     */
    public String getUserId() {
        return userId;
    }

    /**
     * Sets user id.
     *
     * @param value the value
     */
    public void setUserId(String value) {
        this.userId = value;
    }

    /**
     * Gets user name.
     *
     * @return the user name
     */
    public String getUserName() {
        return userName;
    }

    /**
     * Sets user name.
     *
     * @param value the value
     */
    public void setUserName(String value) {
        this.userName = value;
    }

    /**
     * Gets time.
     *
     * @return the time
     */
    public String getTime() {
        return time;
    }

    /**
     * Sets time.
     *
     * @param value the value
     */
    public void setTime(String value) {
        this.time = value;
    }

    /**
     * Gets type.
     *
     * @return the type
     */
    public String getType() {
        return type;
    }

    /**
     * Sets type.
     *
     * @param value the value
     */
    public void setType(String value) {
        this.type = value;
    }

}
