
package com.manulife.esb.xsd.common.jh.header;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * The type Status.
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Status", propOrder = {
    "statusCode",
    "statusDescription"
})
public class Status {

    /**
     * The Status code.
     */
    @XmlElement(name = "StatusCode")
    protected long statusCode;
    /**
     * The Status description.
     */
    @XmlElement(name = "StatusDescription", required = true)
    protected String statusDescription;

    /**
     * Gets status code.
     *
     * @return the status code
     */
    public long getStatusCode() {
        return statusCode;
    }

    /**
     * Sets status code.
     *
     * @param value the value
     */
    public void setStatusCode(long value) {
        this.statusCode = value;
    }

    /**
     * Gets status description.
     *
     * @return the status description
     */
    public String getStatusDescription() {
        return statusDescription;
    }

    /**
     * Sets status description.
     *
     * @param value the value
     */
    public void setStatusDescription(String value) {
        this.statusDescription = value;
    }

}
