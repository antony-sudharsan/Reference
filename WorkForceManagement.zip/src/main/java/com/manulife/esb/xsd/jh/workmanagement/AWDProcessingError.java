
package com.manulife.esb.xsd.jh.workmanagement;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * The type Awd processing error.
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "AWDProcessingError", propOrder = {
    "errorMessage",
    "message"
})
public class AWDProcessingError {

    /**
     * The Error message.
     */
    protected String errorMessage;
    /**
     * The Message.
     */
    protected String message;

    /**
     * Gets error message.
     *
     * @return the error message
     */
    public String getErrorMessage() {
        return errorMessage;
    }

    /**
     * Sets error message.
     *
     * @param value the value
     */
    public void setErrorMessage(String value) {
        this.errorMessage = value;
    }

    /**
     * Gets message.
     *
     * @return the message
     */
    public String getMessage() {
        return message;
    }

    /**
     * Sets message.
     *
     * @param value the value
     */
    public void setMessage(String value) {
        this.message = value;
    }

}
