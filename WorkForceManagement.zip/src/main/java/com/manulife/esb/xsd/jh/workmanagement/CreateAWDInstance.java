
package com.manulife.esb.xsd.jh.workmanagement;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * The type Create awd instance.
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "createAWDInstance", propOrder = {
    "fieldValues",
    "businessArea",
    "type",
    "addManualComment"
})
public class CreateAWDInstance {

    /**
     * The Field values.
     */
    protected FieldValues fieldValues;
    /**
     * The Business area.
     */
    @XmlElement(required = true)
    protected String businessArea;
    /**
     * The Type.
     */
    @XmlElement(required = true)
    protected String type;
    /**
     * The Add manual comment.
     */
    protected String addManualComment;
    /**
     * The Lock.
     */
    @XmlAttribute(name = "lock")
    protected String lock;
    /**
     * The Relationship id.
     */
    @XmlAttribute(name = "relationshipId")
    protected String relationshipId;

    /**
     * Gets field values.
     *
     * @return the field values
     */
    public FieldValues getFieldValues() {
        return fieldValues;
    }

    /**
     * Sets field values.
     *
     * @param value the value
     */
    public void setFieldValues(FieldValues value) {
        this.fieldValues = value;
    }

    /**
     * Gets business area.
     *
     * @return the business area
     */
    public String getBusinessArea() {
        return businessArea;
    }

    /**
     * Sets business area.
     *
     * @param value the value
     */
    public void setBusinessArea(String value) {
        this.businessArea = value;
    }

    /**
     * Gets type.
     *
     * @return the type
     */
    public String getType() {
        return type;
    }

    /**
     * Sets type.
     *
     * @param value the value
     */
    public void setType(String value) {
        this.type = value;
    }

    /**
     * Gets add manual comment.
     *
     * @return the add manual comment
     */
    public String getAddManualComment() {
        return addManualComment;
    }

    /**
     * Sets add manual comment.
     *
     * @param value the value
     */
    public void setAddManualComment(String value) {
        this.addManualComment = value;
    }

    /**
     * Gets lock.
     *
     * @return the lock
     */
    public String getLock() {
        return lock;
    }

    /**
     * Sets lock.
     *
     * @param value the value
     */
    public void setLock(String value) {
        this.lock = value;
    }

    /**
     * Gets relationship id.
     *
     * @return the relationship id
     */
    public String getRelationshipId() {
        return relationshipId;
    }

    /**
     * Sets relationship id.
     *
     * @param value the value
     */
    public void setRelationshipId(String value) {
        this.relationshipId = value;
    }

}
