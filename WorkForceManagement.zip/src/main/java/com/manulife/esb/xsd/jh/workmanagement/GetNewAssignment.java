
package com.manulife.esb.xsd.jh.workmanagement;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * The type Get new assignment.
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "getNewAssignment", propOrder = {
    "getNewAssignmentRequest"
})
public class GetNewAssignment {

    /**
     * The Get new assignment request.
     */
    protected GetNewAssignmentRequest getNewAssignmentRequest;

    /**
     * Gets get new assignment request.
     *
     * @return the get new assignment request
     */
    public GetNewAssignmentRequest getGetNewAssignmentRequest() {
        return getNewAssignmentRequest;
    }

    /**
     * Sets get new assignment request.
     *
     * @param value the value
     */
    public void setGetNewAssignmentRequest(GetNewAssignmentRequest value) {
        this.getNewAssignmentRequest = value;
    }

}
