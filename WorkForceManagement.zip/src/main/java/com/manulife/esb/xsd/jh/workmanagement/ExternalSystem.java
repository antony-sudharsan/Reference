
package com.manulife.esb.xsd.jh.workmanagement;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * The type External system.
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "externalSystem", propOrder = {
    "externalDLL",
    "externalHost",
    "externalParameter",
    "externalProcedure",
    "order"
})
public class ExternalSystem {

    /**
     * The External dll.
     */
    protected String externalDLL;
    /**
     * The External host.
     */
    protected String externalHost;
    /**
     * The External parameter.
     */
    protected String externalParameter;
    /**
     * The External procedure.
     */
    protected String externalProcedure;
    /**
     * The Order.
     */
    protected int order;

    /**
     * Gets external dll.
     *
     * @return the external dll
     */
    public String getExternalDLL() {
        return externalDLL;
    }

    /**
     * Sets external dll.
     *
     * @param value the value
     */
    public void setExternalDLL(String value) {
        this.externalDLL = value;
    }

    /**
     * Gets external host.
     *
     * @return the external host
     */
    public String getExternalHost() {
        return externalHost;
    }

    /**
     * Sets external host.
     *
     * @param value the value
     */
    public void setExternalHost(String value) {
        this.externalHost = value;
    }

    /**
     * Gets external parameter.
     *
     * @return the external parameter
     */
    public String getExternalParameter() {
        return externalParameter;
    }

    /**
     * Sets external parameter.
     *
     * @param value the value
     */
    public void setExternalParameter(String value) {
        this.externalParameter = value;
    }

    /**
     * Gets external procedure.
     *
     * @return the external procedure
     */
    public String getExternalProcedure() {
        return externalProcedure;
    }

    /**
     * Sets external procedure.
     *
     * @param value the value
     */
    public void setExternalProcedure(String value) {
        this.externalProcedure = value;
    }

    /**
     * Gets order.
     *
     * @return the order
     */
    public int getOrder() {
        return order;
    }

    /**
     * Sets order.
     *
     * @param value the value
     */
    public void setOrder(int value) {
        this.order = value;
    }

}
