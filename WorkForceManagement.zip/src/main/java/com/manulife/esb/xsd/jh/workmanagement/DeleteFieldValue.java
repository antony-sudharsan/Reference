
package com.manulife.esb.xsd.jh.workmanagement;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlType;


/**
 * The type Delete field value.
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "deleteFieldValue")
public class DeleteFieldValue {

    /**
     * The Name.
     */
    @XmlAttribute(name = "name", required = true)
    protected String name;

    /**
     * Gets name.
     *
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * Sets name.
     *
     * @param value the value
     */
    public void setName(String value) {
        this.name = value;
    }

}
