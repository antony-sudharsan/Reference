
package com.manulife.esb.xsd.jh.workmanagement;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlType;


/**
 * The type Response details.
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "responseDetails")
public class ResponseDetails {

    /**
     * The Show all.
     */
    @XmlAttribute(name = "showAll")
    protected String showAll;
    /**
     * The Show comments.
     */
    @XmlAttribute(name = "showComments")
    protected String showComments;
    /**
     * The Show events.
     */
    @XmlAttribute(name = "showEvents")
    protected String showEvents;
    /**
     * The Show instance data.
     */
    @XmlAttribute(name = "showInstanceData")
    protected String showInstanceData;
    /**
     * The Show none.
     */
    @XmlAttribute(name = "showNone")
    protected String showNone;
    /**
     * The Show only control data.
     */
    @XmlAttribute(name = "showOnlyControlData")
    protected String showOnlyControlData;
    /**
     * The Show relationships.
     */
    @XmlAttribute(name = "showRelationships")
    protected String showRelationships;
    /**
     * The Show workflow.
     */
    @XmlAttribute(name = "showWorkflow")
    protected String showWorkflow;

    /**
     * Gets show all.
     *
     * @return the show all
     */
    public String getShowAll() {
        return showAll;
    }

    /**
     * Sets show all.
     *
     * @param value the value
     */
    public void setShowAll(String value) {
        this.showAll = value;
    }

    /**
     * Gets show comments.
     *
     * @return the show comments
     */
    public String getShowComments() {
        return showComments;
    }

    /**
     * Sets show comments.
     *
     * @param value the value
     */
    public void setShowComments(String value) {
        this.showComments = value;
    }

    /**
     * Gets show events.
     *
     * @return the show events
     */
    public String getShowEvents() {
        return showEvents;
    }

    /**
     * Sets show events.
     *
     * @param value the value
     */
    public void setShowEvents(String value) {
        this.showEvents = value;
    }

    /**
     * Gets show instance data.
     *
     * @return the show instance data
     */
    public String getShowInstanceData() {
        return showInstanceData;
    }

    /**
     * Sets show instance data.
     *
     * @param value the value
     */
    public void setShowInstanceData(String value) {
        this.showInstanceData = value;
    }

    /**
     * Gets show none.
     *
     * @return the show none
     */
    public String getShowNone() {
        return showNone;
    }

    /**
     * Sets show none.
     *
     * @param value the value
     */
    public void setShowNone(String value) {
        this.showNone = value;
    }

    /**
     * Gets show only control data.
     *
     * @return the show only control data
     */
    public String getShowOnlyControlData() {
        return showOnlyControlData;
    }

    /**
     * Sets show only control data.
     *
     * @param value the value
     */
    public void setShowOnlyControlData(String value) {
        this.showOnlyControlData = value;
    }

    /**
     * Gets show relationships.
     *
     * @return the show relationships
     */
    public String getShowRelationships() {
        return showRelationships;
    }

    /**
     * Sets show relationships.
     *
     * @param value the value
     */
    public void setShowRelationships(String value) {
        this.showRelationships = value;
    }

    /**
     * Gets show workflow.
     *
     * @return the show workflow
     */
    public String getShowWorkflow() {
        return showWorkflow;
    }

    /**
     * Sets show workflow.
     *
     * @param value the value
     */
    public void setShowWorkflow(String value) {
        this.showWorkflow = value;
    }

}
