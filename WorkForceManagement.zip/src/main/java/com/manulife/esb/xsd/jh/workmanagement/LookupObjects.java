
package com.manulife.esb.xsd.jh.workmanagement;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * The type Lookup objects.
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "lookupObjects", propOrder = {
    "lookupObjectsRequest"
})
public class LookupObjects {

    /**
     * The Lookup objects request.
     */
    protected LookupObjectsRequest lookupObjectsRequest;

    /**
     * Gets lookup objects request.
     *
     * @return the lookup objects request
     */
    public LookupObjectsRequest getLookupObjectsRequest() {
        return lookupObjectsRequest;
    }

    /**
     * Sets lookup objects request.
     *
     * @param value the value
     */
    public void setLookupObjectsRequest(LookupObjectsRequest value) {
        this.lookupObjectsRequest = value;
    }

}
