
package com.manulife.esb.xsd.common.jh.commonmessage;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.manulife.esb.xsd.common.jh.header.JHHeader;


/**
 * The type Request common info.
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "RequestCommonInfo", propOrder = {
    "jhHeader"
})
public class RequestCommonInfo {

    /**
     * The Jh header.
     */
    @XmlElement(name = "JHHeader", namespace = "http://www.esb.manulife.com/xsd/common/jh/header", required = true)
    protected JHHeader jhHeader;

    /**
     * Gets jh header.
     *
     * @return the jh header
     */
    public JHHeader getJHHeader() {
        return jhHeader;
    }

    /**
     * Sets jh header.
     *
     * @param value the value
     */
    public void setJHHeader(JHHeader value) {
        this.jhHeader = value;
    }

}
