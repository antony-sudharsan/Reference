
package com.manulife.esb.xsd.jh.workmanagement;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * The type Update objects response.
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "updateObjectsResponse", propOrder = {
    "updateObjectsResponse"
})
@XmlRootElement(name = "updateObjectsResponse")
public class UpdateObjectsResponse {

    /**
     * The Update objects response.
     */
    protected GetObjectsResponse updateObjectsResponse;

    /**
     * Gets update objects response.
     *
     * @return the update objects response
     */
    public GetObjectsResponse getUpdateObjectsResponse() {
        return updateObjectsResponse;
    }

    /**
     * Sets update objects response.
     *
     * @param value the value
     */
    public void setUpdateObjectsResponse(GetObjectsResponse value) {
        this.updateObjectsResponse = value;
    }

}
