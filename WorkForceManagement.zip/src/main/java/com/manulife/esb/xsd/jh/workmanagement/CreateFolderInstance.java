
package com.manulife.esb.xsd.jh.workmanagement;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * The type Create folder instance.
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "createFolderInstance", propOrder = {
    "createAWDInstance",
    "createStation"
})
public class CreateFolderInstance {

    /**
     * The Create awd instance.
     */
    @XmlElement(required = true)
    protected CreateAWDInstance createAWDInstance;
    /**
     * The Create station.
     */
    protected String createStation;

    /**
     * Gets create awd instance.
     *
     * @return the create awd instance
     */
    public CreateAWDInstance getCreateAWDInstance() {
        return createAWDInstance;
    }

    /**
     * Sets create awd instance.
     *
     * @param value the value
     */
    public void setCreateAWDInstance(CreateAWDInstance value) {
        this.createAWDInstance = value;
    }

    /**
     * Gets create station.
     *
     * @return the create station
     */
    public String getCreateStation() {
        return createStation;
    }

    /**
     * Sets create station.
     *
     * @param value the value
     */
    public void setCreateStation(String value) {
        this.createStation = value;
    }

}
