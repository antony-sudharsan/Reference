
package com.manulife.esb.xsd.jh.workmanagement;

import java.math.BigInteger;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * The type Source instance.
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "sourceInstance", propOrder = {
    "awdInstance",
    "accessMethod",
    "annotationBlob",
    "archiveBox",
    "archiveStartPage",
    "commentsExist",
    "format",
    "mailType",
    "contentId",
    "opticalStatus",
    "pageCount",
    "path",
    "receiveTime",
    "revisable",
    "securityLevel",
    "createUser",
    "createStation"
})
public class SourceInstance {

    /**
     * The Awd instance.
     */
    @XmlElement(required = true)
    protected AwdInstance awdInstance;
    /**
     * The Access method.
     */
    protected String accessMethod;
    /**
     * The Annotation blob.
     */
    protected String annotationBlob;
    /**
     * The Archive box.
     */
    protected String archiveBox;
    /**
     * The Archive start page.
     */
    protected String archiveStartPage;
    /**
     * The Comments exist.
     */
    protected String commentsExist;
    /**
     * The Format.
     */
    protected String format;
    /**
     * The Mail type.
     */
    protected String mailType;
    /**
     * The Content id.
     */
    protected String contentId;
    /**
     * The Optical status.
     */
    protected String opticalStatus;
    /**
     * The Page count.
     */
    @XmlSchemaType(name = "nonNegativeInteger")
    protected BigInteger pageCount;
    /**
     * The Path.
     */
    protected String path;
    /**
     * The Receive time.
     */
    protected String receiveTime;
    /**
     * The Revisable.
     */
    protected String revisable;
    /**
     * The Security level.
     */
    protected String securityLevel;
    /**
     * The Create user.
     */
    protected String createUser;
    /**
     * The Create station.
     */
    protected String createStation;

    /**
     * Gets awd instance.
     *
     * @return the awd instance
     */
    public AwdInstance getAwdInstance() {
        return awdInstance;
    }

    /**
     * Sets awd instance.
     *
     * @param value the value
     */
    public void setAwdInstance(AwdInstance value) {
        this.awdInstance = value;
    }

    /**
     * Gets access method.
     *
     * @return the access method
     */
    public String getAccessMethod() {
        return accessMethod;
    }

    /**
     * Sets access method.
     *
     * @param value the value
     */
    public void setAccessMethod(String value) {
        this.accessMethod = value;
    }

    /**
     * Gets annotation blob.
     *
     * @return the annotation blob
     */
    public String getAnnotationBlob() {
        return annotationBlob;
    }

    /**
     * Sets annotation blob.
     *
     * @param value the value
     */
    public void setAnnotationBlob(String value) {
        this.annotationBlob = value;
    }

    /**
     * Gets archive box.
     *
     * @return the archive box
     */
    public String getArchiveBox() {
        return archiveBox;
    }

    /**
     * Sets archive box.
     *
     * @param value the value
     */
    public void setArchiveBox(String value) {
        this.archiveBox = value;
    }

    /**
     * Gets archive start page.
     *
     * @return the archive start page
     */
    public String getArchiveStartPage() {
        return archiveStartPage;
    }

    /**
     * Sets archive start page.
     *
     * @param value the value
     */
    public void setArchiveStartPage(String value) {
        this.archiveStartPage = value;
    }

    /**
     * Gets comments exist.
     *
     * @return the comments exist
     */
    public String getCommentsExist() {
        return commentsExist;
    }

    /**
     * Sets comments exist.
     *
     * @param value the value
     */
    public void setCommentsExist(String value) {
        this.commentsExist = value;
    }

    /**
     * Gets format.
     *
     * @return the format
     */
    public String getFormat() {
        return format;
    }

    /**
     * Sets format.
     *
     * @param value the value
     */
    public void setFormat(String value) {
        this.format = value;
    }

    /**
     * Gets mail type.
     *
     * @return the mail type
     */
    public String getMailType() {
        return mailType;
    }

    /**
     * Sets mail type.
     *
     * @param value the value
     */
    public void setMailType(String value) {
        this.mailType = value;
    }

    /**
     * Gets content id.
     *
     * @return the content id
     */
    public String getContentId() {
        return contentId;
    }

    /**
     * Sets content id.
     *
     * @param value the value
     */
    public void setContentId(String value) {
        this.contentId = value;
    }

    /**
     * Gets optical status.
     *
     * @return the optical status
     */
    public String getOpticalStatus() {
        return opticalStatus;
    }

    /**
     * Sets optical status.
     *
     * @param value the value
     */
    public void setOpticalStatus(String value) {
        this.opticalStatus = value;
    }

    /**
     * Gets page count.
     *
     * @return the page count
     */
    public BigInteger getPageCount() {
        return pageCount;
    }

    /**
     * Sets page count.
     *
     * @param value the value
     */
    public void setPageCount(BigInteger value) {
        this.pageCount = value;
    }

    /**
     * Gets path.
     *
     * @return the path
     */
    public String getPath() {
        return path;
    }

    /**
     * Sets path.
     *
     * @param value the value
     */
    public void setPath(String value) {
        this.path = value;
    }

    /**
     * Gets receive time.
     *
     * @return the receive time
     */
    public String getReceiveTime() {
        return receiveTime;
    }

    /**
     * Sets receive time.
     *
     * @param value the value
     */
    public void setReceiveTime(String value) {
        this.receiveTime = value;
    }

    /**
     * Gets revisable.
     *
     * @return the revisable
     */
    public String getRevisable() {
        return revisable;
    }

    /**
     * Sets revisable.
     *
     * @param value the value
     */
    public void setRevisable(String value) {
        this.revisable = value;
    }

    /**
     * Gets security level.
     *
     * @return the security level
     */
    public String getSecurityLevel() {
        return securityLevel;
    }

    /**
     * Sets security level.
     *
     * @param value the value
     */
    public void setSecurityLevel(String value) {
        this.securityLevel = value;
    }

    /**
     * Gets create user.
     *
     * @return the create user
     */
    public String getCreateUser() {
        return createUser;
    }

    /**
     * Sets create user.
     *
     * @param value the value
     */
    public void setCreateUser(String value) {
        this.createUser = value;
    }

    /**
     * Gets create station.
     *
     * @return the create station
     */
    public String getCreateStation() {
        return createStation;
    }

    /**
     * Sets create station.
     *
     * @param value the value
     */
    public void setCreateStation(String value) {
        this.createStation = value;
    }

}
