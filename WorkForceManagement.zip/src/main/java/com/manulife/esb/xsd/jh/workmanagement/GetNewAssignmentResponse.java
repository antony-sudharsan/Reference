
package com.manulife.esb.xsd.jh.workmanagement;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * The type Get new assignment response.
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "getNewAssignmentResponse", propOrder = {
    "newAssignmentResponse"
})
public class GetNewAssignmentResponse {

    /**
     * The New assignment response.
     */
    protected GetObjectsResponse newAssignmentResponse;

    /**
     * Gets new assignment response.
     *
     * @return the new assignment response
     */
    public GetObjectsResponse getNewAssignmentResponse() {
        return newAssignmentResponse;
    }

    /**
     * Sets new assignment response.
     *
     * @param value the value
     */
    public void setNewAssignmentResponse(GetObjectsResponse value) {
        this.newAssignmentResponse = value;
    }

}
