
package com.manulife.esb.xsd.jh.workmanagement;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * The type Authorization info.
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "authorizationInfo", propOrder = {
    "czValue",
    "userId",
    "userStation"
})
public class AuthorizationInfo {

    /**
     * The Cz value.
     */
    protected String czValue;
    /**
     * The User id.
     */
    @XmlElement(required = true, nillable = true)
    protected String userId;
    /**
     * The User station.
     */
    protected String userStation;

    /**
     * Gets cz value.
     *
     * @return the cz value
     */
    public String getCzValue() {
        return czValue;
    }

    /**
     * Sets cz value.
     *
     * @param value the value
     */
    public void setCzValue(String value) {
        this.czValue = value;
    }

    /**
     * Gets user id.
     *
     * @return the user id
     */
    public String getUserId() {
        return userId;
    }

    /**
     * Sets user id.
     *
     * @param value the value
     */
    public void setUserId(String value) {
        this.userId = value;
    }

    /**
     * Gets user station.
     *
     * @return the user station
     */
    public String getUserStation() {
        return userStation;
    }

    /**
     * Sets user station.
     *
     * @param value the value
     */
    public void setUserStation(String value) {
        this.userStation = value;
    }

    /**
     * Instantiates a new Authorization info.
     *
     * @param czValue the cz value
     * @param userId  the user id
     */
    public AuthorizationInfo(String czValue, String userId) {
        this.czValue = czValue;
        this.userId = userId;
    }

    /**
     * Instantiates a new Authorization info.
     */
    public AuthorizationInfo() {
    }
}
