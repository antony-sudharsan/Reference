
package com.manulife.esb.xsd.jh.workmanagement;

import javax.activation.DataHandler;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlMimeType;
import javax.xml.bind.annotation.XmlType;


/**
 * The type Attachment.
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "attachment", propOrder = {
    "binaryData"
})
public class Attachment {

    /**
     * The Binary data.
     */
    @XmlMimeType("application/octet-stream")
    protected DataHandler binaryData;
    /**
     * The Sequence.
     */
    @XmlAttribute(name = "sequence", required = true)
    protected int sequence;

    /**
     * Gets binary data.
     *
     * @return the binary data
     */
    public DataHandler getBinaryData() {
        return binaryData;
    }

    /**
     * Sets binary data.
     *
     * @param value the value
     */
    public void setBinaryData(DataHandler value) {
        this.binaryData = value;
    }

    /**
     * Gets sequence.
     *
     * @return the sequence
     */
    public int getSequence() {
        return sequence;
    }

    /**
     * Sets sequence.
     *
     * @param value the value
     */
    public void setSequence(int value) {
        this.sequence = value;
    }

}
