
package com.manulife.esb.xsd.jh.workmanagement;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * The type Quality event.
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "qualityEvent", propOrder = {
    "awdEvent",
    "vip",
    "reviewTime",
    "reviewUserId",
    "reviewUserName",
    "reviewDay",
    "deleteErrorTime",
    "deleteUserId"
})
public class QualityEvent {

    /**
     * The Awd event.
     */
    @XmlElement(required = true)
    protected AwdEvent awdEvent;
    /**
     * The Vip.
     */
    @XmlElement(name = "VIP")
    protected String vip;
    /**
     * The Review time.
     */
    protected String reviewTime;
    /**
     * The Review user id.
     */
    protected String reviewUserId;
    /**
     * The Review user name.
     */
    protected String reviewUserName;
    /**
     * The Review day.
     */
    protected String reviewDay;
    /**
     * The Delete error time.
     */
    protected String deleteErrorTime;
    /**
     * The Delete user id.
     */
    protected String deleteUserId;

    /**
     * Gets awd event.
     *
     * @return the awd event
     */
    public AwdEvent getAwdEvent() {
        return awdEvent;
    }

    /**
     * Sets awd event.
     *
     * @param value the value
     */
    public void setAwdEvent(AwdEvent value) {
        this.awdEvent = value;
    }

    /**
     * Gets vip.
     *
     * @return the vip
     */
    public String getVIP() {
        return vip;
    }

    /**
     * Sets vip.
     *
     * @param value the value
     */
    public void setVIP(String value) {
        this.vip = value;
    }

    /**
     * Gets review time.
     *
     * @return the review time
     */
    public String getReviewTime() {
        return reviewTime;
    }

    /**
     * Sets review time.
     *
     * @param value the value
     */
    public void setReviewTime(String value) {
        this.reviewTime = value;
    }

    /**
     * Gets review user id.
     *
     * @return the review user id
     */
    public String getReviewUserId() {
        return reviewUserId;
    }

    /**
     * Sets review user id.
     *
     * @param value the value
     */
    public void setReviewUserId(String value) {
        this.reviewUserId = value;
    }

    /**
     * Gets review user name.
     *
     * @return the review user name
     */
    public String getReviewUserName() {
        return reviewUserName;
    }

    /**
     * Sets review user name.
     *
     * @param value the value
     */
    public void setReviewUserName(String value) {
        this.reviewUserName = value;
    }

    /**
     * Gets review day.
     *
     * @return the review day
     */
    public String getReviewDay() {
        return reviewDay;
    }

    /**
     * Sets review day.
     *
     * @param value the value
     */
    public void setReviewDay(String value) {
        this.reviewDay = value;
    }

    /**
     * Gets delete error time.
     *
     * @return the delete error time
     */
    public String getDeleteErrorTime() {
        return deleteErrorTime;
    }

    /**
     * Sets delete error time.
     *
     * @param value the value
     */
    public void setDeleteErrorTime(String value) {
        this.deleteErrorTime = value;
    }

    /**
     * Gets delete user id.
     *
     * @return the delete user id
     */
    public String getDeleteUserId() {
        return deleteUserId;
    }

    /**
     * Sets delete user id.
     *
     * @param value the value
     */
    public void setDeleteUserId(String value) {
        this.deleteUserId = value;
    }

}
