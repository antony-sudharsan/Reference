
package com.manulife.esb.xsd.jh.workmanagement;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.*;


/**
 * The type Create object request.
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "createObjectRequest", propOrder = {
    "responseDetails",
    "createFolderInstanceOrCreateSourceInstanceOrCreateWorkInstance",
    "relationships"
})

public class CreateObjectRequest {

    /**
     * The Response details.
     */
    protected ResponseDetails responseDetails;
    /**
     * The Create folder instance or create source instance or create work instance.
     */
    @XmlElements({
        @XmlElement(name = "createFolderInstance", type = CreateFolderInstance.class),
        @XmlElement(name = "createSourceInstance", type = CreateSourceInstance.class),
        @XmlElement(name = "createWorkInstance", type = CreateWorkInstance.class)
    })
    protected List<Object> createFolderInstanceOrCreateSourceInstanceOrCreateWorkInstance;
    /**
     * The Relationships.
     */
    protected Relationships relationships;

    /**
     * Gets response details.
     *
     * @return the response details
     */
    public ResponseDetails getResponseDetails() {
        return responseDetails;
    }

    /**
     * Sets response details.
     *
     * @param value the value
     */
    public void setResponseDetails(ResponseDetails value) {
        this.responseDetails = value;
    }

    /**
     * Gets create folder instance or create source instance or create work instance.
     *
     * @return the create folder instance or create source instance or create work instance
     */
    public List<Object> getCreateFolderInstanceOrCreateSourceInstanceOrCreateWorkInstance() {
        if (createFolderInstanceOrCreateSourceInstanceOrCreateWorkInstance == null) {
            createFolderInstanceOrCreateSourceInstanceOrCreateWorkInstance = new ArrayList<Object>();
        }
        return this.createFolderInstanceOrCreateSourceInstanceOrCreateWorkInstance;
    }

    /**
     * Gets relationships.
     *
     * @return the relationships
     */
    public Relationships getRelationships() {
        return relationships;
    }

    /**
     * Sets relationships.
     *
     * @param value the value
     */
    public void setRelationships(Relationships value) {
        this.relationships = value;
    }

}
