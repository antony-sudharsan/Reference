
package com.manulife.esb.xsd.jh.workmanagement;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * The type Update folder instance.
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "updateFolderInstance", propOrder = {
    "updateAWDInstance"
})
public class UpdateFolderInstance {

    /**
     * The Update awd instance.
     */
    @XmlElement(required = true)
    protected UpdateAWDInstance updateAWDInstance;

    /**
     * Gets update awd instance.
     *
     * @return the update awd instance
     */
    public UpdateAWDInstance getUpdateAWDInstance() {
        return updateAWDInstance;
    }

    /**
     * Sets update awd instance.
     *
     * @param value the value
     */
    public void setUpdateAWDInstance(UpdateAWDInstance value) {
        this.updateAWDInstance = value;
    }

}
