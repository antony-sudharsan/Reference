
package com.manulife.esb.xsd.jh.workmanagement;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * The type Get objects request.
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "getObjectsRequest", propOrder = {
    "objectRequests",
    "responseDetails"
})
public class GetObjectsRequest {

    /**
     * The Object requests.
     */
    protected ObjectRequests objectRequests;
    /**
     * The Response details.
     */
    protected ResponseDetails responseDetails;

    /**
     * Gets object requests.
     *
     * @return the object requests
     */
    public ObjectRequests getObjectRequests() {
        return objectRequests;
    }

    /**
     * Sets object requests.
     *
     * @param value the value
     */
    public void setObjectRequests(ObjectRequests value) {
        this.objectRequests = value;
    }

    /**
     * Gets response details.
     *
     * @return the response details
     */
    public ResponseDetails getResponseDetails() {
        return responseDetails;
    }

    /**
     * Sets response details.
     *
     * @param value the value
     */
    public void setResponseDetails(ResponseDetails value) {
        this.responseDetails = value;
    }


    /**
     * The type Object requests.
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "objectRequest"
    })
    public static class ObjectRequests {

        /**
         * The Object request.
         */
        protected List<GetObjectRequest> objectRequest;

        /**
         * Gets object request.
         *
         * @return the object request
         */
        public List<GetObjectRequest> getObjectRequest() {
            if (objectRequest == null) {
                objectRequest = new ArrayList<GetObjectRequest>();
            }
            return this.objectRequest;
        }

    }

}
