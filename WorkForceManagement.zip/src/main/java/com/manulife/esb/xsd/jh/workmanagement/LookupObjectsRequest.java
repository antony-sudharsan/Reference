
package com.manulife.esb.xsd.jh.workmanagement;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlType;


/**
 * The type Lookup objects request.
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "lookupObjectsRequest", propOrder = {
    "responseDetails",
    "lookupParameters"
})
public class LookupObjectsRequest {

    /**
     * The Response details.
     */
    protected ResponseDetails responseDetails;
    /**
     * The Lookup parameters.
     */
    protected LookupParameters lookupParameters;
    /**
     * The Lookup name.
     */
    @XmlAttribute(name = "lookupName", required = true)
    protected String lookupName;

    /**
     * Gets response details.
     *
     * @return the response details
     */
    public ResponseDetails getResponseDetails() {
        return responseDetails;
    }

    /**
     * Sets response details.
     *
     * @param value the value
     */
    public void setResponseDetails(ResponseDetails value) {
        this.responseDetails = value;
    }

    /**
     * Gets lookup parameters.
     *
     * @return the lookup parameters
     */
    public LookupParameters getLookupParameters() {
        return lookupParameters;
    }

    /**
     * Sets lookup parameters.
     *
     * @param value the value
     */
    public void setLookupParameters(LookupParameters value) {
        this.lookupParameters = value;
    }

    /**
     * Gets lookup name.
     *
     * @return the lookup name
     */
    public String getLookupName() {
        return lookupName;
    }

    /**
     * Sets lookup name.
     *
     * @param value the value
     */
    public void setLookupName(String value) {
        this.lookupName = value;
    }


    /**
     * The type Lookup parameters.
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "lookupParameter"
    })
    public static class LookupParameters {

        /**
         * The Lookup parameter.
         */
        protected List<LookupParameter> lookupParameter;

        /**
         * Gets lookup parameter.
         *
         * @return the lookup parameter
         */
        public List<LookupParameter> getLookupParameter() {
            if (lookupParameter == null) {
                lookupParameter = new ArrayList<LookupParameter>();
            }
            return this.lookupParameter;
        }

    }

}
