
package com.manulife.esb.xsd.jh.workmanagement;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElements;
import javax.xml.bind.annotation.XmlType;


/**
 * The type Get objects response.
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "GetObjectsResponse", propOrder = {
    "folderInstanceOrSourceInstanceOrWorkInstance",
    "immediateRelationships"
})
public class GetObjectsResponse {


    /**
     * The Folder instance or source instance or work instance.
     */
    @XmlElements({
        @XmlElement(name = "folderInstance", type = FolderInstance.class),
        @XmlElement(name = "sourceInstance", type = SourceInstance.class),
        @XmlElement(name = "workInstance", type = WorkInstance.class)
    })
    protected List<Object> folderInstanceOrSourceInstanceOrWorkInstance;

    /**
     * Sets folder instance or source instance or work instance.
     *
     * @param folderInstanceOrSourceInstanceOrWorkInstance the folder instance or source instance or work instance
     */
    public void setFolderInstanceOrSourceInstanceOrWorkInstance(List<Object> folderInstanceOrSourceInstanceOrWorkInstance) {
        this.folderInstanceOrSourceInstanceOrWorkInstance = folderInstanceOrSourceInstanceOrWorkInstance;
    }


    /**
     * The Immediate relationships.
     */
    protected ImmediateRelationships immediateRelationships;

    /**
     * Gets folder instance or source instance or work instance.
     *
     * @return the folder instance or source instance or work instance
     */
    public List<Object> getFolderInstanceOrSourceInstanceOrWorkInstance() {
        if (folderInstanceOrSourceInstanceOrWorkInstance == null) {
            folderInstanceOrSourceInstanceOrWorkInstance = new ArrayList<Object>();
        }
        return this.folderInstanceOrSourceInstanceOrWorkInstance;
    }

    /**
     * Gets immediate relationships.
     *
     * @return the immediate relationships
     */
    public ImmediateRelationships getImmediateRelationships() {
        return immediateRelationships;
    }

    /**
     * Sets immediate relationships.
     *
     * @param value the value
     */
    public void setImmediateRelationships(ImmediateRelationships value) {
        this.immediateRelationships = value;
    }


    /**
     * The type Immediate relationships.
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "relateObjects"
    })
    public static class ImmediateRelationships {

        /**
         * Sets relate objects.
         *
         * @param relateObjects the relate objects
         */
        public void setRelateObjects(List<RelateOnlyExistingObjects> relateObjects) {
            this.relateObjects = relateObjects;
        }

        /**
         * The Relate objects.
         */
        protected List<RelateOnlyExistingObjects> relateObjects;

        /**
         * Gets relate objects.
         *
         * @return the relate objects
         */
        public List<RelateOnlyExistingObjects> getRelateObjects() {
            if (relateObjects == null) {
                relateObjects = new ArrayList<RelateOnlyExistingObjects>();
            }
            return this.relateObjects;
        }

    }

}
