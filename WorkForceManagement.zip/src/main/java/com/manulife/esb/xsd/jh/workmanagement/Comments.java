
package com.manulife.esb.xsd.jh.workmanagement;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * The type Comments.
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "comment"
})
@XmlRootElement(name = "comments")
public class Comments {

    /**
     * Sets comment.
     *
     * @param comment the comment
     */
    public void setComment(List<Comment> comment) {
        this.comment = comment;
    }

    /**
     * The Comment.
     */
    protected List<Comment> comment;

    /**
     * Gets comment.
     *
     * @return the comment
     */
    public List<Comment> getComment() {
        if (comment == null) {
            comment = new ArrayList<Comment>();
        }
        return this.comment;
    }

}
