
package com.manulife.esb.xsd.jh.workmanagement;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * The type Ke event.
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "keEvent", propOrder = {
    "systemEvent",
    "jobName",
    "description",
    "returnCode",
    "taskName",
    "nextTaskName"
})
public class KeEvent {

    /**
     * The System event.
     */
    @XmlElement(required = true)
    protected SystemEvent systemEvent;
    /**
     * The Job name.
     */
    protected String jobName;
    /**
     * The Description.
     */
    protected String description;
    /**
     * The Return code.
     */
    protected String returnCode;
    /**
     * The Task name.
     */
    protected String taskName;
    /**
     * The Next task name.
     */
    protected String nextTaskName;

    /**
     * Gets system event.
     *
     * @return the system event
     */
    public SystemEvent getSystemEvent() {
        return systemEvent;
    }

    /**
     * Sets system event.
     *
     * @param value the value
     */
    public void setSystemEvent(SystemEvent value) {
        this.systemEvent = value;
    }

    /**
     * Gets job name.
     *
     * @return the job name
     */
    public String getJobName() {
        return jobName;
    }

    /**
     * Sets job name.
     *
     * @param value the value
     */
    public void setJobName(String value) {
        this.jobName = value;
    }

    /**
     * Gets description.
     *
     * @return the description
     */
    public String getDescription() {
        return description;
    }

    /**
     * Sets description.
     *
     * @param value the value
     */
    public void setDescription(String value) {
        this.description = value;
    }

    /**
     * Gets return code.
     *
     * @return the return code
     */
    public String getReturnCode() {
        return returnCode;
    }

    /**
     * Sets return code.
     *
     * @param value the value
     */
    public void setReturnCode(String value) {
        this.returnCode = value;
    }

    /**
     * Gets task name.
     *
     * @return the task name
     */
    public String getTaskName() {
        return taskName;
    }

    /**
     * Sets task name.
     *
     * @param value the value
     */
    public void setTaskName(String value) {
        this.taskName = value;
    }

    /**
     * Gets next task name.
     *
     * @return the next task name
     */
    public String getNextTaskName() {
        return nextTaskName;
    }

    /**
     * Sets next task name.
     *
     * @param value the value
     */
    public void setNextTaskName(String value) {
        this.nextTaskName = value;
    }

}
