
package com.manulife.esb.xsd.jh.workmanagement;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * The type Relate objects.
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "relateObjects", propOrder = {
    "parentId",
    "childId",
    "parentRelationshipId",
    "childRelationshipId"
})
public class RelateObjects {

    /**
     * The Parent id.
     */
    protected String parentId;
    /**
     * The Child id.
     */
    protected String childId;
    /**
     * The Parent relationship id.
     */
    protected String parentRelationshipId;
    /**
     * The Child relationship id.
     */
    protected String childRelationshipId;

    /**
     * Gets parent id.
     *
     * @return the parent id
     */
    public String getParentId() {
        return parentId;
    }

    /**
     * Sets parent id.
     *
     * @param value the value
     */
    public void setParentId(String value) {
        this.parentId = value;
    }

    /**
     * Gets child id.
     *
     * @return the child id
     */
    public String getChildId() {
        return childId;
    }

    /**
     * Sets child id.
     *
     * @param value the value
     */
    public void setChildId(String value) {
        this.childId = value;
    }

    /**
     * Gets parent relationship id.
     *
     * @return the parent relationship id
     */
    public String getParentRelationshipId() {
        return parentRelationshipId;
    }

    /**
     * Sets parent relationship id.
     *
     * @param value the value
     */
    public void setParentRelationshipId(String value) {
        this.parentRelationshipId = value;
    }

    /**
     * Gets child relationship id.
     *
     * @return the child relationship id
     */
    public String getChildRelationshipId() {
        return childRelationshipId;
    }

    /**
     * Sets child relationship id.
     *
     * @param value the value
     */
    public void setChildRelationshipId(String value) {
        this.childRelationshipId = value;
    }

}
