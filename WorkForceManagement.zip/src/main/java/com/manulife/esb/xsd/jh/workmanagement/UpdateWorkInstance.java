
package com.manulife.esb.xsd.jh.workmanagement;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * The type Update work instance.
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "updateWorkInstance", propOrder = {
    "updateAWDInstance",
    "suspend",
    "status",
    "workStep",
    "routing",
    "queue",
    "priority",
    "priorityIncrease"
})
public class UpdateWorkInstance {

    /**
     * The Update awd instance.
     */
    @XmlElement(required = true)
    protected UpdateAWDInstance updateAWDInstance;
    /**
     * The Suspend.
     */
    protected Suspend suspend;
    /**
     * The Status.
     */
    protected String status;
    /**
     * The Work step.
     */
    protected String workStep;
    /**
     * The Routing.
     */
    protected Routing routing;
    /**
     * The Queue.
     */
    protected String queue;
    /**
     * The Priority.
     */
    protected String priority;
    /**
     * The Priority increase.
     */
    protected String priorityIncrease;
    /**
     * The Assign to.
     */
    @XmlAttribute(name = "assignTo")
    protected String assignTo;
    /**
     * The Autocase.
     */
    @XmlAttribute(name = "autocase")
    protected String autocase;

    /**
     * Gets update awd instance.
     *
     * @return the update awd instance
     */
    public UpdateAWDInstance getUpdateAWDInstance() {
        return updateAWDInstance;
    }

    /**
     * Sets update awd instance.
     *
     * @param value the value
     */
    public void setUpdateAWDInstance(UpdateAWDInstance value) {
        this.updateAWDInstance = value;
    }

    /**
     * Gets suspend.
     *
     * @return the suspend
     */
    public Suspend getSuspend() {
        return suspend;
    }

    /**
     * Sets suspend.
     *
     * @param value the value
     */
    public void setSuspend(Suspend value) {
        this.suspend = value;
    }

    /**
     * Gets status.
     *
     * @return the status
     */
    public String getStatus() {
        return status;
    }

    /**
     * Sets status.
     *
     * @param value the value
     */
    public void setStatus(String value) {
        this.status = value;
    }

    /**
     * Gets work step.
     *
     * @return the work step
     */
    public String getWorkStep() {
        return workStep;
    }

    /**
     * Sets work step.
     *
     * @param value the value
     */
    public void setWorkStep(String value) {
        this.workStep = value;
    }

    /**
     * Gets routing.
     *
     * @return the routing
     */
    public Routing getRouting() {
        return routing;
    }

    /**
     * Sets routing.
     *
     * @param value the value
     */
    public void setRouting(Routing value) {
        this.routing = value;
    }

    /**
     * Gets queue.
     *
     * @return the queue
     */
    public String getQueue() {
        return queue;
    }

    /**
     * Sets queue.
     *
     * @param value the value
     */
    public void setQueue(String value) {
        this.queue = value;
    }

    /**
     * Gets priority.
     *
     * @return the priority
     */
    public String getPriority() {
        return priority;
    }

    /**
     * Sets priority.
     *
     * @param value the value
     */
    public void setPriority(String value) {
        this.priority = value;
    }

    /**
     * Gets priority increase.
     *
     * @return the priority increase
     */
    public String getPriorityIncrease() {
        return priorityIncrease;
    }

    /**
     * Sets priority increase.
     *
     * @param value the value
     */
    public void setPriorityIncrease(String value) {
        this.priorityIncrease = value;
    }

    /**
     * Gets assign to.
     *
     * @return the assign to
     */
    public String getAssignTo() {
        return assignTo;
    }

    /**
     * Sets assign to.
     *
     * @param value the value
     */
    public void setAssignTo(String value) {
        this.assignTo = value;
    }

    /**
     * Gets autocase.
     *
     * @return the autocase
     */
    public String getAutocase() {
        return autocase;
    }

    /**
     * Sets autocase.
     *
     * @param value the value
     */
    public void setAutocase(String value) {
        this.autocase = value;
    }

}
