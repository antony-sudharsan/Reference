
package com.manulife.esb.xsd.jh.workmanagement;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElements;
import javax.xml.bind.annotation.XmlType;


/**
 * The type Update awd instance.
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "updateAWDInstance", propOrder = {
    "fieldValues",
    "businessArea",
    "type",
    "addManualComment"
})
public class UpdateAWDInstance {

    /**
     * The Field values.
     */
    protected FieldValues fieldValues;
    /**
     * The Business area.
     */
    protected String businessArea;
    /**
     * The Type.
     */
    protected String type;
    /**
     * The Add manual comment.
     */
    protected String addManualComment;
    /**
     * The Duration.
     */
    @XmlAttribute(name = "duration")
    protected String duration;
    /**
     * The Id.
     */
    @XmlAttribute(name = "id", required = true)
    protected String id;
    /**
     * The Lock.
     */
    @XmlAttribute(name = "lock")
    protected String lock;

    /**
     * Gets field values.
     *
     * @return the field values
     */
    public FieldValues getFieldValues() {
        return fieldValues;
    }

    /**
     * Sets field values.
     *
     * @param value the value
     */
    public void setFieldValues(FieldValues value) {
        this.fieldValues = value;
    }

    /**
     * Gets business area.
     *
     * @return the business area
     */
    public String getBusinessArea() {
        return businessArea;
    }

    /**
     * Sets business area.
     *
     * @param value the value
     */
    public void setBusinessArea(String value) {
        this.businessArea = value;
    }

    /**
     * Gets type.
     *
     * @return the type
     */
    public String getType() {
        return type;
    }

    /**
     * Sets type.
     *
     * @param value the value
     */
    public void setType(String value) {
        this.type = value;
    }

    /**
     * Gets add manual comment.
     *
     * @return the add manual comment
     */
    public String getAddManualComment() {
        return addManualComment;
    }

    /**
     * Sets add manual comment.
     *
     * @param value the value
     */
    public void setAddManualComment(String value) {
        this.addManualComment = value;
    }

    /**
     * Gets duration.
     *
     * @return the duration
     */
    public String getDuration() {
        return duration;
    }

    /**
     * Sets duration.
     *
     * @param value the value
     */
    public void setDuration(String value) {
        this.duration = value;
    }

    /**
     * Gets id.
     *
     * @return the id
     */
    public String getId() {
        return id;
    }

    /**
     * Sets id.
     *
     * @param value the value
     */
    public void setId(String value) {
        this.id = value;
    }

    /**
     * Gets lock.
     *
     * @return the lock
     */
    public String getLock() {
        return lock;
    }

    /**
     * Sets lock.
     *
     * @param value the value
     */
    public void setLock(String value) {
        this.lock = value;
    }


    /**
     * The type Field values.
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "deleteFieldValueOrFieldValue"
    })
    public static class FieldValues {

        /**
         * The Delete field value or field value.
         */
        @XmlElements({
            @XmlElement(name = "deleteFieldValue", type = DeleteFieldValue.class),
            @XmlElement(name = "fieldValue", type = FieldValue.class)
        })
        protected List<Object> deleteFieldValueOrFieldValue;

        /**
         * Gets delete field value or field value.
         *
         * @return the delete field value or field value
         */
        public List<Object> getDeleteFieldValueOrFieldValue() {
            if (deleteFieldValueOrFieldValue == null) {
                deleteFieldValueOrFieldValue = new ArrayList<Object>();
            }
            return this.deleteFieldValueOrFieldValue;
        }

    }

}
