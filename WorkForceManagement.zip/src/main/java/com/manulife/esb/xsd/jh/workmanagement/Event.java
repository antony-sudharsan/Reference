
package com.manulife.esb.xsd.jh.workmanagement;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * The type Event.
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "event", propOrder = {
    "beginTime",
    "endTime"
})
public class Event {

    /**
     * The Begin time.
     */
    protected String beginTime;
    /**
     * The End time.
     */
    protected String endTime;

    /**
     * Gets begin time.
     *
     * @return the begin time
     */
    public String getBeginTime() {
        return beginTime;
    }

    /**
     * Sets begin time.
     *
     * @param value the value
     */
    public void setBeginTime(String value) {
        this.beginTime = value;
    }

    /**
     * Gets end time.
     *
     * @return the end time
     */
    public String getEndTime() {
        return endTime;
    }

    /**
     * Sets end time.
     *
     * @param value the value
     */
    public void setEndTime(String value) {
        this.endTime = value;
    }

}
