
package com.manulife.esb.xsd.jh.workmanagement;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * The type Field value.
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "fieldValue", propOrder = {
    "name",
    "sequence",
    "value"
})
public class FieldValue {

    /**
     * The Name.
     */
    @XmlElement(required = true)
    protected String name;
    /**
     * The Sequence.
     */
    protected String sequence;
    /**
     * The Value.
     */
    @XmlElement(required = true)
    protected String value;

    /**
     * Gets name.
     *
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * Sets name.
     *
     * @param value the value
     */
    public void setName(String value) {
        this.name = value;
    }

    /**
     * Gets sequence.
     *
     * @return the sequence
     */
    public String getSequence() {
        return sequence;
    }

    /**
     * Sets sequence.
     *
     * @param value the value
     */
    public void setSequence(String value) {
        this.sequence = value;
    }

    /**
     * Gets value.
     *
     * @return the value
     */
    public String getValue() {
        return value;
    }

    /**
     * Sets value.
     *
     * @param value the value
     */
    public void setValue(String value) {
        this.value = value;
    }

}
