
package com.manulife.esb.xsd.jh.workmanagement;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * The type External systems.
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "externalSystem"
})
@XmlRootElement(name = "externalSystems")
public class ExternalSystems {

    /**
     * Sets external system.
     *
     * @param externalSystem the external system
     */
    public void setExternalSystem(List<ExternalSystem> externalSystem) {
        this.externalSystem = externalSystem;
    }

    /**
     * The External system.
     */
    protected List<ExternalSystem> externalSystem;

    /**
     * Gets external system.
     *
     * @return the external system
     */
    public List<ExternalSystem> getExternalSystem() {
        if (externalSystem == null) {
            externalSystem = new ArrayList<ExternalSystem>();
        }
        return this.externalSystem;
    }

}
