
package com.manulife.esb.xsd.jh.workmanagement;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlType;


/**
 * The type Work flow.
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "workFlow", propOrder = {
    "workSteps"
})
public class WorkFlow {


    /**
     * The Work steps.
     */
    protected List<WorkSteps> workSteps;

    /**
     * Sets work steps.
     *
     * @param workSteps the work steps
     */
    public void setWorkSteps(List<WorkSteps> workSteps) {
        this.workSteps = workSteps;
    }

    /**
     * The Route.
     */
    @XmlAttribute(name = "route", required = true)
    protected String route;

    /**
     * Gets work steps.
     *
     * @return the work steps
     */
    public List<WorkSteps> getWorkSteps() {
        if (workSteps == null) {
            workSteps = new ArrayList<WorkSteps>();
        }
        return this.workSteps;
    }

    /**
     * Gets route.
     *
     * @return the route
     */
    public String getRoute() {
        return route;
    }

    /**
     * Sets route.
     *
     * @param value the value
     */
    public void setRoute(String value) {
        this.route = value;
    }

}
