
package com.manulife.esb.xsd.jh.workmanagement;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * The type Folder instance.
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "folderInstance", propOrder = {
    "awdInstance",
    "createUser",
    "createStation"
})
public class FolderInstance {

    /**
     * The Awd instance.
     */
    @XmlElement(required = true)
    protected AwdInstance awdInstance;
    /**
     * The Create user.
     */
    protected String createUser;
    /**
     * The Create station.
     */
    protected String createStation;

    /**
     * Gets awd instance.
     *
     * @return the awd instance
     */
    public AwdInstance getAwdInstance() {
        return awdInstance;
    }

    /**
     * Sets awd instance.
     *
     * @param value the value
     */
    public void setAwdInstance(AwdInstance value) {
        this.awdInstance = value;
    }

    /**
     * Gets create user.
     *
     * @return the create user
     */
    public String getCreateUser() {
        return createUser;
    }

    /**
     * Sets create user.
     *
     * @param value the value
     */
    public void setCreateUser(String value) {
        this.createUser = value;
    }

    /**
     * Gets create station.
     *
     * @return the create station
     */
    public String getCreateStation() {
        return createStation;
    }

    /**
     * Sets create station.
     *
     * @param value the value
     */
    public void setCreateStation(String value) {
        this.createStation = value;
    }

}
