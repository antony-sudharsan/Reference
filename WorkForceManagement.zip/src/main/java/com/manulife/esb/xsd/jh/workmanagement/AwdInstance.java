
package com.manulife.esb.xsd.jh.workmanagement;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElements;
import javax.xml.bind.annotation.XmlType;


/**
 * The type Awd instance.
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "awdInstance", propOrder = {
    "createTime",
    "comments",
    "keEventOrQualityEventOrSystemEvent",
    "fieldValues",
    "businessArea",
    "type",
    "customScreen",
    "iconName",
    "tagLine",
    "externalSystems",
    "lockedBy"
})
public class AwdInstance {

    /**
     * The Create time.
     */
    protected String createTime;
    /**
     * The Comments.
     */
    protected Comments comments;


    /**
     * The Ke event or quality event or system event.
     */
    @XmlElements({
        @XmlElement(name = "keEvent", type = KeEvent.class),
        @XmlElement(name = "qualityEvent", type = QualityEvent.class),
        @XmlElement(name = "systemEvent", type = SystemEvent.class)
    })
    protected List<Object> keEventOrQualityEventOrSystemEvent;

    /**
     * Sets ke event or quality event or system event.
     *
     * @param keEventOrQualityEventOrSystemEvent the ke event or quality event or system event
     */
    public void setKeEventOrQualityEventOrSystemEvent(List<Object> keEventOrQualityEventOrSystemEvent) {
        this.keEventOrQualityEventOrSystemEvent = keEventOrQualityEventOrSystemEvent;
    }

    /**
     * The Field values.
     */
    protected FieldValues fieldValues;
    /**
     * The Business area.
     */
    protected String businessArea;
    /**
     * The Type.
     */
    protected String type;
    /**
     * The Custom screen.
     */
    protected String customScreen;
    /**
     * The Icon name.
     */
    protected String iconName;
    /**
     * The Tag line.
     */
    protected String tagLine;
    /**
     * The External systems.
     */
    protected ExternalSystems externalSystems;
    /**
     * The Locked by.
     */
    protected String lockedBy;
    /**
     * The Id.
     */
    @XmlAttribute(name = "id", required = true)
    protected String id;
    /**
     * The Permission.
     */
    @XmlAttribute(name = "permission")
    protected String permission;

    /**
     * Gets create time.
     *
     * @return the create time
     */
    public String getCreateTime() {
        return createTime;
    }

    /**
     * Sets create time.
     *
     * @param value the value
     */
    public void setCreateTime(String value) {
        this.createTime = value;
    }

    /**
     * Gets comments.
     *
     * @return the comments
     */
    public Comments getComments() {
        return comments;
    }

    /**
     * Sets comments.
     *
     * @param value the value
     */
    public void setComments(Comments value) {
        this.comments = value;
    }

    /**
     * Gets ke event or quality event or system event.
     *
     * @return the ke event or quality event or system event
     */
    public List<Object> getKeEventOrQualityEventOrSystemEvent() {
        if (keEventOrQualityEventOrSystemEvent == null) {
            keEventOrQualityEventOrSystemEvent = new ArrayList<Object>();
        }
        return this.keEventOrQualityEventOrSystemEvent;
    }

    /**
     * Gets field values.
     *
     * @return the field values
     */
    public FieldValues getFieldValues() {
        return fieldValues;
    }

    /**
     * Sets field values.
     *
     * @param value the value
     */
    public void setFieldValues(FieldValues value) {
        this.fieldValues = value;
    }

    /**
     * Gets business area.
     *
     * @return the business area
     */
    public String getBusinessArea() {
        return businessArea;
    }

    /**
     * Sets business area.
     *
     * @param value the value
     */
    public void setBusinessArea(String value) {
        this.businessArea = value;
    }

    /**
     * Gets type.
     *
     * @return the type
     */
    public String getType() {
        return type;
    }

    /**
     * Sets type.
     *
     * @param value the value
     */
    public void setType(String value) {
        this.type = value;
    }

    /**
     * Gets custom screen.
     *
     * @return the custom screen
     */
    public String getCustomScreen() {
        return customScreen;
    }

    /**
     * Sets custom screen.
     *
     * @param value the value
     */
    public void setCustomScreen(String value) {
        this.customScreen = value;
    }

    /**
     * Gets icon name.
     *
     * @return the icon name
     */
    public String getIconName() {
        return iconName;
    }

    /**
     * Sets icon name.
     *
     * @param value the value
     */
    public void setIconName(String value) {
        this.iconName = value;
    }

    /**
     * Gets tag line.
     *
     * @return the tag line
     */
    public String getTagLine() {
        return tagLine;
    }

    /**
     * Sets tag line.
     *
     * @param value the value
     */
    public void setTagLine(String value) {
        this.tagLine = value;
    }

    /**
     * Gets external systems.
     *
     * @return the external systems
     */
    public ExternalSystems getExternalSystems() {
        return externalSystems;
    }

    /**
     * Sets external systems.
     *
     * @param value the value
     */
    public void setExternalSystems(ExternalSystems value) {
        this.externalSystems = value;
    }

    /**
     * Gets locked by.
     *
     * @return the locked by
     */
    public String getLockedBy() {
        return lockedBy;
    }

    /**
     * Sets locked by.
     *
     * @param value the value
     */
    public void setLockedBy(String value) {
        this.lockedBy = value;
    }

    /**
     * Gets id.
     *
     * @return the id
     */
    public String getId() {
        return id;
    }

    /**
     * Sets id.
     *
     * @param value the value
     */
    public void setId(String value) {
        this.id = value;
    }

    /**
     * Gets permission.
     *
     * @return the permission
     */
    public String getPermission() {
        return permission;
    }

    /**
     * Sets permission.
     *
     * @param value the value
     */
    public void setPermission(String value) {
        this.permission = value;
    }

}
