
package com.manulife.esb.xsd.jh.workmanagement;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * The type Lookup parameter.
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "lookupParameter", propOrder = {
    "name",
    "value"
})
public class LookupParameter {

    /**
     * The Name.
     */
    @XmlElement(required = true)
    protected String name;
    /**
     * The Value.
     */
    @XmlElement(required = true)
    protected String value;

    /**
     * Gets name.
     *
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * Sets name.
     *
     * @param value the value
     */
    public void setName(String value) {
        this.name = value;
    }

    /**
     * Gets value.
     *
     * @return the value
     */
    public String getValue() {
        return value;
    }

    /**
     * Sets value.
     *
     * @param value the value
     */
    public void setValue(String value) {
        this.value = value;
    }

}
