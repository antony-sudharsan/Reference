
package com.manulife.esb.xsd.jh.workmanagement;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * The type Lookup objects response.
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "lookupObjectsResponse", propOrder = {
    "lookupObjectsResponse"
})
public class LookupObjectsResponse {

    /**
     * The Lookup objects response.
     */
    protected GetObjectsResponse lookupObjectsResponse;

    /**
     * Gets lookup objects response.
     *
     * @return the lookup objects response
     */
    public GetObjectsResponse getLookupObjectsResponse() {
        return lookupObjectsResponse;
    }

    /**
     * Sets lookup objects response.
     *
     * @param value the value
     */
    public void setLookupObjectsResponse(GetObjectsResponse value) {
        this.lookupObjectsResponse = value;
    }

}
