
package com.manulife.esb.xsd.jh.workmanagement;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * The type Awd event.
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "awdEvent", propOrder = {
    "event",
    "userId",
    "userName",
    "businessArea",
    "type",
    "workStep",
    "queue"
})
public class AwdEvent {

    /**
     * The Event.
     */
    @XmlElement(required = true)
    protected Event event;
    /**
     * The User id.
     */
    @XmlElement(nillable = true)
    protected String userId;
    /**
     * The User name.
     */
    protected String userName;
    /**
     * The Business area.
     */
    protected String businessArea;
    /**
     * The Type.
     */
    protected String type;
    /**
     * The Work step.
     */
    protected String workStep;
    /**
     * The Queue.
     */
    protected String queue;

    /**
     * Gets event.
     *
     * @return the event
     */
    public Event getEvent() {
        return event;
    }

    /**
     * Sets event.
     *
     * @param value the value
     */
    public void setEvent(Event value) {
        this.event = value;
    }

    /**
     * Gets user id.
     *
     * @return the user id
     */
    public String getUserId() {
        return userId;
    }

    /**
     * Sets user id.
     *
     * @param value the value
     */
    public void setUserId(String value) {
        this.userId = value;
    }

    /**
     * Gets user name.
     *
     * @return the user name
     */
    public String getUserName() {
        return userName;
    }

    /**
     * Sets user name.
     *
     * @param value the value
     */
    public void setUserName(String value) {
        this.userName = value;
    }

    /**
     * Gets business area.
     *
     * @return the business area
     */
    public String getBusinessArea() {
        return businessArea;
    }

    /**
     * Sets business area.
     *
     * @param value the value
     */
    public void setBusinessArea(String value) {
        this.businessArea = value;
    }

    /**
     * Gets type.
     *
     * @return the type
     */
    public String getType() {
        return type;
    }

    /**
     * Sets type.
     *
     * @param value the value
     */
    public void setType(String value) {
        this.type = value;
    }

    /**
     * Gets work step.
     *
     * @return the work step
     */
    public String getWorkStep() {
        return workStep;
    }

    /**
     * Sets work step.
     *
     * @param value the value
     */
    public void setWorkStep(String value) {
        this.workStep = value;
    }

    /**
     * Gets queue.
     *
     * @return the queue
     */
    public String getQueue() {
        return queue;
    }

    /**
     * Sets queue.
     *
     * @param value the value
     */
    public void setQueue(String value) {
        this.queue = value;
    }

}
