
package com.manulife.esb.xsd.jh.workmanagement;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlType;


/**
 * The type Get object request.
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "getObjectRequest")
public class GetObjectRequest {

    /**
     * The Id.
     */
    @XmlAttribute(name = "id", required = true)
    protected String id;
    /**
     * The Lock.
     */
    @XmlAttribute(name = "lock")
    protected String lock;

    /**
     * Gets id.
     *
     * @return the id
     */
    public String getId() {
        return id;
    }

    /**
     * Sets id.
     *
     * @param value the value
     */
    public void setId(String value) {
        this.id = value;
    }

    /**
     * Gets lock.
     *
     * @return the lock
     */
    public String getLock() {
        return lock;
    }

    /**
     * Sets lock.
     *
     * @param value the value
     */
    public void setLock(String value) {
        this.lock = value;
    }

}
