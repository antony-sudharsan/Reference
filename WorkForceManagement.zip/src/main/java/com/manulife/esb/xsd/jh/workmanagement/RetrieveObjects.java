
package com.manulife.esb.xsd.jh.workmanagement;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * The type Retrieve objects.
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "retrieveObjects", propOrder = {
    "getObjectsRequest"
})
public class RetrieveObjects {

    /**
     * The Get objects request.
     */
    protected GetObjectsRequest getObjectsRequest;

    /**
     * Gets get objects request.
     *
     * @return the get objects request
     */
    public GetObjectsRequest getGetObjectsRequest() {
        return getObjectsRequest;
    }

    /**
     * Sets get objects request.
     *
     * @param value the value
     */
    public void setGetObjectsRequest(GetObjectsRequest value) {
        this.getObjectsRequest = value;
    }

}
