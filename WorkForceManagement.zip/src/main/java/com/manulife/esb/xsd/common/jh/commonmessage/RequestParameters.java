
package com.manulife.esb.xsd.common.jh.commonmessage;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * The type Request parameters.
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "RequestParameters", propOrder = {
    "requestParameter"
})
public class RequestParameters {

    /**
     * The Request parameter.
     */
    @XmlElement(name = "RequestParameter", required = true)
    protected RequestParameter requestParameter;

    /**
     * Gets request parameter.
     *
     * @return the request parameter
     */
    public RequestParameter getRequestParameter() {
        return requestParameter;
    }

    /**
     * Sets request parameter.
     *
     * @param value the value
     */
    public void setRequestParameter(RequestParameter value) {
        this.requestParameter = value;
    }

}
