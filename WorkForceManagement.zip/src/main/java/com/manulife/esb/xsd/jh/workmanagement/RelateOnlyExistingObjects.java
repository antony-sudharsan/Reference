
package com.manulife.esb.xsd.jh.workmanagement;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * The type Relate only existing objects.
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "relateOnlyExistingObjects", propOrder = {
    "parentId",
    "childId"
})
public class RelateOnlyExistingObjects {

    /**
     * The Parent id.
     */
    @XmlElement(required = true)
    protected String parentId;
    /**
     * The Child id.
     */
    @XmlElement(required = true)
    protected String childId;

    /**
     * Gets parent id.
     *
     * @return the parent id
     */
    public String getParentId() {
        return parentId;
    }

    /**
     * Sets parent id.
     *
     * @param value the value
     */
    public void setParentId(String value) {
        this.parentId = value;
    }

    /**
     * Gets child id.
     *
     * @return the child id
     */
    public String getChildId() {
        return childId;
    }

    /**
     * Sets child id.
     *
     * @param value the value
     */
    public void setChildId(String value) {
        this.childId = value;
    }

}
