/**
 *
 */
package com.jh.workmanagement.config;

/**
 * @author Antony Sudharsan
 *
 */

import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;

/**
 * The type Swagger config.
 */
@Component
public class SwaggerConfig {

    /**
     * Api docket docket.
     *
     * @return the docket
     */
    @Bean
	public Docket apiDocket() {
		return new Docket(DocumentationType.SWAGGER_2).select().apis(RequestHandlerSelectors.basePackage("com.jh.workmanagement.controller"))
				.paths(PathSelectors.any()).build();
	}

}
