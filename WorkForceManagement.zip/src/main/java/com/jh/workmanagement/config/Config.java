package com.jh.workmanagement.config;

import com.jh.workmanagement.service.WorkManagementWebServiceClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;

/**
 * The type Config.
 */
@Configuration
public class Config {

    /**
     * The Client.
     */
    @Autowired
    WorkManagementWebServiceClient client;


    /**
     * Marshaller jaxb 2 marshaller.
     *
     * @return the jaxb 2 marshaller
     */
    @Bean
    public Jaxb2Marshaller marshaller() {
        Jaxb2Marshaller marshaller = new Jaxb2Marshaller();
        marshaller.setContextPath("com.dstawd.processing.ws");
        return marshaller;
    }

    /**
     * Soap connector work management web service client.
     *
     * @param marshaller the marshaller
     *
     * @return the work management web service client
     */
    @Bean
    public WorkManagementWebServiceClient soapConnector(Jaxb2Marshaller marshaller) {

        client.setMarshaller(marshaller);
        client.setUnmarshaller(marshaller);
        return client;
    }

}