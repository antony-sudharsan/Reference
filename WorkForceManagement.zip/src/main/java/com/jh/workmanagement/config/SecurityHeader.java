package com.jh.workmanagement.config;

import com.dstawd.processing.ws.AuthorizationInfo;
import org.springframework.ws.WebServiceMessage;
import org.springframework.ws.client.core.WebServiceMessageCallback;
import org.springframework.ws.soap.SoapHeader;
import org.springframework.ws.soap.SoapMessage;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.transform.TransformerException;
import java.io.IOException;

/**
 * The type Security header.
 */
public class SecurityHeader implements WebServiceMessageCallback {

    private AuthorizationInfo authorizationInfo;

    /**
     * Instantiates a new Security header.
     *
     * @param authorizationInfo the authorization info
     */
    public SecurityHeader(AuthorizationInfo authorizationInfo) {
        this.authorizationInfo = authorizationInfo;
    }

    @Override
    public void doWithMessage(WebServiceMessage message) throws IOException, TransformerException {
        SoapHeader soapHeader = ((SoapMessage)message).getSoapHeader();

        try {
            JAXBContext context = JAXBContext.newInstance(AuthorizationInfo.class);

            Marshaller marshaller = context.createMarshaller();
            marshaller.marshal(authorizationInfo, soapHeader.getResult());

        } catch (JAXBException e) {
            throw new IOException("error while marshalling authentication.");
        }
    }
}