package com.jh.workmanagement.utils;

/**
 * The type Logging context.
 */
public class LoggingContext {

	private String messageUUID;
	private String sourceSystemName;

    /**
     * Sets context.
     *
     * @param messageUUID      the message uuid
     * @param sourceSystemName the source system name
     */
    public void setContext(final String messageUUID, final String sourceSystemName) {
		this.messageUUID = messageUUID;
		this.sourceSystemName = sourceSystemName;
	}

    /**
     * Gets message uuid.
     *
     * @return the message uuid
     */
    public String getMessageUUID() {
		return messageUUID;
	}

    /**
     * Sets message uuid.
     *
     * @param messageUUID the message uuid
     */
    public void setMessageUUID(final String messageUUID) {
		this.messageUUID = messageUUID;
	}

    /**
     * Gets source system name.
     *
     * @return the source system name
     */
    public String getSourceSystemName() {
		return sourceSystemName;
	}

    /**
     * Sets source system name.
     *
     * @param sourceSystemName the source system name
     */
    public void setSourceSystemName(final String sourceSystemName) {
		this.sourceSystemName = sourceSystemName;
	}

    /**
     * Clear.
     */
    public void clear() {
		this.messageUUID = null;
		this.sourceSystemName = null;
	}
}
