package com.jh.workmanagement.utils;

/**
 * The enum Header key.
 */
public enum HeaderKey {
    /**
     * Jh header key header key.
     */
    JH_HEADER_KEY("X-JH-Header");
	
	private String value;
	
	HeaderKey(final String value) {
		this.value = value;
	}

    /**
     * Gets value.
     *
     * @return the value
     */
    public String getValue() {
		return value;
	}

}
