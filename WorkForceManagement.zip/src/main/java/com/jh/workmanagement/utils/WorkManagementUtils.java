package com.jh.workmanagement.utils;

import java.io.File;
import java.io.Reader;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamReader;

import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Component;
import org.w3c.dom.Document;

/**
 * The type Work management utils.
 */
@Component
public class WorkManagementUtils {

    /**
     * Escape meta characters string.
     *
     * @param inputString the input string
     *
     * @return the string
     */
    public static String escapeMetaCharacters(String inputString){
	    final String[] metaCharacters = {"\\","^","$","{","}","[","]","(",")",".","*","+","?","|","<",">","-","&"};
	    String outputString="";
	    for (int i = 0 ; i < metaCharacters.length ; i++){
	        if(inputString.contains(metaCharacters[i])){
	            outputString = inputString.replace(metaCharacters[i],"\\"+metaCharacters[i]);
	            inputString = outputString;
	        }
	    }
	    return outputString;
	}


    /**
     * Parse to body xml stream reader.
     *
     * @param reader   the reader
     * @param elemName the elem name
     *
     * @return the xml stream reader
     *
     * @throws Exception the exception
     */
    public static  XMLStreamReader  ParseToBody(Reader reader, String elemName) throws Exception{
		XMLInputFactory factory = XMLInputFactory.newInstance(); // Or newFactory()
		XMLStreamReader xsr = factory.createXMLStreamReader(reader);
	
		int i=0;
		while (xsr.hasNext()) {
			int eventType = xsr.next();
	
			switch (eventType) {
			case XMLStreamReader.START_ELEMENT:
	
				String elementName = xsr.getLocalName();
				if (elementName.equals(elemName)) {
					i++;
				}
	
				break;
	
			case XMLStreamReader.END_ELEMENT:
				break;
			}
			if(i==2) break;
		}
		
		return xsr;


	}


    /**
     * Load xml document.
     *
     * @param fileName the file name
     *
     * @return the document
     *
     * @throws Exception the exception
     */
    public static Document loadXML(String fileName) throws Exception {
		 Resource resource = new ClassPathResource(fileName);
		 	File fXmlFile = resource.getFile();
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			Document doc = dBuilder.parse(fXmlFile);
			doc.getDocumentElement().normalize();
			
			return doc;
		 
	 }

}
