package com.jh.workmanagement.mapper;

import com.dstawd.processing.ws.WorkStep;
import com.manulife.esb.xsd.jh.workmanagement.*;
import org.springframework.stereotype.Component;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

/**
 * The type Work management mapper helper.
 */
@Component
public class WorkManagementMapperHelper {

    /**
     * Return map awd instance list.
     *
     * @param awdInstancesList the awd instances list
     *
     * @return the list
     */
// TODO reuse
    public List<Object> returnMapAWDInstance(List<com.dstawd.processing.ws.AwdInstance> awdInstancesList){

        List<Object> returnAWDInstanceList = null;

        if(awdInstancesList != null) {
            returnAWDInstanceList = new ArrayList<>();
            for (int i = 0; i < awdInstancesList.size(); i++) {

                com.dstawd.processing.ws.AwdInstance awdInstance = awdInstancesList.get(i);

                if(awdInstance instanceof com.dstawd.processing.ws.SourceInstance){
                    SourceInstance retSourceInstance = new SourceInstance();

                    retSourceInstance.setAccessMethod(((com.dstawd.processing.ws.SourceInstance) awdInstance).getAccessMethod());
                    retSourceInstance.setAnnotationBlob(((com.dstawd.processing.ws.SourceInstance) awdInstance).getAnnotationBlob());
                    retSourceInstance.setArchiveBox(((com.dstawd.processing.ws.SourceInstance) awdInstance).getArchiveBox());
                    retSourceInstance.setArchiveStartPage(((com.dstawd.processing.ws.SourceInstance) awdInstance).getArchiveStartPage());
                    // Mapping the super class AWD Instance
                    retSourceInstance.setAwdInstance(retMapSourceAWDInstance((com.dstawd.processing.ws.SourceInstance) awdInstance));
                    retSourceInstance.setCommentsExist(((com.dstawd.processing.ws.SourceInstance) awdInstance).getCommentsExist());
                    retSourceInstance.setContentId(((com.dstawd.processing.ws.SourceInstance) awdInstance).getContentId());
                    retSourceInstance.setCreateStation(((com.dstawd.processing.ws.SourceInstance) awdInstance).getCreateStation());
                    retSourceInstance.setCreateUser(((com.dstawd.processing.ws.SourceInstance) awdInstance).getCreateUser());
                    retSourceInstance.setFormat(((com.dstawd.processing.ws.SourceInstance) awdInstance).getFormat());
                    retSourceInstance.setMailType(((com.dstawd.processing.ws.SourceInstance) awdInstance).getMailType());
                    retSourceInstance.setOpticalStatus(((com.dstawd.processing.ws.SourceInstance) awdInstance).getOpticalStatus());
                    retSourceInstance.setPageCount(new BigInteger(((com.dstawd.processing.ws.SourceInstance) awdInstance).getPageCount()));
                    retSourceInstance.setPath(((com.dstawd.processing.ws.SourceInstance) awdInstance).getPath());
                    retSourceInstance.setSecurityLevel(((com.dstawd.processing.ws.SourceInstance) awdInstance).getSecurityLevel());
                    retSourceInstance.setRevisable(((com.dstawd.processing.ws.SourceInstance) awdInstance).getRevisable());
                    retSourceInstance.setReceiveTime(((com.dstawd.processing.ws.SourceInstance) awdInstance).getReceiveTime());
                    returnAWDInstanceList.add(retSourceInstance);

                } else if(awdInstance instanceof com.dstawd.processing.ws.WorkInstance){
                    WorkInstance retWorkInstance =new WorkInstance();
                    retWorkInstance.setAssignedTo(((com.dstawd.processing.ws.WorkInstance) awdInstance).getAssignedTo());
                    // Map the AWD Instance
                    retWorkInstance.setAwdInstance(retMapSourceAWDInstance((com.dstawd.processing.ws.WorkInstance) awdInstance));
                    retWorkInstance.setInstanceType(((com.dstawd.processing.ws.WorkInstance) awdInstance).getInstanceType());
                    retWorkInstance.setPriority(((com.dstawd.processing.ws.WorkInstance) awdInstance).getPriority());
                    retWorkInstance.setPriorityIncrease(((com.dstawd.processing.ws.WorkInstance) awdInstance).getPriorityIncrease());
                    retWorkInstance.setQueue(((com.dstawd.processing.ws.WorkInstance) awdInstance).getQueue());
                    retWorkInstance.setStatus(((com.dstawd.processing.ws.WorkInstance) awdInstance).getStatus());
                    // Mapping the suspend data
                    if(((com.dstawd.processing.ws.WorkInstance) awdInstance).getSuspended() != null) {
                        retWorkInstance.setSuspended(retMapAWDSuspend(((com.dstawd.processing.ws.WorkInstance) awdInstance).getSuspended()));
                    }
                    // Mapping the WorkFlow
                    if(((com.dstawd.processing.ws.WorkInstance) awdInstance).getWorkFlow() != null) {
                        retWorkInstance.setWorkFlow(retMapWorkFlow(((com.dstawd.processing.ws.WorkInstance) awdInstance).getWorkFlow()));
                    }
                    returnAWDInstanceList.add(retWorkInstance);
                }else if(awdInstance instanceof com.dstawd.processing.ws.FolderInstance){
                    FolderInstance retFolderInstance = new FolderInstance();

                    retFolderInstance.setAwdInstance(retMapSourceAWDInstance((com.dstawd.processing.ws.FolderInstance) awdInstance));
                    retFolderInstance.setCreateStation(((com.dstawd.processing.ws.FolderInstance) awdInstance).getCreateStation());
                    retFolderInstance.setCreateUser(((com.dstawd.processing.ws.FolderInstance) awdInstance).getCreateUser());
                    returnAWDInstanceList.add(retFolderInstance);
                }

            }
        }
        return returnAWDInstanceList;
    }

    /**
     * Ret map source awd instance awd instance.
     *
     * @param awdInstance the awd instance
     *
     * @return the awd instance
     */
    public AwdInstance retMapSourceAWDInstance(com.dstawd.processing.ws.SourceInstance awdInstance){
        AwdInstance retAwdInstance = new AwdInstance();
        retAwdInstance.setBusinessArea(awdInstance.getBusinessArea());
        // Mapping the comments
        if(awdInstance.getComments() != null) {
            retAwdInstance.setComments(retMapComments(awdInstance.getComments()));
        }
        retAwdInstance.setCreateTime(awdInstance.getCreateTime());
        retAwdInstance.setCustomScreen(awdInstance.getCustomScreen());
        // Mapping the external system
        if(awdInstance.getExternalSystems() != null) {
            retAwdInstance.setExternalSystems(retMapExternalSystems(awdInstance.getExternalSystems()));
        }
        // Mapping the field values
        if(awdInstance.getFieldValues() != null) {
            retAwdInstance.setFieldValues(retMapFieldValues(awdInstance.getFieldValues()));
        }
        retAwdInstance.setIconName(awdInstance.getIconName());
        retAwdInstance.setId(awdInstance.getId());
        retAwdInstance.setLockedBy(awdInstance.getLockedBy());
        retAwdInstance.setPermission(awdInstance.getPermission());
        retAwdInstance.setTagLine(awdInstance.getTagLine());
        retAwdInstance.setType(awdInstance.getType());
        if(awdInstance.getSystemEventOrQualityEventOrKeEvent() != null) {
            retAwdInstance.setKeEventOrQualityEventOrSystemEvent(retMapSystemEvent(awdInstance.getSystemEventOrQualityEventOrKeEvent()));
        }
        return retAwdInstance;
    }


    /**
     * Ret map source awd instance awd instance.
     *
     * @param awdInstance the awd instance
     *
     * @return the awd instance
     */
// TODO reuse
    public AwdInstance retMapSourceAWDInstance(com.dstawd.processing.ws.WorkInstance awdInstance){
        AwdInstance retAwdInstance = new AwdInstance();
        retAwdInstance.setBusinessArea(awdInstance.getBusinessArea());
        // Mapping the comments
        if(awdInstance.getComments() != null) {
            retAwdInstance.setComments(retMapComments(awdInstance.getComments()));
        }
        retAwdInstance.setCreateTime(awdInstance.getCreateTime());
        retAwdInstance.setCustomScreen(awdInstance.getCustomScreen());
        // Mapping the external system
        if(awdInstance.getExternalSystems() != null) {
            retAwdInstance.setExternalSystems(retMapExternalSystems(awdInstance.getExternalSystems()));
        }
        // Mapping the field values
        if(awdInstance.getFieldValues() != null) {
            retAwdInstance.setFieldValues(retMapFieldValues(awdInstance.getFieldValues()));
        }
        retAwdInstance.setIconName(awdInstance.getIconName());
        retAwdInstance.setId(awdInstance.getId());
        retAwdInstance.setLockedBy(awdInstance.getLockedBy());
        retAwdInstance.setPermission(awdInstance.getPermission());
        retAwdInstance.setTagLine(awdInstance.getTagLine());
        retAwdInstance.setType(awdInstance.getType());
        if(awdInstance.getSystemEventOrQualityEventOrKeEvent() != null) {
            retAwdInstance.setKeEventOrQualityEventOrSystemEvent(retMapSystemEvent(awdInstance.getSystemEventOrQualityEventOrKeEvent()));
        }
        return retAwdInstance;
    }

    /**
     * Ret map source awd instance awd instance.
     *
     * @param awdInstance the awd instance
     *
     * @return the awd instance
     */
// TODO reuse
    public AwdInstance retMapSourceAWDInstance(com.dstawd.processing.ws.FolderInstance awdInstance){
        AwdInstance retAwdInstance = new AwdInstance();
        retAwdInstance.setBusinessArea(awdInstance.getBusinessArea());
        // Mapping the comments
        if(awdInstance.getComments() != null) {
            retAwdInstance.setComments(retMapComments(awdInstance.getComments()));
        }
        retAwdInstance.setCreateTime(awdInstance.getCreateTime());
        retAwdInstance.setCustomScreen(awdInstance.getCustomScreen());
        // Mapping the external system
        if(awdInstance.getExternalSystems() != null) {
            retAwdInstance.setExternalSystems(retMapExternalSystems(awdInstance.getExternalSystems()));
        }
        // Mapping the field values
        if(awdInstance.getFieldValues() != null) {
            retAwdInstance.setFieldValues(retMapFieldValues(awdInstance.getFieldValues()));
        }
        retAwdInstance.setIconName(awdInstance.getIconName());
        retAwdInstance.setId(awdInstance.getId());
        retAwdInstance.setLockedBy(awdInstance.getLockedBy());
        retAwdInstance.setPermission(awdInstance.getPermission());
        retAwdInstance.setTagLine(awdInstance.getTagLine());
        retAwdInstance.setType(awdInstance.getType());
        if(awdInstance.getSystemEventOrQualityEventOrKeEvent() != null) {
            retAwdInstance.setKeEventOrQualityEventOrSystemEvent(retMapSystemEvent(awdInstance.getSystemEventOrQualityEventOrKeEvent()));
        }
        return retAwdInstance;
    }

    /**
     * Ret map comments comments.
     *
     * @param awdComments the awd comments
     *
     * @return the comments
     */
// TODO Reuse
    public Comments retMapComments(com.dstawd.processing.ws.AwdInstance.Comments awdComments){
        Comments retComments = new Comments();
        List<Comment> retCommentList = null;
        Comment retComment = null;
        if(awdComments.getComment() != null){
            List<com.dstawd.processing.ws.Comment> awdCommentList = awdComments.getComment();
            retCommentList = new ArrayList<>();
            for(int i =0; i<awdCommentList.size(); i++){
                retComment = new Comment();
                com.dstawd.processing.ws.Comment awdComment = awdCommentList.get(i);
                retComment.setText(awdComment.getText());
                retComment.setTime(awdComment.getTime());
                retComment.setType(awdComment.getType());
                retComment.setUserId(awdComment.getUserId());
                retComment.setUserName(awdComment.getUserName());
                retCommentList.add(retComment);
            }
        }

        retComments.setComment(retCommentList);
        return  retComments;
    }

    /**
     * Ret map system event list.
     *
     * @param awdEventList the awd event list
     *
     * @return the list
     */
// TODO Reuse
    public List<Object> retMapSystemEvent(List<com.dstawd.processing.ws.AwdEvent> awdEventList){

        List<Object> retObjectList = new ArrayList<>();
        if(awdEventList != null){

            for(int i=0; i<awdEventList.size(); i++){
                com.dstawd.processing.ws.AwdEvent awdEvent = awdEventList.get(i);

                if(awdEvent instanceof com.dstawd.processing.ws.SystemEvent){
                    SystemEvent retSystemEvent = new SystemEvent();
                    AwdEvent retAWDEvent  = new AwdEvent();
                    Event retEvent = new Event();
                    retSystemEvent.setPriority(((com.dstawd.processing.ws.SystemEvent) awdEvent).getPriority());
                    retSystemEvent.setQualitySampled(((com.dstawd.processing.ws.SystemEvent) awdEvent).getQualitySampled());
                    retSystemEvent.setSamplingMethod(((com.dstawd.processing.ws.SystemEvent) awdEvent).getSamplingMethod());
                    retSystemEvent.setUserExperienceLevel(((com.dstawd.processing.ws.SystemEvent) awdEvent).getUserExperienceLevel());
                    retAWDEvent.setBusinessArea(awdEvent.getBusinessArea());
                    retEvent.setBeginTime(awdEvent.getBeginTime());
                    retEvent.setEndTime(awdEvent.getEndTime());
                    retAWDEvent.setEvent(retEvent);
                    retAWDEvent.setQueue(awdEvent.getQueue());
                    retAWDEvent.setType(awdEvent.getType());
                    retAWDEvent.setUserId(awdEvent.getUserId());
                    retAWDEvent.setUserName(awdEvent.getUserName());
                    retAWDEvent.setWorkStep(awdEvent.getWorkStep());
                    retSystemEvent.setAwdEvent(retAWDEvent);

                    retObjectList.add(retSystemEvent);
                } else if(awdEvent instanceof com.dstawd.processing.ws.QualityEvent){
                    QualityEvent retQualityEvent = new QualityEvent();
                    AwdEvent retAWDEvent  = new AwdEvent();
                    Event retEvent = new Event();

                    retAWDEvent.setBusinessArea(awdEvent.getBusinessArea());
                    retEvent.setBeginTime(awdEvent.getBeginTime());
                    retEvent.setEndTime(awdEvent.getEndTime());
                    retAWDEvent.setEvent(retEvent);
                    retAWDEvent.setQueue(awdEvent.getQueue());
                    retAWDEvent.setType(awdEvent.getType());
                    retAWDEvent.setUserId(awdEvent.getUserId());
                    retAWDEvent.setUserName(awdEvent.getUserName());
                    retAWDEvent.setWorkStep(awdEvent.getWorkStep());

                    retQualityEvent.setAwdEvent(retAWDEvent);
                    retQualityEvent.setDeleteErrorTime(((com.dstawd.processing.ws.QualityEvent) awdEvent).getDeleteErrorTime());
                    retQualityEvent.setDeleteUserId(awdEvent.getUserId());
                    retQualityEvent.setReviewDay(((com.dstawd.processing.ws.QualityEvent) awdEvent).getReviewDay());
                    retQualityEvent.setReviewTime(((com.dstawd.processing.ws.QualityEvent) awdEvent).getReviewTime());
                    retQualityEvent.setReviewUserId(((com.dstawd.processing.ws.QualityEvent) awdEvent).getReviewUserId());
                    retQualityEvent.setVIP(((com.dstawd.processing.ws.QualityEvent) awdEvent).getVIP());
                    retQualityEvent.setReviewUserName(((com.dstawd.processing.ws.QualityEvent) awdEvent).getReviewUserName());
                    retObjectList.add(retQualityEvent);
                }else if(awdEvent instanceof com.dstawd.processing.ws.KeEvent){
                    KeEvent retKeEvent = new KeEvent();

                    retObjectList.add(retKeEvent);
                   /* retKeEvent.setDescription(awdEvent.);
                    retKeEvent.setJobName(awdEvent.get);
                    retKeEvent.setNextTaskName();
                    retKeEvent.setReturnCode();
                    retKeEvent.setSystemEvent();
                    retKeEvent.setTaskName();
                    retObjectList.add(retKeEvent);*/
                }
            }

        }
        return retObjectList;
    }

    /**
     * Ret map external systems external systems.
     *
     * @param awdExternalSystems the awd external systems
     *
     * @return the external systems
     */
// TODO reuse
    public ExternalSystems retMapExternalSystems(com.dstawd.processing.ws.AwdInstance.ExternalSystems awdExternalSystems){
        ExternalSystems retExternalSystems = new ExternalSystems();
        List<ExternalSystem> retExternalSystemList = null;
        ExternalSystem retExternalSystem = null;
        if(awdExternalSystems != null){
            retExternalSystemList = new ArrayList<>();
            List<com.dstawd.processing.ws.ExternalSystem> awdexternalSystemList = awdExternalSystems.getExternalSystem();
            for(int i=0; i<awdexternalSystemList.size(); i++){
                com.dstawd.processing.ws.ExternalSystem awdExternalSystem = awdexternalSystemList.get(i);
                retExternalSystem = new ExternalSystem();
                retExternalSystem.setExternalDLL(awdExternalSystem.getExternalDLL());
                retExternalSystem.setExternalHost(awdExternalSystem.getExternalHost());
                retExternalSystem.setExternalParameter(awdExternalSystem.getExternalParameter());
                retExternalSystem.setExternalProcedure(awdExternalSystem.getExternalProcedure());
                retExternalSystem.setOrder(awdExternalSystem.getOrder());
                retExternalSystemList.add(retExternalSystem);
            }

            retExternalSystems.setExternalSystem(retExternalSystemList);
        }

        return retExternalSystems;
    }

    /**
     * Ret map awd suspend suspended.
     *
     * @param inSuspended the in suspended
     *
     * @return the suspended
     */
//TODO Reuse
    public Suspended retMapAWDSuspend(com.dstawd.processing.ws.Suspended inSuspended){
        Suspended retSuspended = new Suspended();
        retSuspended.setActivationDate(inSuspended.getActivationDate());
        retSuspended.setActivationRoutingStatus(inSuspended.getActivationRoutingStatus());
        retSuspended.setReasonCode(inSuspended.getReasonCode());
        return retSuspended;
    }

    /**
     * Ret map work flow work flow.
     *
     * @param inWorkFlow the in work flow
     *
     * @return the work flow
     */
// TODO reuse
    public WorkFlow retMapWorkFlow(com.dstawd.processing.ws.WorkFlow inWorkFlow){
        WorkFlow retWorkFlow = new WorkFlow();

        List<WorkSteps> retWorkStepsList = null;
        WorkSteps retWorkSteps = null;
        retWorkFlow.setRoute(inWorkFlow.getRoute());
        if(inWorkFlow != null && inWorkFlow.getWorkSteps() != null){
            retWorkStepsList = new ArrayList<>();
            for(int i=0; i< inWorkFlow.getWorkSteps().size(); i++){
                WorkStep workStep = inWorkFlow.getWorkSteps().get(i);
                retWorkSteps = new WorkSteps();
                retWorkSteps.setBusinessArea(workStep.getBusinessArea());
                retWorkSteps.setNext(workStep.getNext());
                retWorkSteps.setStatus(workStep.getStatus());
                retWorkSteps.setWorkType(workStep.getWorkType());
                retWorkStepsList.add(retWorkSteps);
            }
            retWorkFlow.setWorkSteps(retWorkStepsList);
        }

        return retWorkFlow;
    }

    /**
     * Map immediate relationships get objects response . immediate relationships.
     *
     * @param immediateRelationships the immediate relationships
     *
     * @return the get objects response . immediate relationships
     */
//TODO Reuse
    public GetObjectsResponse.ImmediateRelationships mapImmediateRelationships(com.dstawd.processing.ws.GetObjectsResponse.ImmediateRelationships immediateRelationships){

        GetObjectsResponse.ImmediateRelationships retImmediateRelationships = new GetObjectsResponse.ImmediateRelationships();

        if(immediateRelationships != null){

            List<com.dstawd.processing.ws.RelateOnlyExistingObjects> awdRelateObjectList = immediateRelationships.getRelateObjects();
            List<RelateOnlyExistingObjects> retRelateObjectList = null;
            if(awdRelateObjectList != null && awdRelateObjectList.size() >0){
                retRelateObjectList = new ArrayList<>();
                RelateOnlyExistingObjects retRelateOnlyExistingObj;
                for(int i=0; i< awdRelateObjectList.size(); i++) {
                    com.dstawd.processing.ws.RelateOnlyExistingObjects relateOnlyExistingObjects = awdRelateObjectList.get(i);
                    retRelateOnlyExistingObj = new RelateOnlyExistingObjects();
                    retRelateOnlyExistingObj.setChildId(relateOnlyExistingObjects.getChildId());
                    retRelateOnlyExistingObj.setParentId(relateOnlyExistingObjects.getParentId());
                    retRelateObjectList.add(retRelateOnlyExistingObj);
                }
            }

            retImmediateRelationships.setRelateObjects(retRelateObjectList);
        }

        return retImmediateRelationships;
    }

    /**
     * Map response details com . dstawd . processing . ws . response details.
     *
     * @param inputResponseDetails the input response details
     *
     * @return the com . dstawd . processing . ws . response details
     */
// Method to Map the Response Details in the Input Mapping
    // TODO reuse this method
    public com.dstawd.processing.ws.ResponseDetails mapResponseDetails(ResponseDetails inputResponseDetails) {
        com.dstawd.processing.ws.ResponseDetails responseDetails = new com.dstawd.processing.ws.ResponseDetails();
        if (inputResponseDetails != null) {
            responseDetails.setShowAll(inputResponseDetails.getShowAll());
            responseDetails.setShowComments(inputResponseDetails.getShowComments());
            responseDetails.setShowEvents(inputResponseDetails.getShowEvents());
            responseDetails.setShowAll(inputResponseDetails.getShowAll());
            responseDetails.setShowInstanceData(inputResponseDetails.getShowInstanceData());
            responseDetails.setShowNone(inputResponseDetails.getShowNone());
            responseDetails.setShowOnlyControlData(inputResponseDetails.getShowOnlyControlData());
            responseDetails.setShowWorkflow(inputResponseDetails.getShowWorkflow());
            responseDetails.setShowRelationships(inputResponseDetails.getShowRelationships());
        }
        return responseDetails;
    }

    /**
     * Ret map field values field values.
     *
     * @param awdFieldValues the awd field values
     *
     * @return the field values
     */
//TODO reuse
    public FieldValues retMapFieldValues(com.dstawd.processing.ws.AwdInstance.FieldValues awdFieldValues){
        FieldValues retFieldValues = new FieldValues();
        List<com.dstawd.processing.ws.FieldValue> awdFieldValueList = null;
        List<FieldValue>  retFieldValuesList = null;
        FieldValue retFieldValue = null;
        if(awdFieldValues != null && awdFieldValues.getFieldValue() != null){
            awdFieldValueList = awdFieldValues.getFieldValue();
            retFieldValuesList = new ArrayList<>();
            for(int i=0; i<awdFieldValueList.size(); i++){
                retFieldValue = new FieldValue();
                com.dstawd.processing.ws.FieldValue awdFiledValue = awdFieldValueList.get(i);

                retFieldValue.setName(awdFiledValue.getName());
                retFieldValue.setSequence(awdFiledValue.getSequence());
                retFieldValue.setValue(awdFiledValue.getValue());

                retFieldValuesList.add(retFieldValue);
            }
        }
        retFieldValues.setFieldValue(retFieldValuesList);
        return retFieldValues;
    }

}
