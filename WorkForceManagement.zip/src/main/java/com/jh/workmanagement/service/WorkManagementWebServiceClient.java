package com.jh.workmanagement.service;


import com.dstawd.processing.ws.*;
import com.jh.common.logging.LoggerHandler;
import com.jh.workmanagement.config.SecurityHeader;
import com.jh.workmanagement.exception.TechnicalErrorException;
import com.jh.workmanagement.utils.LoggerUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;
import org.springframework.ws.client.core.support.WebServiceGatewaySupport;

import javax.xml.bind.JAXBElement;
import java.lang.Exception;

/**
 * The type Work management web service client.
 */
@Component
public class WorkManagementWebServiceClient extends WebServiceGatewaySupport {

    @Autowired
    private Environment env;

    @Autowired
    private LoggerUtils loggerUtils;

    /**
     * Invoke create web service create objects response.
     *
     * @param businessAreaStr  the business area str
     * @param messageUUID      the message uuid
     * @param sourceSystemName the source system name
     * @param createObjects    the create objects
     *
     * @return the create objects response
     */
    public CreateObjectsResponse invokeCreateWebService(String businessAreaStr, String messageUUID, String sourceSystemName, CreateObjects createObjects) {

        LoggerHandler.LogOut("INFO", "3", "messageUUID", "sourceSystemName", this.getClass().getName(),
                "Entering Webservice Client  " + loggerUtils.writeAsJson(createObjects));

        String userId = env.getProperty(businessAreaStr+".UserID");
        String endUrl = env.getProperty(businessAreaStr+".endpointURL");

        AuthorizationInfo authorizationInfo = new AuthorizationInfo();
        authorizationInfo.setUserId(userId);
        JAXBElement<CreateObjectsResponse> root = null;
        try {
            root = (JAXBElement<CreateObjectsResponse>) getWebServiceTemplate()
                    .marshalSendAndReceive(endUrl, createObjects, new SecurityHeader(authorizationInfo));

            LoggerHandler.LogOut("INFO", "4", "messageUUID", "sourceSystemName", this.getClass().getName(),
                    "Exiting Webservice Client  " + loggerUtils.writeAsJson(root));

        } catch (Exception e) {
            throw new TechnicalErrorException("Technical Error",e.getCause());
        }

        return root.getValue();
    }


    /**
     * Invoke update web service update objects response.
     *
     * @param businessAreaStr      the business area str
     * @param messageUUID          the message uuid
     * @param sourceSystemName     the source system name
     * @param updateObjectsRequest the update objects request
     *
     * @return the update objects response
     */
    public UpdateObjectsResponse invokeUpdateWebService(String businessAreaStr, String messageUUID, String sourceSystemName, UpdateObjects updateObjectsRequest) {

        LoggerHandler.LogOut("INFO", "3b", "messageUUID", "sourceSystemName", this.getClass().getName(),
                "Entering Webservice Client  " + loggerUtils.writeAsJson(updateObjectsRequest));

        String userId = env.getProperty(businessAreaStr+".UserID");
        String endUrl = env.getProperty(businessAreaStr+".endpointURL");


        AuthorizationInfo authorizationInfo = new AuthorizationInfo();
        authorizationInfo.setUserId(userId);
        JAXBElement<UpdateObjectsResponse> root = null;
        try {
            root = (JAXBElement<UpdateObjectsResponse>) getWebServiceTemplate()
                    .marshalSendAndReceive(endUrl, updateObjectsRequest, new SecurityHeader(authorizationInfo));

            LoggerHandler.LogOut("INFO", "4b", "messageUUID", "sourceSystemName", this.getClass().getName(),
                    "Exiting Webservice Client  " + loggerUtils.writeAsJson(root));
        } catch (Exception e) {
            throw new TechnicalErrorException("Technical Error",e.getCause());
        }

        return root.getValue();
    }


    /**
     * Invoke retrieve service retrieve objects response.
     *
     * @param businessAreaStr    the business area str
     * @param messageUUID        the message uuid
     * @param sourceSystemName   the source system name
     * @param retrieveObjectsReq the retrieve objects req
     *
     * @return the retrieve objects response
     */
    public RetrieveObjectsResponse invokeRetrieveService(String businessAreaStr, String messageUUID, String sourceSystemName, RetrieveObjects retrieveObjectsReq) {

        LoggerHandler.LogOut("INFO", "3", "messageUUID", "sourceSystemName", this.getClass().getName(),
                "Entering Webservice Client  " + loggerUtils.writeAsJson(retrieveObjectsReq));

        String userId = env.getProperty(businessAreaStr+".UserID");
        String endUrl = env.getProperty(businessAreaStr+".endpointURL");


        AuthorizationInfo authorizationInfo = new AuthorizationInfo();
        authorizationInfo.setUserId(userId);
        JAXBElement<RetrieveObjectsResponse> root = null;

        try {
            root = (JAXBElement<RetrieveObjectsResponse>) getWebServiceTemplate()
                    .marshalSendAndReceive(endUrl, retrieveObjectsReq, new SecurityHeader(authorizationInfo));

            LoggerHandler.LogOut("INFO", "4", "messageUUID", "sourceSystemName", this.getClass().getName(),
                    "Exiting Webservice Client  " + loggerUtils.writeAsJson(root));
        } catch (Exception e) {
            throw new TechnicalErrorException("Technical Error",e.getCause());
        }

        return root.getValue();
    }


    /**
     * Invoke update lock service update objects response.
     *
     * @param businessAreaStr      the business area str
     * @param messageUUID          the message uuid
     * @param sourceSystemName     the source system name
     * @param updateObjectsRequest the update objects request
     *
     * @return the update objects response
     */
    public UpdateObjectsResponse invokeUpdateLockService(String businessAreaStr, String messageUUID, String sourceSystemName, UpdateObjects updateObjectsRequest) {

        LoggerHandler.LogOut("INFO", "3a", "messageUUID", "sourceSystemName", this.getClass().getName(),
                "Entering Webservice Client  " + loggerUtils.writeAsJson(updateObjectsRequest));

        String userId = env.getProperty(businessAreaStr+".UserID");
        String endUrl = env.getProperty(businessAreaStr+".endpointURL");

        AuthorizationInfo authorizationInfo = new AuthorizationInfo();
        authorizationInfo.setUserId(userId);
        JAXBElement<UpdateObjectsResponse> root = null;
        try {
            root = (JAXBElement<UpdateObjectsResponse>) getWebServiceTemplate()
                    .marshalSendAndReceive(endUrl, updateObjectsRequest, new SecurityHeader(authorizationInfo));

            LoggerHandler.LogOut("INFO", "4a", "messageUUID", "sourceSystemName", this.getClass().getName(),
                    "Exiting Webservice Client  " + loggerUtils.writeAsJson(root));

        } catch (Exception e) {
            throw new TechnicalErrorException("Technical Error",e.getCause());
        }

        return root.getValue();
    }



}
