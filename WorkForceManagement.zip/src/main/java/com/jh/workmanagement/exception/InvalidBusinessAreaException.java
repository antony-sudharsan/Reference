package com.jh.workmanagement.exception;

/**
 * The type Invalid business area exception.
 */
public class InvalidBusinessAreaException extends BaseFaultException {
	private static final long serialVersionUID = -6016805724195451879L;

	private static final String DEFAULT_CODE = "BIZ-DATA-E5000";
	private static final String DEFAULT_REASON = "Invalid Business Area-Invalid Business Area";
	private static final String DEFAULT_DETAILS = "Invalid Business Area-Invalid Business Area";
	private static final String FAULT_STRING = "Internal Error";

    /**
     * Instantiates a new Invalid business area exception.
     */
    public InvalidBusinessAreaException() {
		super(DEFAULT_CODE, DEFAULT_REASON, DEFAULT_DETAILS, FAULT_STRING);
	}

}
