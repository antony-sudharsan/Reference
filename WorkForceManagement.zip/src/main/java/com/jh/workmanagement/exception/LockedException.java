package com.jh.workmanagement.exception;

/**
 * The type Invalid business type exception.
 */
public class LockedException extends BaseFaultException {
	private static final long serialVersionUID = -6016805724195451879L;

	private static final String DEFAULT_CODE = "BIZ-DATA-E5501";
	private static final String DEFAULT_REASON = "Record is Locked";
	private static final String DEFAULT_DETAILS = "Record is Locked";
	private static final String FAULT_STRING = "Internal Error";

	/**
	 * Instantiates a new Invalid business type exception.
	 */
	public LockedException() {
		super(DEFAULT_CODE, DEFAULT_REASON, DEFAULT_DETAILS, FAULT_STRING);
	}

}
