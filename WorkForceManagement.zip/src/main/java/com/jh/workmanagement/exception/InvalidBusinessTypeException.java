package com.jh.workmanagement.exception;

/**
 * The type Invalid business type exception.
 */
public class InvalidBusinessTypeException extends BaseFaultException {
	private static final long serialVersionUID = -6016805724195451879L;

	private static final String DEFAULT_CODE = "BIZ-DATA-E5500";
	private static final String DEFAULT_REASON = "Invalid type supplied for business area";
	private static final String DEFAULT_DETAILS = "Invalid type supplied for business area";
	private static final String FAULT_STRING = "Internal Error";

    /**
     * Instantiates a new Invalid business type exception.
     */
    public InvalidBusinessTypeException() {
		super(DEFAULT_CODE, DEFAULT_REASON, DEFAULT_DETAILS, FAULT_STRING);
	}

}
