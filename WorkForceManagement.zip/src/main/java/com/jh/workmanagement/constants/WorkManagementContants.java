package com.jh.workmanagement.constants;

/**
 * The type Work management contants.
 */
public class WorkManagementContants {

    // ####### Error Messages #####################


    /**
     * The constant TECHNICAL_ERROR_REASON.
     */
    public static String TECHNICAL_ERROR_REASON = "Technical Error";
    /**
     * The constant INVALID_INPUT_ERROR_REASON.
     */
    public static String INVALID_INPUT_ERROR_REASON = "Invalid Input";
    /**
     * The constant TIMEOUT_ERROR_REASON.
     */
    public static String TIMEOUT_ERROR_REASON = "Service Timedout";
    /**
     * The constant NO_RECORD_FOUND_ERROR_REASON.
     */
    public static String NO_RECORD_FOUND_ERROR_REASON = "No Data Found";
    /**
     * The constant MAX_RECORD_ERROR_REASON.
     */
    public static String MAX_RECORD_ERROR_REASON = "Max Result Limit Encountered";

    /**
     * The constant ValidationExceptionMessage_LockUpdate.
     */
    public static String ValidationExceptionMessage_LockUpdate="Lock Update Request failed for Specified Work Instance";
    /**
     * The constant ValidationExceptionMessage_LockAuthorise.
     */
    public static String ValidationExceptionMessage_LockAuthorise="The Work Instance is currently not locked by Authorised User";
    /**
     * The constant ValidationExceptionMessage_BusinessArea.
     */
    public static String ValidationExceptionMessage_BusinessArea="Business Area Validation Failed";
    /**
     * The constant NotFoundExceptionMessage.
     */
    public static String NotFoundExceptionMessage="Backend AWD Service is Not Reachable";
    /**
     * The constant RequestTimeoutExceptionMessage.
     */
    public static String RequestTimeoutExceptionMessage="Request Timeout from Backend";
    /**
     * The constant InternalServerErrorExceptionMessage.
     */
    public static String InternalServerErrorExceptionMessage="Internal Server Error";
    /**
     * The constant AWDRecordNotFoundExceptionMessage.
     */
    public static String AWDRecordNotFoundExceptionMessage="AWD Instance Record not found";
    /**
     * The constant BackendErrorExceptionMessage.
     */
    public static String BackendErrorExceptionMessage="AWD Backend returned an error";
    /**
     * The constant BackendValidationExceptionMessage.
     */
    public static String BackendValidationExceptionMessage="AWD Backend returned validation exception";
    /**
     * The constant UnauthorizedExceptionMessage.
     */
    public static String UnauthorizedExceptionMessage="Unauthorized to perform operation";
    /**
     * The constant GeneralApplicationExceptionMessage.
     */
    public static String GeneralApplicationExceptionMessage="Service Processing Error";

    // ####### Error Codes #####################

    /**
     * The constant TECHNICAL_ERROR_CODE.
     */
    public static String TECHNICAL_ERROR_CODE = "9999";
    /**
     * The constant INVALID_INPUT_ERROR_CODE.
     */
    public static String INVALID_INPUT_ERROR_CODE = "993";
    /**
     * The constant TIMEOUT_ERROR_CODE.
     */
    public static String TIMEOUT_ERROR_CODE = "99999";
    /**
     * The constant NO_RECORD_FOUND_ERROR_CODE.
     */
    public static String NO_RECORD_FOUND_ERROR_CODE = "999";
    /**
     * The constant MAX_RECORD_ERROR_CODE.
     */
    public static String MAX_RECORD_ERROR_CODE = "998";

    /**
     * Instantiates a new Work management contants.
     */
    public WorkManagementContants() {
    }
}
