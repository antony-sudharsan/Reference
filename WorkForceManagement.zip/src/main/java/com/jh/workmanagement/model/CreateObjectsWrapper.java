package com.jh.workmanagement.model;

import com.manulife.esb.xsd.common.jh.header.JHHeader;
import com.manulife.esb.xsd.jh.workmanagement.CreateObjects;

/**
 * The type Create objects wrapper.
 */
public class CreateObjectsWrapper {
    private CreateObjects createObjects;
    private JHHeader header;

    /**
     * Gets create objects.
     *
     * @return the create objects
     */
    public CreateObjects getCreateObjects() {
        return createObjects;
    }

    /**
     * Sets create objects.
     *
     * @param createObjects the create objects
     */
    public void setCreateObjects(CreateObjects createObjects) {
        this.createObjects = createObjects;
    }

    /**
     * Gets header.
     *
     * @return the header
     */
    public JHHeader getHeader() {
        return header;
    }

    /**
     * Sets header.
     *
     * @param header the header
     */
    public void setHeader(JHHeader header) {
        this.header = header;
    }
}
