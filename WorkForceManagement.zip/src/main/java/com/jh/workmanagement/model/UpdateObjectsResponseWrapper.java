package com.jh.workmanagement.model;

import com.manulife.esb.xsd.common.jh.header.JHHeader;
import com.manulife.esb.xsd.jh.workmanagement.UpdateObjects;
import com.manulife.esb.xsd.jh.workmanagement.UpdateObjectsResponse;

/**
 * The type Update objects response wrapper.
 */
public class UpdateObjectsResponseWrapper {
    private JHHeader header;
    private UpdateObjectsResponse updateObjects;

    /**
     * Gets header.
     *
     * @return the header
     */
    public JHHeader getHeader() {
        return header;
    }

    /**
     * Sets header.
     *
     * @param header the header
     */
    public void setHeader(JHHeader header) {
        this.header = header;
    }

    /**
     * Gets update objects.
     *
     * @return the update objects
     */
    public UpdateObjectsResponse getUpdateObjects() {
        return updateObjects;
    }

    /**
     * Sets update objects.
     *
     * @param updateObjects the update objects
     */
    public void setUpdateObjects(UpdateObjectsResponse updateObjects) {
        this.updateObjects = updateObjects;
    }
}
