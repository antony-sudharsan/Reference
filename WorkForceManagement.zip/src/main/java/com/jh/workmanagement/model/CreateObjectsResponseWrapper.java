package com.jh.workmanagement.model;

import com.manulife.esb.xsd.common.jh.header.JHHeader;
import com.manulife.esb.xsd.jh.workmanagement.CreateObjectsResponse;

/**
 * The type Create objects response wrapper.
 */
public class CreateObjectsResponseWrapper {

    private JHHeader header;
    private CreateObjectsResponse createObjectsResponse;

    /**
     * Gets header.
     *
     * @return the header
     */
    public JHHeader getHeader() {
        return header;
    }

    /**
     * Sets header.
     *
     * @param header the header
     */
    public void setHeader(JHHeader header) {
        this.header = header;
    }

    /**
     * Gets create objects response.
     *
     * @return the create objects response
     */
    public CreateObjectsResponse getCreateObjectsResponse() {
        return createObjectsResponse;
    }

    /**
     * Sets create objects response.
     *
     * @param createObjectsResponse the create objects response
     */
    public void setCreateObjectsResponse(CreateObjectsResponse createObjectsResponse) {
        this.createObjectsResponse = createObjectsResponse;
    }


}
