package com.jh.workmanagement.model;

import com.manulife.esb.xsd.common.jh.header.JHHeader;
import com.manulife.esb.xsd.jh.workmanagement.UpdateObjects;

/**
 * The type Update objects wrapper.
 */
public class UpdateObjectsWrapper {
    private JHHeader header;
    private UpdateObjects updateObjects;

    /**
     * Gets header.
     *
     * @return the header
     */
    public JHHeader getHeader() {
        return header;
    }

    /**
     * Sets header.
     *
     * @param header the header
     */
    public void setHeader(JHHeader header) {
        this.header = header;
    }

    /**
     * Gets update objects.
     *
     * @return the update objects
     */
    public UpdateObjects getUpdateObjects() {
        return updateObjects;
    }

    /**
     * Sets update objects.
     *
     * @param updateObjects the update objects
     */
    public void setUpdateObjects(UpdateObjects updateObjects) {
        this.updateObjects = updateObjects;
    }
}
