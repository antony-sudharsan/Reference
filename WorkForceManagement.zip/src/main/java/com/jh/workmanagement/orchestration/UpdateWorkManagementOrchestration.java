package com.jh.workmanagement.orchestration;

import com.jh.common.logging.LoggerHandler;
import com.jh.workmanagement.exception.InvalidBusinessAreaException;
import com.jh.workmanagement.exception.InvalidBusinessTypeException;
import com.jh.workmanagement.exception.LockedException;
import com.jh.workmanagement.mapper.WorkManagementMapperHelper;
import com.jh.workmanagement.model.UpdateObjectsResponseWrapper;
import com.jh.workmanagement.service.WorkManagementWebServiceClient;
import com.jh.workmanagement.utils.LoggerUtils;
import com.jh.workmanagement.utils.LoggingContextHolder;
import com.jh.workmanagement.validator.WorkManagementValidator;
import com.manulife.esb.wsdl.wealth.pfs.workmanagement_1.WorkManagementFault;
import com.manulife.esb.xsd.common.jh.header.JHHeader;
import com.manulife.esb.xsd.common.jh.header.Status;
import com.manulife.esb.xsd.jh.workmanagement.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.lang.Exception;
import java.util.ArrayList;
import java.util.List;

/**
 * The type Update work management orchestration.
 */
@Component
public class UpdateWorkManagementOrchestration {

    @Autowired
    private LoggerUtils loggerUtils;

    /**
     * The Work management validator.
     */
    @Autowired
    WorkManagementValidator workManagementValidator;


    /**
     * The Work management mapper helper.
     */
    @Autowired
    WorkManagementMapperHelper workManagementMapperHelper;

    /**
     * The Work management web service client.
     */
    @Autowired
    WorkManagementWebServiceClient workManagementWebServiceClient;

    /**
     * Update work management update objects response wrapper.
     *
     * @param header  the header
     * @param request the request
     *
     * @return the update objects response wrapper
     *
     * @throws WorkManagementFault the work management fault
     * @throws Exception           the exception
     */
    public UpdateObjectsResponseWrapper updateWorkManagement(JHHeader header, UpdateObjects request) throws WorkManagementFault, Exception {

        /**
         * The logic is as in TICBO
         *
         * 1. Get the Business Area and Validate it, else throw exception
         * 2. Map the Retrieve input Object from the UpdateObjects request
         * 3. Invoke the invokeRetrieveService with the input object mapped in Step2
         * 4. Validate the whether any lock is present in the Retrieve Object, if locked throw LockedException
         * 5. Place a lock into the object using the invokeUpdateLockService
         * 6. Validate the response from the Step 5
         * 7. Now update the request object with the Lock status as "N"
         * 8. Update the Object by invoking the invokeUpdateWebService using the request in Step 7
         * 9. Map the Response to the SOAP response
         */
        final String messageUUID = LoggingContextHolder.getLoggingContext().getMessageUUID();
        final String sourceSystemName = LoggingContextHolder.getLoggingContext().getSourceSystemName();

        UpdateObjectsResponseWrapper updateObjectsResponseWrapper = new UpdateObjectsResponseWrapper();

        LoggerHandler.LogOut("INFO", "2", "messageUUID", "sourceSystemName", this.getClass().getName(),
                "Entering Update Orchestration>> " + loggerUtils.writeAsJson(request));

        UpdateObjectsResponse updateObjectsResponse = new UpdateObjectsResponse();

        // Transformation of the Input Object
        com.dstawd.processing.ws.UpdateObjects  awdUpdateObjectReq = mapInput(request);



       // 1. Get the Business Area and Validate it, else throw exception
        String businessArea = getBusinessArea(request);
        if (!workManagementValidator.ValidateBusinessArea(businessArea)) {
            throw new InvalidBusinessAreaException();
        }

        if (workManagementValidator.ValidateUpdateBusinessType(request)) {
            throw new InvalidBusinessTypeException();
        }

        // 2. Map the Retrieve input Object from the UpdateObjects request
        com.dstawd.processing.ws.RetrieveObjects retrieveObjects = mapRetrieveRequest(request);

        LoggerHandler.LogOut("INFO", "2a", "messageUUID", "sourceSystemName", this.getClass().getName(),
                "Mapped retrieveObjects>> " + loggerUtils.writeAsJson(retrieveObjects));

        // 3. Invoke the invokeRetrieveService with the input object mapped in Step2
        com.dstawd.processing.ws.RetrieveObjectsResponse currentLockObjectAWDResponse = (com.dstawd.processing.ws.RetrieveObjectsResponse)
                workManagementWebServiceClient.invokeRetrieveService(businessArea, messageUUID, sourceSystemName, retrieveObjects);

        LoggerHandler.LogOut("INFO", "2b", "messageUUID", "sourceSystemName", this.getClass().getName(),
                "Reponse for retrieveObjects>> " + loggerUtils.writeAsJson(currentLockObjectAWDResponse));

        // 4. Validate the whether any lock is present in the Retrieve Object, if locked throw LockedException
        if (workManagementValidator.validateLock(currentLockObjectAWDResponse.getRetrieveObjectsResponse(),messageUUID,sourceSystemName) ){

            // 5. Place a lock into the object using the invokeUpdateLockService
            com.dstawd.processing.ws.UpdateObjectsResponse updateLockObjectAWDResponse = (com.dstawd.processing.ws.UpdateObjectsResponse)
                    workManagementWebServiceClient.invokeUpdateLockService(businessArea, messageUUID, sourceSystemName, awdUpdateObjectReq);

            // 6. Validate the response from the Step 5
            if (workManagementValidator.validateLockUpdateRequest(updateLockObjectAWDResponse.getUpdateObjectsResponse(), messageUUID,sourceSystemName)) {


                // 7. Now update the request object with the Lock status as "N"

                awdUpdateObjectReq = updateLockWorkInstance(awdUpdateObjectReq);

                // 8. Update the Object by invoking the invokeUpdateWebService using the request in Step 7

                com.dstawd.processing.ws.UpdateObjectsResponse updateObjectAWDResponse = (com.dstawd.processing.ws.UpdateObjectsResponse)
                        workManagementWebServiceClient.invokeUpdateWebService(businessArea, messageUUID, sourceSystemName, awdUpdateObjectReq);

                // 9. Map the Response to the SOAP response
                updateObjectsResponse = mapOutput(updateObjectAWDResponse.getUpdateObjectsResponse(), updateObjectsResponse);
            }

        }else{
                throw new LockedException();
        }

        Status status = new Status();
        status.setStatusCode(0);
        status.setStatusDescription("Completed");
        header.setStatus(status);
        LoggerHandler.LogOut("INFO", "5", "messageUUID", "sourceSystemName", this.getClass().getName(),
                "Existing Update Orchestration>> " + loggerUtils.writeAsJson(updateObjectsResponse));
        updateObjectsResponseWrapper.setHeader(header);
        updateObjectsResponseWrapper.setUpdateObjects(updateObjectsResponse);
        return updateObjectsResponseWrapper;
    }

    /**
     * Update lock work instance com . dstawd . processing . ws . update objects.
     *
     * @param awdUpdateObjectReq the awd update object req
     *
     * @return the com . dstawd . processing . ws . update objects
     */
    public com.dstawd.processing.ws.UpdateObjects updateLockWorkInstance(com.dstawd.processing.ws.UpdateObjects awdUpdateObjectReq) {

        com.dstawd.processing.ws.UpdateObjectRequest outUpdateObjectRequest =awdUpdateObjectReq.getUpdateObjectRequest();

        List<com.dstawd.processing.ws.UpdateAWDInstance> outUpdateAWDInstaceList = outUpdateObjectRequest.getUpdateWorkInstanceOrUpdateFolderInstanceOrUpdateSourceInstance();
        if(outUpdateAWDInstaceList != null) {
            for (int i = 0; i < outUpdateAWDInstaceList.size(); i++) {
                com.dstawd.processing.ws.UpdateAWDInstance updateAWDInstance = outUpdateAWDInstaceList.get(i);
                if(updateAWDInstance instanceof com.dstawd.processing.ws.UpdateWorkInstance){
                    updateAWDInstance.setLock("N");
                }
            }
        }
        return awdUpdateObjectReq;
    }

    /**
     * Map retrieve request com . dstawd . processing . ws . retrieve objects.
     *
     * @param request the request
     *
     * @return the com . dstawd . processing . ws . retrieve objects
     */
    public com.dstawd.processing.ws.RetrieveObjects mapRetrieveRequest(UpdateObjects request) {

        com.dstawd.processing.ws.RetrieveObjects retRetrieveObj = new com.dstawd.processing.ws.RetrieveObjects();
        com.dstawd.processing.ws.GetObjectsRequest getObjectsRequest = new com.dstawd.processing.ws.GetObjectsRequest();
        com.dstawd.processing.ws.GetObjectsRequest.ObjectRequests objectRequests = new com.dstawd.processing.ws.GetObjectsRequest.ObjectRequests();
        List<com.dstawd.processing.ws.GetObjectRequest> objectRequestList;

        com.dstawd.processing.ws.GetObjectRequest getObjectRequest = null;

        if (request.getUpdateObjectRequest().getUpdateFolderInstanceOrUpdateSourceInstanceOrUpdateWorkInstance() != null) {

            List<Object> awdInstancesList = request.getUpdateObjectRequest().getUpdateFolderInstanceOrUpdateSourceInstanceOrUpdateWorkInstance();

            if (awdInstancesList != null) {

                objectRequestList = new ArrayList<>();

                for (int i = 0; i < awdInstancesList.size(); i++) {

                    Object obj = awdInstancesList.get(i);

                    if (obj instanceof UpdateWorkInstance) {
                        UpdateWorkInstance updateWorkInstance = (UpdateWorkInstance) obj;
                        getObjectRequest = new com.dstawd.processing.ws.GetObjectRequest();
                        getObjectRequest.setId(updateWorkInstance.getUpdateAWDInstance().getId());
                        getObjectRequest.setLock("N");
                        objectRequestList.add(getObjectRequest);
                    }

                }

                objectRequests.setObjectRequest(objectRequestList);
            }

        }
        getObjectsRequest.setObjectRequests(objectRequests);
        retRetrieveObj.setGetObjectsRequest(getObjectsRequest);

        return retRetrieveObj;
    }

    /**
     * Gets business area.
     *
     * @param request the request
     *
     * @return the business area
     */
    public  String getBusinessArea(UpdateObjects request) {
        String businessArea = "";
        if (request.getUpdateObjectRequest().getUpdateFolderInstanceOrUpdateSourceInstanceOrUpdateWorkInstance() != null) {

            List<Object> awdInstancesList = request.getUpdateObjectRequest().getUpdateFolderInstanceOrUpdateSourceInstanceOrUpdateWorkInstance();

            if (awdInstancesList != null) {

                for (int i = 0; i < awdInstancesList.size(); i++) {

                    Object obj = awdInstancesList.get(i);

                    if (obj instanceof UpdateWorkInstance) {
                        UpdateWorkInstance updateWorkInstance = (UpdateWorkInstance) obj;

                        businessArea = updateWorkInstance.getUpdateAWDInstance().getBusinessArea().toUpperCase();

                    }

                }
            }

        }
        return businessArea;
    }

    /**
     * Map output update objects response.
     *
     * @param updateObjectAWDResponse the update object awd response
     * @param updateObjectsResponse   the update objects response
     *
     * @return the update objects response
     */
    public UpdateObjectsResponse mapOutput(com.dstawd.processing.ws.GetObjectsResponse updateObjectAWDResponse, UpdateObjectsResponse updateObjectsResponse){

        GetObjectsResponse objectsResponse = new GetObjectsResponse();

        if(updateObjectAWDResponse.getImmediateRelationships() != null){
            objectsResponse.setImmediateRelationships(workManagementMapperHelper.mapImmediateRelationships(updateObjectAWDResponse.getImmediateRelationships()));
        }
        objectsResponse.setFolderInstanceOrSourceInstanceOrWorkInstance(workManagementMapperHelper.returnMapAWDInstance(updateObjectAWDResponse.getWorkInstanceOrFolderInstanceOrSourceInstance()));

        updateObjectsResponse.setUpdateObjectsResponse(objectsResponse);
        return updateObjectsResponse;
    }


    /**
     * Map input com . dstawd . processing . ws . update objects.
     *
     * @param wmRequest the wm request
     *
     * @return the com . dstawd . processing . ws . update objects
     */
    public com.dstawd.processing.ws.UpdateObjects mapInput(UpdateObjects wmRequest) {

        com.dstawd.processing.ws.UpdateObjects outUpdateAWDRequest = new com.dstawd.processing.ws.UpdateObjects();

        com.dstawd.processing.ws.UpdateObjectRequest outUpdateObjectRequest = new com.dstawd.processing.ws.UpdateObjectRequest();

        if(wmRequest.getUpdateObjectRequest() != null && wmRequest.getUpdateObjectRequest().getResponseDetails() != null ) {
            outUpdateObjectRequest.setResponseDetails(workManagementMapperHelper.mapResponseDetails(wmRequest.getUpdateObjectRequest().getResponseDetails()));
        }

        outUpdateObjectRequest.setUpdateWorkInstanceOrUpdateFolderInstanceOrUpdateSourceInstance(mapAWDInstance(wmRequest.getUpdateObjectRequest().getUpdateFolderInstanceOrUpdateSourceInstanceOrUpdateWorkInstance()));

        outUpdateAWDRequest.setUpdateObjectRequest(outUpdateObjectRequest);

        return outUpdateAWDRequest;

    }

    /**
     * Map awd instance list.
     *
     * @param inputAWDInstanceList the input awd instance list
     *
     * @return the list
     */
    public List<com.dstawd.processing.ws.UpdateAWDInstance> mapAWDInstance(List<Object> inputAWDInstanceList) {

        List<com.dstawd.processing.ws.UpdateAWDInstance> outUpdateAWDInstaceList = new ArrayList<>();

        if (inputAWDInstanceList != null) {

            for (int i = 0; i < inputAWDInstanceList.size(); i++) {

                Object obj = inputAWDInstanceList.get(i);

                if (obj instanceof UpdateFolderInstance) {
                    UpdateFolderInstance inUpdateFolderInstance = (UpdateFolderInstance) obj;

                    com.dstawd.processing.ws.UpdateFolderInstance outUpdateFolderInstance = new com.dstawd.processing.ws.UpdateFolderInstance();

                    outUpdateFolderInstance.setType(inUpdateFolderInstance.getUpdateAWDInstance().getType());
                    outUpdateFolderInstance.setBusinessArea(inUpdateFolderInstance.getUpdateAWDInstance().getBusinessArea());
                    outUpdateFolderInstance.setId(inUpdateFolderInstance.getUpdateAWDInstance().getId());
                    outUpdateFolderInstance.setDuration(inUpdateFolderInstance.getUpdateAWDInstance().getDuration());
                    // Mapping the Field Value
                    outUpdateFolderInstance.setFieldValues(mapFieldValue(inUpdateFolderInstance.getUpdateAWDInstance().getFieldValues().getDeleteFieldValueOrFieldValue()));

                    outUpdateFolderInstance.setAddManualComment(inUpdateFolderInstance.getUpdateAWDInstance().getAddManualComment());
                    outUpdateFolderInstance.setLock(inUpdateFolderInstance.getUpdateAWDInstance().getLock());

                    outUpdateAWDInstaceList.add(outUpdateFolderInstance);

                } else if (obj instanceof UpdateSourceInstance) {
                    com.dstawd.processing.ws.UpdateSourceInstance outUpdateSourceInstance = new com.dstawd.processing.ws.UpdateSourceInstance();
                    UpdateSourceInstance inUpdateSourceInstance = (UpdateSourceInstance) obj;


                    outUpdateSourceInstance.setLock(inUpdateSourceInstance.getUpdateAWDInstance().getLock());
                    outUpdateSourceInstance.setAddManualComment(inUpdateSourceInstance.getUpdateAWDInstance().getAddManualComment());
                    outUpdateSourceInstance.setDuration(inUpdateSourceInstance.getUpdateAWDInstance().getDuration());
                    outUpdateSourceInstance.setId(inUpdateSourceInstance.getUpdateAWDInstance().getId());
                    outUpdateSourceInstance.setBusinessArea(inUpdateSourceInstance.getUpdateAWDInstance().getBusinessArea());
                    outUpdateSourceInstance.setType(inUpdateSourceInstance.getUpdateAWDInstance().getType());

                    // Map the FieldValues
                    outUpdateSourceInstance.setFieldValues(mapFieldValue(inUpdateSourceInstance.getUpdateAWDInstance().getFieldValues().getDeleteFieldValueOrFieldValue()));

                    outUpdateSourceInstance.setAccessMethod(inUpdateSourceInstance.getAccessMethod());
                    outUpdateSourceInstance.setAnnotationBlob(inUpdateSourceInstance.getAnnotationBlob());
                    outUpdateSourceInstance.setArchiveBox(inUpdateSourceInstance.getArchiveBox());
                    outUpdateSourceInstance.setArchiveStartPage(inUpdateSourceInstance.getArchiveStartPage());
                    outUpdateSourceInstance.setReceiveTime(inUpdateSourceInstance.getReceiveTime());


                    outUpdateSourceInstance.setFormat(inUpdateSourceInstance.getFormat());
                    outUpdateSourceInstance.setMailType(inUpdateSourceInstance.getMailType());
                    outUpdateSourceInstance.setPageCount(String.valueOf(inUpdateSourceInstance.getPageCount()));
                    outUpdateSourceInstance.setReceiveTime(inUpdateSourceInstance.getReceiveTime());
                    outUpdateSourceInstance.setSecurityLevel(inUpdateSourceInstance.getSecurityLevel());

                    outUpdateAWDInstaceList.add(outUpdateSourceInstance);

                } else if (obj instanceof UpdateWorkInstance) {
                    com.dstawd.processing.ws.UpdateWorkInstance outUpdateWorkInstance = new com.dstawd.processing.ws.UpdateWorkInstance();
                    UpdateWorkInstance inUpdateWorkInstance = (UpdateWorkInstance) obj;

                    outUpdateWorkInstance.setLock(inUpdateWorkInstance.getUpdateAWDInstance().getLock());
                    outUpdateWorkInstance.setAddManualComment(inUpdateWorkInstance.getUpdateAWDInstance().getAddManualComment());
                    outUpdateWorkInstance.setDuration(inUpdateWorkInstance.getUpdateAWDInstance().getDuration());
                    outUpdateWorkInstance.setId(inUpdateWorkInstance.getUpdateAWDInstance().getId());
                    outUpdateWorkInstance.setBusinessArea(inUpdateWorkInstance.getUpdateAWDInstance().getBusinessArea());
                    outUpdateWorkInstance.setType(inUpdateWorkInstance.getUpdateAWDInstance().getType());

                    // Map the FieldValues
                    outUpdateWorkInstance.setFieldValues(mapFieldValue(inUpdateWorkInstance.getUpdateAWDInstance().getFieldValues().getDeleteFieldValueOrFieldValue()));


                    if(outUpdateWorkInstance.getSuspend() != null) {
                        outUpdateWorkInstance.setSuspend(mapSuspend(inUpdateWorkInstance.getSuspend()));
                    }
                    outUpdateWorkInstance.setStatus(inUpdateWorkInstance.getStatus());
                    outUpdateWorkInstance.setWorkStep(inUpdateWorkInstance.getWorkStep());
                    if(outUpdateWorkInstance.getRouting() != null) {
                        outUpdateWorkInstance.setRouting(mapRouting(inUpdateWorkInstance.getRouting()));
                    }
                    outUpdateWorkInstance.setQueue(inUpdateWorkInstance.getQueue());
                    outUpdateWorkInstance.setPriority(inUpdateWorkInstance.getPriority());
                    outUpdateWorkInstance.setPriorityIncrease(inUpdateWorkInstance.getPriorityIncrease());
                    outUpdateWorkInstance.setAssignTo(inUpdateWorkInstance.getAssignTo());
                    outUpdateWorkInstance.setAutocase(inUpdateWorkInstance.getAutocase());

                    outUpdateAWDInstaceList.add(outUpdateWorkInstance);
                }
            }
        }
        return outUpdateAWDInstaceList;
    }

    /**
     * Map routing com . dstawd . processing . ws . routing.
     *
     * @param inRouting the in routing
     *
     * @return the com . dstawd . processing . ws . routing
     */
    public com.dstawd.processing.ws.Routing mapRouting (Routing inRouting){
        com.dstawd.processing.ws.Routing retRouting = new com.dstawd.processing.ws.Routing();

        retRouting.setBusinessArea(inRouting.getBusinessArea());
        retRouting.setRoute(inRouting.getRoute());
        retRouting.setStatus(inRouting.getStatus());
        retRouting.setType(inRouting.getType());
        retRouting.setValue(inRouting.getValue());

        return retRouting;
    }

    /**
     * Map suspend com . dstawd . processing . ws . suspend.
     *
     * @param inSuspend the in suspend
     *
     * @return the com . dstawd . processing . ws . suspend
     */
    public com.dstawd.processing.ws.Suspend mapSuspend(Suspend inSuspend) {
        com.dstawd.processing.ws.Suspend outSupend = new com.dstawd.processing.ws.Suspend();

        if(inSuspend != null) {
            outSupend.setActivationDate(inSuspend.getActivationDate());
            outSupend.setActivationRoutingStatus(inSuspend.getActivationRoutingStatus());
            outSupend.setDuration(inSuspend.getDuration());
            outSupend.setReasonCode(inSuspend.getReasonCode());
        }
        return outSupend;
    }


    /**
     * Map field value com . dstawd . processing . ws . update awd instance . field values.
     *
     * @param inputObjectList the input object list
     *
     * @return the com . dstawd . processing . ws . update awd instance . field values
     */
    public com.dstawd.processing.ws.UpdateAWDInstance.FieldValues mapFieldValue(List<Object> inputObjectList) {

        com.dstawd.processing.ws.UpdateAWDInstance.FieldValues outFieldValues = new com.dstawd.processing.ws.UpdateAWDInstance.FieldValues();
        List<Object>  outFieldValueList;

        if (inputObjectList != null && inputObjectList.size() > 0) {
            outFieldValueList = new ArrayList<>();
            com.dstawd.processing.ws.FieldValue retFieldValue = null;
            com.dstawd.processing.ws.DeleteFieldValue retDeleteFieldValue = null;

            for (int i = 0; i < inputObjectList.size(); i++) {
                Object inputObj = inputObjectList.get(i);

                if(inputObj instanceof DeleteFieldValue){
                    retDeleteFieldValue = new com.dstawd.processing.ws.DeleteFieldValue();
                    retDeleteFieldValue.setName(((DeleteFieldValue) inputObj).getName());
                    outFieldValueList.add(retDeleteFieldValue);
                } else if(inputObj instanceof FieldValue){
                    retFieldValue = new com.dstawd.processing.ws.FieldValue();
                    retFieldValue.setName(((FieldValue) inputObj).getName());
                    retFieldValue.setValue(((FieldValue) inputObj).getValue());
                    retFieldValue.setSequence(((FieldValue) inputObj).getSequence());
                    outFieldValueList.add(retFieldValue);
                }

            }

            outFieldValues.setFieldValueOrDeleteFieldValue(outFieldValueList);
        }


        return outFieldValues;
    }


}
