#!/bin/bash

set -e -u -x # fail fast

echo ""
echo " .. install 'newman' "
echo ""
npm install -g newman

echo ""
echo " .. Running newman tests"
echo ""

cd service-repo

# execute newman tests
newman run src/test/resources/postman/Wor*.json --environment src/test/resources/postman/dev.postman_environment.json

echo ""
echo " Build completed!!!!!!!!!"
echo ""






