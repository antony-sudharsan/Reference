###AWDIndex Agent

operation|uri|method
---|---|---
GetAgentData|/jh/wealth/ann/awdindex/agentbyid|GET
GetAgentDetails|/jh/wealth/ann/awdindex/agentbyname|GET

SWAGGER URI
https://awdindexagent.apps.cac.preview.pcf.manulife.com/swagger-ui.html
Logging Information
Component Name: AWDIndexAgent
Audit  Points
AUDIT POINT NO	REFERENCE INTERPRETATION
1	DATA FROM INPUT
2	DATA SEND TO END SYSTEM
3	DATA OUTPUT FROM END SYSTEM
4	DATA FINALLY SEND OUT IN RESPONSE
HTTP ERROR CODE
404 � If a Resource is not found
400 � Request fails validation or request is invalid
401 - Unauthorized
500 - Server Error
204 � Backend Record not found