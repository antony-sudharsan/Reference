package com.jh.life.policyindexingdata.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;


/**
 * The type Internal server error exception.
 */
public class InternalServerErrorException extends RuntimeException {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Instantiates a new Internal server error exception.
	 *
	 * @param message the message
	 */
	public InternalServerErrorException(String message) {
		super(message);
	}
}


