package com.jh.life.policyindexingdata.mapper;

import com.manulife.esb.xsd.annuity.jh.awdindexing.AgentType;
import com.manulife.esb.xsd.annuity.jh.awdindexing.AnnuitantType;
import com.manulife.esb.xsd.annuity.jh.awdindexing.AnnuityOwnerType;
import com.manulife.esb.xsd.annuity.jh.awdindexing.GetPolicyDataResponse;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * The type Get policy data mapper.
 *
 * @author Antony Sudharsan
 */
public class GetPolicyDataMapper implements RowMapper {

	@Override
	public Object mapRow(ResultSet rsPolicyData, int rowNum) throws SQLException {
		GetPolicyDataResponse getPolicyDataResponse = new GetPolicyDataResponse();

		AgentType agentType = new AgentType();
        AnnuitantType annuitantType = new AnnuitantType();
        AnnuityOwnerType annuityOwnerType = new AnnuityOwnerType();

        getPolicyDataResponse.setAnnuityLob(rsPolicyData.getString("lob"));
        getPolicyDataResponse.setAnnuityCompanyCode(rsPolicyData.getString("company_code"));
       // getPolicyDataResponse.setFixedVarCode(FixedVarCodeType.fromValue(rsPolicyData.getString("FixedVarInd")));
        getPolicyDataResponse.setBrokerCount(rsPolicyData.getInt("number_of_brokers"));

		annuityOwnerType.setCompanyIndividualCode(rsPolicyData.getString("OwnerCompanyIndividualCode"));
        annuityOwnerType.setFirmName(rsPolicyData.getString("OwnerCompanyName"));
        annuityOwnerType.setLastName(rsPolicyData.getString("OwnerLastName"));
        annuityOwnerType.setFirstName(rsPolicyData.getString("OwnerFirstName"));
        annuityOwnerType.setGovtID(rsPolicyData.getString("OwnerSSN"));

        annuitantType.setFirstName(rsPolicyData.getString("AnnuitantFirstName"));
        annuitantType.setLastName(rsPolicyData.getString("AnnuitantLastName"));
        annuitantType.setGovtID(rsPolicyData.getString("AnnuitantSSN"));

		//awdIndexPolicyDataResponse.setcust
        agentType.setAgentId(rsPolicyData.getString("agent_id"));
        agentType.setBrokerDealerId(rsPolicyData.getString("broker_dealer_id"));
        agentType.setBrokerDealerName(rsPolicyData.getString("broker_dealer_name"));
        agentType.setCustomBrokerCode(rsPolicyData.getString("CustomBroker"));
        agentType.setGovtID(rsPolicyData.getString("AgentTaxNumber"));
        agentType.setFirstName(rsPolicyData.getString("AgentFirstName"));
        agentType.setLastName(rsPolicyData.getString("AgentLastName"));
        agentType.setPhoneNumber(rsPolicyData.getString("AgentPhoneNumber"));

/*		awdIndexPolicyDataResponse.setRepAgentid(rsPolicyData.getString("rep_agent_id"));
		awdIndexPolicyDataResponse.setRepBrokerDealerId(rsPolicyData.getString("rep_broker_dealer_id"));
		awdIndexPolicyDataResponse.setRepBrokerdealerName(rsPolicyData.getString("rep_broker_dealer_name"));
        awdIndexPolicyDataResponse.setCustomBrokerCode(rsPolicyData.getString("rep_CustomBroker"));
		awdIndexPolicyDataResponse.setRepAgentTaxId(rsPolicyData.getString("rep_AgentTaxNumber"));
		awdIndexPolicyDataResponse.setRepAgentFirstName(rsPolicyData.getString("rep_AgentFirstName"));
		awdIndexPolicyDataResponse.setRepAgentLastName(rsPolicyData.getString("rep_AgentLastName"));
		awdIndexPolicyDataResponse.setRepAgentPhoneNo(rsPolicyData.getString("rep_AgentPhoneNumber"));*/

        getPolicyDataResponse.setAgent(agentType);
        getPolicyDataResponse.setAnnuitant(annuitantType);
        getPolicyDataResponse.setAnnuityOwner(annuityOwnerType);

		return getPolicyDataResponse;
	}

}

