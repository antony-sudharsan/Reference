package com.jh.life.policyindexingdata.dao;

import com.jh.common.logging.LoggerHandler;
import com.jh.life.policyindexingdata.constants.PolicyIndexDataConstants;
import com.jh.life.policyindexingdata.exception.QueryException;
import com.jh.life.policyindexingdata.exception.SQLServerErrorException;
import com.jh.life.policyindexingdata.exception.TechnicalErrorException;
import com.jh.life.policyindexingdata.mapper.GetAgentDataMapper;
import com.jh.life.policyindexingdata.mapper.GetPolicyDataMapper;
import com.jh.life.policyindexingdata.mapper.SearchAgentNameMapper;
import com.manulife.esb.xsd.annuity.jh.awdindexing.*;
import com.manulife.esb.xsd.common.jh.commonmessage.FaultType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.QueryTimeoutException;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.List;

/**
 * The type Policy index data dao.
 */
@Component
public class PolicyIndexDataDAO {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Value("${RequestTimeoutLimit:10000}")
    private int requestTimeoutLimit;

    /**
     * Init.
     */
    @PostConstruct
    public void init() {
        if (requestTimeoutLimit != 0) {
            this.jdbcTemplate.setQueryTimeout(requestTimeoutLimit);
        }
    }

    /**
     * Search agent name search agent name response.
     *
     * @param messageUUID      the message uuid
     * @param sourceSystemName the source system name
     * @param request          the request
     *
     * @return search agent name response
     *
     * @throws Exception the exception
     */
    public SearchAgentNameResponse searchAgentName( String messageUUID, String sourceSystemName, SearchAgentNameRequest request) throws Exception {

        SearchAgentNameResponse searchAgentNameResponse = new SearchAgentNameResponse();

        LoggerHandler.LogOut("INFO", "3", messageUUID, sourceSystemName, this.getClass().getName(), "First Name>" + request.getFirstName() + "Last Name>" + request.getLastName());

        try {

            List<AgentSearchResultsType> agentSearchResults = (List<AgentSearchResultsType>) jdbcTemplate.query("{call uspAgentNameSearch(?,?)}",
                    new Object[]{request.getLastName(), request.getFirstName()}, new SearchAgentNameMapper());

            LoggerHandler.LogOut("INFO", "4", messageUUID, sourceSystemName, this.getClass().getName(), "agentSearchResults size >>"+agentSearchResults.size());
            LoggerHandler.LogOut("DEBUG", "4", messageUUID, sourceSystemName, this.getClass().getName(), "Passed getContractDetailsData");

            searchAgentNameResponse.setAgentSearchResults(agentSearchResults);
        } catch (QueryTimeoutException e) {
            LoggerHandler.ErrorOut(e, messageUUID, sourceSystemName, this.getClass().getName(), e.getMessage());
           throw new QueryException(PolicyIndexDataConstants.TIMEOUT_ERROR_CODE, e);
        } catch (DataAccessException e) {
            LoggerHandler.ErrorOut(e, messageUUID, sourceSystemName, this.getClass().getName(), e.getMessage());
            throw new SQLServerErrorException(PolicyIndexDataConstants.TECHNICAL_ERROR_CODE, e);

        } catch (Exception e) {
            LoggerHandler.ErrorOut(e, messageUUID, sourceSystemName, this.getClass().getName(), e.getMessage());
            throw new TechnicalErrorException(PolicyIndexDataConstants.TECHNICAL_ERROR_CODE, e);

        }

        return searchAgentNameResponse;
    }


    /**
     * Gets agent data.
     *
     * @param messageUUID      the message uuid
     * @param sourceSystemName the source system name
     * @param request          the request
     *
     * @return agent data
     *
     * @throws Exception the exception
     */
    public List<GetAgentDataResponse> getAgentData( String messageUUID, String sourceSystemName, GetAgentDataRequest request) throws Exception {

        LoggerHandler.LogOut("INFO", "3", messageUUID, sourceSystemName, this.getClass().getName(), "Agent Id >" + request.getAgentId());

        List<GetAgentDataResponse> getAgentDataResponseList = null;
        try {

            getAgentDataResponseList = ( List<GetAgentDataResponse>) jdbcTemplate.query("{call uspEncorrAgentData(?)}", new Object[]{request.getAgentId()},
                    new GetAgentDataMapper());

            LoggerHandler.LogOut("INFO", "4", messageUUID, sourceSystemName, this.getClass().getName(), "Exiting getContractDetailsData ");
            LoggerHandler.LogOut("DEBUG", "4", messageUUID, sourceSystemName, this.getClass().getName(), "Passed getContractDetailsData");

        } catch (QueryTimeoutException e) {
            LoggerHandler.ErrorOut(e, messageUUID, sourceSystemName, this.getClass().getName(), e.getMessage());
            throw new QueryException(PolicyIndexDataConstants.TIMEOUT_ERROR_CODE, e);
        } catch (DataAccessException e) {
            LoggerHandler.ErrorOut(e, messageUUID, sourceSystemName, this.getClass().getName(), e.getMessage());
            throw new SQLServerErrorException(PolicyIndexDataConstants.TECHNICAL_ERROR_CODE, e);

        } catch (Exception e) {
            LoggerHandler.ErrorOut(e, messageUUID, sourceSystemName, this.getClass().getName(), e.getMessage());
            throw new TechnicalErrorException(PolicyIndexDataConstants.TECHNICAL_ERROR_CODE, e);
        }
        return getAgentDataResponseList;
    }


    /**
     * Gets policy data.
     *
     * @param messageUUID      the message uuid
     * @param sourceSystemName the source system name
     * @param request          the request
     *
     * @return policy data
     *
     * @throws Exception the exception
     */
    public GetPolicyDataResponse getPolicyData(String messageUUID, String sourceSystemName, GetPolicyDataRequest request) throws Exception {
        LoggerHandler.LogOut("INFO", "3", messageUUID, sourceSystemName, this.getClass().getName(), "Pol Number>" + request.getPolNumber());
        GetPolicyDataResponse policyDataResponse = null;
        try {

            policyDataResponse = (GetPolicyDataResponse) jdbcTemplate.queryForObject("{call uspGetConsolidatedPolicyData(?)}",
                    new Object[]{request.getPolNumber()}, new GetPolicyDataMapper());


            LoggerHandler.LogOut("INFO", "4", messageUUID, sourceSystemName, this.getClass().getName(), "Exiting getContractDetailsData ");
            LoggerHandler.LogOut("DEBUG", "4", messageUUID, sourceSystemName, this.getClass().getName(), "Passed getContractDetailsData");

        } catch (QueryTimeoutException e) {
            LoggerHandler.ErrorOut(e, messageUUID, sourceSystemName, this.getClass().getName(), e.getMessage());
            throw new QueryException(PolicyIndexDataConstants.TIMEOUT_ERROR_CODE, e);
        } catch (DataAccessException e) {
            LoggerHandler.ErrorOut(e, messageUUID, sourceSystemName, this.getClass().getName(), e.getMessage());
            throw new SQLServerErrorException(PolicyIndexDataConstants.TECHNICAL_ERROR_CODE, e);

        } catch (Exception e) {
            LoggerHandler.ErrorOut(e, messageUUID, sourceSystemName, this.getClass().getName(), e.getMessage());
            throw new TechnicalErrorException(PolicyIndexDataConstants.TECHNICAL_ERROR_CODE, e);
        }
        return policyDataResponse;
    }
}
