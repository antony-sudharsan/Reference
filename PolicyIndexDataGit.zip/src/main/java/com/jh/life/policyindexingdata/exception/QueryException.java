package com.jh.life.policyindexingdata.exception;

import com.jh.life.policyindexingdata.utils.Utility;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

/**
 * The type Query exception.
 */
@ResponseStatus(HttpStatus.NOT_FOUND)
public class QueryException extends BaseFaultException {
	/**
	 *
	 */
	private static final long serialVersionUID = 1L;
	private static final String DEFAULT_CODE = "99999";
	private static final String DEFAULT_REASON = "Query Timed Out";
	private static final String DEFAULT_DETAILS = "Query Timed Out";
	private static final String FAULT_STRING = "Internal Error";

	/**
	 * Instantiates a new Query exception.
	 */
	public QueryException() {
		super(DEFAULT_CODE, DEFAULT_REASON, DEFAULT_DETAILS, FAULT_STRING);
	}

	public QueryException(final String message, final Throwable cause) {
		super(DEFAULT_CODE, DEFAULT_REASON, getMessage(message, cause), FAULT_STRING, cause);
	}

	private static String getMessage(final String message, final Throwable cause) {
		String detail = message;
		if (cause != null) {
			detail = message + ", " + Utility.getStackTrace(cause);
		}
		return detail;
	}
}
