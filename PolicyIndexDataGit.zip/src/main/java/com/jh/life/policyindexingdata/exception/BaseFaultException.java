package com.jh.life.policyindexingdata.exception;

import org.apache.commons.lang3.builder.ToStringBuilder;

/**
 * The type Base fault exception.
 */
public abstract class BaseFaultException extends RuntimeException {

	private static final long serialVersionUID = 1387749572104551287L;
	private String code;
	private String reason;
	private String details;

    /**
     * Instantiates a new Base fault exception.
     *
     * @param code    the code
     * @param reason  the reason
     * @param details the details
     * @param message the message
     */
    public BaseFaultException(final String code, final String reason, final String details, final String message) {
		super(message);
		this.code = code;
		this.reason = reason;
		this.details = details;
	}

    /**
     * Instantiates a new Base fault exception.
     *
     * @param code    the code
     * @param reason  the reason
     * @param details the details
     * @param message the message
     * @param cause   the cause
     */
    public BaseFaultException(final String code, final String reason, final String details, final String message,
			final Throwable cause) {
		super(message, cause);
		this.code = code;
		this.reason = reason;
		this.details = details;
	}

    /**
     * Gets code.
     *
     * @return the code
     */
    public String getCode() {
		return code;
	}

    /**
     * Sets code.
     *
     * @param code the code
     */
    public void setCode(final String code) {
		this.code = code;
	}

    /**
     * Gets reason.
     *
     * @return the reason
     */
    public String getReason() {
		return reason;
	}

    /**
     * Sets reason.
     *
     * @param reason the reason
     */
    public void setReason(final String reason) {
		this.reason = reason;
	}

    /**
     * Gets details.
     *
     * @return the details
     */
    public String getDetails() {
		return details;
	}

    /**
     * Sets details.
     *
     * @param details the details
     */
    public void setDetails(final String details) {
		this.details = details;
	}

    /**
     * Gets exception response.
     *
     * @return the exception response
     */
    public ExceptionResponse getExceptionResponse() {
		return new ExceptionResponse(this.code, this.reason, this.getDetails());
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}

}
