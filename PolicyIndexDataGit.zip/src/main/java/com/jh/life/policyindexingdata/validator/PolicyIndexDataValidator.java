package com.jh.life.policyindexingdata.validator;

import com.jh.life.policyindexingdata.constants.PolicyIndexDataConstants;
import com.jh.life.policyindexingdata.exception.InvalidInputException;
import com.manulife.esb.xsd.annuity.jh.awdindexing.GetAgentDataFault;
import com.manulife.esb.xsd.annuity.jh.awdindexing.GetPolicyDataFault;
import com.manulife.esb.xsd.annuity.jh.awdindexing.SearchAgentNameFault;
import com.manulife.esb.xsd.common.jh.commonmessage.FaultType;
import org.springframework.stereotype.Component;

/**
 * The type Policy index data validator.
 */
@Component
public class PolicyIndexDataValidator {

    /**
     * Validate agent id.
     *
     * @param agentId the agent id
     *
     * @throws GetAgentDataFault
     */
    public void validateAgentId(String agentId) {
        if (agentId.length() <= 2) {
            throw new InvalidInputException("Agent Id cannot be less than two characters");
        }
    }

    /**
     * Validate agent details.
     *
     * @param lastName  the last name
     * @param firstName the first name
     *
     * @throws SearchAgentNameFault the search agent name fault
     */
    public void validateAgentDetails(String lastName, String firstName) {
        if ((lastName != null && lastName.length() <= 2) || (firstName != null && firstName.length() <= 2)) {
            throw new InvalidInputException("First name or Last name cannot be less than two characters");
        }
    }

    /**
     * Validate policy.
     *
     * @param policyNo the policy no
     *
     * @throws GetPolicyDataFault the get policy data fault
     */
    public  void validatePolicy(String policyNo) {
        if (policyNo.length() <= 2){

            throw new InvalidInputException("First name or Last name cannot be less than two characters");

        }

    }
}
