package com.jh.life.policyindexingdata.exception;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;


/**
 * The type No content exception.
 */
@ResponseStatus(HttpStatus.NOT_FOUND)
public class NoContentException extends RuntimeException {
    /**
     * Instantiates a new No content exception.
     *
     * @param message the message
     */
    public NoContentException(String message) {
		super(message);
	}
}
