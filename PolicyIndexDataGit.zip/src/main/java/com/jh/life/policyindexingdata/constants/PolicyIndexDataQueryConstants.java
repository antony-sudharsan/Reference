package com.jh.life.policyindexingdata.constants;

/**
 * The type Policy index data query constants.
 */
public class PolicyIndexDataQueryConstants {

    /**
     * The constant GET_INDEX_AGENT.
     */
    public static String GET_INDEX_AGENT = "{call uspAgentNameSearch(?,?)}";

    /**
     * The constant GET_INDEX_POLICY.
     */
    public static String GET_INDEX_POLICY = "{call uspGetConsolidatedPolicyData(?)}";


    /**
     * Instantiates a new Policy index data query constants.
     */
    public PolicyIndexDataQueryConstants() {
    }


}
