	package com.jh.life.policyindexingdata.exception;

    /**
     * The type Validation exception.
     */
    public class ValidationException extends RuntimeException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

        /**
         * Instantiates a new Validation exception.
         *
         * @param message the message
         */
        public ValidationException(String message) {
		super(message);
	
	}

}
