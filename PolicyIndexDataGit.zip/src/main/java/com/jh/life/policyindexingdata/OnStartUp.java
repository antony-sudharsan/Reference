/**
 * 
 */
package com.jh.life.policyindexingdata;

import com.jh.common.logging.LoggerHandler;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;


/**
 * The type On start up.
 *
 * @author deepain
 */
@Component
public class OnStartUp {
		
	@Value("${log.appID}")
	private String appID;
	
	@Value("${log.svcName}")
	private String svcName;
	
	@Value("${log.componentName}")
	private String componentName;
	
	@Value("${log.svcVersion}")
	private String svcVersion;

    /**
     * Init.
     */
    @PostConstruct
	public void init() {
		try {	
			
			//Initializing Logger class
			System.out.println("AppID :"+appID+", SvcName :"+svcName+", ComponentName :"+componentName+", Svc Version :"+svcVersion);
			LoggerHandler.getInstance(appID, svcName, componentName, svcVersion);
			
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
}
