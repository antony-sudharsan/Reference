package com.jh.life.policyindexingdata.controller;

import com.jh.common.logging.LoggerHandler;
import com.jh.life.policyindexingdata.constants.PolicyIndexDataConstants;
import com.jh.life.policyindexingdata.orchestration.PolicyIndexDataOrchectration;
import com.manulife.esb.xsd.annuity.jh.awdindexing.*;
import com.manulife.esb.xsd.common.jh.commonmessage.FaultType;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

/**
 * The type Policy index data controller.
 */
@RestController
@EnableSwagger2
public class PolicyIndexDataController {

    /**
     * The Response headers.
     */
    HttpHeaders responseHeaders = new HttpHeaders();

    /**
     * The Policy index data orchectration.
     */
    @Autowired
    PolicyIndexDataOrchectration policyIndexDataOrchectration;


    /**
     * Gets agent data.
     *
     * @param messageUUID         the message uuid
     * @param sourceSystemName    the source system name
     * @param getAgentDataRequest the get agent data request
     *
     * @return the agent data
     *
     * @throws Exception the exception
     */
    @ApiOperation(httpMethod = "POST", value = "Gets the agent details based on Agent ID", notes = "Gets the agent details based on Agent ID ")
    @ApiResponses(value = {@ApiResponse(code = 200, message = "Success"), @ApiResponse(code = 400, message = "Validation Error: Invalid Request"),
            @ApiResponse(code = 404, message = "The downstream resource not reacheable"), @ApiResponse(code = 500, message = "Internal Service Error")})
    @RequestMapping(path = "/jh/wealth/ann/policyindexingdata/agentbyid", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<GetAgentDataResponse> getAgentData(@RequestHeader("MessageUUID") String messageUUID,
                                                             @RequestHeader("SourceSystemName") String sourceSystemName,
                                                             @RequestBody GetAgentDataRequest getAgentDataRequest) throws Exception

    {
        GetAgentDataResponse getAgentDataResponse = null;
        try {

            LoggerHandler.LogOut("INFO", "1", messageUUID, sourceSystemName, this.getClass().getName(), getAgentDataRequest.toString());

            getAgentDataResponse = policyIndexDataOrchectration.getAgentData(messageUUID, sourceSystemName, getAgentDataRequest);


        }  catch (final Exception e) {
            LoggerHandler.ErrorOut(e, messageUUID, sourceSystemName, this.getClass().getName(), e.getMessage());
            throw e;
        }
        return ResponseEntity.ok().headers(responseHeaders).body(getAgentDataResponse);
    }

    /**
     * Search agent name response entity.
     *
     * @param messageUUID            the message uuid
     * @param sourceSystemName       the source system name
     * @param searchAgentNameRequest the search agent name request
     *
     * @return the response entity
     *
     * @throws Exception the exception
     */
    @ApiOperation(httpMethod = "POST", value = "Gets the agent details based on Agent First Name and Agent Last Name", notes = "Gets the agent details based on Agent First Name and Agent Last Name ")
    @ApiResponses(value = {@ApiResponse(code = 200, message = "Success"), @ApiResponse(code = 400, message = "Validation Error: Invalid Request"),
            @ApiResponse(code = 404, message = "The downstream resource not reacheable"), @ApiResponse(code = 500, message = "Internal Service Error")})
    @RequestMapping(path = "/jh/wealth/ann/policyindexingdata/agentbyname", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<SearchAgentNameResponse> searchAgentName(@RequestHeader("MessageUUID") String messageUUID,
                                                                   @RequestHeader("SourceSystemName") String sourceSystemName, @RequestBody SearchAgentNameRequest searchAgentNameRequest) throws Exception {

        SearchAgentNameResponse searchAgentNameResponse = null;
        try {

            LoggerHandler.LogOut("INFO", "1", messageUUID, sourceSystemName, this.getClass().getName(), searchAgentNameRequest.toString());

            searchAgentNameResponse = policyIndexDataOrchectration.searchAgentName(messageUUID, sourceSystemName, searchAgentNameRequest);


        } catch (final Exception e) {
            LoggerHandler.ErrorOut(e, messageUUID, sourceSystemName, this.getClass().getName(), e.getMessage());
            throw e;
        }

        return ResponseEntity.ok().headers(responseHeaders).body(searchAgentNameResponse);
    }

    /**
     * Gets policy data.
     *
     * @param messageUUID          the message uuid
     * @param sourceSystemName     the source system name
     * @param getPolicyDataRequest the get policy data request
     *
     * @return the policy data
     *
     * @throws Exception the exception
     */
    @ApiOperation(httpMethod = "POST", value = "Get AWD Index Policy Details", notes = "Service is designed to retrieve required policy information", response = GetPolicyDataResponse.class)
    @ApiResponses(value = {@ApiResponse(code = 200, message = "Successfully retrieved list"),
            @ApiResponse(code = 401, message = "You are not authorized to view the resource"),
            @ApiResponse(code = 403, message = "Accessing the resource you were trying to reach is forbidden"),
            @ApiResponse(code = 404, message = "The resource you were trying to reach is not found")})
    @RequestMapping(path = "/jh/wealth/ann/awdindex/policy", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<GetPolicyDataResponse> getPolicyData(@RequestHeader("MessageUUID") String messageUUID,
                                                               @RequestHeader("SourceSystemName") String sourceSystemName, @RequestBody GetPolicyDataRequest getPolicyDataRequest) throws Exception {
        GetPolicyDataResponse getPolicyDataResponse = null;
        try {
            LoggerHandler.LogOut("INFO", "1", messageUUID, sourceSystemName, this.getClass().getName(), getPolicyDataRequest.toString());
            getPolicyDataResponse = policyIndexDataOrchectration.getPolicyData(messageUUID, sourceSystemName, getPolicyDataRequest);
            LoggerHandler.LogOut("INFO", "4", messageUUID, sourceSystemName, this.getClass().getName(), getPolicyDataResponse.toString());

        }   catch (final Exception e) {
            LoggerHandler.ErrorOut(e, messageUUID, sourceSystemName, this.getClass().getName(), e.getMessage());
            throw e;
        }

        return ResponseEntity.ok().headers(responseHeaders).body(getPolicyDataResponse);

    }

}
