package com.jh.life.policyindexingdata.controller;

import com.jh.life.policyindexingdata.exception.*;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;


/**
 * The type Policy index data exception.
 */
@ControllerAdvice
public class PolicyIndexDataException extends ResponseEntityExceptionHandler{


    /**
     * Handle all exceptions response entity.
     *
     * @param ex      the ex
     * @param request the request
     *
     * @return the response entity
     */
    @ExceptionHandler(NoContentException.class)
	 @ResponseStatus(HttpStatus.NO_CONTENT)
	public final ResponseEntity<Object> handleAllExceptions(Exception ex, WebRequest request) {
		ExceptionResponse exceptionResponse = new ExceptionResponse("204", "No Content Found",
				ex.getMessage());
		return new ResponseEntity(exceptionResponse, HttpStatus.NO_CONTENT);
		
	}

    /**
     * Handle exception response entity.
     *
     * @param ex      the ex
     * @param request the request
     *
     * @return the response entity
     */
//408
	@ExceptionHandler(RequestTimeoutException.class)
	public final ResponseEntity<ExceptionResponse>  handleException(RequestTimeoutException ex, WebRequest request) {

		ExceptionResponse exceptionResponse = new ExceptionResponse("408", "SQL Server back end timed out" ,ex.getMessage());		
		return new ResponseEntity(exceptionResponse, HttpStatus.REQUEST_TIMEOUT);
	}

    /**
     * Handle exception response entity.
     *
     * @param ex      the ex
     * @param request the request
     *
     * @return the response entity
     */
//500
			@ExceptionHandler(SQLServerErrorException.class)
			public final ResponseEntity<Object>  handleException(SQLServerErrorException ex, WebRequest request) {

				ExceptionResponse exceptionResponse = new ExceptionResponse("500", ex.getMessage(),ex.getDetails());		
				return new ResponseEntity(exceptionResponse, HttpStatus.INTERNAL_SERVER_ERROR);
			}


    /**
     * Handle not found exception response entity.
     *
     * @param ex      the ex
     * @param request the request
     *
     * @return the response entity
     */
    @ExceptionHandler(NotFoundException.class)
	 @ResponseStatus(HttpStatus.NOT_FOUND)
	@ResponseBody
	public final ResponseEntity<Object> handleNotFoundException(NotFoundException ex, WebRequest request) {
		ExceptionResponse exceptionResponse = new ExceptionResponse("404", "No Agent Data Found with the details provided",
				ex.getMessage());
		return new ResponseEntity(exceptionResponse, HttpStatus.NOT_FOUND);
	}

    /**
     * Handle not found exception response entity.
     *
     * @param ex      the ex
     * @param request the request
     *
     * @return the response entity
     */
    @ExceptionHandler(InvalidRequestException.class)
	 @ResponseStatus(HttpStatus.BAD_REQUEST)
	@ResponseBody
	public final ResponseEntity<Object> handleNotFoundException(InvalidRequestException ex, WebRequest request) {
		ExceptionResponse exceptionResponse = new ExceptionResponse("400", "Invalid input request",
				ex.getMessage());
		return new ResponseEntity(exceptionResponse, HttpStatus.BAD_REQUEST);
	}
	
	@Override
	protected ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException ex,
			HttpHeaders headers, HttpStatus status, WebRequest request) {
		ExceptionResponse exceptionResponse = new ExceptionResponse("400", "Validation Failed",
				ex.getBindingResult().toString());
		return new ResponseEntity(exceptionResponse, HttpStatus.BAD_REQUEST);
	}	
	
	
	
}

