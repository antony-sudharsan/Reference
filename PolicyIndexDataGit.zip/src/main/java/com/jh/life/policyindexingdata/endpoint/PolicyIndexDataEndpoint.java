package com.jh.life.policyindexingdata.endpoint;

import com.jh.common.logging.LoggerHandler;
import com.jh.life.policyindexingdata.constants.PolicyIndexDataConstants;
import com.jh.life.policyindexingdata.exception.BadRequestException;
import com.jh.life.policyindexingdata.orchestration.PolicyIndexDataOrchectration;
import com.jh.life.policyindexingdata.utils.HeaderKey;
import com.jh.life.policyindexingdata.utils.JHHeaderJaxbUtils;
import com.jh.life.policyindexingdata.utils.LoggerUtils;
import com.jh.life.policyindexingdata.utils.LoggingContextHolder;
import com.manulife.esb.xsd.annuity.jh.awdindexing.*;
import com.manulife.esb.xsd.common.jh.commonmessage.FaultType;
import com.manulife.esb.xsd.common.jh.header.JHHeader;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ws.context.MessageContext;
import org.springframework.ws.server.endpoint.annotation.Endpoint;
import org.springframework.ws.server.endpoint.annotation.PayloadRoot;
import org.springframework.ws.server.endpoint.annotation.RequestPayload;
import org.springframework.ws.server.endpoint.annotation.ResponsePayload;
import org.springframework.ws.soap.SoapHeaderElement;
import org.springframework.ws.soap.server.endpoint.annotation.SoapHeader;

/**
 * The type Policy index data endpoint.
 */
@Endpoint
public class PolicyIndexDataEndpoint {

    private static final String NAMESPACE_URI = "http://www.esb.manulife.com/xsd/Annuity/jh/AWDIndexing";

    private static final String JH_HEADER_NS = "http://www.esb.manulife.com/xsd/common/jh/header";

    @Autowired
    private PolicyIndexDataOrchectration policyIndexDataOrchectration;
    @Autowired
    private JHHeaderJaxbUtils jhHeaderJaxbUtils;
    @Autowired
    private LoggerUtils loggerUtils;


    /**
     * Instantiates a new Policy index data endpoint.
     *
     * @param policyIndexDataOrchectration the policy index data orchectration
     * @param jhHeaderJaxbUtils            the jh header jaxb utils
     * @param loggerUtils                  the logger utils
     */
    @Autowired
    public PolicyIndexDataEndpoint(PolicyIndexDataOrchectration policyIndexDataOrchectration, JHHeaderJaxbUtils jhHeaderJaxbUtils, LoggerUtils loggerUtils) {
        this.policyIndexDataOrchectration = policyIndexDataOrchectration;
        this.jhHeaderJaxbUtils = jhHeaderJaxbUtils;
        this.loggerUtils = loggerUtils;
    }

    /**
     * Search agent name search agent name response.
     *
     * @param request         the request
     * @param jhHeaderElement the jh header element
     * @param messageContext  the message context
     *
     * @return search agent name response
     *
     * @throws Exception the exception
     */
    @PayloadRoot(namespace = NAMESPACE_URI, localPart = "SearchAgentName_request")
    @ResponsePayload
    public SearchAgentNameResponse searchAgentName(
            @RequestPayload SearchAgentNameRequest request,
            @SoapHeader("{" + JH_HEADER_NS + "}JHHeader") SoapHeaderElement jhHeaderElement,
            MessageContext messageContext) throws Exception {

        SearchAgentNameResponse reply = null;
        JHHeader header = parseHeader(jhHeaderElement);
        validateHeader(header);

        String messageUUID = header.getMessageUID();
        String sourceSystemName = header.getMessageSource().getApplicationName();
        String userId = header.getMessageSource().getUserID();

        try {

            LoggerHandler.LogOut("INFO", "1", messageUUID, sourceSystemName, this.getClass().getName(),
                    "Entering Get Annuity Contract EndPoint " + loggerUtils.writeAsJson(request));

            reply = policyIndexDataOrchectration.searchAgentName( messageUUID, sourceSystemName, request);

            LoggerHandler.LogOut("INFO", "6", messageUUID, sourceSystemName, this.getClass().getName(),
                    "Exiting GetAnnuityContract EndPoint " + loggerUtils.writeAsJson(reply));

        } catch (SearchAgentNameFault searchAgentNameFault) {
            throw searchAgentNameFault;
        } catch (final Exception e) {
            LoggerHandler.ErrorOut(e, messageUUID, sourceSystemName, this.getClass().getName(), e.getMessage());
            FaultType faultInfo = new FaultType(PolicyIndexDataConstants.TECHNICAL_ERROR_CODE, e.getMessage());
            SearchAgentNameFault searchAgentNameFault = new SearchAgentNameFault( faultInfo);
            throw searchAgentNameFault;
        }
        // add response header as a property to be used by EndpointInterceptor
        // Current service does not modify header on response
        messageContext.setProperty(HeaderKey.JH_HEADER_KEY.getValue(), header);
        LoggingContextHolder.getLoggingContext().clear();

        return reply;
    }


    /**
     * Gets agent data.
     *
     * @param request         the request
     * @param jhHeaderElement the jh header element
     * @param messageContext  the message context
     *
     * @return agent data
     *
     * @throws Exception the exception
     */
    @PayloadRoot(namespace = NAMESPACE_URI, localPart = "GetAgentData_request")
    @ResponsePayload
    public GetAgentDataResponse getAgentData(
            @RequestPayload GetAgentDataRequest request,
            @SoapHeader("{" + JH_HEADER_NS + "}JHHeader") SoapHeaderElement jhHeaderElement,
            MessageContext messageContext) throws Exception {

        GetAgentDataResponse reply = null;
        JHHeader header = parseHeader(jhHeaderElement);
        validateHeader(header);

        String messageUUID = header.getMessageUID();
        String sourceSystemName = header.getMessageSource().getApplicationName();
        String userId = header.getMessageSource().getUserID();

        try {

            LoggerHandler.LogOut("INFO", "1", messageUUID, sourceSystemName, this.getClass().getName(),
                    "Entering Get Annuity Contract EndPoint " + loggerUtils.writeAsJson(request));

            reply = policyIndexDataOrchectration.getAgentData( messageUUID, sourceSystemName, request);

            LoggerHandler.LogOut("INFO", "6", messageUUID, sourceSystemName, this.getClass().getName(),
                    "Exiting GetAnnuityContract EndPoint " + loggerUtils.writeAsJson(reply));

        } catch (GetAgentDataFault getAgentDataFault) {
            throw getAgentDataFault;
        } catch (final Exception e) {
            LoggerHandler.ErrorOut(e, messageUUID, sourceSystemName, this.getClass().getName(), e.getMessage());
            FaultType faultType = new FaultType(PolicyIndexDataConstants.TECHNICAL_ERROR_CODE, e.getMessage());
            GetAgentDataFault getAgentDataFault = new GetAgentDataFault( faultType);
            throw getAgentDataFault;
        }
        // add response header as a property to be used by EndpointInterceptor
        // Current service does not modify header on response
        messageContext.setProperty(HeaderKey.JH_HEADER_KEY.getValue(), header);
        LoggingContextHolder.getLoggingContext().clear();

        return reply;
    }

    /**
     * Gets policy data.
     *
     * @param request         the request
     * @param jhHeaderElement the jh header element
     * @param messageContext  the message context
     *
     * @return policy data
     *
     * @throws Exception the exception
     */
    @PayloadRoot(namespace = NAMESPACE_URI, localPart = "GetPolicyData_request")
    @ResponsePayload
    public GetPolicyDataResponse getPolicyData(
            @RequestPayload GetPolicyDataRequest request,
            @SoapHeader("{" + JH_HEADER_NS + "}JHHeader") SoapHeaderElement jhHeaderElement,
            MessageContext messageContext) throws Exception {

        GetPolicyDataResponse reply = null;
        JHHeader header = parseHeader(jhHeaderElement);
        validateHeader(header);

        String messageUUID = header.getMessageUID();
        String sourceSystemName = header.getMessageSource().getApplicationName();

        try {

            LoggerHandler.LogOut("INFO", "1", messageUUID, sourceSystemName, this.getClass().getName(),
                    "Entering Get Annuity Contract EndPoint " + loggerUtils.writeAsJson(request));

            reply = policyIndexDataOrchectration.getPolicyData( messageUUID, sourceSystemName, request);

            LoggerHandler.LogOut("INFO", "6", messageUUID, sourceSystemName, this.getClass().getName(),
                    "Exiting GetAnnuityContract EndPoint " + loggerUtils.writeAsJson(reply));

        } catch (GetPolicyDataFault getPolicyDataFault) {
            throw getPolicyDataFault;
        } catch (final Exception e) {
            LoggerHandler.ErrorOut(e, messageUUID, sourceSystemName, this.getClass().getName(), e.getMessage());
            FaultType faultType = new FaultType(PolicyIndexDataConstants.TECHNICAL_ERROR_CODE, e.getMessage());
            GetPolicyDataFault getPolicyDataFault = new GetPolicyDataFault( faultType);
            throw getPolicyDataFault;
        }
        // add response header as a property to be used by EndpointInterceptor
        // Current service does not modify header on response
        messageContext.setProperty(HeaderKey.JH_HEADER_KEY.getValue(), header);
        LoggingContextHolder.getLoggingContext().clear();

        return reply;
    }


    /**
     * @param jhHeaderElement
     * @return
     */
    private JHHeader parseHeader(final SoapHeaderElement jhHeaderElement) {
        // parse JH Header if present
        JHHeader header = null;
        if (null != jhHeaderElement) {
            header = jhHeaderJaxbUtils.unmarshallJHHeader(jhHeaderElement);
        } else {
            throw new BadRequestException("Missing Header");
        }

        return header;
    }

    /**
     * @param header
     */
    private void validateHeader(final JHHeader header) {
        if ((header == null) || (header.getMessageSource() == null)
                || StringUtils.isEmpty(header.getMessageSource().getApplicationName())) {
            throw new BadRequestException("Invalid Header Sent");
        }
    }
}
