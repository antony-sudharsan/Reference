package com.jh.life.policyindexingdata.exception;

import com.jh.life.policyindexingdata.utils.Utility;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

import lombok.Getter;
import lombok.Setter;


/**
 * The type Sql server error exception.
 */
public class SQLServerErrorException extends BaseFaultException {

	private static final long serialVersionUID = 1L;
	private static final String DEFAULT_CODE = "99999";
	private static final String DEFAULT_REASON = "Database Error";
	private static final String DEFAULT_DETAILS = "Error Occured in Access DB";
	private static final String FAULT_STRING = "Internal Error";

	/**
	 * Instantiates a new Sql server error exception.
	 */
	public SQLServerErrorException() {
		super(DEFAULT_CODE, DEFAULT_REASON, DEFAULT_DETAILS, FAULT_STRING);
	}

	public SQLServerErrorException(final String message, final Throwable cause) {
		super(DEFAULT_CODE, DEFAULT_REASON, getMessage(message, cause), FAULT_STRING, cause);
	}

	private static String getMessage(final String message, final Throwable cause) {
		String detail = message;
		if (cause != null) {
			detail = message + ", " + Utility.getStackTrace(cause);
		}
		return detail;
	}
}


