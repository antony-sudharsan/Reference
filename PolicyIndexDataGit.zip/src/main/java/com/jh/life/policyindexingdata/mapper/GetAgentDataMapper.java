package com.jh.life.policyindexingdata.mapper;

import com.jh.life.policyindexingdata.utils.PolicyIndexDataUtils;
import com.manulife.esb.xsd.annuity.jh.awdindexing.AddressType;
import com.manulife.esb.xsd.annuity.jh.awdindexing.GetAgentDataResponse;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * The type Get agent data mapper.
 *
 * @author chaudha
 */
public class GetAgentDataMapper implements RowMapper {

	@Override
	public Object mapRow(ResultSet rsAgentDetails, int rowNum) throws SQLException {

        PolicyIndexDataUtils policyIndexDataUtils =  new PolicyIndexDataUtils();

		GetAgentDataResponse getAgentDataResponse = new GetAgentDataResponse();
        AddressType addressType = new AddressType();

		getAgentDataResponse.setAgentAnnuityCompanyCode(rsAgentDetails.getString("COMPANY_CODE"));
		getAgentDataResponse.setAgentId(rsAgentDetails.getString("AGENT_ID"));
		getAgentDataResponse.setMasterAgentId(rsAgentDetails.getString("MASTER_AGENT_ID"));
		getAgentDataResponse.setMasterAnnuityCompanyCode(rsAgentDetails.getString("MASTER_COMPANY_CODE"));
		getAgentDataResponse.setGovtID(rsAgentDetails.getString("TAX_NUMBER"));
		getAgentDataResponse.setLastName(rsAgentDetails.getString("AGENT_LAST_NAME"));

		getAgentDataResponse.setFirstName(rsAgentDetails.getString("AGENT_FIRST_NAME"));
		getAgentDataResponse.setPrefix(rsAgentDetails.getString("AGENT_NAME_PREFIX"));
       // TODO check the Tax suffix
       // getAgentDataResponse.set(rsAgentDetails.getString("TAX_SUFFIX"));
		getAgentDataResponse.setSuffix(rsAgentDetails.getString("AGENT_NAME_SUFFIX"));

        addressType.setLine1(rsAgentDetails.getString("AGENT_ADDR_LINE_1"));
        addressType.setLine2(rsAgentDetails.getString("AGENT_ADDR_LINE_2"));
        addressType.setLine3(rsAgentDetails.getString("AGENT_ADDR_LINE_3"));
        addressType.setLine4(rsAgentDetails.getString("AGENT_ADDR_LINE_4"));
        addressType.setAddressStateCode(rsAgentDetails.getString("AGENT_STATE_CODE"));
        addressType.setCity(rsAgentDetails.getString("AGENT_CITY_CODE"));
        addressType.setAddressCountryCode(rsAgentDetails.getString("AGENT_COUNTRY_CODE"));
        addressType.setZipPrefix(rsAgentDetails.getString("AGENT_ZIP_PREFIX"));
        addressType.setZipSuffix(rsAgentDetails.getString("AGENT_ZIP_SUFFIX"));


		getAgentDataResponse.setAddress(addressType);
		getAgentDataResponse.setBirthDate(policyIndexDataUtils.convertUtilDateToGregoerianCalendar(rsAgentDetails.getDate("BIRTH_DATE")));
		getAgentDataResponse.setFirmName(rsAgentDetails.getString("CORPORATE_NAME"));
		getAgentDataResponse.setGenderTC(rsAgentDetails.getInt("SEX_CODE"));
		getAgentDataResponse.setPhoneNumber(rsAgentDetails.getString("TELEPHONE_NUMBER"));
		getAgentDataResponse.setAltPhoneNumber(rsAgentDetails.getString("ALT_TELEPHONE_NUMBER"));
		getAgentDataResponse.setFaxNumber(rsAgentDetails.getString("FAX_TELEPHONE_NUMBER"));
		return getAgentDataResponse;
	}


}
