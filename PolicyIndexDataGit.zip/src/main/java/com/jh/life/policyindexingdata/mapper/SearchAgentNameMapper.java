package com.jh.life.policyindexingdata.mapper;

import com.manulife.esb.xsd.annuity.jh.awdindexing.AgentSearchResultsType;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;


/**
 * The type Search agent name mapper.
 */
public class SearchAgentNameMapper implements RowMapper{

	@Override
	public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
		AgentSearchResultsType agentSearchResultsType = new AgentSearchResultsType();
		agentSearchResultsType.setStateCode(rs.getString("AGENT_STATE_CODE"));
		agentSearchResultsType.setLastName(rs.getString("AGENT_LAST_NAME"));
		agentSearchResultsType.setFirstName(rs.getString("AGENT_FIRST_NAME"));
		agentSearchResultsType.setGovtID(rs.getString("TAX_NUMBER"));
		agentSearchResultsType.setPhoneNumber(rs.getString("TELEPHONE_NUMBER"));
		return agentSearchResultsType;
	}

}
