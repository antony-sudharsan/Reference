package com.jh.life.policyindexingdata.utils;

import org.springframework.stereotype.Component;

import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;
import java.util.Date;
import java.util.GregorianCalendar;

/**
 * The type Policy index data utils.
 */
@Component
public class PolicyIndexDataUtils {

    /**
     * Convert util date to gregoerian calendar xml gregorian calendar.
     *
     * @param inputDate the input date
     *
     * @return xml gregorian calendar
     */
    public XMLGregorianCalendar convertUtilDateToGregoerianCalendar(Date inputDate)  {
        XMLGregorianCalendar date2 = null;
        if(inputDate != null) {
            GregorianCalendar gregorianCalContactEffDate = new GregorianCalendar();
            gregorianCalContactEffDate.setTime(inputDate);

            try {
                date2 = DatatypeFactory.newInstance().newXMLGregorianCalendar(gregorianCalContactEffDate);
            } catch (Exception e) {

            }
        }
        return date2;
    }

}
