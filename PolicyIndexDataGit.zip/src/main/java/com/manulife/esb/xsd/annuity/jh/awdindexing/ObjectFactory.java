
package com.manulife.esb.xsd.annuity.jh.awdindexing;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each
 * Java content interface and Java element interface
 * generated in the com.manulife.esb.xsd.annuity.jh.awdindexing package.
 * <p>An ObjectFactory allows you to programatically
 * construct new instances of the Java representation
 * for XML content. The Java representation of XML
 * content can consist of schema derived interfaces
 * and classes representing the binding of schema
 * type definitions, element declarations and model
 * groups.  Factory methods for each of these are
 * provided in this class.
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _PolNumber_QNAME = new QName("http://www.esb.manulife.com/xsd/Annuity/jh/AWDIndexing", "PolNumber");
    private final static QName _GovtIDTC_QNAME = new QName("http://www.esb.manulife.com/xsd/Annuity/jh/AWDIndexing", "GovtIDTC");
    private final static QName _CustomBrokerCode_QNAME = new QName("http://www.esb.manulife.com/xsd/Annuity/jh/AWDIndexing", "CustomBrokerCode");
    private final static QName _AddressCountryCode_QNAME = new QName("http://www.esb.manulife.com/xsd/Annuity/jh/AWDIndexing", "AddressCountryCode");
    private final static QName _Suffix_QNAME = new QName("http://www.esb.manulife.com/xsd/Annuity/jh/AWDIndexing", "Suffix");
    private final static QName _BirthDate_QNAME = new QName("http://www.esb.manulife.com/xsd/Annuity/jh/AWDIndexing", "BirthDate");
    private final static QName _GenderTC_QNAME = new QName("http://www.esb.manulife.com/xsd/Annuity/jh/AWDIndexing", "GenderTC");
    private final static QName _Annuitant_QNAME = new QName("http://www.esb.manulife.com/xsd/Annuity/jh/AWDIndexing", "Annuitant");
    private final static QName _LastName_QNAME = new QName("http://www.esb.manulife.com/xsd/Annuity/jh/AWDIndexing", "LastName");
    private final static QName _FirmName_QNAME = new QName("http://www.esb.manulife.com/xsd/Annuity/jh/AWDIndexing", "FirmName");
    private final static QName _Agent_QNAME = new QName("http://www.esb.manulife.com/xsd/Annuity/jh/AWDIndexing", "Agent");
    private final static QName _CompanyIndividualCode_QNAME = new QName("http://www.esb.manulife.com/xsd/Annuity/jh/AWDIndexing", "CompanyIndividualCode");
    private final static QName _BrokerCount_QNAME = new QName("http://www.esb.manulife.com/xsd/Annuity/jh/AWDIndexing", "BrokerCount");
    private final static QName _AgentAnnuityCompanyCode_QNAME = new QName("http://www.esb.manulife.com/xsd/Annuity/jh/AWDIndexing", "AgentAnnuityCompanyCode");
    private final static QName _City_QNAME = new QName("http://www.esb.manulife.com/xsd/Annuity/jh/AWDIndexing", "City");
    private final static QName _AnnuityOwner_QNAME = new QName("http://www.esb.manulife.com/xsd/Annuity/jh/AWDIndexing", "AnnuityOwner");
    private final static QName _FaxNumber_QNAME = new QName("http://www.esb.manulife.com/xsd/Annuity/jh/AWDIndexing", "FaxNumber");
    private final static QName _AgentId_QNAME = new QName("http://www.esb.manulife.com/xsd/Annuity/jh/AWDIndexing", "AgentId");
    private final static QName _GovtID_QNAME = new QName("http://www.esb.manulife.com/xsd/Annuity/jh/AWDIndexing", "GovtID");
    private final static QName _Address_QNAME = new QName("http://www.esb.manulife.com/xsd/Annuity/jh/AWDIndexing", "Address");
    private final static QName _AnnuityCompanyCode_QNAME = new QName("http://www.esb.manulife.com/xsd/Annuity/jh/AWDIndexing", "AnnuityCompanyCode");
    private final static QName _AddressStateCode_QNAME = new QName("http://www.esb.manulife.com/xsd/Annuity/jh/AWDIndexing", "AddressStateCode");
    private final static QName _AgentSearchResults_QNAME = new QName("http://www.esb.manulife.com/xsd/Annuity/jh/AWDIndexing", "AgentSearchResults");
    private final static QName _Line1_QNAME = new QName("http://www.esb.manulife.com/xsd/Annuity/jh/AWDIndexing", "Line1");
    private final static QName _Line3_QNAME = new QName("http://www.esb.manulife.com/xsd/Annuity/jh/AWDIndexing", "Line3");
    private final static QName _Line2_QNAME = new QName("http://www.esb.manulife.com/xsd/Annuity/jh/AWDIndexing", "Line2");
    private final static QName _PhoneNumber_QNAME = new QName("http://www.esb.manulife.com/xsd/Annuity/jh/AWDIndexing", "PhoneNumber");
    private final static QName _BrokerDealerName_QNAME = new QName("http://www.esb.manulife.com/xsd/Annuity/jh/AWDIndexing", "BrokerDealerName");
    private final static QName _FirstName_QNAME = new QName("http://www.esb.manulife.com/xsd/Annuity/jh/AWDIndexing", "FirstName");
    private final static QName _MasterAgentId_QNAME = new QName("http://www.esb.manulife.com/xsd/Annuity/jh/AWDIndexing", "MasterAgentId");
    private final static QName _MasterAnnuityCompanyCode_QNAME = new QName("http://www.esb.manulife.com/xsd/Annuity/jh/AWDIndexing", "MasterAnnuityCompanyCode");
    private final static QName _ZipPrefix_QNAME = new QName("http://www.esb.manulife.com/xsd/Annuity/jh/AWDIndexing", "ZipPrefix");
    private final static QName _StateCode_QNAME = new QName("http://www.esb.manulife.com/xsd/Annuity/jh/AWDIndexing", "StateCode");
    private final static QName _AltPhoneNumber_QNAME = new QName("http://www.esb.manulife.com/xsd/Annuity/jh/AWDIndexing", "AltPhoneNumber");
    private final static QName _ZipSuffix_QNAME = new QName("http://www.esb.manulife.com/xsd/Annuity/jh/AWDIndexing", "ZipSuffix");
    private final static QName _GenderDesc_QNAME = new QName("http://www.esb.manulife.com/xsd/Annuity/jh/AWDIndexing", "GenderDesc");
    private final static QName _ReinsTrtyInd_QNAME = new QName("http://www.esb.manulife.com/xsd/Annuity/jh/AWDIndexing", "ReinsTrtyInd");
    private final static QName _FixedVarCode_QNAME = new QName("http://www.esb.manulife.com/xsd/Annuity/jh/AWDIndexing", "FixedVarCode");
    private final static QName _Line4_QNAME = new QName("http://www.esb.manulife.com/xsd/Annuity/jh/AWDIndexing", "Line4");
    private final static QName _BrokerDealerId_QNAME = new QName("http://www.esb.manulife.com/xsd/Annuity/jh/AWDIndexing", "BrokerDealerId");
    private final static QName _Prefix_QNAME = new QName("http://www.esb.manulife.com/xsd/Annuity/jh/AWDIndexing", "Prefix");
    private final static QName _AnnuityLob_QNAME = new QName("http://www.esb.manulife.com/xsd/Annuity/jh/AWDIndexing", "AnnuityLob");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.manulife.esb.xsd.annuity.jh.awdindexing
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link AddressType }
     *
     * @return the address type
     */
    public AddressType createAddressType() {
        return new AddressType();
    }

    /**
     * Create an instance of {@link SearchAgentNameFault }
     *
     * @return the search agent name fault
     */
    public SearchAgentNameFault createSearchAgentNameFault() {
        return new SearchAgentNameFault();
    }

    /**
     * Create an instance of {@link GetPolicyDataResponse }
     *
     * @return the get policy data response
     */
    public GetPolicyDataResponse createGetPolicyDataResponse() {
        return new GetPolicyDataResponse();
    }

    /**
     * Create an instance of {@link AnnuityOwnerType }
     *
     * @return the annuity owner type
     */
    public AnnuityOwnerType createAnnuityOwnerType() {
        return new AnnuityOwnerType();
    }

    /**
     * Create an instance of {@link AnnuitantType }
     *
     * @return the annuitant type
     */
    public AnnuitantType createAnnuitantType() {
        return new AnnuitantType();
    }

    /**
     * Create an instance of {@link AgentType }
     *
     * @return the agent type
     */
    public AgentType createAgentType() {
        return new AgentType();
    }

    /**
     * Create an instance of {@link GetAgentDataRequest }
     *
     * @return the get agent data request
     */
    public GetAgentDataRequest createGetAgentDataRequest() {
        return new GetAgentDataRequest();
    }

    /**
     * Create an instance of {@link GetPolicyDataFault }
     *
     * @return the get policy data fault
     */
    public GetPolicyDataFault createGetPolicyDataFault() {
        return new GetPolicyDataFault();
    }

    /**
     * Create an instance of {@link SearchAgentNameResponse }
     *
     * @return the search agent name response
     */
    public SearchAgentNameResponse createSearchAgentNameResponse() {
        return new SearchAgentNameResponse();
    }

    /**
     * Create an instance of {@link AgentSearchResultsType }
     *
     * @return the agent search results type
     */
    public AgentSearchResultsType createAgentSearchResultsType() {
        return new AgentSearchResultsType();
    }

    /**
     * Create an instance of {@link GetAgentDataFault }
     *
     * @return the get agent data fault
     */
    public GetAgentDataFault createGetAgentDataFault() {
        return new GetAgentDataFault();
    }

    /**
     * Create an instance of {@link GetAgentDataResponse }
     *
     * @return the get agent data response
     */
    public GetAgentDataResponse createGetAgentDataResponse() {
        return new GetAgentDataResponse();
    }

    /**
     * Create an instance of {@link SearchAgentNameRequest }
     *
     * @return the search agent name request
     */
    public SearchAgentNameRequest createSearchAgentNameRequest() {
        return new SearchAgentNameRequest();
    }

    /**
     * Create an instance of {@link GetPolicyDataRequest }
     *
     * @return the get policy data request
     */
    public GetPolicyDataRequest createGetPolicyDataRequest() {
        return new GetPolicyDataRequest();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/Annuity/jh/AWDIndexing", name = "PolNumber")
    public JAXBElement<String> createPolNumber(String value) {
        return new JAXBElement<String>(_PolNumber_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Integer }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/Annuity/jh/AWDIndexing", name = "GovtIDTC")
    public JAXBElement<Integer> createGovtIDTC(Integer value) {
        return new JAXBElement<Integer>(_GovtIDTC_QNAME, Integer.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/Annuity/jh/AWDIndexing", name = "CustomBrokerCode")
    public JAXBElement<String> createCustomBrokerCode(String value) {
        return new JAXBElement<String>(_CustomBrokerCode_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/Annuity/jh/AWDIndexing", name = "AddressCountryCode")
    public JAXBElement<String> createAddressCountryCode(String value) {
        return new JAXBElement<String>(_AddressCountryCode_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/Annuity/jh/AWDIndexing", name = "Suffix")
    public JAXBElement<String> createSuffix(String value) {
        return new JAXBElement<String>(_Suffix_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/Annuity/jh/AWDIndexing", name = "BirthDate")
    public JAXBElement<XMLGregorianCalendar> createBirthDate(XMLGregorianCalendar value) {
        return new JAXBElement<XMLGregorianCalendar>(_BirthDate_QNAME, XMLGregorianCalendar.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Integer }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/Annuity/jh/AWDIndexing", name = "GenderTC")
    public JAXBElement<Integer> createGenderTC(Integer value) {
        return new JAXBElement<Integer>(_GenderTC_QNAME, Integer.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AnnuitantType }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/Annuity/jh/AWDIndexing", name = "Annuitant")
    public JAXBElement<AnnuitantType> createAnnuitant(AnnuitantType value) {
        return new JAXBElement<AnnuitantType>(_Annuitant_QNAME, AnnuitantType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/Annuity/jh/AWDIndexing", name = "LastName")
    public JAXBElement<String> createLastName(String value) {
        return new JAXBElement<String>(_LastName_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/Annuity/jh/AWDIndexing", name = "FirmName")
    public JAXBElement<String> createFirmName(String value) {
        return new JAXBElement<String>(_FirmName_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AgentType }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/Annuity/jh/AWDIndexing", name = "Agent")
    public JAXBElement<AgentType> createAgent(AgentType value) {
        return new JAXBElement<AgentType>(_Agent_QNAME, AgentType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/Annuity/jh/AWDIndexing", name = "CompanyIndividualCode")
    public JAXBElement<String> createCompanyIndividualCode(String value) {
        return new JAXBElement<String>(_CompanyIndividualCode_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Integer }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/Annuity/jh/AWDIndexing", name = "BrokerCount")
    public JAXBElement<Integer> createBrokerCount(Integer value) {
        return new JAXBElement<Integer>(_BrokerCount_QNAME, Integer.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/Annuity/jh/AWDIndexing", name = "AgentAnnuityCompanyCode")
    public JAXBElement<String> createAgentAnnuityCompanyCode(String value) {
        return new JAXBElement<String>(_AgentAnnuityCompanyCode_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/Annuity/jh/AWDIndexing", name = "City")
    public JAXBElement<String> createCity(String value) {
        return new JAXBElement<String>(_City_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AnnuityOwnerType }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/Annuity/jh/AWDIndexing", name = "AnnuityOwner")
    public JAXBElement<AnnuityOwnerType> createAnnuityOwner(AnnuityOwnerType value) {
        return new JAXBElement<AnnuityOwnerType>(_AnnuityOwner_QNAME, AnnuityOwnerType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/Annuity/jh/AWDIndexing", name = "FaxNumber")
    public JAXBElement<String> createFaxNumber(String value) {
        return new JAXBElement<String>(_FaxNumber_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/Annuity/jh/AWDIndexing", name = "AgentId")
    public JAXBElement<String> createAgentId(String value) {
        return new JAXBElement<String>(_AgentId_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/Annuity/jh/AWDIndexing", name = "GovtID")
    public JAXBElement<String> createGovtID(String value) {
        return new JAXBElement<String>(_GovtID_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AddressType }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/Annuity/jh/AWDIndexing", name = "Address")
    public JAXBElement<AddressType> createAddress(AddressType value) {
        return new JAXBElement<AddressType>(_Address_QNAME, AddressType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/Annuity/jh/AWDIndexing", name = "AnnuityCompanyCode")
    public JAXBElement<String> createAnnuityCompanyCode(String value) {
        return new JAXBElement<String>(_AnnuityCompanyCode_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/Annuity/jh/AWDIndexing", name = "AddressStateCode")
    public JAXBElement<String> createAddressStateCode(String value) {
        return new JAXBElement<String>(_AddressStateCode_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AgentSearchResultsType }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/Annuity/jh/AWDIndexing", name = "AgentSearchResults")
    public JAXBElement<AgentSearchResultsType> createAgentSearchResults(AgentSearchResultsType value) {
        return new JAXBElement<AgentSearchResultsType>(_AgentSearchResults_QNAME, AgentSearchResultsType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/Annuity/jh/AWDIndexing", name = "Line1")
    public JAXBElement<String> createLine1(String value) {
        return new JAXBElement<String>(_Line1_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/Annuity/jh/AWDIndexing", name = "Line3")
    public JAXBElement<String> createLine3(String value) {
        return new JAXBElement<String>(_Line3_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/Annuity/jh/AWDIndexing", name = "Line2")
    public JAXBElement<String> createLine2(String value) {
        return new JAXBElement<String>(_Line2_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/Annuity/jh/AWDIndexing", name = "PhoneNumber")
    public JAXBElement<String> createPhoneNumber(String value) {
        return new JAXBElement<String>(_PhoneNumber_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/Annuity/jh/AWDIndexing", name = "BrokerDealerName")
    public JAXBElement<String> createBrokerDealerName(String value) {
        return new JAXBElement<String>(_BrokerDealerName_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/Annuity/jh/AWDIndexing", name = "FirstName")
    public JAXBElement<String> createFirstName(String value) {
        return new JAXBElement<String>(_FirstName_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/Annuity/jh/AWDIndexing", name = "MasterAgentId")
    public JAXBElement<String> createMasterAgentId(String value) {
        return new JAXBElement<String>(_MasterAgentId_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/Annuity/jh/AWDIndexing", name = "MasterAnnuityCompanyCode")
    public JAXBElement<String> createMasterAnnuityCompanyCode(String value) {
        return new JAXBElement<String>(_MasterAnnuityCompanyCode_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/Annuity/jh/AWDIndexing", name = "ZipPrefix")
    public JAXBElement<String> createZipPrefix(String value) {
        return new JAXBElement<String>(_ZipPrefix_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/Annuity/jh/AWDIndexing", name = "StateCode")
    public JAXBElement<String> createStateCode(String value) {
        return new JAXBElement<String>(_StateCode_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/Annuity/jh/AWDIndexing", name = "AltPhoneNumber")
    public JAXBElement<String> createAltPhoneNumber(String value) {
        return new JAXBElement<String>(_AltPhoneNumber_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/Annuity/jh/AWDIndexing", name = "ZipSuffix")
    public JAXBElement<String> createZipSuffix(String value) {
        return new JAXBElement<String>(_ZipSuffix_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/Annuity/jh/AWDIndexing", name = "GenderDesc")
    public JAXBElement<String> createGenderDesc(String value) {
        return new JAXBElement<String>(_GenderDesc_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Indicator }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/Annuity/jh/AWDIndexing", name = "ReinsTrtyInd")
    public JAXBElement<Indicator> createReinsTrtyInd(Indicator value) {
        return new JAXBElement<Indicator>(_ReinsTrtyInd_QNAME, Indicator.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link FixedVarCodeType }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/Annuity/jh/AWDIndexing", name = "FixedVarCode")
    public JAXBElement<FixedVarCodeType> createFixedVarCode(FixedVarCodeType value) {
        return new JAXBElement<FixedVarCodeType>(_FixedVarCode_QNAME, FixedVarCodeType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/Annuity/jh/AWDIndexing", name = "Line4")
    public JAXBElement<String> createLine4(String value) {
        return new JAXBElement<String>(_Line4_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/Annuity/jh/AWDIndexing", name = "BrokerDealerId")
    public JAXBElement<String> createBrokerDealerId(String value) {
        return new JAXBElement<String>(_BrokerDealerId_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/Annuity/jh/AWDIndexing", name = "Prefix")
    public JAXBElement<String> createPrefix(String value) {
        return new JAXBElement<String>(_Prefix_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/Annuity/jh/AWDIndexing", name = "AnnuityLob")
    public JAXBElement<String> createAnnuityLob(String value) {
        return new JAXBElement<String>(_AnnuityLob_QNAME, String.class, null, value);
    }

}
