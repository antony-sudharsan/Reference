
package com.manulife.esb.xsd.annuity.jh.awdindexing;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 *
 * <p>The following schema fragment specifies the expected content contained within this class.
 *
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/Annuity/jh/AWDIndexing}AnnuityCompanyCode"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/Annuity/jh/AWDIndexing}AnnuityLob"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/Annuity/jh/AWDIndexing}FixedVarCode"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/Annuity/jh/AWDIndexing}ReinsTrtyInd"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/Annuity/jh/AWDIndexing}AnnuityOwner"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/Annuity/jh/AWDIndexing}Annuitant"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/Annuity/jh/AWDIndexing}BrokerCount"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/Annuity/jh/AWDIndexing}Agent"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "annuityCompanyCode",
    "annuityLob",
    "fixedVarCode",
    "reinsTrtyInd",
    "annuityOwner",
    "annuitant",
    "brokerCount",
    "agent"
})
@XmlRootElement(name = "GetPolicyData_response")
public class GetPolicyDataResponse {

    /**
     * The Annuity company code.
     */
    @XmlElement(name = "AnnuityCompanyCode", required = true)
    protected String annuityCompanyCode;
    /**
     * The Annuity lob.
     */
    @XmlElement(name = "AnnuityLob", required = true)
    protected String annuityLob;
    /**
     * The Fixed var code.
     */
    @XmlElement(name = "FixedVarCode", required = true)
    @XmlSchemaType(name = "string")
    protected FixedVarCodeType fixedVarCode;
    /**
     * The Reins trty ind.
     */
    @XmlElement(name = "ReinsTrtyInd", required = true)
    @XmlSchemaType(name = "string")
    protected Indicator reinsTrtyInd;
    /**
     * The Annuity owner.
     */
    @XmlElement(name = "AnnuityOwner", required = true)
    protected AnnuityOwnerType annuityOwner;
    /**
     * The Annuitant.
     */
    @XmlElement(name = "Annuitant", required = true)
    protected AnnuitantType annuitant;
    /**
     * The Broker count.
     */
    @XmlElement(name = "BrokerCount")
    protected int brokerCount;
    /**
     * The Agent.
     */
    @XmlElement(name = "Agent", required = true)
    protected AgentType agent;

    /**
     * Gets the value of the annuityCompanyCode property.
     *
     * @return possible      object is     {@link String }
     */
    public String getAnnuityCompanyCode() {
        return annuityCompanyCode;
    }

    /**
     * Sets the value of the annuityCompanyCode property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setAnnuityCompanyCode(String value) {
        this.annuityCompanyCode = value;
    }

    /**
     * Gets the value of the annuityLob property.
     *
     * @return possible      object is     {@link String }
     */
    public String getAnnuityLob() {
        return annuityLob;
    }

    /**
     * Sets the value of the annuityLob property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setAnnuityLob(String value) {
        this.annuityLob = value;
    }

    /**
     * Gets the value of the fixedVarCode property.
     *
     * @return possible      object is     {@link FixedVarCodeType }
     */
    public FixedVarCodeType getFixedVarCode() {
        return fixedVarCode;
    }

    /**
     * Sets the value of the fixedVarCode property.
     *
     * @param value allowed object is     {@link FixedVarCodeType }
     */
    public void setFixedVarCode(FixedVarCodeType value) {
        this.fixedVarCode = value;
    }

    /**
     * Gets the value of the reinsTrtyInd property.
     *
     * @return possible      object is     {@link Indicator }
     */
    public Indicator getReinsTrtyInd() {
        return reinsTrtyInd;
    }

    /**
     * Sets the value of the reinsTrtyInd property.
     *
     * @param value allowed object is     {@link Indicator }
     */
    public void setReinsTrtyInd(Indicator value) {
        this.reinsTrtyInd = value;
    }

    /**
     * Gets the value of the annuityOwner property.
     *
     * @return possible      object is     {@link AnnuityOwnerType }
     */
    public AnnuityOwnerType getAnnuityOwner() {
        return annuityOwner;
    }

    /**
     * Sets the value of the annuityOwner property.
     *
     * @param value allowed object is     {@link AnnuityOwnerType }
     */
    public void setAnnuityOwner(AnnuityOwnerType value) {
        this.annuityOwner = value;
    }

    /**
     * Gets the value of the annuitant property.
     *
     * @return possible      object is     {@link AnnuitantType }
     */
    public AnnuitantType getAnnuitant() {
        return annuitant;
    }

    /**
     * Sets the value of the annuitant property.
     *
     * @param value allowed object is     {@link AnnuitantType }
     */
    public void setAnnuitant(AnnuitantType value) {
        this.annuitant = value;
    }

    /**
     * Gets the value of the brokerCount property.
     *
     * @return the broker count
     */
    public int getBrokerCount() {
        return brokerCount;
    }

    /**
     * Sets the value of the brokerCount property.
     *
     * @param value the value
     */
    public void setBrokerCount(int value) {
        this.brokerCount = value;
    }

    /**
     * Gets the value of the agent property.
     *
     * @return possible      object is     {@link AgentType }
     */
    public AgentType getAgent() {
        return agent;
    }

    /**
     * Sets the value of the agent property.
     *
     * @param value allowed object is     {@link AgentType }
     */
    public void setAgent(AgentType value) {
        this.agent = value;
    }

}
