
package com.manulife.esb.xsd.annuity.jh.awdindexing;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for Address_Type complex type.
 *
 * <p>The following schema fragment specifies the expected content contained within this class.
 *
 * <pre>
 * &lt;complexType name="Address_Type">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/Annuity/jh/AWDIndexing}Line1"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/Annuity/jh/AWDIndexing}Line2" minOccurs="0"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/Annuity/jh/AWDIndexing}Line3" minOccurs="0"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/Annuity/jh/AWDIndexing}Line4" minOccurs="0"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/Annuity/jh/AWDIndexing}City"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/Annuity/jh/AWDIndexing}AddressStateCode"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/Annuity/jh/AWDIndexing}ZipPrefix" minOccurs="0"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/Annuity/jh/AWDIndexing}ZipSuffix" minOccurs="0"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/Annuity/jh/AWDIndexing}AddressCountryCode" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Address_Type", propOrder = {
    "line1",
    "line2",
    "line3",
    "line4",
    "city",
    "addressStateCode",
    "zipPrefix",
    "zipSuffix",
    "addressCountryCode"
})
public class AddressType {

    /**
     * The Line 1.
     */
    @XmlElement(name = "Line1", required = true)
    protected String line1;
    /**
     * The Line 2.
     */
    @XmlElement(name = "Line2")
    protected String line2;
    /**
     * The Line 3.
     */
    @XmlElement(name = "Line3")
    protected String line3;
    /**
     * The Line 4.
     */
    @XmlElement(name = "Line4")
    protected String line4;
    /**
     * The City.
     */
    @XmlElement(name = "City", required = true)
    protected String city;
    /**
     * The Address state code.
     */
    @XmlElement(name = "AddressStateCode", required = true)
    protected String addressStateCode;
    /**
     * The Zip prefix.
     */
    @XmlElement(name = "ZipPrefix")
    protected String zipPrefix;
    /**
     * The Zip suffix.
     */
    @XmlElement(name = "ZipSuffix")
    protected String zipSuffix;
    /**
     * The Address country code.
     */
    @XmlElement(name = "AddressCountryCode")
    protected String addressCountryCode;

    /**
     * Gets the value of the line1 property.
     *
     * @return possible      object is     {@link String }
     */
    public String getLine1() {
        return line1;
    }

    /**
     * Sets the value of the line1 property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setLine1(String value) {
        this.line1 = value;
    }

    /**
     * Gets the value of the line2 property.
     *
     * @return possible      object is     {@link String }
     */
    public String getLine2() {
        return line2;
    }

    /**
     * Sets the value of the line2 property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setLine2(String value) {
        this.line2 = value;
    }

    /**
     * Gets the value of the line3 property.
     *
     * @return possible      object is     {@link String }
     */
    public String getLine3() {
        return line3;
    }

    /**
     * Sets the value of the line3 property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setLine3(String value) {
        this.line3 = value;
    }

    /**
     * Gets the value of the line4 property.
     *
     * @return possible      object is     {@link String }
     */
    public String getLine4() {
        return line4;
    }

    /**
     * Sets the value of the line4 property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setLine4(String value) {
        this.line4 = value;
    }

    /**
     * Gets the value of the city property.
     *
     * @return possible      object is     {@link String }
     */
    public String getCity() {
        return city;
    }

    /**
     * Sets the value of the city property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setCity(String value) {
        this.city = value;
    }

    /**
     * Gets the value of the addressStateCode property.
     *
     * @return possible      object is     {@link String }
     */
    public String getAddressStateCode() {
        return addressStateCode;
    }

    /**
     * Sets the value of the addressStateCode property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setAddressStateCode(String value) {
        this.addressStateCode = value;
    }

    /**
     * Gets the value of the zipPrefix property.
     *
     * @return possible      object is     {@link String }
     */
    public String getZipPrefix() {
        return zipPrefix;
    }

    /**
     * Sets the value of the zipPrefix property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setZipPrefix(String value) {
        this.zipPrefix = value;
    }

    /**
     * Gets the value of the zipSuffix property.
     *
     * @return possible      object is     {@link String }
     */
    public String getZipSuffix() {
        return zipSuffix;
    }

    /**
     * Sets the value of the zipSuffix property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setZipSuffix(String value) {
        this.zipSuffix = value;
    }

    /**
     * Gets the value of the addressCountryCode property.
     *
     * @return possible      object is     {@link String }
     */
    public String getAddressCountryCode() {
        return addressCountryCode;
    }

    /**
     * Sets the value of the addressCountryCode property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setAddressCountryCode(String value) {
        this.addressCountryCode = value;
    }

}
