
package com.manulife.esb.xsd.annuity.jh.awdindexing;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 *
 * <p>The following schema fragment specifies the expected content contained within this class.
 *
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/Annuity/jh/AWDIndexing}AgentSearchResults" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "agentSearchResults"
})
@XmlRootElement(name = "SearchAgentName_response")
public class SearchAgentNameResponse {

    /**
     * Sets agent search results.
     *
     * @param agentSearchResults the agent search results
     */
    public void setAgentSearchResults(List<AgentSearchResultsType> agentSearchResults) {
        this.agentSearchResults = agentSearchResults;
    }

    /**
     * The Agent search results.
     */
    @XmlElement(name = "AgentSearchResults")
    protected List<AgentSearchResultsType> agentSearchResults;

    /**
     * Gets the value of the agentSearchResults property.
     * <p>
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the agentSearchResults property.
     * <p>
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAgentSearchResults().add(newItem);
     * </pre>
     * <p>
     * <p>
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link AgentSearchResultsType }
     *
     * @return the agent search results
     */
    public List<AgentSearchResultsType> getAgentSearchResults() {
        if (agentSearchResults == null) {
            agentSearchResults = new ArrayList<AgentSearchResultsType>();
        }
        return this.agentSearchResults;
    }

}
