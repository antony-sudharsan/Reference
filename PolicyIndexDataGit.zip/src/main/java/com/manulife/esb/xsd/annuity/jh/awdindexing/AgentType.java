
package com.manulife.esb.xsd.annuity.jh.awdindexing;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for Agent_Type complex type.
 *
 * <p>The following schema fragment specifies the expected content contained within this class.
 *
 * <pre>
 * &lt;complexType name="Agent_Type">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/Annuity/jh/AWDIndexing}AgentId"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/Annuity/jh/AWDIndexing}BrokerDealerId" minOccurs="0"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/Annuity/jh/AWDIndexing}BrokerDealerName" minOccurs="0"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/Annuity/jh/AWDIndexing}CustomBrokerCode" minOccurs="0"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/Annuity/jh/AWDIndexing}FirstName"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/Annuity/jh/AWDIndexing}LastName"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/Annuity/jh/AWDIndexing}GovtID"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/Annuity/jh/AWDIndexing}GovtIDTC"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/Annuity/jh/AWDIndexing}PhoneNumber"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Agent_Type", propOrder = {
    "agentId",
    "brokerDealerId",
    "brokerDealerName",
    "customBrokerCode",
    "firstName",
    "lastName",
    "govtID",
    "govtIDTC",
    "phoneNumber"
})
public class AgentType {

    /**
     * The Agent id.
     */
    @XmlElement(name = "AgentId", required = true)
    protected String agentId;
    /**
     * The Broker dealer id.
     */
    @XmlElement(name = "BrokerDealerId")
    protected String brokerDealerId;
    /**
     * The Broker dealer name.
     */
    @XmlElement(name = "BrokerDealerName")
    protected String brokerDealerName;
    /**
     * The Custom broker code.
     */
    @XmlElement(name = "CustomBrokerCode")
    protected String customBrokerCode;
    /**
     * The First name.
     */
    @XmlElement(name = "FirstName", required = true)
    protected String firstName;
    /**
     * The Last name.
     */
    @XmlElement(name = "LastName", required = true)
    protected String lastName;
    /**
     * The Govt id.
     */
    @XmlElement(name = "GovtID", required = true)
    protected String govtID;
    /**
     * The Govt idtc.
     */
    @XmlElement(name = "GovtIDTC")
    protected int govtIDTC;
    /**
     * The Phone number.
     */
    @XmlElement(name = "PhoneNumber", required = true)
    protected String phoneNumber;

    /**
     * Gets the value of the agentId property.
     *
     * @return possible      object is     {@link String }
     */
    public String getAgentId() {
        return agentId;
    }

    /**
     * Sets the value of the agentId property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setAgentId(String value) {
        this.agentId = value;
    }

    /**
     * Gets the value of the brokerDealerId property.
     *
     * @return possible      object is     {@link String }
     */
    public String getBrokerDealerId() {
        return brokerDealerId;
    }

    /**
     * Sets the value of the brokerDealerId property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setBrokerDealerId(String value) {
        this.brokerDealerId = value;
    }

    /**
     * Gets the value of the brokerDealerName property.
     *
     * @return possible      object is     {@link String }
     */
    public String getBrokerDealerName() {
        return brokerDealerName;
    }

    /**
     * Sets the value of the brokerDealerName property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setBrokerDealerName(String value) {
        this.brokerDealerName = value;
    }

    /**
     * Expected values are 0 or 1.
     *
     * @return possible      object is     {@link String }
     */
    public String getCustomBrokerCode() {
        return customBrokerCode;
    }

    /**
     * Sets the value of the customBrokerCode property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setCustomBrokerCode(String value) {
        this.customBrokerCode = value;
    }

    /**
     * Gets the value of the firstName property.
     *
     * @return possible      object is     {@link String }
     */
    public String getFirstName() {
        return firstName;
    }

    /**
     * Sets the value of the firstName property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setFirstName(String value) {
        this.firstName = value;
    }

    /**
     * Gets the value of the lastName property.
     *
     * @return possible      object is     {@link String }
     */
    public String getLastName() {
        return lastName;
    }

    /**
     * Sets the value of the lastName property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setLastName(String value) {
        this.lastName = value;
    }

    /**
     * Gets the value of the govtID property.
     *
     * @return possible      object is     {@link String }
     */
    public String getGovtID() {
        return govtID;
    }

    /**
     * Sets the value of the govtID property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setGovtID(String value) {
        this.govtID = value;
    }

    /**
     * Gets the value of the govtIDTC property.
     *
     * @return the govt idtc
     */
    public int getGovtIDTC() {
        return govtIDTC;
    }

    /**
     * Sets the value of the govtIDTC property.
     *
     * @param value the value
     */
    public void setGovtIDTC(int value) {
        this.govtIDTC = value;
    }

    /**
     * Gets the value of the phoneNumber property.
     *
     * @return possible      object is     {@link String }
     */
    public String getPhoneNumber() {
        return phoneNumber;
    }

    /**
     * Sets the value of the phoneNumber property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setPhoneNumber(String value) {
        this.phoneNumber = value;
    }

}
