
package com.manulife.esb.xsd.annuity.jh.awdindexing;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for AgentSearchResults_Type complex type.
 *
 * <p>The following schema fragment specifies the expected content contained within this class.
 *
 * <pre>
 * &lt;complexType name="AgentSearchResults_Type">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/Annuity/jh/AWDIndexing}FirstName"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/Annuity/jh/AWDIndexing}LastName"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/Annuity/jh/AWDIndexing}StateCode"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/Annuity/jh/AWDIndexing}GovtID"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/Annuity/jh/AWDIndexing}GovtIDTC"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/Annuity/jh/AWDIndexing}PhoneNumber"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "AgentSearchResults_Type", propOrder = {
    "firstName",
    "lastName",
    "stateCode",
    "govtID",
    "govtIDTC",
    "phoneNumber"
})
public class AgentSearchResultsType {

    /**
     * The First name.
     */
    @XmlElement(name = "FirstName", required = true)
    protected String firstName;
    /**
     * The Last name.
     */
    @XmlElement(name = "LastName", required = true)
    protected String lastName;
    /**
     * The State code.
     */
    @XmlElement(name = "StateCode", required = true)
    protected String stateCode;
    /**
     * The Govt id.
     */
    @XmlElement(name = "GovtID", required = true)
    protected String govtID;
    /**
     * The Govt idtc.
     */
    @XmlElement(name = "GovtIDTC")
    protected int govtIDTC;
    /**
     * The Phone number.
     */
    @XmlElement(name = "PhoneNumber", required = true)
    protected String phoneNumber;

    /**
     * Gets the value of the firstName property.
     *
     * @return possible      object is     {@link String }
     */
    public String getFirstName() {
        return firstName;
    }

    /**
     * Sets the value of the firstName property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setFirstName(String value) {
        this.firstName = value;
    }

    /**
     * Gets the value of the lastName property.
     *
     * @return possible      object is     {@link String }
     */
    public String getLastName() {
        return lastName;
    }

    /**
     * Sets the value of the lastName property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setLastName(String value) {
        this.lastName = value;
    }

    /**
     * Gets the value of the stateCode property.
     *
     * @return possible      object is     {@link String }
     */
    public String getStateCode() {
        return stateCode;
    }

    /**
     * Sets the value of the stateCode property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setStateCode(String value) {
        this.stateCode = value;
    }

    /**
     * Gets the value of the govtID property.
     *
     * @return possible      object is     {@link String }
     */
    public String getGovtID() {
        return govtID;
    }

    /**
     * Sets the value of the govtID property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setGovtID(String value) {
        this.govtID = value;
    }

    /**
     * Gets the value of the govtIDTC property.
     *
     * @return the govt idtc
     */
    public int getGovtIDTC() {
        return govtIDTC;
    }

    /**
     * Sets the value of the govtIDTC property.
     *
     * @param value the value
     */
    public void setGovtIDTC(int value) {
        this.govtIDTC = value;
    }

    /**
     * Gets the value of the phoneNumber property.
     *
     * @return possible      object is     {@link String }
     */
    public String getPhoneNumber() {
        return phoneNumber;
    }

    /**
     * Sets the value of the phoneNumber property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setPhoneNumber(String value) {
        this.phoneNumber = value;
    }

}
