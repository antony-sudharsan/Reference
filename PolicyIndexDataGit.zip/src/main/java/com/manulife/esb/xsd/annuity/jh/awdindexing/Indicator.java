
package com.manulife.esb.xsd.annuity.jh.awdindexing;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for Indicator.
 *
 * <p>The following schema fragment specifies the expected content contained within this class.
 *
 * <pre>
 * &lt;simpleType name="Indicator">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="Y"/>
 *     &lt;enumeration value="B"/>
 *     &lt;enumeration value="C"/>
 *     &lt;enumeration value="N"/>
 *     &lt;enumeration value="A"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 */
@XmlType(name = "Indicator")
@XmlEnum
public enum Indicator {

    /**
     * Y indicator.
     */
    Y,
    /**
     * B indicator.
     */
    B,
    /**
     * C indicator.
     */
    C,
    /**
     * N indicator.
     */
    N,
    /**
     * A indicator.
     */
    A;

    /**
     * Value string.
     *
     * @return the string
     */
    public String value() {
        return name();
    }

    /**
     * From value indicator.
     *
     * @param v the v
     *
     * @return the indicator
     */
    public static Indicator fromValue(String v) {
        return valueOf(v);
    }

}
