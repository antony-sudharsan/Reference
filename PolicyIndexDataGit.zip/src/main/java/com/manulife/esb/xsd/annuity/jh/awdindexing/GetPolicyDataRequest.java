
package com.manulife.esb.xsd.annuity.jh.awdindexing;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 *
 * <p>The following schema fragment specifies the expected content contained within this class.
 *
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/Annuity/jh/AWDIndexing}PolNumber"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "polNumber"
})
@XmlRootElement(name = "GetPolicyData_request")
public class GetPolicyDataRequest {

    /**
     * The Pol number.
     */
    @XmlElement(name = "PolNumber", required = true)
    protected String polNumber;

    /**
     * Gets the value of the polNumber property.
     *
     * @return possible      object is     {@link String }
     */
    public String getPolNumber() {
        return polNumber;
    }

    /**
     * Sets the value of the polNumber property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setPolNumber(String value) {
        this.polNumber = value;
    }

}
