
package com.manulife.esb.xsd.annuity.jh.awdindexing;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for AnnuityOwner_Type complex type.
 *
 * <p>The following schema fragment specifies the expected content contained within this class.
 *
 * <pre>
 * &lt;complexType name="AnnuityOwner_Type">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/Annuity/jh/AWDIndexing}CompanyIndividualCode"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/Annuity/jh/AWDIndexing}FirmName" minOccurs="0"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/Annuity/jh/AWDIndexing}LastName" minOccurs="0"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/Annuity/jh/AWDIndexing}FirstName" minOccurs="0"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/Annuity/jh/AWDIndexing}GovtID" minOccurs="0"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/Annuity/jh/AWDIndexing}GovtIDTC" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "AnnuityOwner_Type", propOrder = {
    "companyIndividualCode",
    "firmName",
    "lastName",
    "firstName",
    "govtID",
    "govtIDTC"
})
public class AnnuityOwnerType {

    /**
     * The Company individual code.
     */
    @XmlElement(name = "CompanyIndividualCode", required = true)
    protected String companyIndividualCode;
    /**
     * The Firm name.
     */
    @XmlElement(name = "FirmName")
    protected String firmName;
    /**
     * The Last name.
     */
    @XmlElement(name = "LastName")
    protected String lastName;
    /**
     * The First name.
     */
    @XmlElement(name = "FirstName")
    protected String firstName;
    /**
     * The Govt id.
     */
    @XmlElement(name = "GovtID")
    protected String govtID;
    /**
     * The Govt idtc.
     */
    @XmlElement(name = "GovtIDTC")
    protected Integer govtIDTC;

    /**
     * Gets the value of the companyIndividualCode property.
     *
     * @return possible      object is     {@link String }
     */
    public String getCompanyIndividualCode() {
        return companyIndividualCode;
    }

    /**
     * Sets the value of the companyIndividualCode property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setCompanyIndividualCode(String value) {
        this.companyIndividualCode = value;
    }

    /**
     * Gets the value of the firmName property.
     *
     * @return possible      object is     {@link String }
     */
    public String getFirmName() {
        return firmName;
    }

    /**
     * Sets the value of the firmName property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setFirmName(String value) {
        this.firmName = value;
    }

    /**
     * Gets the value of the lastName property.
     *
     * @return possible      object is     {@link String }
     */
    public String getLastName() {
        return lastName;
    }

    /**
     * Sets the value of the lastName property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setLastName(String value) {
        this.lastName = value;
    }

    /**
     * Gets the value of the firstName property.
     *
     * @return possible      object is     {@link String }
     */
    public String getFirstName() {
        return firstName;
    }

    /**
     * Sets the value of the firstName property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setFirstName(String value) {
        this.firstName = value;
    }

    /**
     * Gets the value of the govtID property.
     *
     * @return possible      object is     {@link String }
     */
    public String getGovtID() {
        return govtID;
    }

    /**
     * Sets the value of the govtID property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setGovtID(String value) {
        this.govtID = value;
    }

    /**
     * Gets the value of the govtIDTC property.
     *
     * @return possible      object is     {@link Integer }
     */
    public Integer getGovtIDTC() {
        return govtIDTC;
    }

    /**
     * Sets the value of the govtIDTC property.
     *
     * @param value allowed object is     {@link Integer }
     */
    public void setGovtIDTC(Integer value) {
        this.govtIDTC = value;
    }

}
