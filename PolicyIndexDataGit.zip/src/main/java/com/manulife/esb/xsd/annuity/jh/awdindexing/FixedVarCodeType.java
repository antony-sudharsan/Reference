
package com.manulife.esb.xsd.annuity.jh.awdindexing;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for FixedVarCode_Type.
 *
 * <p>The following schema fragment specifies the expected content contained within this class.
 *
 * <pre>
 * &lt;simpleType name="FixedVarCode_Type">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="F"/>
 *     &lt;enumeration value="V"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 */
@XmlType(name = "FixedVarCode_Type")
@XmlEnum
public enum FixedVarCodeType {


    /**
     * Fixed
     */
    F,

    /**
     * Variable
     */
    V;

    /**
     * Value string.
     *
     * @return the string
     */
    public String value() {
        return name();
    }

    /**
     * From value fixed var code type.
     *
     * @param v the v
     *
     * @return the fixed var code type
     */
    public static FixedVarCodeType fromValue(String v) {
        return valueOf(v);
    }

}
