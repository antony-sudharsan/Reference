
package com.manulife.esb.xsd.common.jh.header;

import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for anonymous complex type.
 *
 * <p>The following schema fragment specifies the expected content contained within this class.
 *
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/common/jh/header}Version"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/common/jh/header}ConversationUID"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/common/jh/header}MessageUID"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/common/jh/header}RelatesTo"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/common/jh/header}MessageType"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/common/jh/header}OriginalMessageDateTime"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/common/jh/header}CurrentMessageDateTime"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/common/jh/header}MessageSource"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/common/jh/header}ServiceInfo"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/common/jh/header}Status" minOccurs="0"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/common/jh/header}EnvironmentID" minOccurs="0"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/common/jh/header}RequestTimeOut" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "version",
    "conversationUID",
    "messageUID",
    "relatesTo",
    "messageType",
    "originalMessageDateTime",
    "currentMessageDateTime",
    "messageSource",
    "serviceInfo",
    "status",
    "environmentID",
    "requestTimeOut"
})
@XmlRootElement(name = "JHHeader")
public class JHHeader {

    /**
     * The Version.
     */
    @XmlElement(name = "Version", required = true)
    protected String version;
    /**
     * The Conversation uid.
     */
    @XmlElement(name = "ConversationUID", required = true)
    protected String conversationUID;
    /**
     * The Message uid.
     */
    @XmlElement(name = "MessageUID", required = true)
    protected String messageUID;
    /**
     * The Relates to.
     */
    @XmlElement(name = "RelatesTo", required = true)
    protected String relatesTo;
    /**
     * The Message type.
     */
    @XmlElement(name = "MessageType", required = true)
    protected String messageType;
    /**
     * The Original message date time.
     */
    @XmlElement(name = "OriginalMessageDateTime", required = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar originalMessageDateTime;
    /**
     * The Current message date time.
     */
    @XmlElement(name = "CurrentMessageDateTime", required = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar currentMessageDateTime;
    /**
     * The Message source.
     */
    @XmlElement(name = "MessageSource", required = true)
    protected MessageSource messageSource;
    /**
     * The Service info.
     */
    @XmlElement(name = "ServiceInfo", required = true)
    protected ServiceInfo serviceInfo;
    /**
     * The Status.
     */
    @XmlElement(name = "Status")
    protected Status status;
    /**
     * The Environment id.
     */
    @XmlElement(name = "EnvironmentID", nillable = true)
    protected String environmentID;
    /**
     * The Request time out.
     */
    @XmlElement(name = "RequestTimeOut")
    protected BigDecimal requestTimeOut;

    /**
     * Used to indicate the XML document
     * Version
     *
     * @return possible      object is     {@link String }
     */
    public String getVersion() {
        return version;
    }

    /**
     * Sets the value of the version property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setVersion(String value) {
        this.version = value;
    }

    /**
     * This must be unique ID across a chain of messages and should be carried by each requestor at each stage of message flow.
     * UID is used to trace the request/response in the multiple channels-clients. It is strongly recommended that the client log this ID in their log.
     *
     * @return possible      object is     {@link String }
     */
    public String getConversationUID() {
        return conversationUID;
    }

    /**
     * Sets the value of the conversationUID property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setConversationUID(String value) {
        this.conversationUID = value;
    }

    /**
     * This must be unique for each request and should be created by each requestor at each stage of message flow.
     * UID is used to trace the request/response in the multiple channels-clients. It is strongly recommended that the client log this ID in their log.
     * Channel/Requestor supplies its own UID and ESB /service provider sets it in the response SOAP header.
     *
     * @return possible      object is     {@link String }
     */
    public String getMessageUID() {
        return messageUID;
    }

    /**
     * Sets the value of the messageUID property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setMessageUID(String value) {
        this.messageUID = value;
    }

    /**
     * This element specifies the MessageUID to which it is related. In a chain of requests, this specifies the messageUID of previous requestor.
     * It should be set to \ufffdNA\ufffd by the request initiator in the message chain. Together with MessageUID, it constitutes a unique combination across the chain of messages.
     *
     * @return possible      object is     {@link String }
     */
    public String getRelatesTo() {
        return relatesTo;
    }

    /**
     * Sets the value of the relatesTo property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setRelatesTo(String value) {
        this.relatesTo = value;
    }

    /**
     * This element is required to distinguish a record in the logs from a request or response type assuming for a request-reply pattern we log both incoming request and outgoing response message.
     *
     * @return possible      object is     {@link String }
     */
    public String getMessageType() {
        return messageType;
    }

    /**
     * Sets the value of the messageType property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setMessageType(String value) {
        this.messageType = value;
    }

    /**
     * This date time is set by the request initiator and carried AS_IS by each message in the chain. format,
     * yyyy-MM-dd'T'HH:mm:ss.SSS.T
     *
     * @return possible      object is     {@link XMLGregorianCalendar }
     */
    public XMLGregorianCalendar getOriginalMessageDateTime() {
        return originalMessageDateTime;
    }

    /**
     * Sets the value of the originalMessageDateTime property.
     *
     * @param value allowed object is     {@link XMLGregorianCalendar }
     */
    public void setOriginalMessageDateTime(XMLGregorianCalendar value) {
        this.originalMessageDateTime = value;
    }

    /**
     * Time according to the client, In cases where there is
     * an external client.
     *
     * @return possible      object is     {@link XMLGregorianCalendar }
     */
    public XMLGregorianCalendar getCurrentMessageDateTime() {
        return currentMessageDateTime;
    }

    /**
     * Sets the value of the currentMessageDateTime property.
     *
     * @param value allowed object is     {@link XMLGregorianCalendar }
     */
    public void setCurrentMessageDateTime(XMLGregorianCalendar value) {
        this.currentMessageDateTime = value;
    }

    /**
     * Describes the Source of a message.
     *
     * @return possible      object is     {@link MessageSource }
     */
    public MessageSource getMessageSource() {
        return messageSource;
    }

    /**
     * Sets the value of the messageSource property.
     *
     * @param value allowed object is     {@link MessageSource }
     */
    public void setMessageSource(MessageSource value) {
        this.messageSource = value;
    }

    /**
     * Describes the Service that is requested. This
     * element is set by the first server on the request processing path. It is optional for
     * client  issuing the original request.
     *
     * @return possible      object is     {@link ServiceInfo }
     */
    public ServiceInfo getServiceInfo() {
        return serviceInfo;
    }

    /**
     * Sets the value of the serviceInfo property.
     *
     * @param value allowed object is     {@link ServiceInfo }
     */
    public void setServiceInfo(ServiceInfo value) {
        this.serviceInfo = value;
    }

    /**
     * Describes the status of a request.
     *
     * @return possible      object is     {@link Status }
     */
    public Status getStatus() {
        return status;
    }

    /**
     * Sets the value of the status property.
     *
     * @param value allowed object is     {@link Status }
     */
    public void setStatus(Status value) {
        this.status = value;
    }

    /**
     * This is useful for both a localized and shared service with multiple dev and QA environment dependencies. The ID would help to select the appropriate environment dependent resources to be used in the service.
     * Format : BU_Env.Name
     *
     * @return possible      object is     {@link String }
     */
    public String getEnvironmentID() {
        return environmentID;
    }

    /**
     * Sets the value of the environmentID property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setEnvironmentID(String value) {
        this.environmentID = value;
    }

    /**
     * Specifies a time-out period in seconds that the service consumer will wait for a response to the request.  After this time any response should be discarded.
     *
     * @return possible      object is     {@link BigDecimal }
     */
    public BigDecimal getRequestTimeOut() {
        return requestTimeOut;
    }

    /**
     * Sets the value of the requestTimeOut property.
     *
     * @param value allowed object is     {@link BigDecimal }
     */
    public void setRequestTimeOut(BigDecimal value) {
        this.requestTimeOut = value;
    }

}
