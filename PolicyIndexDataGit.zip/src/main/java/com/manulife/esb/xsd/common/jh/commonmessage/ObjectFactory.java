
package com.manulife.esb.xsd.common.jh.commonmessage;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each
 * Java content interface and Java element interface
 * generated in the com.manulife.esb.xsd.common.jh.commonmessage package.
 * <p>An ObjectFactory allows you to programatically
 * construct new instances of the Java representation
 * for XML content. The Java representation of XML
 * content can consist of schema derived interfaces
 * and classes representing the binding of schema
 * type definitions, element declarations and model
 * groups.  Factory methods for each of these are
 * provided in this class.
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _Fault_QNAME = new QName("http://www.esb.manulife.com/xsd/common/jh/CommonMessage", "Fault");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.manulife.esb.xsd.common.jh.commonmessage
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link FaultType }
     *
     * @return the fault type
     */
    public FaultType createFaultType() {
        return new FaultType();
    }

    /**
     * Create an instance of {@link RequestParameter }
     *
     * @return the request parameter
     */
    public RequestParameter createRequestParameter() {
        return new RequestParameter();
    }

    /**
     * Create an instance of {@link RequestParameters }
     *
     * @return the request parameters
     */
    public RequestParameters createRequestParameters() {
        return new RequestParameters();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link FaultType }{@code >}}
     *
     * @param value the value
     *
     * @return the jaxb element
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/common/jh/CommonMessage", name = "Fault")
    public JAXBElement<FaultType> createFault(FaultType value) {
        return new JAXBElement<FaultType>(_Fault_QNAME, FaultType.class, null, value);
    }

}
