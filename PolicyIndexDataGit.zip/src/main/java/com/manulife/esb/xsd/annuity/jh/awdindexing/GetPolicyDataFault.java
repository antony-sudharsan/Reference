
package com.manulife.esb.xsd.annuity.jh.awdindexing;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import com.manulife.esb.xsd.common.jh.commonmessage.FaultType;


/**
 * <p>Java class for anonymous complex type.
 *
 * <p>The following schema fragment specifies the expected content contained within this class.
 *
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Fault" type="{http://www.esb.manulife.com/xsd/common/jh/CommonMessage}FaultType"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "fault"
})
@XmlRootElement(name = "GetPolicyData_fault")
public class GetPolicyDataFault extends Exception {

    /**
     * The Fault.
     */
    @XmlElement(name = "Fault", required = true)
    protected FaultType fault;

    /**
     * Instantiates a new Get policy data fault.
     *
     * @param fault the fault
     */
    public GetPolicyDataFault(FaultType fault) {
        this.fault = fault;
    }

    /**
     * Instantiates a new Get policy data fault.
     */
    public GetPolicyDataFault() {

    }

    /**
     * Gets the value of the fault property.
     *
     * @return possible      object is     {@link FaultType }
     */
    public FaultType getFault() {
        return fault;
    }

    /**
     * Sets the value of the fault property.
     *
     * @param value allowed object is     {@link FaultType }
     */
    public void setFault(FaultType value) {
        this.fault = value;
    }

}
