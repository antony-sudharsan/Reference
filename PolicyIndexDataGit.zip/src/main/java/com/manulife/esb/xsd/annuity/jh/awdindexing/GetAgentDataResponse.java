
package com.manulife.esb.xsd.annuity.jh.awdindexing;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for anonymous complex type.
 *
 * <p>The following schema fragment specifies the expected content contained within this class.
 *
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/Annuity/jh/AWDIndexing}AgentAnnuityCompanyCode"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/Annuity/jh/AWDIndexing}AgentId"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/Annuity/jh/AWDIndexing}MasterAgentId" minOccurs="0"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/Annuity/jh/AWDIndexing}MasterAnnuityCompanyCode" minOccurs="0"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/Annuity/jh/AWDIndexing}GovtID" minOccurs="0"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/Annuity/jh/AWDIndexing}GovtIDTC" minOccurs="0"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/Annuity/jh/AWDIndexing}Prefix" minOccurs="0"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/Annuity/jh/AWDIndexing}FirstName"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/Annuity/jh/AWDIndexing}LastName"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/Annuity/jh/AWDIndexing}Suffix" minOccurs="0"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/Annuity/jh/AWDIndexing}GenderDesc" minOccurs="0"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/Annuity/jh/AWDIndexing}GenderTC" minOccurs="0"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/Annuity/jh/AWDIndexing}BirthDate" minOccurs="0"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/Annuity/jh/AWDIndexing}PhoneNumber" minOccurs="0"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/Annuity/jh/AWDIndexing}AltPhoneNumber" minOccurs="0"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/Annuity/jh/AWDIndexing}FaxNumber" minOccurs="0"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/Annuity/jh/AWDIndexing}Address" minOccurs="0"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/Annuity/jh/AWDIndexing}FirmName" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "agentAnnuityCompanyCode",
    "agentId",
    "masterAgentId",
    "masterAnnuityCompanyCode",
    "govtID",
    "govtIDTC",
    "prefix",
    "firstName",
    "lastName",
    "suffix",
    "genderDesc",
    "genderTC",
    "birthDate",
    "phoneNumber",
    "altPhoneNumber",
    "faxNumber",
    "address",
    "firmName"
})
@XmlRootElement(name = "GetAgentData_response")
public class GetAgentDataResponse {

    /**
     * The Agent annuity company code.
     */
    @XmlElement(name = "AgentAnnuityCompanyCode", required = true)
    protected String agentAnnuityCompanyCode;
    /**
     * The Agent id.
     */
    @XmlElement(name = "AgentId", required = true)
    protected String agentId;
    /**
     * The Master agent id.
     */
    @XmlElement(name = "MasterAgentId")
    protected String masterAgentId;
    /**
     * The Master annuity company code.
     */
    @XmlElement(name = "MasterAnnuityCompanyCode")
    protected String masterAnnuityCompanyCode;
    /**
     * The Govt id.
     */
    @XmlElement(name = "GovtID")
    protected String govtID;
    /**
     * The Govt idtc.
     */
    @XmlElement(name = "GovtIDTC")
    protected Integer govtIDTC;
    /**
     * The Prefix.
     */
    @XmlElement(name = "Prefix")
    protected String prefix;
    /**
     * The First name.
     */
    @XmlElement(name = "FirstName", required = true)
    protected String firstName;
    /**
     * The Last name.
     */
    @XmlElement(name = "LastName", required = true)
    protected String lastName;
    /**
     * The Suffix.
     */
    @XmlElement(name = "Suffix")
    protected String suffix;
    /**
     * The Gender desc.
     */
    @XmlElement(name = "GenderDesc")
    protected String genderDesc;
    /**
     * The Gender tc.
     */
    @XmlElement(name = "GenderTC")
    protected Integer genderTC;
    /**
     * The Birth date.
     */
    @XmlElement(name = "BirthDate")
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar birthDate;
    /**
     * The Phone number.
     */
    @XmlElement(name = "PhoneNumber")
    protected String phoneNumber;
    /**
     * The Alt phone number.
     */
    @XmlElement(name = "AltPhoneNumber")
    protected String altPhoneNumber;
    /**
     * The Fax number.
     */
    @XmlElement(name = "FaxNumber")
    protected String faxNumber;
    /**
     * The Address.
     */
    @XmlElement(name = "Address")
    protected AddressType address;
    /**
     * The Firm name.
     */
    @XmlElement(name = "FirmName")
    protected String firmName;

    /**
     * Gets the value of the agentAnnuityCompanyCode property.
     *
     * @return possible      object is     {@link String }
     */
    public String getAgentAnnuityCompanyCode() {
        return agentAnnuityCompanyCode;
    }

    /**
     * Sets the value of the agentAnnuityCompanyCode property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setAgentAnnuityCompanyCode(String value) {
        this.agentAnnuityCompanyCode = value;
    }

    /**
     * Gets the value of the agentId property.
     *
     * @return possible      object is     {@link String }
     */
    public String getAgentId() {
        return agentId;
    }

    /**
     * Sets the value of the agentId property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setAgentId(String value) {
        this.agentId = value;
    }

    /**
     * Gets the value of the masterAgentId property.
     *
     * @return possible      object is     {@link String }
     */
    public String getMasterAgentId() {
        return masterAgentId;
    }

    /**
     * Sets the value of the masterAgentId property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setMasterAgentId(String value) {
        this.masterAgentId = value;
    }

    /**
     * Gets the value of the masterAnnuityCompanyCode property.
     *
     * @return possible      object is     {@link String }
     */
    public String getMasterAnnuityCompanyCode() {
        return masterAnnuityCompanyCode;
    }

    /**
     * Sets the value of the masterAnnuityCompanyCode property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setMasterAnnuityCompanyCode(String value) {
        this.masterAnnuityCompanyCode = value;
    }

    /**
     * Gets the value of the govtID property.
     *
     * @return possible      object is     {@link String }
     */
    public String getGovtID() {
        return govtID;
    }

    /**
     * Sets the value of the govtID property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setGovtID(String value) {
        this.govtID = value;
    }

    /**
     * Gets the value of the govtIDTC property.
     *
     * @return possible      object is     {@link Integer }
     */
    public Integer getGovtIDTC() {
        return govtIDTC;
    }

    /**
     * Sets the value of the govtIDTC property.
     *
     * @param value allowed object is     {@link Integer }
     */
    public void setGovtIDTC(Integer value) {
        this.govtIDTC = value;
    }

    /**
     * Gets the value of the prefix property.
     *
     * @return possible      object is     {@link String }
     */
    public String getPrefix() {
        return prefix;
    }

    /**
     * Sets the value of the prefix property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setPrefix(String value) {
        this.prefix = value;
    }

    /**
     * Gets the value of the firstName property.
     *
     * @return possible      object is     {@link String }
     */
    public String getFirstName() {
        return firstName;
    }

    /**
     * Sets the value of the firstName property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setFirstName(String value) {
        this.firstName = value;
    }

    /**
     * Gets the value of the lastName property.
     *
     * @return possible      object is     {@link String }
     */
    public String getLastName() {
        return lastName;
    }

    /**
     * Sets the value of the lastName property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setLastName(String value) {
        this.lastName = value;
    }

    /**
     * Gets the value of the suffix property.
     *
     * @return possible      object is     {@link String }
     */
    public String getSuffix() {
        return suffix;
    }

    /**
     * Sets the value of the suffix property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setSuffix(String value) {
        this.suffix = value;
    }

    /**
     * Gets the value of the genderDesc property.
     *
     * @return possible      object is     {@link String }
     */
    public String getGenderDesc() {
        return genderDesc;
    }

    /**
     * Sets the value of the genderDesc property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setGenderDesc(String value) {
        this.genderDesc = value;
    }

    /**
     * Gets the value of the genderTC property.
     *
     * @return possible      object is     {@link Integer }
     */
    public Integer getGenderTC() {
        return genderTC;
    }

    /**
     * Sets the value of the genderTC property.
     *
     * @param value allowed object is     {@link Integer }
     */
    public void setGenderTC(Integer value) {
        this.genderTC = value;
    }

    /**
     * Gets the value of the birthDate property.
     *
     * @return possible      object is     {@link XMLGregorianCalendar }
     */
    public XMLGregorianCalendar getBirthDate() {
        return birthDate;
    }

    /**
     * Sets the value of the birthDate property.
     *
     * @param value allowed object is     {@link XMLGregorianCalendar }
     */
    public void setBirthDate(XMLGregorianCalendar value) {
        this.birthDate = value;
    }

    /**
     * Gets the value of the phoneNumber property.
     *
     * @return possible      object is     {@link String }
     */
    public String getPhoneNumber() {
        return phoneNumber;
    }

    /**
     * Sets the value of the phoneNumber property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setPhoneNumber(String value) {
        this.phoneNumber = value;
    }

    /**
     * Gets the value of the altPhoneNumber property.
     *
     * @return possible      object is     {@link String }
     */
    public String getAltPhoneNumber() {
        return altPhoneNumber;
    }

    /**
     * Sets the value of the altPhoneNumber property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setAltPhoneNumber(String value) {
        this.altPhoneNumber = value;
    }

    /**
     * Gets the value of the faxNumber property.
     *
     * @return possible      object is     {@link String }
     */
    public String getFaxNumber() {
        return faxNumber;
    }

    /**
     * Sets the value of the faxNumber property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setFaxNumber(String value) {
        this.faxNumber = value;
    }

    /**
     * Gets the value of the address property.
     *
     * @return possible      object is     {@link AddressType }
     */
    public AddressType getAddress() {
        return address;
    }

    /**
     * Sets the value of the address property.
     *
     * @param value allowed object is     {@link AddressType }
     */
    public void setAddress(AddressType value) {
        this.address = value;
    }

    /**
     * Gets the value of the firmName property.
     *
     * @return possible      object is     {@link String }
     */
    public String getFirmName() {
        return firmName;
    }

    /**
     * Sets the value of the firmName property.
     *
     * @param value allowed object is     {@link String }
     */
    public void setFirmName(String value) {
        this.firmName = value;
    }

}
