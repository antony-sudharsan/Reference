package com.jh.life.policyindexingdata.orchestration;

import com.jh.life.policyindexingdata.dao.PolicyIndexDataDAO;
import com.jh.life.policyindexingdata.validator.PolicyIndexDataValidator;
import com.manulife.esb.xsd.annuity.jh.awdindexing.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.ArrayList;
import java.util.List;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.*;
import static org.mockito.Mockito.when;

@RunWith(SpringRunner.class)
public class PolicyIndexDataOrchectrationTest {

    @Mock
    PolicyIndexDataDAO policyIndexDataDAO = new PolicyIndexDataDAO();

    @Mock
    PolicyIndexDataValidator policyIndexDataValidator;

    @InjectMocks
    PolicyIndexDataOrchectration policyIndexDataOrchectration;

    GetAgentDataResponse getAgentDataResponse = null;
    SearchAgentNameResponse searchAgentNameResponse = null;
    GetPolicyDataResponse getPolicyDataResponse = null;
    AgentSearchResultsType agentSearchResultsType = null;
    List<AgentSearchResultsType> agentSearchResultsTypeList = new ArrayList<AgentSearchResultsType>();
    SearchAgentNameRequest searchAgentNameRequest = new SearchAgentNameRequest();
    GetAgentDataRequest getAgentDataRequest = new GetAgentDataRequest();
    List<GetAgentDataResponse> agentDataResponseList = new ArrayList<GetAgentDataResponse>();
    GetPolicyDataRequest getPolicyDataRequest = new GetPolicyDataRequest();

    @Before
    public void setup() throws Exception{
        searchAgentNameRequest.setFirstName("Prince");
        searchAgentNameRequest.setLastName("Cathy");

        getAgentDataResponse = new GetAgentDataResponse();
        getAgentDataResponse.setGenderTC(1);
        getAgentDataResponse.setSuffix("Mr");
        getAgentDataResponse.setFirmName("JH");
        getAgentDataResponse.setFaxNumber("12121112");
        getAgentDataResponse.setAltPhoneNumber("12121112");
        getAgentDataResponse.setPhoneNumber("23111111222");
        getAgentDataResponse.setGovtID("979214657");
        getAgentDataResponse.setMasterAnnuityCompanyCode("TCC");
        getAgentDataResponse.setMasterAgentId("979214657");
        getAgentDataResponse.setAgentId("3095768V8I");
        getAgentDataResponse.setAgentAnnuityCompanyCode("");
        getAgentDataResponse.setFirstName("Claman");
        getAgentDataResponse.setGenderDesc("");
        getAgentDataResponse.setGovtIDTC(1);
        getAgentDataResponse.setLastName("Perine");
        getAgentDataResponse.setAddress(new AddressType());

        agentDataResponseList.add(getAgentDataResponse);
        searchAgentNameResponse = new SearchAgentNameResponse();
        agentSearchResultsType = new AgentSearchResultsType();
        agentSearchResultsType.setPhoneNumber("1212121");;
        agentSearchResultsType.setStateCode("TN");
        agentSearchResultsType.setFirstName("Claman");
        agentSearchResultsType.setGovtID("979214657");
        agentSearchResultsType.setGovtIDTC(1);
        agentSearchResultsType.setLastName("Perine");
        agentSearchResultsTypeList.add(agentSearchResultsType);
        searchAgentNameResponse.setAgentSearchResults(agentSearchResultsTypeList);

        getPolicyDataResponse = new GetPolicyDataResponse();
        getPolicyDataResponse.setAnnuityCompanyCode("TCC");
        getPolicyDataResponse.setAnnuityLob("LDF");
        getPolicyDataResponse.setBrokerCount(1);

    }


    @After
    public void tearDown() throws Exception {
    }

    @Test
    public void searchAgentName() throws Exception {
        when(policyIndexDataDAO.searchAgentName("FNA70053569", "1234", searchAgentNameRequest)).thenReturn(searchAgentNameResponse);
        assertEquals(1,policyIndexDataOrchectration.searchAgentName("FNA70053569", "1234",searchAgentNameRequest).getAgentSearchResults().size());
    }

    @Test
    public void getAgentData() throws Exception {
        when(policyIndexDataDAO.getAgentData("FNA70053569", "1234", getAgentDataRequest)).thenReturn(agentDataResponseList);
        assertEquals("3095768V8I",policyIndexDataOrchectration.getAgentData("FNA70053569", "1234",getAgentDataRequest).getAgentId());
        assertEquals("979214657",policyIndexDataOrchectration.getAgentData("FNA70053569", "1234",getAgentDataRequest).getMasterAgentId());
        assertEquals("TCC",policyIndexDataOrchectration.getAgentData("FNA70053569", "1234",getAgentDataRequest).getMasterAnnuityCompanyCode());
        assertEquals("JH",policyIndexDataOrchectration.getAgentData("FNA70053569", "1234",getAgentDataRequest).getFirmName());
        assertEquals("Claman",policyIndexDataOrchectration.getAgentData("FNA70053569", "1234",getAgentDataRequest).getFirstName());
        assertEquals("Perine",policyIndexDataOrchectration.getAgentData("FNA70053569", "1234",getAgentDataRequest).getLastName());

    }

    @Test
    public void getPolicyData() throws Exception {
        when(policyIndexDataDAO.getPolicyData("FNA70053569", "1234", getPolicyDataRequest)).thenReturn(getPolicyDataResponse);
        assertEquals("TCC",policyIndexDataOrchectration.getPolicyData("FNA70053569", "1234",getPolicyDataRequest).getAnnuityCompanyCode());
        assertEquals("LDF",policyIndexDataOrchectration.getPolicyData("FNA70053569", "1234",getPolicyDataRequest).getAnnuityLob());
    }
}