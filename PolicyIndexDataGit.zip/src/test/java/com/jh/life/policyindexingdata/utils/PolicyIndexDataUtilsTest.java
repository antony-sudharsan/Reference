package com.jh.life.policyindexingdata.utils;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.GregorianCalendar;

import static org.junit.Assert.*;

public class PolicyIndexDataUtilsTest {

    Date oldDate;

    XMLGregorianCalendar xmlGregCal;
    PolicyIndexDataUtils policyIndexDataUtils = null;

    @Before
    public void setUp() throws Exception {
        policyIndexDataUtils = new PolicyIndexDataUtils();
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        oldDate = sdf.parse("21/12/2012");
        DateFormat format = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
        GregorianCalendar cal = new GregorianCalendar();
        cal.setTime(oldDate);
        xmlGregCal = DatatypeFactory.newInstance().newXMLGregorianCalendar(cal);
    }

    @After
    public void tearDown() throws Exception {
        policyIndexDataUtils = null;
    }

    @Test
    public void convertUtilDateToGregoerianCalendar() {
        assertEquals(xmlGregCal,policyIndexDataUtils.convertUtilDateToGregoerianCalendar(oldDate));
    }
}