package com.jh.life.policyindexingdata.controller;

import com.jh.life.policyindexingdata.orchestration.PolicyIndexDataOrchectration;
import com.manulife.esb.xsd.annuity.jh.awdindexing.*;
import org.codehaus.jackson.map.ObjectMapper;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;

import java.util.ArrayList;
import java.util.List;

import static org.hamcrest.CoreMatchers.is;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;


@RunWith(SpringRunner.class)
/**
 * @WebMvcTest.
 * It will auto-configure the Spring MVC infrastructure for our unit tests.
 * Setting up WebMvc Context for the Controller which is under test("AnnuityController")
 */
@WebMvcTest(PolicyIndexDataController.class)
public class AWDIndexPolicyControllerTest {

    /**
     * Initializing MockMvc
     */
    @Autowired
    private MockMvc mvc;

    /**
     * @MockBean
     * The class is included in the spring-boot-test library.
     * It allows to add Mockito mocks in a Spring ApplicationContext.
     * If a bean, compatible with the declared class exists in the context, it replaces it by the mock.
     * If it is not the case, it adds the mock in the context as a bean.
     */
  @MockBean
  PolicyIndexDataOrchectration policyIndexDataOrchectration = null;



    GetAgentDataResponse getAgentDataResponse = null;
    SearchAgentNameResponse searchAgentNameResponse = null;
    GetPolicyDataResponse getPolicyDataResponse = null;
    AgentSearchResultsType agentSearchResultsType = null;
    List<AgentSearchResultsType> agentSearchResultsTypeList = new ArrayList<AgentSearchResultsType>();
	@Before
    public void setup() throws Exception{
        getAgentDataResponse = new GetAgentDataResponse();
        getAgentDataResponse.setGenderTC(1);
        getAgentDataResponse.setSuffix("Mr");
        getAgentDataResponse.setFirmName("JH");
        getAgentDataResponse.setFaxNumber("12121112");
        getAgentDataResponse.setAltPhoneNumber("12121112");
        getAgentDataResponse.setPhoneNumber("23111111222");
        getAgentDataResponse.setGovtID("979214657");
        getAgentDataResponse.setMasterAnnuityCompanyCode("TCC");
        getAgentDataResponse.setMasterAgentId("979214657");
        getAgentDataResponse.setAgentId("3095768V8I");
        getAgentDataResponse.setAgentAnnuityCompanyCode("");
        getAgentDataResponse.setFirstName("Claman");
        getAgentDataResponse.setGenderDesc("");
        getAgentDataResponse.setGovtIDTC(1);
        getAgentDataResponse.setLastName("Perine");
        getAgentDataResponse.setAddress(new AddressType());


        searchAgentNameResponse = new SearchAgentNameResponse();
        agentSearchResultsType = new AgentSearchResultsType();
        agentSearchResultsType.setPhoneNumber("1212121");;
        agentSearchResultsType.setStateCode("TN");
        agentSearchResultsType.setFirstName("Claman");
        agentSearchResultsType.setGovtID("979214657");
        agentSearchResultsType.setGovtIDTC(1);
        agentSearchResultsType.setLastName("Perine");
        agentSearchResultsTypeList.add(agentSearchResultsType);
        searchAgentNameResponse.setAgentSearchResults(agentSearchResultsTypeList);

        getPolicyDataResponse = new GetPolicyDataResponse();
        getPolicyDataResponse.setAnnuityCompanyCode("TCC");
        getPolicyDataResponse.setAnnuityLob("LDF");
        getPolicyDataResponse.setBrokerCount(1);

    }

    /**
     *
     * @throws Exception
     */
  @Test
    public void getAgentDetailsTest() throws Exception{

     when(policyIndexDataOrchectration.getAgentData(anyString(),anyString(),   any(GetAgentDataRequest.class))).thenReturn(getAgentDataResponse);
      mvc.perform(post("/jh/wealth/ann/policyindexingdata/agentbyid")
              .content(asJsonString(getAgentDataResponse))
              .accept(MediaType.APPLICATION_JSON_VALUE)
              .contentType(MediaType.APPLICATION_JSON_VALUE)
              .header("MessageUUID", "1234")
              .header("sourceSystemName", "FNA"))
              .andExpect(status().isOk())
              .andExpect(jsonPath("govtID").value("979214657"))
              .andExpect(jsonPath("firstName", is("Claman")))
              .andExpect(jsonPath("govtID", is("979214657")))
              .andExpect(jsonPath("govtIDTC", is(1)))
              .andExpect(jsonPath("lastName", is("Perine")));
    }


    /**
     *
     * @throws Exception
     */
    @Test
    public void getPolicyDetailsTest() throws Exception{

       when(policyIndexDataOrchectration.getPolicyData(anyString(),anyString(),   any(GetPolicyDataRequest.class))).thenReturn(getPolicyDataResponse);
        mvc.perform(post("/jh/wealth/ann/awdindex/policy")
                .content(asJsonString(getAgentDataResponse))
                .accept(MediaType.APPLICATION_JSON_VALUE)
                .contentType(MediaType.APPLICATION_JSON_VALUE)
                .header("MessageUUID", "1234")
                .header("sourceSystemName", "FNA"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("annuityCompanyCode").value("TCC"))
                .andExpect(jsonPath("annuityLob").value("LDF"));
    }


    /**
     *
     * @throws Exception
     */
    @Test
    public void getSearchAgentTest() throws Exception{

       when(policyIndexDataOrchectration.searchAgentName(anyString(),anyString(),   any(SearchAgentNameRequest.class))).thenReturn(searchAgentNameResponse);
        mvc.perform(post("/jh/wealth/ann/policyindexingdata/agentbyname")
                .content(asJsonString(getAgentDataResponse))
                .accept(MediaType.APPLICATION_JSON_VALUE)
                .contentType(MediaType.APPLICATION_JSON_VALUE)
                .header("MessageUUID", "1234")
                .header("sourceSystemName", "FNA"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("agentSearchResults[0].firstName", is("Claman")))
                .andExpect(jsonPath("agentSearchResults[0].stateCode", is("TN")))
                .andExpect(jsonPath("agentSearchResults[0].govtID", is("979214657")))
                .andExpect(jsonPath("agentSearchResults[0].govtIDTC", is(1)))
                .andExpect(jsonPath("agentSearchResults[0].lastName", is("Perine")));
    }

    @After
    public void teardown(){

    }

    /*
     * converts a Java object into JSON representation
     */
    public static String asJsonString(final Object obj) {
        try {
            String returnStr = new ObjectMapper().writeValueAsString(obj);
            return returnStr;

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

}