package com.jh.life.policyindexingdata.validator;

import com.jh.life.policyindexingdata.exception.InvalidInputException;
import com.manulife.esb.xsd.annuity.jh.awdindexing.GetAgentDataFault;
import com.manulife.esb.xsd.annuity.jh.awdindexing.GetPolicyDataFault;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class PolicyIndexDataValidatorTest {

    PolicyIndexDataValidator policyIndexDataValidator = null;

    @Before
    public void setUp() throws Exception {
        policyIndexDataValidator = new PolicyIndexDataValidator();
    }

    @After
    public void tearDown() throws Exception {
    }

    @Test
    public void validateAgentId()  {
        policyIndexDataValidator.validateAgentId("1121");
    }

    @Test(expected = InvalidInputException.class)
    public void validateAgentIdException() throws GetAgentDataFault {
        policyIndexDataValidator.validateAgentId("1");
    }

    @Test
    public void validateAgentDetails()  {
        policyIndexDataValidator.validateAgentDetails("qqqqq","bbbbb");
    }

    @Test(expected = InvalidInputException.class)
    public void validateAgentDetailsException()  {
        policyIndexDataValidator.validateAgentDetails("q","b");
    }
    @Test
    public void validatePolicy()  {
        policyIndexDataValidator.validatePolicy("qqqqq");
    }

    @Test(expected = InvalidInputException.class)
    public void validatePolicyException() throws GetPolicyDataFault {
        policyIndexDataValidator.validatePolicy("q");
    }
}