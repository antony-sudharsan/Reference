package com.jh.life.policyindexingdata.dao;

import com.manulife.esb.xsd.annuity.jh.awdindexing.*;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.test.context.junit4.SpringRunner;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import static junit.framework.TestCase.assertEquals;
import static org.junit.Assert.*;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
@RunWith(SpringRunner.class)
public class PolicyIndexDataDAOTest {

    @Mock
    JdbcTemplate template = mock(JdbcTemplate.class);
    @InjectMocks
    PolicyIndexDataDAO policyIndexDataDAO;

    GetAgentDataResponse getAgentDataResponse = null;
    SearchAgentNameResponse searchAgentNameResponse = null;
    GetPolicyDataResponse getPolicyDataResponse = null;
    AgentSearchResultsType agentSearchResultsType = null;
    List<AgentSearchResultsType> agentSearchResultsTypeList = new ArrayList<AgentSearchResultsType>();
    SearchAgentNameRequest searchAgentNameRequest = new SearchAgentNameRequest();
    GetAgentDataRequest getAgentDataRequest = new GetAgentDataRequest();
    List<GetAgentDataResponse> agentDataResponseList = new ArrayList<GetAgentDataResponse>();
    GetPolicyDataRequest getPolicyDataRequest = new GetPolicyDataRequest();

    @Before
    public void setup() throws Exception{
        searchAgentNameRequest.setFirstName("Prince");
        searchAgentNameRequest.setLastName("Cathy");

        getAgentDataResponse = new GetAgentDataResponse();
        getAgentDataResponse.setGenderTC(1);
        getAgentDataResponse.setSuffix("Mr");
        getAgentDataResponse.setFirmName("JH");
        getAgentDataResponse.setFaxNumber("12121112");
        getAgentDataResponse.setAltPhoneNumber("12121112");
        getAgentDataResponse.setPhoneNumber("23111111222");
        getAgentDataResponse.setGovtID("979214657");
        getAgentDataResponse.setMasterAnnuityCompanyCode("TCC");
        getAgentDataResponse.setMasterAgentId("979214657");
        getAgentDataResponse.setAgentId("3095768V8I");
        getAgentDataResponse.setAgentAnnuityCompanyCode("");
        getAgentDataResponse.setFirstName("Claman");
        getAgentDataResponse.setGenderDesc("");
        getAgentDataResponse.setGovtIDTC(1);
        getAgentDataResponse.setLastName("Perine");
        getAgentDataResponse.setAddress(new AddressType());

        agentDataResponseList.add(getAgentDataResponse);


        searchAgentNameResponse = new SearchAgentNameResponse();
        agentSearchResultsType = new AgentSearchResultsType();
        agentSearchResultsType.setPhoneNumber("1212121");;
        agentSearchResultsType.setStateCode("TN");
        agentSearchResultsType.setFirstName("Claman");
        agentSearchResultsType.setGovtID("979214657");
        agentSearchResultsType.setGovtIDTC(1);
        agentSearchResultsType.setLastName("Perine");
        agentSearchResultsTypeList.add(agentSearchResultsType);
        searchAgentNameResponse.setAgentSearchResults(agentSearchResultsTypeList);

        getPolicyDataResponse = new GetPolicyDataResponse();
        getPolicyDataResponse.setAnnuityCompanyCode("TCC");
        getPolicyDataResponse.setAnnuityLob("LDF");
        getPolicyDataResponse.setBrokerCount(1);

    }


    @Test
    public void searchAgentName() throws Exception {
        when(template.queryForObject(anyString(),any(Object[].class),any(RowMapper.class))).thenReturn(searchAgentNameResponse);
        Assert.assertEquals(0,policyIndexDataDAO.searchAgentName("FNA70053569", "1234",searchAgentNameRequest).getAgentSearchResults().size());
    }


    @Test
    public void getPolicyData() throws Exception {
        when(template.queryForObject(anyString(),any(Object[].class),any(RowMapper.class))).thenReturn(getPolicyDataResponse);
        Assert.assertEquals("TCC",policyIndexDataDAO.getPolicyData("FNA70053569", "1234",getPolicyDataRequest).getAnnuityCompanyCode());
        Assert.assertEquals("LDF",policyIndexDataDAO.getPolicyData("FNA70053569", "1234",getPolicyDataRequest).getAnnuityLob());
    }

    @After
    public void tearDown() throws Exception {
    }


}