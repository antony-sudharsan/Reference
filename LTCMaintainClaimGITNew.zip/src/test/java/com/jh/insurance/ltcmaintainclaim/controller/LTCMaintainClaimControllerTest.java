/**
 * 
 */
package com.jh.insurance.ltcmaintainclaim.controller;


import static org.hamcrest.CoreMatchers.is;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;

import com.jh.insurance.ltcmaintainclaim.orchestration.LTCMaintainClaimOrchestration;
import com.manulife.esb.xsd.ltc.jh.ltcmaintainclaim.CreateClaimRequest;
import com.manulife.esb.xsd.ltc.jh.ltcmaintainclaim.CreateClaimRequestParms;
import com.manulife.esb.xsd.ltc.jh.ltcmaintainclaim.CreateClaimResponse;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.GregorianCalendar;

/**
 * @author deepain
 *
 */

@RunWith(SpringRunner.class)
@WebMvcTest(LTCMaintainClaimController.class)
public class LTCMaintainClaimControllerTest {
	
	@Autowired
	private MockMvc mockMvc;
	
	@MockBean
	private LTCMaintainClaimOrchestration LTCMaintainClaimOrchestration;


    public void createClaimSuccessResult() throws Exception{
		CreateClaimRequest createClaimRequest = new CreateClaimRequest();
		CreateClaimRequestParms createClaimRequestParms = new CreateClaimRequestParms();
		CreateClaimResponse createClaimResponse = new CreateClaimResponse();
        CreateClaimRequestParms.GroupPolicy groupPolicy = new CreateClaimRequestParms.GroupPolicy();
        CreateClaimRequestParms.RetailPolicy retailPolicy = new CreateClaimRequestParms.RetailPolicy();

		createClaimRequestParms.setClaimNumber("R18000263");
		createClaimRequestParms.setClaimOriginatingSystem("Beacon");
		createClaimRequestParms.setClaimStatusCode("PreClaim");
		createClaimRequestParms.setClaimStatusEffectiveDate(convertStringXMLGregorianCalendar("2018-04-11 09:19:41"));
		createClaimRequestParms.setClaimSubStatusCode("Pending");
		createClaimRequestParms.setCurrentlyProcessedBySystem("Promise");
        groupPolicy.setGroupLTCId("");
        groupPolicy.setGroupSeqNbr(0);
        createClaimRequestParms.setGroupPolicy(groupPolicy);

		createClaimRequestParms.setLineOfBusinessCode("Retail");
        retailPolicy.setPolNumber("9437958");
        retailPolicy.setRetailCompanyCode("07");
        createClaimRequestParms.setRetailPolicy(retailPolicy);

		createClaimRequest.setCreateClaimRequestParms(createClaimRequestParms);

		createClaimResponse.setCreateClaimRequestParms(createClaimRequestParms);

		createClaimResponse.setStatusCode("11111");
		createClaimResponse.setStatusDescription("Success");
		
		when(LTCMaintainClaimOrchestration.createClaim("JHK", "1234556", "LTC", createClaimRequest)).thenReturn(createClaimResponse);

        mockMvc.perform(post("/jh/ins/ltc/promise/claim")
        		.contentType(MediaType.APPLICATION_JSON_UTF8_VALUE)
        		.content(asJSONString(createClaimRequest))
        		.header("MessageUUID", "1234556")
        		.header("SourceSystemName", "LTC")
        		.header("UserID", "JHK"))
                .andExpect(status().isOk())
        		.andExpect(jsonPath("$.createClaimRequestParms.claimNumber", is("R18000263")))
                .andExpect(jsonPath("statusCode", is("11111")))
                .andExpect(jsonPath("statusDescription", is("Success")));
       verify(LTCMaintainClaimOrchestration, times(1)).createClaim("JHK", "1234556", "LTC",createClaimRequest);
       verifyNoMoreInteractions(LTCMaintainClaimOrchestration);
       
    }
	

	
	/**
	 * Method to convert the Object to JSON String using the Jackson
	 * @param obj
	 * @return
	 */
	public static String asJSONString(final Object obj) 
	{
		try {

		    System.out.println("The value of the JSON >>"+new ObjectMapper().writeValueAsString(obj));
			return new ObjectMapper().writeValueAsString(obj);
		} catch (JsonProcessingException e) {
			throw new RuntimeException(e);
		}		
	}

	@Test
	public void validateInput(){

	}


	private XMLGregorianCalendar convertStringXMLGregorianCalendar(String stringDate) throws DatatypeConfigurationException, ParseException {
		DateFormat format = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
		Date date = format.parse(stringDate);

		GregorianCalendar cal = new GregorianCalendar();
		cal.setTime(date);

		XMLGregorianCalendar xmlGregCal =  DatatypeFactory.newInstance().newXMLGregorianCalendar(cal);
		return xmlGregCal;
	}
}
