package com.jh.insurance.ltcmaintainclaim.validator;

import com.jh.insurance.ltcmaintainclaim.utils.LTCMaintainClaimUtils;
import com.manulife.esb.wsdl.ltc.jh.ltcmaintainclaim.ltcmaintainclaim.LTCMaintainClaimFault;
import com.manulife.esb.xsd.ltc.jh.ltcmaintainclaim.CreateClaimRequest;
import com.manulife.esb.xsd.ltc.jh.ltcmaintainclaim.CreateClaimRequestParms;
import com.manulife.esb.xsd.ltc.jh.ltcmaintainclaim.UpdateClaimRequest;
import com.manulife.esb.xsd.ltc.jh.ltcmaintainclaim.UpdateClaimRequestParms;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.test.context.junit4.SpringRunner ;

import static org.mockito.Mockito.when;

@RunWith(SpringRunner.class)
public class LTCMaintainClaimValidatorTest {

    CreateClaimRequestParms createClaimRequestParms;
    CreateClaimRequest createClaimRequest;

    UpdateClaimRequestParms updateClaimRequestParms;
    UpdateClaimRequest updateClaimRequest;

    @InjectMocks
    LTCMaintainClaimValidator ltcMaintainClaimValidator;

    @Mock
    LTCMaintainClaimUtils ltcMaintainClaimUtils;

    @Before
    public void setUp() throws Exception {
    }

    @After
    public void tearDown() throws Exception {
    }

    @Test
    public void validateCreateClaimRequest() throws LTCMaintainClaimFault,Exception {
        createClaimRequest = new CreateClaimRequest();
        createClaimRequestParms = new CreateClaimRequestParms();
        CreateClaimRequestParms.GroupPolicy groupPolicy = new CreateClaimRequestParms.GroupPolicy();
        CreateClaimRequestParms.RetailPolicy retailPolicy = new CreateClaimRequestParms.RetailPolicy();

        createClaimRequestParms.setClaimNumber("R18000263");
        createClaimRequestParms.setClaimOriginatingSystem("Beacon");
        createClaimRequestParms.setClaimStatusCode("PreClaim");
        createClaimRequestParms.setClaimSubStatusCode("Pending");
        createClaimRequestParms.setCurrentlyProcessedBySystem("Promise");
        createClaimRequestParms.setLineOfBusinessCode("Retail");

        groupPolicy.setGroupLTCId(" ");
        groupPolicy.setGroupSeqNbr(0);
        createClaimRequestParms.setGroupPolicy(groupPolicy);

        retailPolicy.setPolNumber("9437958");
        retailPolicy.setRetailCompanyCode("07");
        createClaimRequestParms.setRetailPolicy(retailPolicy);
        createClaimRequest.setCreateClaimRequestParms(createClaimRequestParms);

        when(ltcMaintainClaimUtils.getGroupLTCId(createClaimRequestParms)).thenReturn(" ");
        when(ltcMaintainClaimUtils.getGroupSqNo(createClaimRequestParms)).thenReturn("AAA");
        when(ltcMaintainClaimUtils.getRetailCompanyCode(createClaimRequestParms)).thenReturn("AAA");
        when(ltcMaintainClaimUtils.getRetailPolNo(createClaimRequestParms)).thenReturn("AAA");

        ltcMaintainClaimValidator.validateRequest("AAA","AAA",createClaimRequest);

    }

    @Test
    public void validateUpdateClaimRequest() throws LTCMaintainClaimFault {
        updateClaimRequest = new UpdateClaimRequest();
        updateClaimRequestParms = new UpdateClaimRequestParms();
        UpdateClaimRequestParms.GroupPolicy groupPolicy = new UpdateClaimRequestParms.GroupPolicy();
        UpdateClaimRequestParms.RetailPolicy retailPolicy = new UpdateClaimRequestParms.RetailPolicy();

        updateClaimRequestParms.setNewClaimNumber("R18000263");
        updateClaimRequestParms.setClaimOriginatingSystem("Beacon");
        updateClaimRequestParms.setClaimStatusCode("PreClaim");
        updateClaimRequestParms.setClaimSubStatusCode("Pending");
        updateClaimRequestParms.setCurrentlyProcessedBySystem("Promise");
        updateClaimRequestParms.setLineOfBusinessCode("Retail");

        groupPolicy.setGroupLTCId(" ");
        groupPolicy.setGroupSeqNbr(0);
        updateClaimRequestParms.setGroupPolicy(groupPolicy);

        retailPolicy.setPolNumber("9437958");
        retailPolicy.setRetailCompanyCode("07");
        updateClaimRequestParms.setRetailPolicy(retailPolicy);
        updateClaimRequest.setUpdateClaimRequestParms(updateClaimRequestParms);

        when(ltcMaintainClaimUtils.getGroupLTCId(updateClaimRequestParms)).thenReturn(" ");
        when(ltcMaintainClaimUtils.getGroupSqNo(updateClaimRequestParms)).thenReturn("AAA");
        when(ltcMaintainClaimUtils.getRetailCompanyCode(updateClaimRequestParms)).thenReturn("AAA");
        when(ltcMaintainClaimUtils.getRetailPolNo(updateClaimRequestParms)).thenReturn("AAA");

        ltcMaintainClaimValidator.validateRequest("AAA","AAA",updateClaimRequest);

    }
}