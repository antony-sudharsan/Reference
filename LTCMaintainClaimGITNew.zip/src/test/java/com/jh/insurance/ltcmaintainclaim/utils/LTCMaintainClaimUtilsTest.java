package com.jh.insurance.ltcmaintainclaim.utils;

import com.manulife.esb.xsd.ltc.jh.ltcmaintainclaim.CreateClaimRequestParms;
import com.manulife.esb.xsd.ltc.jh.ltcmaintainclaim.CreateClaimResponse;
import com.manulife.esb.xsd.ltc.jh.ltcmaintainclaim.UpdateClaimRequestParms;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.junit4.SpringRunner;

import static org.junit.Assert.*;

@RunWith(SpringRunner.class)
public class LTCMaintainClaimUtilsTest {

    LTCMaintainClaimUtils ltcMaintainClaimUtils = new LTCMaintainClaimUtils();

    CreateClaimRequestParms createClaimRequestParms;
    UpdateClaimRequestParms updateClaimRequestParms;

    @Before
    public void setUp() throws Exception {
        updateClaimRequestParms = new UpdateClaimRequestParms();
        createClaimRequestParms = new CreateClaimRequestParms();

        CreateClaimRequestParms.GroupPolicy groupPolicy = new CreateClaimRequestParms.GroupPolicy();
        CreateClaimRequestParms.RetailPolicy retailPolicy = new CreateClaimRequestParms.RetailPolicy();

        createClaimRequestParms.setClaimNumber("R18000263");
        createClaimRequestParms.setClaimOriginatingSystem("Beacon");
        createClaimRequestParms.setClaimStatusCode("PreClaim");
        createClaimRequestParms.setClaimSubStatusCode("Pending");
        createClaimRequestParms.setCurrentlyProcessedBySystem("Promise");
        createClaimRequestParms.setLineOfBusinessCode("Retail");

        groupPolicy.setGroupLTCId(" ");
        groupPolicy.setGroupSeqNbr(0);
        createClaimRequestParms.setGroupPolicy(groupPolicy);

        retailPolicy.setPolNumber("9437958");
        retailPolicy.setRetailCompanyCode("07");
        createClaimRequestParms.setRetailPolicy(retailPolicy);


        UpdateClaimRequestParms.GroupPolicy groupUpdatePolicy = new UpdateClaimRequestParms.GroupPolicy();
        UpdateClaimRequestParms.RetailPolicy retailUpdatePolicy = new UpdateClaimRequestParms.RetailPolicy();

        updateClaimRequestParms.setNewClaimNumber("R18000263");
        updateClaimRequestParms.setClaimOriginatingSystem("Beacon");
        updateClaimRequestParms.setClaimStatusCode("PreClaim");
        updateClaimRequestParms.setClaimSubStatusCode("Pending");
        updateClaimRequestParms.setCurrentlyProcessedBySystem("Promise");
        updateClaimRequestParms.setLineOfBusinessCode("Retail");

        groupUpdatePolicy.setGroupLTCId(" ");
        groupUpdatePolicy.setGroupSeqNbr(0);
        updateClaimRequestParms.setGroupPolicy(groupUpdatePolicy);

        retailUpdatePolicy.setPolNumber("9437958");
        retailUpdatePolicy.setRetailCompanyCode("07");
        updateClaimRequestParms.setRetailPolicy(retailUpdatePolicy);
    }

    @After
    public void tearDown() throws Exception {
    }

    @Test
    public void getGroupSqNo() {
        assertEquals("0",ltcMaintainClaimUtils.getGroupSqNo(createClaimRequestParms));
    }

    @Test
    public void getGroupLTCId() {
        assertEquals(" ",ltcMaintainClaimUtils.getGroupLTCId(createClaimRequestParms));
    }

    @Test
    public void getRetailCompanyCode() {

        assertEquals("07",ltcMaintainClaimUtils.getRetailCompanyCode(createClaimRequestParms));
    }

    @Test
    public void getRetailPolNo() {
        assertEquals("9437958",ltcMaintainClaimUtils.getRetailPolNo(createClaimRequestParms));
    }

    @Test
    public void getRetailCompanyCodeUpdate() {
        assertEquals("07",ltcMaintainClaimUtils.getRetailCompanyCode(updateClaimRequestParms));
    }

    @Test
    public void getRetailPolNoUpdate() {
        assertEquals("9437958",ltcMaintainClaimUtils.getRetailPolNo(updateClaimRequestParms));
    }

    @Test
    public void getGroupLTCIdUpdate() {
        assertEquals(" ",ltcMaintainClaimUtils.getGroupLTCId(updateClaimRequestParms));
    }

    @Test
    public void getGroupSqNoUpdate() {
        assertEquals("0",ltcMaintainClaimUtils.getGroupSqNo(updateClaimRequestParms));
    }


}