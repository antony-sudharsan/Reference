package com.jh.insurance.ltcmaintainclaim.orchestration;

import com.jh.insurance.ltcmaintainclaim.dao.CreateClaimDAO;
import com.jh.insurance.ltcmaintainclaim.utils.LoggerUtils;
import com.jh.insurance.ltcmaintainclaim.validator.LTCMaintainClaimValidator;
import com.manulife.esb.wsdl.ltc.jh.ltcmaintainclaim.ltcmaintainclaim.LTCMaintainClaimFault;
import com.manulife.esb.xsd.ltc.jh.ltcmaintainclaim.*;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.stubbing.OngoingStubbing;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.junit4.SpringRunner;

import static org.junit.Assert.*;
import static org.mockito.Mockito.when;

@RunWith(SpringRunner.class)
public class CreateLTCMaintainClaimOrchestrationTest {

    @Mock
    CreateClaimDAO createClaimDAO;
    @Mock
    LoggerUtils loggerUtils;

    @Mock
    LTCMaintainClaimValidator ltcMaintainClaimValidator;

    @InjectMocks
    LTCMaintainClaimOrchestration LTCMaintainClaimOrchestration;

    CreateClaimRequestParms createClaimRequestParms;
    CreateClaimRequest createClaimRequest;

    CreateClaimResponse createClaimResponse;

    @Test
    public void createClaimStatusCodeCheck() throws LTCMaintainClaimFault {

        createClaimRequest = new CreateClaimRequest();
        createClaimRequestParms = new CreateClaimRequestParms();
        createClaimResponse = new CreateClaimResponse();

        CreateClaimRequestParms.GroupPolicy groupPolicy = new CreateClaimRequestParms.GroupPolicy();
        CreateClaimRequestParms.RetailPolicy retailPolicy = new CreateClaimRequestParms.RetailPolicy();

        createClaimRequestParms.setClaimNumber("R18000263");
        createClaimRequestParms.setClaimOriginatingSystem("Beacon");
        createClaimRequestParms.setClaimStatusCode("PreClaim");
        createClaimRequestParms.setClaimSubStatusCode("Pending");
        createClaimRequestParms.setCurrentlyProcessedBySystem("Promise");
        createClaimRequestParms.setLineOfBusinessCode("Retail");

        groupPolicy.setGroupLTCId(" ");
        groupPolicy.setGroupSeqNbr(0);
        createClaimRequestParms.setGroupPolicy(groupPolicy);

        retailPolicy.setPolNumber("9437958");
        retailPolicy.setRetailCompanyCode("07");
        createClaimRequestParms.setRetailPolicy(retailPolicy);
        createClaimRequest.setCreateClaimRequestParms(createClaimRequestParms);

        createClaimResponse.setCreateClaimRequestParms(createClaimRequestParms);
        createClaimResponse.setStatusCode("0000");
        createClaimResponse.setStatusDescription("Success");

        when(createClaimDAO.createClaim("1234", "123434", "FNA", createClaimRequest)).thenReturn(createClaimResponse);
        assertEquals("0000", LTCMaintainClaimOrchestration.createClaim( "1234","123434", "FNA", createClaimRequest).getStatusCode());
    }

    @Test
    public void createClaimStatusDescCheck() throws LTCMaintainClaimFault {

        createClaimRequest = new CreateClaimRequest();
        createClaimRequestParms = new CreateClaimRequestParms();
        createClaimResponse = new CreateClaimResponse();

        CreateClaimRequestParms.GroupPolicy groupPolicy = new CreateClaimRequestParms.GroupPolicy();
        CreateClaimRequestParms.RetailPolicy retailPolicy = new CreateClaimRequestParms.RetailPolicy();

        createClaimRequestParms.setClaimNumber("R18000263");
        createClaimRequestParms.setClaimOriginatingSystem("Beacon");
        createClaimRequestParms.setClaimStatusCode("PreClaim");
        createClaimRequestParms.setClaimSubStatusCode("Pending");
        createClaimRequestParms.setCurrentlyProcessedBySystem("Promise");
        createClaimRequestParms.setLineOfBusinessCode("Retail");

        groupPolicy.setGroupLTCId(" ");
        groupPolicy.setGroupSeqNbr(0);
        createClaimRequestParms.setGroupPolicy(groupPolicy);

        retailPolicy.setPolNumber("9437958");
        retailPolicy.setRetailCompanyCode("07");
        createClaimRequestParms.setRetailPolicy(retailPolicy);
        createClaimRequest.setCreateClaimRequestParms(createClaimRequestParms);

        createClaimResponse.setCreateClaimRequestParms(createClaimRequestParms);
        createClaimResponse.setStatusCode("0000");
        createClaimResponse.setStatusDescription("Success");

        when(createClaimDAO.createClaim("1234", "123434", "FNA", createClaimRequest)).thenReturn(createClaimResponse);
        assertEquals("Success", LTCMaintainClaimOrchestration.createClaim( "1234","123434", "FNA", createClaimRequest).getStatusDescription());
    }

    @Test
    public void createClaimNoCheck() throws LTCMaintainClaimFault {

        createClaimRequest = new CreateClaimRequest();
        createClaimRequestParms = new CreateClaimRequestParms();
        createClaimResponse = new CreateClaimResponse();

        CreateClaimRequestParms.GroupPolicy groupPolicy = new CreateClaimRequestParms.GroupPolicy();
        CreateClaimRequestParms.RetailPolicy retailPolicy = new CreateClaimRequestParms.RetailPolicy();

        createClaimRequestParms.setClaimNumber("R18000263");
        createClaimRequestParms.setClaimOriginatingSystem("Beacon");
        createClaimRequestParms.setClaimStatusCode("PreClaim");
        createClaimRequestParms.setClaimSubStatusCode("Pending");
        createClaimRequestParms.setCurrentlyProcessedBySystem("Promise");
        createClaimRequestParms.setLineOfBusinessCode("Retail");

        groupPolicy.setGroupLTCId(" ");
        groupPolicy.setGroupSeqNbr(0);
        createClaimRequestParms.setGroupPolicy(groupPolicy);

        retailPolicy.setPolNumber("9437958");
        retailPolicy.setRetailCompanyCode("07");
        createClaimRequestParms.setRetailPolicy(retailPolicy);
        createClaimRequest.setCreateClaimRequestParms(createClaimRequestParms);

        createClaimResponse.setCreateClaimRequestParms(createClaimRequestParms);
        createClaimResponse.setStatusCode("0000");
        createClaimResponse.setStatusDescription("Success");

        when(createClaimDAO.createClaim("1234", "123434", "FNA", createClaimRequest)).thenReturn(createClaimResponse);
        assertEquals("R18000263", LTCMaintainClaimOrchestration.createClaim( "1234","123434", "FNA", createClaimRequest).getCreateClaimRequestParms().getClaimNumber());
    }
}