package com.jh.insurance.ltcmaintainclaim.orchestration;

import com.jh.insurance.ltcmaintainclaim.dao.CreateClaimDAO;
import com.jh.insurance.ltcmaintainclaim.dao.UpdateClaimDAO;
import com.jh.insurance.ltcmaintainclaim.utils.LoggerUtils;
import com.manulife.esb.wsdl.ltc.jh.ltcmaintainclaim.ltcmaintainclaim.LTCMaintainClaimFault;
import com.manulife.esb.xsd.ltc.jh.ltcmaintainclaim.*;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.test.context.junit4.SpringRunner;

import static org.junit.Assert.*;
import static org.mockito.Mockito.when;
@RunWith(SpringRunner.class)
public class UpdateLTCMaintainClaimOrchestrationTest {

    @Mock
    UpdateClaimDAO updateClaimDAO;

    @Mock
    LoggerUtils loggerUtils;

    @InjectMocks
    LTCMaintainClaimOrchestration updateLTCMaintainClaimOrchestration;


    UpdateClaimResponse updateClaimResponse;

    UpdateClaimRequestParms updateClaimRequestParms;
    UpdateClaimRequest updateClaimRequest;

    @Test
    public void updateClaimStatusCodeCheck() throws com.manulife.esb.wsdl.ltc.jh.ltcmaintainclaim.ltcmaintainclaim.LTCMaintainClaimFault {

        updateClaimRequest = new UpdateClaimRequest();
        updateClaimRequestParms = new UpdateClaimRequestParms();
        updateClaimResponse = new UpdateClaimResponse();

        UpdateClaimRequestParms.GroupPolicy groupPolicy = new UpdateClaimRequestParms.GroupPolicy();
        UpdateClaimRequestParms.RetailPolicy retailPolicy = new UpdateClaimRequestParms.RetailPolicy();

        updateClaimRequestParms.setNewClaimNumber("R18000263");
        updateClaimRequestParms.setClaimOriginatingSystem("Beacon");
        updateClaimRequestParms.setClaimStatusCode("PreClaim");
        updateClaimRequestParms.setClaimSubStatusCode("Pending");
        updateClaimRequestParms.setCurrentlyProcessedBySystem("Promise");
        updateClaimRequestParms.setLineOfBusinessCode("Retail");

        groupPolicy.setGroupLTCId(" ");
        groupPolicy.setGroupSeqNbr(0);
        updateClaimRequestParms.setGroupPolicy(groupPolicy);

        retailPolicy.setPolNumber("9437958");
        retailPolicy.setRetailCompanyCode("07");
        updateClaimRequestParms.setRetailPolicy(retailPolicy);
        updateClaimRequest.setUpdateClaimRequestParms(updateClaimRequestParms);

        updateClaimResponse.setUpdateClaimRequestParms(updateClaimRequestParms);
        updateClaimResponse.setStatusCode("0000");
        updateClaimResponse.setStatusDescription("Success");

        when(updateClaimDAO.updateClaim("1234", "123434", "FNA", updateClaimRequest)).thenReturn(updateClaimResponse);
        assertEquals("0000",updateLTCMaintainClaimOrchestration.updateClaim( "1234","123434", "FNA", updateClaimRequest).getStatusCode());
    }

    @Test
    public void updateClaimStatusDescCheck() throws com.manulife.esb.wsdl.ltc.jh.ltcmaintainclaim.ltcmaintainclaim.LTCMaintainClaimFault {

        updateClaimRequest = new UpdateClaimRequest();
        updateClaimRequestParms = new UpdateClaimRequestParms();
        updateClaimResponse = new UpdateClaimResponse();

        UpdateClaimRequestParms.GroupPolicy groupPolicy = new UpdateClaimRequestParms.GroupPolicy();
        UpdateClaimRequestParms.RetailPolicy retailPolicy = new UpdateClaimRequestParms.RetailPolicy();

        updateClaimRequestParms.setNewClaimNumber("R18000263");
        updateClaimRequestParms.setClaimOriginatingSystem("Beacon");
        updateClaimRequestParms.setClaimStatusCode("PreClaim");
        updateClaimRequestParms.setClaimSubStatusCode("Pending");
        updateClaimRequestParms.setCurrentlyProcessedBySystem("Promise");
        updateClaimRequestParms.setLineOfBusinessCode("Retail");

        groupPolicy.setGroupLTCId(" ");
        groupPolicy.setGroupSeqNbr(0);
        updateClaimRequestParms.setGroupPolicy(groupPolicy);

        retailPolicy.setPolNumber("9437958");
        retailPolicy.setRetailCompanyCode("07");
        updateClaimRequestParms.setRetailPolicy(retailPolicy);
        updateClaimRequest.setUpdateClaimRequestParms(updateClaimRequestParms);

        updateClaimResponse.setUpdateClaimRequestParms(updateClaimRequestParms);
        updateClaimResponse.setStatusCode("0000");
        updateClaimResponse.setStatusDescription("Success");

        when(updateClaimDAO.updateClaim("1234", "123434", "FNA", updateClaimRequest)).thenReturn(updateClaimResponse);
        assertEquals("Success",updateLTCMaintainClaimOrchestration.updateClaim( "1234","123434", "FNA", updateClaimRequest).getStatusDescription());
    }

    @Test
    public void updateClaimNoCheck() throws LTCMaintainClaimFault {

        updateClaimRequest = new UpdateClaimRequest();
        updateClaimRequestParms = new UpdateClaimRequestParms();
        updateClaimResponse = new UpdateClaimResponse();

        UpdateClaimRequestParms.GroupPolicy groupPolicy = new UpdateClaimRequestParms.GroupPolicy();
        UpdateClaimRequestParms.RetailPolicy retailPolicy = new UpdateClaimRequestParms.RetailPolicy();

        updateClaimRequestParms.setNewClaimNumber("R18000263");
        updateClaimRequestParms.setClaimOriginatingSystem("Beacon");
        updateClaimRequestParms.setClaimStatusCode("PreClaim");
        updateClaimRequestParms.setClaimSubStatusCode("Pending");
        updateClaimRequestParms.setCurrentlyProcessedBySystem("Promise");
        updateClaimRequestParms.setLineOfBusinessCode("Retail");

        groupPolicy.setGroupLTCId(" ");
        groupPolicy.setGroupSeqNbr(0);
        updateClaimRequestParms.setGroupPolicy(groupPolicy);

        retailPolicy.setPolNumber("9437958");
        retailPolicy.setRetailCompanyCode("07");
        updateClaimRequestParms.setRetailPolicy(retailPolicy);
        updateClaimRequest.setUpdateClaimRequestParms(updateClaimRequestParms);

        updateClaimResponse.setUpdateClaimRequestParms(updateClaimRequestParms);
        updateClaimResponse.setStatusCode("0000");
        updateClaimResponse.setStatusDescription("Success");

        when(updateClaimDAO.updateClaim("1234", "123434", "FNA", updateClaimRequest)).thenReturn(updateClaimResponse);
        assertEquals("R18000263",updateLTCMaintainClaimOrchestration.updateClaim( "1234","123434", "FNA", updateClaimRequest).getUpdateClaimRequestParms().getNewClaimNumber());
    }
}