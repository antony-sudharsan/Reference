
package com.manulife.esb.xsd.ltc.jh.ltcmaintainclaim;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="CreateClaim_RequestParms" type="{http://www.esb.manulife.com/xsd/LTC/jh/LTCMaintainClaim}CreateClaim_RequestParms"/>
 *         &lt;element name="StatusCode" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="StatusDescription" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "createClaimRequestParms",
    "statusCode",
    "statusDescription"
})
@XmlRootElement(name = "CreateClaim_response")
public class CreateClaimResponse {

    @XmlElement(name = "CreateClaim_RequestParms", required = true)
    protected CreateClaimRequestParms createClaimRequestParms;
    @XmlElement(name = "StatusCode", required = true)
    protected String statusCode;
    @XmlElement(name = "StatusDescription", required = true)
    protected String statusDescription;

    /**
     * Gets the value of the createClaimRequestParms property.
     * 
     * @return
     *     possible object is
     *     {@link CreateClaimRequestParms }
     *     
     */
    public CreateClaimRequestParms getCreateClaimRequestParms() {
        return createClaimRequestParms;
    }

    /**
     * Sets the value of the createClaimRequestParms property.
     * 
     * @param value
     *     allowed object is
     *     {@link CreateClaimRequestParms }
     *     
     */
    public void setCreateClaimRequestParms(CreateClaimRequestParms value) {
        this.createClaimRequestParms = value;
    }

    /**
     * Gets the value of the statusCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStatusCode() {
        return statusCode;
    }

    /**
     * Sets the value of the statusCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStatusCode(String value) {
        this.statusCode = value;
    }

    /**
     * Gets the value of the statusDescription property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStatusDescription() {
        return statusDescription;
    }

    /**
     * Sets the value of the statusDescription property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStatusDescription(String value) {
        this.statusDescription = value;
    }

}
