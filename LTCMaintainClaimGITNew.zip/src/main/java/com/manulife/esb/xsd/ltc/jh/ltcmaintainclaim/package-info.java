@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.esb.manulife.com/xsd/LTC/jh/LTCMaintainClaim", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.manulife.esb.xsd.ltc.jh.ltcmaintainclaim;
