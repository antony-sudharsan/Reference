
package com.manulife.esb.xsd.ltc.jh.ltcmaintainclaim;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="CreateClaim_RequestParms" type="{http://www.esb.manulife.com/xsd/LTC/jh/LTCMaintainClaim}CreateClaim_RequestParms"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "createClaimRequestParms"
})
@XmlRootElement(name = "CreateClaim_request")
public class CreateClaimRequest {

    @XmlElement(name = "CreateClaim_RequestParms", required = true)
    protected CreateClaimRequestParms createClaimRequestParms;

    /**
     * Gets the value of the createClaimRequestParms property.
     * 
     * @return
     *     possible object is
     *     {@link CreateClaimRequestParms }
     *     
     */
    public CreateClaimRequestParms getCreateClaimRequestParms() {
        return createClaimRequestParms;
    }

    /**
     * Sets the value of the createClaimRequestParms property.
     * 
     * @param value
     *     allowed object is
     *     {@link CreateClaimRequestParms }
     *     
     */
    public void setCreateClaimRequestParms(CreateClaimRequestParms value) {
        this.createClaimRequestParms = value;
    }

}
