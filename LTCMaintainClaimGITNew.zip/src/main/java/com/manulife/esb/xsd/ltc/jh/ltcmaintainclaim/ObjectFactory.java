
package com.manulife.esb.xsd.ltc.jh.ltcmaintainclaim;

import javax.xml.bind.annotation.XmlRegistry;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.manulife.esb.xsd.ltc.jh.ltcmaintainclaim package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {


    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.manulife.esb.xsd.ltc.jh.ltcmaintainclaim
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link UpdateClaimRequestParms }
     * 
     */
    public UpdateClaimRequestParms createUpdateClaimRequestParms() {
        return new UpdateClaimRequestParms();
    }

    /**
     * Create an instance of {@link CreateClaimRequestParms }
     * 
     */
    public CreateClaimRequestParms createCreateClaimRequestParms() {
        return new CreateClaimRequestParms();
    }

    /**
     * Create an instance of {@link CreateClaimResponse }
     * 
     */
    public CreateClaimResponse createCreateClaimResponse() {
        return new CreateClaimResponse();
    }

    /**
     * Create an instance of {@link UpdateClaimRequest }
     * 
     */
    public UpdateClaimRequest createUpdateClaimRequest() {
        return new UpdateClaimRequest();
    }

    /**
     * Create an instance of {@link UpdateClaimResponse }
     * 
     */
    public UpdateClaimResponse createUpdateClaimResponse() {
        return new UpdateClaimResponse();
    }

    /**
     * Create an instance of {@link CreateClaimRequest }
     * 
     */
    public CreateClaimRequest createCreateClaimRequest() {
        return new CreateClaimRequest();
    }

    /**
     * Create an instance of {@link LTCMaintainClaimFault }
     * 
     */
    public LTCMaintainClaimFault createLTCMaintainClaimFault() {
        return new LTCMaintainClaimFault();
    }

    /**
     * Create an instance of {@link UpdateClaimRequestParms.GroupPolicy }
     * 
     */
    public UpdateClaimRequestParms.GroupPolicy createUpdateClaimRequestParmsGroupPolicy() {
        return new UpdateClaimRequestParms.GroupPolicy();
    }

    /**
     * Create an instance of {@link UpdateClaimRequestParms.RetailPolicy }
     * 
     */
    public UpdateClaimRequestParms.RetailPolicy createUpdateClaimRequestParmsRetailPolicy() {
        return new UpdateClaimRequestParms.RetailPolicy();
    }

    /**
     * Create an instance of {@link CreateClaimRequestParms.GroupPolicy }
     * 
     */
    public CreateClaimRequestParms.GroupPolicy createCreateClaimRequestParmsGroupPolicy() {
        return new CreateClaimRequestParms.GroupPolicy();
    }

    /**
     * Create an instance of {@link CreateClaimRequestParms.RetailPolicy }
     * 
     */
    public CreateClaimRequestParms.RetailPolicy createCreateClaimRequestParmsRetailPolicy() {
        return new CreateClaimRequestParms.RetailPolicy();
    }

}
