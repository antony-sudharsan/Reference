
package com.manulife.esb.xsd.ltc.jh.ltcmaintainclaim;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="UpdateClaim_RequestParms" type="{http://www.esb.manulife.com/xsd/LTC/jh/LTCMaintainClaim}UpdateClaim_RequestParms"/>
 *         &lt;element name="StatusCode" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="StatusDescription" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "updateClaimRequestParms",
    "statusCode",
    "statusDescription"
})
@XmlRootElement(name = "UpdateClaim_response")
public class UpdateClaimResponse {

    @XmlElement(name = "UpdateClaim_RequestParms", required = true)
    protected UpdateClaimRequestParms updateClaimRequestParms;
    @XmlElement(name = "StatusCode", required = true)
    protected String statusCode;
    @XmlElement(name = "StatusDescription", required = true)
    protected String statusDescription;

    /**
     * Gets the value of the updateClaimRequestParms property.
     * 
     * @return
     *     possible object is
     *     {@link UpdateClaimRequestParms }
     *     
     */
    public UpdateClaimRequestParms getUpdateClaimRequestParms() {
        return updateClaimRequestParms;
    }

    /**
     * Sets the value of the updateClaimRequestParms property.
     * 
     * @param value
     *     allowed object is
     *     {@link UpdateClaimRequestParms }
     *     
     */
    public void setUpdateClaimRequestParms(UpdateClaimRequestParms value) {
        this.updateClaimRequestParms = value;
    }

    /**
     * Gets the value of the statusCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStatusCode() {
        return statusCode;
    }

    /**
     * Sets the value of the statusCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStatusCode(String value) {
        this.statusCode = value;
    }

    /**
     * Gets the value of the statusDescription property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStatusDescription() {
        return statusDescription;
    }

    /**
     * Sets the value of the statusDescription property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStatusDescription(String value) {
        this.statusDescription = value;
    }

}
