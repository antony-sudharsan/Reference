
package com.manulife.esb.xsd.ltc.jh.ltcmaintainclaim;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for CreateClaim_RequestParms complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="CreateClaim_RequestParms">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="LineOfBusinessCode" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;choice>
 *           &lt;element name="GroupPolicy">
 *             &lt;complexType>
 *               &lt;complexContent>
 *                 &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                   &lt;sequence>
 *                     &lt;element name="GroupLTCId" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                     &lt;element name="GroupSeqNbr" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *                   &lt;/sequence>
 *                 &lt;/restriction>
 *               &lt;/complexContent>
 *             &lt;/complexType>
 *           &lt;/element>
 *           &lt;element name="RetailPolicy">
 *             &lt;complexType>
 *               &lt;complexContent>
 *                 &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                   &lt;sequence>
 *                     &lt;element name="RetailCompanyCode" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                     &lt;element name="PolNumber" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                   &lt;/sequence>
 *                 &lt;/restriction>
 *               &lt;/complexContent>
 *             &lt;/complexType>
 *           &lt;/element>
 *         &lt;/choice>
 *         &lt;element name="ClaimStatusCode" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ClaimSubStatusCode" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ClaimStatusEffectiveDate" type="{http://www.w3.org/2001/XMLSchema}dateTime"/>
 *         &lt;element name="ClaimOriginatingSystem" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="CurrentlyProcessedBySystem" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ClaimNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CreateClaim_RequestParms", propOrder = {
    "lineOfBusinessCode",
    "groupPolicy",
    "retailPolicy",
    "claimStatusCode",
    "claimSubStatusCode",
    "claimStatusEffectiveDate",
    "claimOriginatingSystem",
    "currentlyProcessedBySystem",
    "claimNumber"
})
public class CreateClaimRequestParms {

    @XmlElement(name = "LineOfBusinessCode", required = true)
    protected String lineOfBusinessCode;
    @XmlElement(name = "GroupPolicy")
    protected GroupPolicy groupPolicy;
    @XmlElement(name = "RetailPolicy")
    protected RetailPolicy retailPolicy;
    @XmlElement(name = "ClaimStatusCode", required = true)
    protected String claimStatusCode;
    @XmlElement(name = "ClaimSubStatusCode", required = true)
    protected String claimSubStatusCode;
    @XmlElement(name = "ClaimStatusEffectiveDate", required = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar claimStatusEffectiveDate;
    @XmlElement(name = "ClaimOriginatingSystem", required = true)
    protected String claimOriginatingSystem;
    @XmlElement(name = "CurrentlyProcessedBySystem", required = true)
    protected String currentlyProcessedBySystem;
    @XmlElement(name = "ClaimNumber")
    protected String claimNumber;

    /**
     * Gets the value of the lineOfBusinessCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLineOfBusinessCode() {
        return lineOfBusinessCode;
    }

    /**
     * Sets the value of the lineOfBusinessCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLineOfBusinessCode(String value) {
        this.lineOfBusinessCode = value;
    }

    /**
     * Gets the value of the groupPolicy property.
     * 
     * @return
     *     possible object is
     *     {@link GroupPolicy }
     *     
     */
    public GroupPolicy getGroupPolicy() {
        return groupPolicy;
    }

    /**
     * Sets the value of the groupPolicy property.
     * 
     * @param value
     *     allowed object is
     *     {@link GroupPolicy }
     *     
     */
    public void setGroupPolicy(GroupPolicy value) {
        this.groupPolicy = value;
    }

    /**
     * Gets the value of the retailPolicy property.
     * 
     * @return
     *     possible object is
     *     {@link RetailPolicy }
     *     
     */
    public RetailPolicy getRetailPolicy() {
        return retailPolicy;
    }

    /**
     * Sets the value of the retailPolicy property.
     * 
     * @param value
     *     allowed object is
     *     {@link RetailPolicy }
     *     
     */
    public void setRetailPolicy(RetailPolicy value) {
        this.retailPolicy = value;
    }

    /**
     * Gets the value of the claimStatusCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getClaimStatusCode() {
        return claimStatusCode;
    }

    /**
     * Sets the value of the claimStatusCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClaimStatusCode(String value) {
        this.claimStatusCode = value;
    }

    /**
     * Gets the value of the claimSubStatusCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getClaimSubStatusCode() {
        return claimSubStatusCode;
    }

    /**
     * Sets the value of the claimSubStatusCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClaimSubStatusCode(String value) {
        this.claimSubStatusCode = value;
    }

    /**
     * Gets the value of the claimStatusEffectiveDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getClaimStatusEffectiveDate() {
        return claimStatusEffectiveDate;
    }

    /**
     * Sets the value of the claimStatusEffectiveDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setClaimStatusEffectiveDate(XMLGregorianCalendar value) {
        this.claimStatusEffectiveDate = value;
    }

    /**
     * Gets the value of the claimOriginatingSystem property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getClaimOriginatingSystem() {
        return claimOriginatingSystem;
    }

    /**
     * Sets the value of the claimOriginatingSystem property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClaimOriginatingSystem(String value) {
        this.claimOriginatingSystem = value;
    }

    /**
     * Gets the value of the currentlyProcessedBySystem property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCurrentlyProcessedBySystem() {
        return currentlyProcessedBySystem;
    }

    /**
     * Sets the value of the currentlyProcessedBySystem property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCurrentlyProcessedBySystem(String value) {
        this.currentlyProcessedBySystem = value;
    }

    /**
     * Gets the value of the claimNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getClaimNumber() {
        return claimNumber;
    }

    /**
     * Sets the value of the claimNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClaimNumber(String value) {
        this.claimNumber = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="GroupLTCId" type="{http://www.w3.org/2001/XMLSchema}string"/>
     *         &lt;element name="GroupSeqNbr" type="{http://www.w3.org/2001/XMLSchema}int"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "groupLTCId",
        "groupSeqNbr"
    })
    public static class GroupPolicy {

        @XmlElement(name = "GroupLTCId", required = true)
        protected String groupLTCId;
        @XmlElement(name = "GroupSeqNbr")
        protected int groupSeqNbr;

        /**
         * Gets the value of the groupLTCId property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getGroupLTCId() {
            return groupLTCId;
        }

        /**
         * Sets the value of the groupLTCId property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setGroupLTCId(String value) {
            this.groupLTCId = value;
        }

        /**
         * Gets the value of the groupSeqNbr property.
         * 
         */
        public int getGroupSeqNbr() {
            return groupSeqNbr;
        }

        /**
         * Sets the value of the groupSeqNbr property.
         * 
         */
        public void setGroupSeqNbr(int value) {
            this.groupSeqNbr = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="RetailCompanyCode" type="{http://www.w3.org/2001/XMLSchema}string"/>
     *         &lt;element name="PolNumber" type="{http://www.w3.org/2001/XMLSchema}string"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "retailCompanyCode",
        "polNumber"
    })
    public static class RetailPolicy {

        @XmlElement(name = "RetailCompanyCode", required = true)
        protected String retailCompanyCode;
        @XmlElement(name = "PolNumber",   required = true)
        protected String polNumber;

        /**
         * Gets the value of the retailCompanyCode property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getRetailCompanyCode() {
            return retailCompanyCode;
        }

        /**
         * Sets the value of the retailCompanyCode property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setRetailCompanyCode(String value) {
            this.retailCompanyCode = value;
        }

        /**
         * Gets the value of the polNumber property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getPolNumber() {
            return polNumber;
        }

        /**
         * Sets the value of the polNumber property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setPolNumber(String value) {
            this.polNumber = value;
        }

    }

}
