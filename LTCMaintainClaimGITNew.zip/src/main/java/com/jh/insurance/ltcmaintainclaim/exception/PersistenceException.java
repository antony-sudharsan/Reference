package com.jh.insurance.ltcmaintainclaim.exception;


import com.jh.insurance.ltcmaintainclaim.utils.Utility;

public class PersistenceException extends BaseFaultException {
	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	private static final String DEFAULT_CODE = "E5008";
	private static final String DEFAULT_REASON = "Invalid SQL Statement Exception";
	private static final String FAULT_STRING = "Internal Error";

	public PersistenceException(final String message, final Throwable cause) {
		super(DEFAULT_CODE, DEFAULT_REASON, getMessage(message, cause), FAULT_STRING, cause);
	}

	private static String getMessage(final String message, final Throwable cause) {
		String detail = message;
		if (cause != null) {
			detail = message + ", " + Utility.getStackTrace(cause);
		}
		return detail;
	}

}
