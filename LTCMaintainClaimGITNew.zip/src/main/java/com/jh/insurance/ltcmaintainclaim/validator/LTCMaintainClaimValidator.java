package com.jh.insurance.ltcmaintainclaim.validator;

import com.jh.insurance.ltcmaintainclaim.constants.LTCMaintainClaimConstants;
import com.jh.insurance.ltcmaintainclaim.exception.BlankPolicyException;
import com.jh.insurance.ltcmaintainclaim.exception.InvalidInputException;
import com.jh.insurance.ltcmaintainclaim.utils.LTCMaintainClaimUtils;
import com.manulife.esb.wsdl.ltc.jh.ltcmaintainclaim.ltcmaintainclaim.LTCMaintainClaimFault;
import com.manulife.esb.xsd.common.jh.commonmessage.FaultType;
import com.manulife.esb.xsd.ltc.jh.ltcmaintainclaim.CreateClaimRequest;
import com.manulife.esb.xsd.ltc.jh.ltcmaintainclaim.CreateClaimRequestParms;
import com.manulife.esb.xsd.ltc.jh.ltcmaintainclaim.UpdateClaimRequest;
import com.manulife.esb.xsd.ltc.jh.ltcmaintainclaim.UpdateClaimRequestParms;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

@Component
public class LTCMaintainClaimValidator {

    LTCMaintainClaimUtils ltcMaintainClaimUtils = new LTCMaintainClaimUtils();
    /**
     *
     * @param messageUUID
     * @param sourceSystemName
     * @param createClaimRequest
     */
    public  void validateRequest( String messageUUID,  String sourceSystemName,
                                  CreateClaimRequest createClaimRequest)  {

        CreateClaimRequestParms createClaimRequestParms = createClaimRequest.getCreateClaimRequestParms();

        System.out.println("ltcMaintainClaimUtils.getGroupLTCId(createClaimRequestParms)>>"+ltcMaintainClaimUtils.getGroupLTCId(createClaimRequestParms));
        System.out.println("ltcMaintainClaimUtils.getRetailCompanyCode(createClaimRequestParms)>>"+ltcMaintainClaimUtils.getRetailCompanyCode(createClaimRequestParms));
        if(messageUUID.length() == 0) {

            throw new InvalidInputException();

        }else if(sourceSystemName.length() == 0) {
            throw new InvalidInputException();
        }/*else if(ltcMaintainClaimUtils.getRetailPolNo(createClaimRequestParms).trim().isEmpty()) {
            throw new BlankPolicyException();
        }*/ else if(createClaimRequestParms.getClaimOriginatingSystem().trim().isEmpty() || createClaimRequestParms.getCurrentlyProcessedBySystem().trim().isEmpty()){
            throw new BlankPolicyException();
        } /*else if(ltcMaintainClaimUtils.getGroupLTCId(createClaimRequestParms).trim().isEmpty() && ltcMaintainClaimUtils.getRetailCompanyCode(createClaimRequestParms).trim().isEmpty() && ltcMaintainClaimUtils.getRetailPolNo(createClaimRequestParms).trim().isEmpty()){
            throw new BlankPolicyException();
        }*/


    }

    /**
     *
     * @param messageUUID
     * @param sourceSystemName
     * @param updateClaimRequest
     */
    public  void validateRequest(final String messageUUID, final String sourceSystemName,	final UpdateClaimRequest updateClaimRequest){

        UpdateClaimRequestParms updateClaimRequestParms = updateClaimRequest.getUpdateClaimRequestParms();

        System.out.println("First Condition >>"+ltcMaintainClaimUtils.getGroupLTCId(updateClaimRequestParms));
        System.out.println("Second Condition >>"+ltcMaintainClaimUtils.getRetailCompanyCode(updateClaimRequestParms));
        System.out.println("Third  Condition >>"+ltcMaintainClaimUtils.getRetailPolNo(updateClaimRequestParms));
        System.out.println("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%55");
        System.out.println("First Condition >>"+ltcMaintainClaimUtils.getGroupLTCId(updateClaimRequestParms).trim().isEmpty());
        System.out.println("Second Condition >>"+ltcMaintainClaimUtils.getRetailCompanyCode(updateClaimRequestParms).trim().isEmpty());
        System.out.println("Third  Condition >>"+ltcMaintainClaimUtils.getRetailPolNo(updateClaimRequestParms).trim().isEmpty());

        if(messageUUID.length() == 0) {

            throw new InvalidInputException();

        }else if(sourceSystemName.length() == 0) {
            throw new InvalidInputException();
        }else if(ltcMaintainClaimUtils.getRetailPolNo(updateClaimRequestParms).trim().isEmpty()) {
            throw new BlankPolicyException();
        }else if(updateClaimRequestParms.getClaimOriginatingSystem().trim().isEmpty() || updateClaimRequestParms.getCurrentlyProcessedBySystem().trim().isEmpty()){
            throw new BlankPolicyException();

        } else if(ltcMaintainClaimUtils.getGroupLTCId(updateClaimRequestParms).trim().isEmpty() && ltcMaintainClaimUtils.getRetailCompanyCode(updateClaimRequestParms).trim().isEmpty() && ltcMaintainClaimUtils.getRetailPolNo(updateClaimRequestParms).trim().isEmpty()){
            throw new BlankPolicyException();
        }
    }

}