package com.jh.insurance.ltcmaintainclaim.config;

import com.jh.insurance.ltcmaintainclaim.exception.InvalidInputException;
import org.springframework.core.io.ClassPathResource;
import org.springframework.ws.WebServiceMessage;
import org.springframework.ws.soap.server.endpoint.interceptor.PayloadValidatingInterceptor;
import org.xml.sax.SAXException;

import javax.xml.transform.Source;
import javax.xml.transform.dom.DOMResult;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import javax.xml.validation.Validator;
import java.io.IOException;

/**
 * The Class CustomValidatingInterceptor.
 */
public class CustomValidatingInterceptor extends PayloadValidatingInterceptor {

    /**
     *
     * @param request
     * @return
     */
    protected Source getValidationRequestSource(WebServiceMessage request) {
        Source source = request.getPayloadSource();
        try {
            validateSchema(source);
        } catch (Exception e){
            throw new InvalidInputException();
        }
        return source;
    }

    /**
     *
     * @param source
     * @throws SAXException
     * @throws IOException
     */
    private void validateSchema(Source source) throws SAXException, IOException {
        SchemaFactory schemaFactory = SchemaFactory.newInstance(getSchemaLanguage());
        try {
            Schema schema = schemaFactory.newSchema(new ClassPathResource("LTCMaintainClaim_0.1.0.xsd").getFile());
            Validator validator = schema.newValidator();
            DOMResult result = new DOMResult();
            validator.validate(source, result);


        } catch (SAXException ex) {
           throw ex;
        } catch (Exception ex) {
            throw ex;
        }
    }
}