package com.jh.insurance.ltcmaintainclaim.constants;

public class LTCMaintainClaimConstants {

    // ####### Error Messages #####################

    public static String TECHNICAL_ERROR_REASON = "Technical Error";
    public static String INVALID_INPUT_ERROR_REASON = "Invalid Input";
    public static String TIMEOUT_ERROR_REASON = "Service Timedout";
    public static String NO_RECORD_FOUND_ERROR_REASON = "No Data Found";
    public static String MAX_RECORD_ERROR_REASON = "Max Result Limit Encountered";


    // ####### Error Codes #####################

    public static String TECHNICAL_ERROR_CODE = "9999";
    public static String INVALID_INPUT_ERROR_CODE = "993";
    public static String TIMEOUT_ERROR_CODE = "99999";
    public static String NO_RECORD_FOUND_ERROR_CODE = "999";
    public static String MAX_RECORD_ERROR_CODE = "998";

    public LTCMaintainClaimConstants() {
    }
}
