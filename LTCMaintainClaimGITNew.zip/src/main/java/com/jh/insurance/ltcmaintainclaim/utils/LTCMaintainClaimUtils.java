package com.jh.insurance.ltcmaintainclaim.utils;

import com.manulife.esb.xsd.ltc.jh.ltcmaintainclaim.CreateClaimRequestParms;
import com.manulife.esb.xsd.ltc.jh.ltcmaintainclaim.UpdateClaimRequestParms;
import org.springframework.stereotype.Component;

@Component
public class LTCMaintainClaimUtils {

    /**
     *
     * @param updateClaimRequestParms
     * @return
     */
    public String getGroupSqNo(UpdateClaimRequestParms updateClaimRequestParms){
        String retValue = null;
        if(updateClaimRequestParms.getGroupPolicy() != null){
            retValue =  String.valueOf(updateClaimRequestParms.getGroupPolicy().getGroupSeqNbr());
        }
        return retValue;
    }

    /**
     *
     * @param updateClaimRequestParms
     * @return
     */
    public String getGroupLTCId(UpdateClaimRequestParms updateClaimRequestParms){
        String retValue = null;
        if(updateClaimRequestParms.getGroupPolicy() != null){
            retValue =  updateClaimRequestParms.getGroupPolicy().getGroupLTCId();
        }
        return retValue;
    }

    /**
     *
     * @param updateClaimRequestParms
     * @return
     */
    public String getRetailCompanyCode(UpdateClaimRequestParms updateClaimRequestParms){
        String retValue = null;
        if(updateClaimRequestParms.getRetailPolicy() != null){
            retValue =  updateClaimRequestParms.getRetailPolicy().getRetailCompanyCode();
        }
        return retValue;
    }

    /**
     *
     * @param updateClaimRequestParms
     * @return
     */
    public String getRetailPolNo(UpdateClaimRequestParms updateClaimRequestParms){
        String retValue = null;
        if(updateClaimRequestParms.getRetailPolicy() != null){
            System.out.println("The value of the Policy No >>"+updateClaimRequestParms.getRetailPolicy().getPolNumber()+"<<");
            retValue =  updateClaimRequestParms.getRetailPolicy().getPolNumber();
        }
        return retValue;
    }


    /**
     *
     * @param createClaimRequestParms
     * @return
     */
    public String getRetailCompanyCode(CreateClaimRequestParms createClaimRequestParms){
        String retValue = "NULL";
        if(createClaimRequestParms.getRetailPolicy() != null){
            retValue =  createClaimRequestParms.getRetailPolicy().getRetailCompanyCode();
        }
        return retValue;
    }

    /**
     *
     * @param createClaimRequestParms
     * @return
     */
    public String getRetailPolNo(CreateClaimRequestParms createClaimRequestParms){
        String retValue = "NULL";
        if(createClaimRequestParms.getRetailPolicy() != null){
            retValue =  createClaimRequestParms.getRetailPolicy().getPolNumber();
        }
        return retValue;
    }

    /**
     *
     * @param createClaimRequestParms
     * @return
     */
    public String getGroupLTCId(CreateClaimRequestParms createClaimRequestParms){
        String retValue = "NULL";
        if(createClaimRequestParms.getGroupPolicy() != null){
            retValue =  createClaimRequestParms.getGroupPolicy().getGroupLTCId();
        }
        return retValue;
    }
    /**
     *
     * @param createClaimRequestParms
     * @return
     */
    public String getGroupSqNo(CreateClaimRequestParms createClaimRequestParms){
        String retValue = null;
        if(createClaimRequestParms.getGroupPolicy() != null){
            retValue =  String.valueOf(createClaimRequestParms.getGroupPolicy().getGroupSeqNbr());
        }
        return retValue;
    }

    public String getXMLCalendarValue(CreateClaimRequestParms createClaimRequestParms){
        String retValue = null;
        if(createClaimRequestParms.getClaimStatusEffectiveDate() != null){
            retValue =  String.valueOf(createClaimRequestParms.getClaimStatusEffectiveDate());
        }
        return retValue;
    }

    public String getXMLCalendarValue(UpdateClaimRequestParms updateClaimRequestParms){
        String retValue = null;
        if(updateClaimRequestParms.getClaimStatusEffectiveDate() != null){
            retValue =  String.valueOf(updateClaimRequestParms.getClaimStatusEffectiveDate());
        }
        return retValue;
    }
}
