package com.jh.insurance.ltcmaintainclaim.exception;

public class BlankPolicyException extends BaseFaultException {
	private static final long serialVersionUID = -6016805724195451879L;

	private static final String DEFAULT_CODE = "E5008";
	private static final String DEFAULT_REASON = "Invalid SQL Statement Exception";
	private static final String DEFAULT_DETAILS = "Invalid Service Request";
	private static final String FAULT_STRING = "Internal Error";

	public BlankPolicyException() {
		super(DEFAULT_CODE, DEFAULT_REASON, DEFAULT_DETAILS, FAULT_STRING);
	}

}
