package com.jh.insurance.ltcmaintainclaim.exception;

import com.manulife.esb.xsd.common.jh.commonmessage.FaultType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import org.springframework.ws.soap.SoapFault;
import org.springframework.ws.soap.SoapFaultDetail;
import org.springframework.ws.soap.server.endpoint.SoapFaultMappingExceptionResolver;

public class DetailSoapFaultDefinitionExceptionResolver extends SoapFaultMappingExceptionResolver {

	private static final Logger logger = LoggerFactory.getLogger(DetailSoapFaultDefinitionExceptionResolver.class);
	private static final String DEFAULT_FAULT_ACTOR = "PROVIDER";
	private Jaxb2Marshaller marshaller;

	public DetailSoapFaultDefinitionExceptionResolver() {
		try {
			marshaller = new Jaxb2Marshaller();
			marshaller.setPackagesToScan(com.manulife.esb.xsd.common.jh.commonmessage.FaultType.class.getPackage().getName());
			marshaller.afterPropertiesSet();
		} catch (final Exception e) {
			logger.error("Failed initializing Jaxb2Marshaller ", e);
			throw new RuntimeException(e);
		}
	}

	@Override
	protected void customizeFault(final Object endpoint, final Exception ex, final SoapFault fault) {
		logger.warn("Exception processed ", ex);

		if (ex instanceof BaseFaultException) {
			// add fault details

            final BaseFaultException baseFaultException = (BaseFaultException) ex;

            FaultType faultInfo = new FaultType();
            faultInfo.setErrorCode(baseFaultException.getCode());
            faultInfo.setErrorDescription(baseFaultException.getReason());

            final SoapFaultDetail detail = fault.addFaultDetail();
            marshaller.marshal(faultInfo, detail.getResult());
            fault.setFaultActorOrRole(DEFAULT_FAULT_ACTOR);


		}

	}
}
