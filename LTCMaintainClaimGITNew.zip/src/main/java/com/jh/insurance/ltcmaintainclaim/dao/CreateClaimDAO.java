/**
 *
 */
package com.jh.insurance.ltcmaintainclaim.dao;


import com.jh.common.logging.LoggerHandler;
import com.jh.insurance.ltcmaintainclaim.constants.LTCMaintainClaimConstants;
import com.jh.insurance.ltcmaintainclaim.exception.PersistenceException;
import com.jh.insurance.ltcmaintainclaim.exception.QueryException;
import com.jh.insurance.ltcmaintainclaim.exception.SQLServerException;
import com.jh.insurance.ltcmaintainclaim.exception.TechnicalErrorException;
import com.jh.insurance.ltcmaintainclaim.utils.LTCMaintainClaimUtils;
import com.jh.insurance.ltcmaintainclaim.utils.LoggerUtils;
import com.manulife.esb.xsd.ltc.jh.ltcmaintainclaim.CreateClaimRequest;
import com.manulife.esb.xsd.ltc.jh.ltcmaintainclaim.CreateClaimRequestParms;
import com.manulife.esb.xsd.ltc.jh.ltcmaintainclaim.CreateClaimResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.QueryTimeoutException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

/*import javax.persistence.PersistenceException;
import javax.persistence.QueryTimeoutException;
import javax.persistence.StoredProcedureQuery;*/
import java.sql.CallableStatement;
import java.sql.Types;

/**
 * @author deepain
 */
@Component
public class CreateClaimDAO {


    @Autowired
    LTCMaintainClaimUtils ltcMaintainClaimUtils;

    @Autowired
    private LoggerUtils loggerUtils;


    @Autowired
    private JdbcTemplate jdbcTemplate;


  public CreateClaimResponse createClaim(String userID, String messageUUID, String sourceSystemName, CreateClaimRequest createClaimRequest) {

        LoggerHandler.LogOut("INFO", "4", messageUUID, sourceSystemName, this.getClass().getName(), createClaimRequest.toString());
        CreateClaimResponse createClaimResponse = new CreateClaimResponse();
        try {
            CreateClaimRequestParms createClaimRequestParms = createClaimRequest.getCreateClaimRequestParms();

            CallableStatement callableStatement = jdbcTemplate.getDataSource().getConnection().prepareCall("{call usp_SVC_CreateClaim(?,?,?,?,?,?,?,?,?,?,?,?,?)}");


            callableStatement.setString("LineOfBusinessCode", createClaimRequestParms.getLineOfBusinessCode());
            callableStatement.setString("RetailCompanyCode", ltcMaintainClaimUtils.getRetailCompanyCode(createClaimRequestParms));
            callableStatement.setString("PolNumber",  ltcMaintainClaimUtils.getRetailPolNo(createClaimRequestParms));
            callableStatement.setString("GroupSeqNbr", ltcMaintainClaimUtils.getGroupSqNo(createClaimRequestParms));
            callableStatement.setString("GroupLTCID",  ltcMaintainClaimUtils.getGroupLTCId(createClaimRequestParms));
            callableStatement.setString("ClaimNumber", createClaimRequestParms.getClaimNumber());
            callableStatement.setString("ClaimStatusCode", createClaimRequestParms.getClaimStatusCode());
            callableStatement.setString("ClaimSubStatusCode", createClaimRequestParms.getClaimSubStatusCode());
            callableStatement.setString("ClaimStatusEffectiveDate", ltcMaintainClaimUtils.getXMLCalendarValue(createClaimRequestParms));
            callableStatement.setString("ClaimOriginatingSystem", createClaimRequestParms.getClaimOriginatingSystem());
            callableStatement.setString("CurrentlyProcessedBySystem", createClaimRequestParms.getCurrentlyProcessedBySystem());
            callableStatement.registerOutParameter("outClaimNumber", Types.VARCHAR);
            callableStatement.setString("UserName", userID);

            callableStatement.executeUpdate();

            String claimNumber = (String) callableStatement.getString("outClaimNumber");


            createClaimRequestParms.setClaimNumber(claimNumber);
            createClaimResponse.setCreateClaimRequestParms(createClaimRequestParms);

            if (claimNumber.length() > 0) {
                createClaimResponse.setStatusCode("0000");
                createClaimResponse.setStatusDescription("Success");
            } else {
                createClaimResponse.setStatusCode("0100");
                createClaimResponse.setStatusDescription("Failure");
            }
        } catch (QueryTimeoutException e) {
            throw new QueryException(LTCMaintainClaimConstants.TIMEOUT_ERROR_CODE, e.getCause());

        } catch (DataAccessException e) {
            throw new SQLServerException(LTCMaintainClaimConstants.TECHNICAL_ERROR_CODE, e.getCause());

        } catch (PersistenceException e) {
            throw new com.jh.insurance.ltcmaintainclaim.exception.PersistenceException(LTCMaintainClaimConstants.TECHNICAL_ERROR_CODE, e.getCause());

        } catch (Exception e) {
            e.printStackTrace();
            throw new TechnicalErrorException(LTCMaintainClaimConstants.TECHNICAL_ERROR_CODE, e.getCause());
        }
        LoggerHandler.LogOut("INFO", "4", messageUUID, sourceSystemName, this.getClass().getName(), loggerUtils.writeAsJson(createClaimResponse));

        return createClaimResponse;
    }


    /*public CreateClaimResponse createClaim(String userID, String messageUUID, String sourceSystemName, CreateClaimRequest createClaimRequest) {

        LoggerHandler.LogOut("INFO", "4", messageUUID, sourceSystemName, this.getClass().getName(), createClaimRequest.toString());
        CreateClaimResponse createClaimResponse = new CreateClaimResponse();
        try {
            CreateClaimRequestParms createClaimRequestParms = createClaimRequest.getCreateClaimRequestParms();

            String claimNumber = (String)jdbcTemplate.queryForObject("call usp_SVC_CreateClaim (?, ?,?, ?,?, ?,?, ?,?, ?,?, ?,?)",String.class, createClaimRequestParms.getLineOfBusinessCode(),
                    ltcMaintainClaimUtils.getRetailCompanyCode(createClaimRequestParms), ltcMaintainClaimUtils.getRetailPolNo(createClaimRequestParms),
                    ltcMaintainClaimUtils.getGroupSqNo(createClaimRequestParms), ltcMaintainClaimUtils.getGroupLTCId(createClaimRequestParms),
                    createClaimRequestParms.getClaimNumber(),createClaimRequestParms.getClaimStatusCode(),
                    createClaimRequestParms.getClaimSubStatusCode(),ltcMaintainClaimUtils.getXMLCalendarValue(createClaimRequestParms),
                    createClaimRequestParms.getClaimOriginatingSystem(),createClaimRequestParms.getCurrentlyProcessedBySystem(),
                    createClaimRequestParms.getClaimNumber(),userID );

             createClaimRequestParms.setClaimNumber(claimNumber);
            createClaimResponse.setCreateClaimRequestParms(createClaimRequestParms);

            if (claimNumber.length() > 0) {
                createClaimResponse.setStatusCode("0000");
                createClaimResponse.setStatusDescription("Success");
            } else {
                createClaimResponse.setStatusCode("0100");
                createClaimResponse.setStatusDescription("Failure");
            }
        } catch (QueryTimeoutException e) {
            throw new QueryTimeoutException();

        } catch (DataAccessException e) {
            throw new SQLServerException("Antony", e.getCause());

        } catch (PersistenceException e) {
            throw new com.jh.insurance.ltcmaintainclaim.exception.PersistenceException("Antony", e.getCause());

        } catch (Exception e) {
            throw new TechnicalErrorException(LTCMaintainClaimConstants.TECHNICAL_ERROR_CODE, e.getCause());
        }
        LoggerHandler.LogOut("INFO", "4", messageUUID, sourceSystemName, this.getClass().getName(), loggerUtils.writeAsJson(createClaimResponse));

        return createClaimResponse;
    }*/



    /*public CreateClaimResponse createClaim(String userID, String messageUUID, String sourceSystemName, CreateClaimRequest createClaimRequest) {

        LoggerHandler.LogOut("INFO", "4", messageUUID, sourceSystemName, this.getClass().getName(), createClaimRequest.toString());
        CreateClaimResponse createClaimResponse = new CreateClaimResponse();
        try {
            CreateClaimRequestParms createClaimRequestParms = createClaimRequest.getCreateClaimRequestParms();
            createClaimProcedure = entityManager.createStoredProcedureQuery(storeProcedureName);

            createClaimProcedure.registerStoredProcedureParameter("LineOfBusinessCode", String.class, ParameterMode.IN);
            createClaimProcedure.registerStoredProcedureParameter("RetailCompanyCode", String.class, ParameterMode.IN);
            createClaimProcedure.registerStoredProcedureParameter("PolNumber", String.class, ParameterMode.IN);
            createClaimProcedure.registerStoredProcedureParameter("GroupSeqNbr", String.class, ParameterMode.IN);
            createClaimProcedure.registerStoredProcedureParameter("GroupLTCID", String.class, ParameterMode.IN);
            createClaimProcedure.registerStoredProcedureParameter("ClaimNumber", String.class, ParameterMode.IN);
            createClaimProcedure.registerStoredProcedureParameter("ClaimStatusCode", String.class, ParameterMode.IN);
            createClaimProcedure.registerStoredProcedureParameter("ClaimSubStatusCode", String.class, ParameterMode.IN);
            createClaimProcedure.registerStoredProcedureParameter("ClaimStatusEffectiveDate", String.class, ParameterMode.IN);
            createClaimProcedure.registerStoredProcedureParameter("ClaimOriginatingSystem", String.class, ParameterMode.IN);
            createClaimProcedure.registerStoredProcedureParameter("CurrentlyProcessedBySystem", String.class, ParameterMode.IN);
            createClaimProcedure.registerStoredProcedureParameter("outClaimNumber", String.class, ParameterMode.INOUT);
            createClaimProcedure.registerStoredProcedureParameter("UserName", String.class, ParameterMode.IN);


            createClaimProcedure.setParameter("LineOfBusinessCode", createClaimRequestParms.getLineOfBusinessCode());

            createClaimProcedure.setParameter("RetailCompanyCode", ltcMaintainClaimUtils.getRetailCompanyCode(createClaimRequestParms));

          *//*  if(ltcMaintainClaimUtils.getRetailPolNo(createClaimRequestParms).trim().length()>0) {
                LoggerHandler.LogOut("INFO", "3", messageUUID, sourceSystemName, this.getClass().getName(),
                        "Inside the IF $$$$$" );
                createClaimProcedure.setParameter("PolNumber", ltcMaintainClaimUtils.getRetailPolNo(createClaimRequestParms));
            }else{
                LoggerHandler.LogOut("INFO", "3", messageUUID, sourceSystemName, this.getClass().getName(),
                        "Inside the ELSE $$$$$" );
                createClaimProcedure.setParameter("PolNumber", "");
            }*//*

            createClaimProcedure.setParameter("PolNumber", ltcMaintainClaimUtils.getRetailPolNo(createClaimRequestParms));

            createClaimProcedure.setParameter("GroupSeqNbr", ltcMaintainClaimUtils.getGroupSqNo(createClaimRequestParms));
            createClaimProcedure.setParameter("GroupLTCID", ltcMaintainClaimUtils.getGroupLTCId(createClaimRequestParms));


            createClaimProcedure.setParameter("ClaimNumber", createClaimRequestParms.getClaimNumber());
            createClaimProcedure.setParameter("ClaimStatusCode", createClaimRequestParms.getClaimStatusCode());
            createClaimProcedure.setParameter("ClaimSubStatusCode", createClaimRequestParms.getClaimSubStatusCode());
            createClaimProcedure.setParameter("ClaimStatusEffectiveDate", ltcMaintainClaimUtils.getXMLCalendarValue(createClaimRequestParms));
            createClaimProcedure.setParameter("ClaimOriginatingSystem", createClaimRequestParms.getClaimOriginatingSystem());
            createClaimProcedure.setParameter("CurrentlyProcessedBySystem", createClaimRequestParms.getCurrentlyProcessedBySystem());
            createClaimProcedure.setParameter("outClaimNumber", createClaimRequestParms.getClaimNumber());
            createClaimProcedure.setParameter("UserName", userID);

            createClaimProcedure.execute();

            String claimNumber = (String) createClaimProcedure.getOutputParameterValue("outClaimNumber");

            createClaimRequestParms.setClaimNumber(claimNumber);
            createClaimResponse.setCreateClaimRequestParms(createClaimRequestParms);

            if (claimNumber.length() > 0) {
                createClaimResponse.setStatusCode("0000");
                createClaimResponse.setStatusDescription("Success");
            } else {
                createClaimResponse.setStatusCode("0100");
                createClaimResponse.setStatusDescription("Failure");
            }
        } catch (QueryTimeoutException e) {
            throw new QueryTimeoutException();

        } catch (DataAccessException e) {
            throw new SQLServerException("Antony", e.getCause());

        } catch (PersistenceException e) {
            throw new com.jh.insurance.ltcmaintainclaim.exception.PersistenceException("Antony", e.getCause());

        } catch (Exception e) {
            throw new TechnicalErrorException(LTCMaintainClaimConstants.TECHNICAL_ERROR_CODE, e.getCause());
        }
        LoggerHandler.LogOut("INFO", "4", messageUUID, sourceSystemName, this.getClass().getName(), loggerUtils.writeAsJson(createClaimResponse));

        return createClaimResponse;
    }*/
}
