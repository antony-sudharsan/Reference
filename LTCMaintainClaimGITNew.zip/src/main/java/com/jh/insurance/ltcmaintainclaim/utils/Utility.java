package com.jh.insurance.ltcmaintainclaim.utils;

import java.io.PrintWriter;
import java.io.StringWriter;

public class Utility {

	public static String getStackTrace(final Throwable t) {
		final StringWriter sw = new StringWriter();
		t.printStackTrace(new PrintWriter(sw));
		return sw.toString();
	}

}
