package com.jh.insurance.ltcmaintainclaim.utils;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import javax.xml.transform.Result;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.ws.soap.SoapHeaderElement;

import com.manulife.esb.xsd.common.jh.header.JHHeader;

/**
 * Utility class to marshall and unmarshall various forms of the JHHeader.
 */
@Component
public class JHHeaderJaxbUtils {

	private static final Logger logger = LoggerFactory.getLogger(JHHeaderJaxbUtils.class);

	// JAXBContext is thread safe so for performance reasons create once.
	private final JAXBContext context;

	public JHHeaderJaxbUtils() {
		try {
			context = JAXBContext.newInstance(JHHeader.class);
		} catch (final JAXBException e) {
			logger.error("Failed Creating JAXBContext for JHHeader ", e);
			throw new RuntimeException(e);
		}
	}

	public void marshallJHHeaderToResult(final JHHeader jhHeader, final Result result) {
		try {
			final Marshaller marshaller = context.createMarshaller();
			marshaller.marshal(jhHeader, result);

		} catch (final JAXBException e) {
			logger.error("Failed marshalling JHHeader to Result", e);
			throw new RuntimeException(e);
		}
	}

	public JHHeader unmarshallJHHeader(final SoapHeaderElement headerElement) {
		JHHeader jhHeader = null;
		try {
			final Unmarshaller unmarshaller = context.createUnmarshaller();
			jhHeader = (JHHeader) unmarshaller.unmarshal(headerElement.getSource());

		} catch (final JAXBException e) {
			logger.error("Failed unmarshalling JHHeader ", e);
			throw new RuntimeException(e);
		}

		return jhHeader;
	}

}
