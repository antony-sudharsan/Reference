/**
 *
 */
package com.jh.insurance.ltcmaintainclaim.controller;

import com.jh.insurance.ltcmaintainclaim.orchestration.LTCMaintainClaimOrchestration;
import com.manulife.esb.xsd.ltc.jh.ltcmaintainclaim.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.jh.common.logging.LoggerHandler;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

/**
 * @author deepain
 */

@Component
@RestController
@EnableSwagger2
public class LTCMaintainClaimController {

    private HttpHeaders responseHeaders = new HttpHeaders();
    private ResponseEntity<Object> responseEntity;

    @Autowired
    LTCMaintainClaimOrchestration ltcMaintainClaimOrchestration;



    @ApiOperation(
            value = "Create Claim",
            notes = "The dao enables you to Create a new Claim number for LTC's group policy or Retail Policy",
            response = CreateClaimResponse.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Success"),
            @ApiResponse(code = 400, message = "Validation Error: Invalid Request"),
            @ApiResponse(code = 404, message = "Downstream system not reacheable"),
            @ApiResponse(code = 204, message = "Claim record could not be created"),
            @ApiResponse(code = 500, message = "Internal Service Error")
    })
    @RequestMapping(value = "/jh/ins/ltc/promise/claim", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Object> createClaim(@RequestHeader("MessageUUID") String messageUUID, @RequestHeader("SourceSystemName") String sourceSystemName, @RequestHeader("UserID") String userID, @RequestBody CreateClaimRequest createClaimRequest) throws Exception {
        CreateClaimRequestParms createClaimRequestParms = null;
        CreateClaimResponse createClaimResponse = null;
        try {

            createClaimResponse = ltcMaintainClaimOrchestration.createClaim(messageUUID, sourceSystemName, userID, createClaimRequest);


            LoggerHandler.LogOut("INFO", "1", messageUUID, sourceSystemName, this.getClass().getName(), createClaimResponse.toString());


            if (createClaimResponse.getCreateClaimRequestParms().getClaimNumber().length() > 0) {
                responseHeaders.clear();
                responseHeaders.add("MessageUUID", messageUUID);
                responseHeaders.add("SourceSystemName", sourceSystemName);
                responseHeaders.add("StatusCode", createClaimResponse.getStatusCode());
                responseHeaders.add("StatusMessage", createClaimResponse.getStatusDescription());
                responseEntity = new ResponseEntity<>(createClaimResponse, responseHeaders, HttpStatus.OK);
            }

            LoggerHandler.LogOut("INFO", "4", messageUUID, sourceSystemName, this.getClass().getName(), createClaimResponse.toString());

            return responseEntity;

        } catch (Exception e) {

            LoggerHandler.ErrorOut(e, messageUUID, sourceSystemName, this.getClass().getName(), createClaimResponse.toString());
            throw e;

        }
    }


    @ApiOperation(
            value = "Update Claim",
            notes = "The dao enables you to Update the claim number of an existing Claim for LTC's group policy or Retail Policy",
            response = UpdateClaimResponse.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Success"),
            @ApiResponse(code = 400, message = "Validation Error: Invalid Request"),
            @ApiResponse(code = 404, message = "Downstream system not reacheable"),
            @ApiResponse(code = 204, message = "Claim record could not be updated"),
            @ApiResponse(code = 500, message = "Internal Service Error")
    })
    @RequestMapping(value = "/jh/ins/ltc/promise/claim", method = RequestMethod.PUT, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Object> updateClaim(@RequestHeader("MessageUUID") String messageUUID, @RequestHeader("SourceSystemName") String sourceSystemName, @RequestHeader("UserID") String userID, @RequestBody UpdateClaimRequest updateClaimRequest) throws Exception {

        UpdateClaimResponse updateClaimResponse = null;
        try {

            updateClaimResponse =  ltcMaintainClaimOrchestration.updateClaim(userID, messageUUID, sourceSystemName, updateClaimRequest);

            LoggerHandler.LogOut("INFO", "1", messageUUID, sourceSystemName, this.getClass().getName(), updateClaimResponse.toString());


            if (updateClaimResponse.getStatusDescription().equals("Success")) {
                responseHeaders.clear();
                responseHeaders.add("MessageUUID", messageUUID);
                responseHeaders.add("SourceSystemName", sourceSystemName);
                responseHeaders.add("StatusCode", updateClaimResponse.getStatusCode());
                responseHeaders.add("StatusMessage", updateClaimResponse.getStatusDescription());
                responseEntity = new ResponseEntity<>(updateClaimResponse, responseHeaders, HttpStatus.OK);
            }

            LoggerHandler.LogOut("INFO", "4", messageUUID, sourceSystemName, this.getClass().getName(), updateClaimResponse.toString());

            return responseEntity;
        } catch (Exception e) {
            LoggerHandler.ErrorOut(e, messageUUID, sourceSystemName, this.getClass().getName(), updateClaimResponse.toString());
            throw e;
        }
    }
}
