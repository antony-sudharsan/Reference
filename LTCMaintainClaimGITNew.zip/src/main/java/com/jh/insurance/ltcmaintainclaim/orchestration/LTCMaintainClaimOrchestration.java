package com.jh.insurance.ltcmaintainclaim.orchestration;

import com.jh.common.logging.LoggerHandler;
import com.jh.insurance.ltcmaintainclaim.dao.CreateClaimDAO;
import com.jh.insurance.ltcmaintainclaim.dao.UpdateClaimDAO;
import com.jh.insurance.ltcmaintainclaim.utils.LoggerUtils;
import com.jh.insurance.ltcmaintainclaim.validator.LTCMaintainClaimValidator;
import com.manulife.esb.wsdl.ltc.jh.ltcmaintainclaim.ltcmaintainclaim.LTCMaintainClaimFault;
import com.manulife.esb.xsd.ltc.jh.ltcmaintainclaim.CreateClaimRequest;
import com.manulife.esb.xsd.ltc.jh.ltcmaintainclaim.CreateClaimResponse;
import com.manulife.esb.xsd.ltc.jh.ltcmaintainclaim.UpdateClaimRequest;
import com.manulife.esb.xsd.ltc.jh.ltcmaintainclaim.UpdateClaimResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;


/**
 * Copyright (c) 2018, John Hancock and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 * <p>
 * Please contact John Hancock, 200 Berkley, Boston, MA 02116 USA
 * or visit https://www.johnhancock.com/legal.html if you need additional information or have any
 * questions.
 */


/**
 * This class consists exclusively methods to expose the methods as RestFull
 * webservices
 *
 * @author Antony Sudharsan Gnanaraj
 * @version %I%, %G%
 * @since 1.0
 */
@Component
public class LTCMaintainClaimOrchestration {


    @Autowired
    CreateClaimDAO createClaimDAO;

    @Autowired
    LoggerUtils loggerUtils;

    @Autowired
    UpdateClaimDAO updateClaimDAO;



    /**
     * @param userID
     * @param messageUUID
     * @param sourceSystemName
     * @param createClaimRequest
     * @return
     * @throws LTCMaintainClaimFault
     */
    public CreateClaimResponse createClaim(String userID, String messageUUID, String sourceSystemName, CreateClaimRequest createClaimRequest) {

        LoggerHandler.LogOut("INFO", "3", messageUUID, sourceSystemName, this.getClass().getName(),
                "Entering Create Claim EndPoint " + loggerUtils.writeAsJson(createClaimRequest));

        CreateClaimResponse createClaimResponse = (CreateClaimResponse) createClaimDAO.createClaim(userID, messageUUID, sourceSystemName, createClaimRequest);
        LoggerHandler.LogOut("INFO", "5", messageUUID, sourceSystemName, this.getClass().getName(),
                "Entering create claim EndPoint " + loggerUtils.writeAsJson(createClaimResponse));
        return createClaimResponse;
    }

    /**
     *
     * @param userID
     * @param messageUUID
     * @param sourceSystemName
     * @param updateClaimRequest
     * @return
     * @throws LTCMaintainClaimFault
     */
    public UpdateClaimResponse updateClaim(String userID, String messageUUID, String sourceSystemName, UpdateClaimRequest updateClaimRequest) {
        LoggerHandler.LogOut("INFO", "3", messageUUID, sourceSystemName, this.getClass().getName(),
                "Entering updateClaim EndPoint " + loggerUtils.writeAsJson(updateClaimRequest));

        UpdateClaimResponse updateClaimResponse =null;
//                UpdateClaimResponse updateClaimResponse = (UpdateClaimResponse) updateClaimDAO.updateClaim(userID, messageUUID, sourceSystemName, updateClaimRequest);
        LoggerHandler.LogOut("INFO", "5", messageUUID, sourceSystemName, this.getClass().getName(),
                "Entering updateClaim EndPoint " + loggerUtils.writeAsJson(updateClaimRequest));
        return updateClaimResponse;
    }

}
