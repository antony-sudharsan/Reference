/**
 *
 */
package com.jh.insurance.ltcmaintainclaim.dao;

//import javax.persistence.*;
//
import com.jh.insurance.ltcmaintainclaim.constants.LTCMaintainClaimConstants;
import com.jh.insurance.ltcmaintainclaim.exception.SQLServerException;
import com.jh.insurance.ltcmaintainclaim.exception.TechnicalErrorException;
import com.jh.insurance.ltcmaintainclaim.utils.LTCMaintainClaimUtils;
import com.manulife.esb.wsdl.ltc.jh.ltcmaintainclaim.ltcmaintainclaim.LTCMaintainClaimFault;
import com.manulife.esb.xsd.common.jh.commonmessage.FaultType;
import com.manulife.esb.xsd.ltc.jh.ltcmaintainclaim.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Component;

import com.jh.common.logging.LoggerHandler;

/**
 * @author deepain
 */
@Component
public class UpdateClaimDAO {

/*
    @PersistenceContext
    private EntityManager entityManager;

    @Autowired
    LTCMaintainClaimUtils ltcMaintainClaimUtils;

    @Value("${LTCMaintainClaim.storedProcedureDetails.updateClaim}")
    private String storeProcedureName;

    private StoredProcedureQuery updateClaimProcedure;


    *//**
     * @param userID
     * @param messageUUID
     * @param sourceSystemName
     * @param updateClaimRequest
     *
     * @return
     *
     * @throws LTCMaintainClaimFault
     *//*
    public UpdateClaimResponse updateClaim(String userID, String messageUUID, String sourceSystemName, UpdateClaimRequest updateClaimRequest) {

        LoggerHandler.LogOut("INFO", "4", messageUUID, sourceSystemName, this.getClass().getName(), updateClaimRequest.toString());
        UpdateClaimRequestParms updateClaimRequestParms = updateClaimRequest.getUpdateClaimRequestParms();
        UpdateClaimResponse updateClaimResponse = new UpdateClaimResponse();
        try {
            updateClaimProcedure = entityManager.createStoredProcedureQuery(storeProcedureName);

            updateClaimProcedure.registerStoredProcedureParameter("LineOfBusinessCode", String.class, ParameterMode.IN);
            updateClaimProcedure.registerStoredProcedureParameter("RetailCompanyCode", String.class, ParameterMode.IN);
            updateClaimProcedure.registerStoredProcedureParameter("PolNumber", String.class, ParameterMode.IN);
            updateClaimProcedure.registerStoredProcedureParameter("GroupSeqNbr", String.class, ParameterMode.IN);
            updateClaimProcedure.registerStoredProcedureParameter("GroupLTCID", String.class, ParameterMode.IN);
            updateClaimProcedure.registerStoredProcedureParameter("NewClaimNumber", String.class, ParameterMode.IN);
            updateClaimProcedure.registerStoredProcedureParameter("CurrentClaimNumber", String.class, ParameterMode.IN);
            updateClaimProcedure.registerStoredProcedureParameter("ClaimStatusCode", String.class, ParameterMode.IN);
            updateClaimProcedure.registerStoredProcedureParameter("ClaimSubStatusCode", String.class, ParameterMode.IN);
            updateClaimProcedure.registerStoredProcedureParameter("ClaimStatusEffectiveDate", String.class, ParameterMode.IN);
            updateClaimProcedure.registerStoredProcedureParameter("ClaimOriginatingSystem", String.class, ParameterMode.IN);
            updateClaimProcedure.registerStoredProcedureParameter("CurrentlyProcessedBySystem", String.class, ParameterMode.IN);
            updateClaimProcedure.registerStoredProcedureParameter("RecUpdated", Integer.class, ParameterMode.INOUT);
            updateClaimProcedure.registerStoredProcedureParameter("UserName", String.class, ParameterMode.IN);

            updateClaimProcedure.setParameter("LineOfBusinessCode", updateClaimRequestParms.getLineOfBusinessCode());
            updateClaimProcedure.setParameter("RetailCompanyCode", ltcMaintainClaimUtils.getRetailCompanyCode(updateClaimRequestParms));
            updateClaimProcedure.setParameter("PolNumber", ltcMaintainClaimUtils.getRetailPolNo(updateClaimRequestParms));
            updateClaimProcedure.setParameter("GroupSeqNbr", ltcMaintainClaimUtils.getGroupSqNo(updateClaimRequestParms));
            updateClaimProcedure.setParameter("GroupLTCID", ltcMaintainClaimUtils.getGroupLTCId(updateClaimRequestParms));
            updateClaimProcedure.setParameter("NewClaimNumber", updateClaimRequestParms.getNewClaimNumber());
            updateClaimProcedure.setParameter("CurrentClaimNumber", updateClaimRequestParms.getCurrentClaimNumber());
            updateClaimProcedure.setParameter("ClaimStatusCode", updateClaimRequestParms.getClaimStatusCode());
            updateClaimProcedure.setParameter("ClaimSubStatusCode", updateClaimRequestParms.getClaimSubStatusCode());
            updateClaimProcedure.setParameter("ClaimStatusEffectiveDate", ltcMaintainClaimUtils.getXMLCalendarValue(updateClaimRequestParms));
            updateClaimProcedure.setParameter("ClaimOriginatingSystem", updateClaimRequestParms.getClaimOriginatingSystem());
            updateClaimProcedure.setParameter("CurrentlyProcessedBySystem", updateClaimRequestParms.getCurrentlyProcessedBySystem());
            updateClaimProcedure.setParameter("RecUpdated", 0);
            updateClaimProcedure.setParameter("UserName", userID);

            updateClaimProcedure.execute();

            int recordUpdated = (int) updateClaimProcedure.getOutputParameterValue("RecUpdated");
            if (recordUpdated > 0) {
                updateClaimResponse.setStatusCode("0000");
                updateClaimResponse.setStatusDescription("Success");
            } else {
                updateClaimResponse.setStatusCode("0100");
                updateClaimResponse.setStatusDescription("Failure");
            }

            updateClaimResponse.setUpdateClaimRequestParms(updateClaimRequestParms);
        } catch (QueryTimeoutException e) {
            throw new QueryTimeoutException();

        } catch (DataAccessException e) {
            throw new SQLServerException("Antony", e.getCause());

        } catch (PersistenceException e) {
            throw new com.jh.insurance.ltcmaintainclaim.exception.PersistenceException("Antony", e.getCause());

        } catch (Exception e) {
            throw new TechnicalErrorException(LTCMaintainClaimConstants.TECHNICAL_ERROR_CODE, e.getCause());
        }
        LoggerHandler.LogOut("INFO", "5", messageUUID, sourceSystemName, this.getClass().getName(), updateClaimResponse.toString());
        return updateClaimResponse;
    }*/

}
