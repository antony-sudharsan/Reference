package com.jh.life.producertwo.utils;
import java.io.StringReader;
import java.util.HashMap;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

public class DataCrossLookUp {

    private static HashMap<String, String> dataset = new HashMap();

    public DataCrossLookUp() {
    }

    public static String init(String xmlstr) {
        if (xmlstr.length() > 0) {
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();

            try {
                DocumentBuilder builder = factory.newDocumentBuilder();
                Document document = builder.parse(new InputSource(new StringReader(xmlstr)));
                Element documentElement = document.getDocumentElement();
                NodeList children = documentElement.getChildNodes();
                Node currentChild = null;

                for(int j = 0; j < children.getLength(); ++j) {
                    currentChild = children.item(j);
                    if (currentChild.getNodeType() == 1) {
                        Element child = (Element)currentChild;
                        NodeList sList = child.getElementsByTagName("ValueMapping");
                        if (sList != null && sList.getLength() > 0) {
                            for(int i = 0; i < sList.getLength(); ++i) {
                                Node node = sList.item(i);
                                if (node.getNodeType() == 1) {
                                    Element e = (Element)node;
                                    NodeList nodeList = e.getElementsByTagName("Key");
                                    String key = nodeList.item(0).getChildNodes().item(0).getNodeValue();
                                    nodeList = e.getElementsByTagName("Value");
                                    String value = nodeList.item(0).getChildNodes().item(0).getNodeValue();
                                    System.out.println(child.getNodeName() + "_" + key +"_"+ value);
                                    dataset.put(child.getNodeName() + "_" + key, value);
                                }
                            }
                        }
                    }
                }
            } catch (Exception var16) {
                System.out.println("exception occured" + var16.getMessage());
            }

            return "Success";
        } else {
            System.out.println("File not exists");
            return "File Does not exists";
        }
    }

    public static String getValue(String name, String key) {

        System.out.println("The value of the Name >>"+name+"<<Key>>"+key);
        return (String)dataset.get(name + "_" + key);
    }
}
