/**
 *
 */
package com.jh.life.producertwo.utils;

import com.jh.life.producertwo.exception.BadRequestException;
import com.manulife.esb.xsd.common.jh.header.JHHeader;
import net.logstash.logback.encoder.org.apache.commons.lang.Validate;
import org.springframework.util.StringUtils;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * Utility methods related to handling the JHHeader.
 */
public class JHHeaderUtils {

    private static final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyddMM-HHmmss");
    private static final String DEFAULT_SOURCE_SYSTEM_NAME = "Unknown";

    public static void validateHeader(final JHHeader header) {
        if ((header == null) || (header.getMessageUID() == null) || (header.getMessageSource() == null)
                || (header.getMessageSource().getApplicationName() == null)) {
            throw new BadRequestException("Invalid Header Sent");
        }
    }

    public static String retrieveOrDefaultMessageUID(final JHHeader header, final String operationName) {
        Validate.notNull(operationName, "operationName can not be null");
        String messageUID = header.getMessageUID();
        if (StringUtils.isEmpty(messageUID)) {
            final LocalDateTime now = LocalDateTime.now();
            messageUID = operationName + now.format(formatter);
        }

        return messageUID;
    }

    public static String retrieveOrDefaultSourceSystemName(final JHHeader header) {
        String sourceSystemName = DEFAULT_SOURCE_SYSTEM_NAME;
        if ((header != null) && (header.getMessageSource() != null)
                && !StringUtils.isEmpty(header.getMessageSource().getApplicationName())) {
            sourceSystemName = header.getMessageSource().getApplicationName();
        }

        return sourceSystemName;
    }
}
