/**
 *
 */
package com.jh.life.producertwo.exception;


import com.jh.life.producertwo.exception.BaseFaultException;

/**
 * Exception for max records.
 */
public class MaxRecordsException extends BaseFaultException {

    private static final long serialVersionUID = -3723020711896654003L;
    private static final String DEFAULT_CODE = "998";
    private static final String DEFAULT_REASON = "%d records found, refine search criteria";
    private static final String DEFAULT_DETAILS = "%d records found, it is greater than user maximum input of %d";
    private static final String FAULT_STRING = "Internal Error";

    public MaxRecordsException(final int recordsFound, final long maxRecords) {
        super(DEFAULT_CODE, String.format(DEFAULT_REASON, recordsFound),
                String.format(DEFAULT_DETAILS, recordsFound, maxRecords), FAULT_STRING);
    }

}
