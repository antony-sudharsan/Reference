package com.jh.life.producertwo.mapper;

import com.jh.common.logging.LoggerHandler;
import com.jh.life.producertwo.constants.ProducerConstants;
import com.jh.life.producertwo.model.GetProducerResponseWrapper;
import com.jh.life.producertwo.utils.ProducerUtils;
import com.manulife.esb.xsd.common.jh.header.JHHeader;
import com.manulife.esb.xsd.common.jh.header.Status;
import com.manulife.esb.xsd.life.jh.producer.CheckLicenseStatusResponse;
import com.manulife.esb.xsd.life.jh.producer.GetProducerResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.math.BigInteger;
import java.sql.CallableStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

/**
 * The type Get producer data mapper.
 */
@Component
public class GetProducerDataMapper {

    /**
     * The Producer utils.
     */
    @Autowired
    ProducerUtils producerUtils;


    /**
     * Gets producer mapper.
     *
     * @param jhHeader         the jh header
     * @param messageUUID      the message uuid
     * @param sourceSystemName the source system name
     * @param resultset        the resultset
     *
     * @return producer mapper
     *
     * @throws SQLException the sql exception
     */
    public GetProducerResponseWrapper getProducerMapper(JHHeader jhHeader, String messageUUID, String sourceSystemName, CallableStatement resultset) throws SQLException {

        GetProducerResponseWrapper reply = new GetProducerResponseWrapper();
        GetProducerResponse getProducerResponse = new GetProducerResponse();
        GetProducerResponse.Party party = new GetProducerResponse.Party();
        GetProducerResponse.Party.GovtIDTC govtIDTC = new GetProducerResponse.Party.GovtIDTC();
        GetProducerResponse.Party.Person person = new GetProducerResponse.Party.Person();
        GetProducerResponse.Party.Producer producer = new GetProducerResponse.Party.Producer();

        List<GetProducerResponse.Party.Producer.AgencyAffiliation> agencyAffiliation = new ArrayList<>();
        String errCode = null;

        LoggerHandler.LogOut("INFO", "2", messageUUID, sourceSystemName, this.getClass().getName(),
                "Mapping the Result Set");
        if (resultset != null) {


            errCode = resultset.getString("OUT_ERR_CD");


            if (errCode != null && errCode.equals("0100")) {
                party.setPartyTypeCode("");
                party.setFullName("");
                reply.setErrCode(errCode);
            } else {
                String partyTypeCode = resultset.getString("OUT_PRDCR_TYP");
                String firstName = resultset.getString("OUT_PRDCR_FRST_NM");
                String lastName = resultset.getString("OUT_PRDCR_LAST_NM");
                String prodIdNo = resultset.getString("OUT_PRDCR_ID_NO");
                String agencyCode = resultset.getString("OUT_AGY_CD");
                String prodStatusCode = resultset.getString("OUT_PRDCR_STTS_CD");
                String jitStatus = resultset.getString("OUT_JIT_STATUS");
                party.setPartyTypeCode(partyTypeCode);


                if (partyTypeCode.equals("1")) {
                    party.setFullName(String.join(" ", firstName, lastName));
                } else {
                    party.setFullName(firstName);
                }

                if (partyTypeCode.equals("87286") || partyTypeCode.equals("92856")) {
                    party.setGovtID(prodIdNo);
                } else {
                    party.setGovtID("");
                }

                if (partyTypeCode.equals("87286")) {
                    govtIDTC.setTc(BigInteger.valueOf(1));
                } else if (partyTypeCode.equals("92856")) {
                    govtIDTC.setTc(BigInteger.valueOf(2));
                }
                if (partyTypeCode.equals("1")) {
                    person.setFirstName(firstName);
                    person.setLastName(lastName);
                }

                if (partyTypeCode.equals("94560") && prodIdNo != null) {
                    producer.setNIPRNumber(Integer.parseInt(prodIdNo));
                }

                if (partyTypeCode.equals("87287") && prodIdNo != null) {
                    producer.setJHPayrollNumber(Integer.parseInt(prodIdNo));
                }

                if (agencyCode != null && agencyCode.length() > 0 && errCode.equals("0119")) {
                    producer.setJHAgencyNumber(new BigInteger(agencyCode));
                }

                if (errCode != null && errCode.equals("0110")) {
                    producer.setLARSProducerStatus(BigInteger.valueOf(1000000000));
                } else if (prodStatusCode.equals("Unknown")) {
                    producer.setLARSProducerStatus(BigInteger.valueOf(0));
                } else if (prodStatusCode.equals("Active")) {
                    producer.setLARSProducerStatus(BigInteger.valueOf(1));
                } else if (prodStatusCode.equals("Inactive")) {
                    producer.setLARSProducerStatus(BigInteger.valueOf(2));
                } else if (prodStatusCode.equals("Pending")) {
                    producer.setLARSProducerStatus(BigInteger.valueOf(3));
                }

                if (jitStatus.equals("Yes")) {
                    producer.setJITInd(true);
                } else {
                    producer.setJITInd(false);
                }
                reply.setErrCode("0000");
            }
        }
        party.setGovtIDTC(govtIDTC);
        party.setPerson(person);
        party.setProducer(producer);
        getProducerResponse.setParty(party);

//        System.out.println("Value in the Mapper %%%%%%%%" + reply.getErrCode());

        reply.setHeader(mapStatusHeader(jhHeader, errCode));
        reply.setGetProducerResponse(getProducerResponse);

        return reply;
    }

    /**
     * Map producer affln get producer response.
     *
     * @param callableStatement   the callable statement
     * @param getProducerResponse the get producer response
     *
     * @return get producer response
     *
     * @throws SQLException the sql exception
     */
    public GetProducerResponse mapProducerAffln(CallableStatement callableStatement, GetProducerResponse getProducerResponse) throws SQLException {

        List<GetProducerResponse.Party.Producer.AgencyAffiliation> agencyAffiliationList = new ArrayList<>();
        GetProducerResponse.Party.Producer.AgencyAffiliation agencyAffiliation = null;


        if(callableStatement != null) {

            ResultSet rs = (ResultSet) callableStatement.getObject("OUT_AFFIL_CSR");

            for (int i = 0; i < agencyAffiliationList.size(); i++) {

                agencyAffiliation = new GetProducerResponse.Party.Producer.AgencyAffiliation();
                agencyAffiliation.setJHAgencyNumber(new BigInteger(rs.getString(1))); /// AFFIL_SNS_ORG_NO
                agencyAffiliation.setFullName(rs.getString(2)); // AFFIL_ORG_NM

                String affilPartyInd = rs.getString(3);
                if (affilPartyInd.equals("N")) {
                    agencyAffiliation.setContractStatus("Inactive"); // AFFIL_PARTY_IND
                } else {
                    agencyAffiliation.setContractStatus("Active"); // AFFIL_PARTY_IND
                }
                agencyAffiliation.setContractStatus(rs.getString(3)); // AFFIL_PARTY_IND
                agencyAffiliationList.add(agencyAffiliation);
            }
        }
        getProducerResponse.getParty().getProducer().setAgencyAffiliation(agencyAffiliationList);
        return getProducerResponse;
    }


    /**
     *
     * @param jhHeader
     * @param errorCode
     * @return
     */
    private JHHeader mapStatusHeader(JHHeader jhHeader, String errorCode) {
        String statusCode = null;
        String statusDescription = null;
        Status status = jhHeader.getStatus();

        if(errorCode != null) {

            if (errorCode.equals("0")) {
                statusCode = "0000";
                statusDescription = ProducerConstants.LICENSE_SUCESS_MSG;
            } else if (errorCode.equals("0100")) {
                statusCode = "0100";
                statusDescription =ProducerConstants.PROD_NO_MATCH_FOUND;
            } else if (errorCode.equals("0119")) {
                statusCode = "0119";
                statusDescription = ProducerConstants.PROD_ORG_MULTIPLE_AGENCY;
            } else if (errorCode.equals("0219")) {
                statusCode = "0219";
                statusDescription = ProducerConstants.PROD_ORG_NO_AGENCY;
            } else if (errorCode.equals("0130")) {
                statusCode = "0100";
                statusDescription = ProducerConstants.PROD_NO_AFILLATION;
            } else if (errorCode.equals("0140")) {
                statusCode = "0100";
                statusDescription = ProducerConstants.PROD_PAYROLL_NOT_ACTIVE;
            } else if (errorCode.equals("0130")) {
                statusCode = "0100";
                statusDescription = ProducerConstants.PROD_NO_AFILLATION;
            } else {
                statusCode = "0000";
                statusDescription = ProducerConstants.PROD_SUCCESS;
            }
        }else{
            statusCode = "0000";
            statusDescription = "Success";
        }

        status.setStatusCode(statusCode);
        status.setStatusDescription(statusDescription);
        jhHeader.setStatus(status);
        return jhHeader;
    }

}
