package com.jh.life.producertwo.dao;

import com.jh.common.logging.LoggerHandler;
import com.jh.life.producertwo.mapper.CheckLicenceStatusMapper;
import com.jh.life.producertwo.mapper.GetProducerDataMapper;
import com.jh.life.producertwo.model.CheckLicenseStatusResponseWrapper;
import com.jh.life.producertwo.model.GetProducerResponseWrapper;
import com.jh.life.producertwo.model.LicenseCheckIn;
import com.jh.life.producertwo.model.ProducerStatusIn;
import com.jh.life.producertwo.utils.LoggerUtils;
import com.jh.life.producertwo.utils.LoggingContextHolder;
import com.manulife.esb.xsd.common.jh.header.JHHeader;
import com.manulife.esb.xsd.life.jh.producer.CheckLicenseStatusResponse;
import com.manulife.esb.xsd.life.jh.producer.GetProducerResponse;
import oracle.jdbc.driver.OracleTypes;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.sql.CallableStatement;
import java.sql.SQLException;

/**
 * The type Producer dao.
 */
@Component
public class ProducerDAO {


    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Autowired
    private LoggerUtils loggerUtils;

    @Value("${RequestTimeoutLimit:10000}")
    private int requestTimeoutLimit;

    /**
     * The Check licence status mapper.
     */
    @Autowired
    CheckLicenceStatusMapper checkLicenceStatusMapper;

    /**
     * The Get producer data mapper.
     */
    @Autowired
    GetProducerDataMapper getProducerDataMapper;

    /**
     * Init.
     */
    @PostConstruct
    public void init() {
        if (requestTimeoutLimit != 0) {
            this.jdbcTemplate.setQueryTimeout(requestTimeoutLimit);
        }
    }

    /**
     * Gets license status.
     *
     * @param header  the header
     * @param request the request
     *
     * @return the license status
     *
     * @throws SQLException the sql exception
     */
    public CheckLicenseStatusResponseWrapper getLicenseStatus(JHHeader header, LicenseCheckIn request) throws SQLException {

        final String messageUUID = LoggingContextHolder.getLoggingContext().getMessageUUID();
        final String sourceSystemName = LoggingContextHolder.getLoggingContext().getSourceSystemName();

        CheckLicenseStatusResponseWrapper reply = new CheckLicenseStatusResponseWrapper();

        CheckLicenseStatusResponse checkLicenseStatusResponse = new CheckLicenseStatusResponse();

        LoggerHandler.LogOut("INFO", "3", messageUUID, sourceSystemName, this.getClass().getName(),
                "Entering getLicenseStatus  " + loggerUtils.writeAsJson(request));


        CallableStatement callableStatement = jdbcTemplate.getDataSource().getConnection().prepareCall("{call lars_owner.PKG_LICENSE_CHECK_WRAPPER.LICENSE_CHECK_WRAPPER_PROC(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}");

        callableStatement.setString("P1_PRODUCER_ID_NO", request.getP1ProducerIdNo());
        callableStatement.setString("P1_PRODUCER_ID_TYP", request.getP1ProducerIdType());
        callableStatement.setString("P1_ORG_ID_NO", request.getP1OrgIdNo());
        callableStatement.setString("P1_ORG_ID_TYP_CD", request.getP1OrgIdTypCd());
        callableStatement.setString("P1_PSTL_JURS_CD_APP", request.getP1PstlJursCdApp());
        callableStatement.setDouble("P1_PSTL_JURS_CD_RESI", request.getP1PstlJursCdResi());
        callableStatement.setDouble("P1_PRD_TYP_CD", request.getP1PrdTypCd());
        callableStatement.setDouble("P1_MANUF_INS_CO_CD", request.getP1ManufInsCoCd());
        callableStatement.setString("P1_TRANSACTION_DT", request.getP1TransactionDt());
        callableStatement.setString("P1_APPL_SUB_DT", request.getP1ApplSubDt());
        callableStatement.setDouble("P1_SRC_SYSTEM_ID_NO", request.getP1SrcSystemIdNo());
        callableStatement.setString("P1_SUB_REF_NO", request.getP1SubRefNo());
        callableStatement.setString("P1_USER_INFO", request.getP1UserInfo());

        callableStatement.registerOutParameter("P1_SUCCESS", OracleTypes.NUMBER);
        callableStatement.registerOutParameter("P1_SQL_ERRC", OracleTypes.NUMBER);
        callableStatement.registerOutParameter("P1_SQL_ERRM", OracleTypes.VARCHAR);
        callableStatement.registerOutParameter("P1_LARS_RETN_CD", OracleTypes.NUMBER);
        callableStatement.registerOutParameter("P1_LARS_ERR_CD", OracleTypes.VARCHAR);
        callableStatement.registerOutParameter("P1_LARS_ERR_MESG", OracleTypes.VARCHAR);
        callableStatement.registerOutParameter("P1_CODE_VALUE_CSR", OracleTypes.CURSOR);

        callableStatement.executeUpdate();

        reply = checkLicenceStatusMapper.getLicenseStatusDetails(header, messageUUID, sourceSystemName, callableStatement);


        LoggerHandler.LogOut("INFO", "6", messageUUID, sourceSystemName, this.getClass().getName(),
                "Exiting getLicenseStatus " + loggerUtils.writeAsJson(reply));


        return reply;
    }


    /**
     * Check producer status get producer response wrapper.
     *
     * @param header  the header
     * @param request the request
     *
     * @return the get producer response wrapper
     *
     * @throws SQLException the sql exception
     */
    public GetProducerResponseWrapper checkProducerStatus(JHHeader header,  ProducerStatusIn request) throws SQLException {

        final String messageUUID = LoggingContextHolder.getLoggingContext().getMessageUUID();
        final String sourceSystemName = LoggingContextHolder.getLoggingContext().getSourceSystemName();

        LoggerHandler.LogOut("INFO", "3", messageUUID, sourceSystemName, this.getClass().getName(),
                "Entering chekProducerStatus " + loggerUtils.writeAsJson(request));

        GetProducerResponseWrapper getProducerResponseWrapper = new GetProducerResponseWrapper();
        CallableStatement callableStatement = jdbcTemplate.getDataSource().getConnection().prepareCall("{call PKG_LTC_CAPTIVATE.USP_PRODUCER_STATUS(?,?,?,?,?,?,?,?,?,?,?,?)}");

        callableStatement.setString("IN_PRODUCER_ID_TYP", request.getInProducerIdTyp());
        callableStatement.setString("IN_PRODUCER_ID_NO", request.getInProducerIdNo());

        callableStatement.registerOutParameter("OUT_PRDCR_FRST_NM", OracleTypes.VARCHAR);
        callableStatement.registerOutParameter("OUT_PRDCR_LAST_NM", OracleTypes.VARCHAR);
        callableStatement.registerOutParameter("OUT_PRDCR_TYP", OracleTypes.NUMBER);
        callableStatement.registerOutParameter("OUT_PRDCR_STTS_CD", OracleTypes.VARCHAR);
        callableStatement.registerOutParameter("OUT_PRDCR_ID_TYP", OracleTypes.NUMBER);
        callableStatement.registerOutParameter("OUT_PRDCR_ID_NO", OracleTypes.VARCHAR);
        callableStatement.registerOutParameter("OUT_ERR_CD", OracleTypes.VARCHAR);
        callableStatement.registerOutParameter("OUT_ERR_MSG", OracleTypes.VARCHAR);
        callableStatement.registerOutParameter("OUT_JIT_STATUS", OracleTypes.VARCHAR);
        callableStatement.registerOutParameter("OUT_AGY_CD", OracleTypes.VARCHAR);

        callableStatement.executeUpdate();

        getProducerResponseWrapper = getProducerDataMapper.getProducerMapper(header, messageUUID, sourceSystemName, callableStatement);

        LoggerHandler.LogOut("INFO", "3", messageUUID, sourceSystemName, this.getClass().getName(),
                "Exiting chekProducerStatus " + loggerUtils.writeAsJson(getProducerResponseWrapper));
        return getProducerResponseWrapper;
    }


    /**
     * Check producer affln get producer response.
     *
     * @param request the request
     * @param reply   the reply
     *
     * @return the get producer response
     *
     * @throws SQLException the sql exception
     */
    public GetProducerResponse checkProducerAffln(final ProducerStatusIn request, GetProducerResponse reply) throws SQLException {

        final String messageUUID = LoggingContextHolder.getLoggingContext().getMessageUUID();
        final String sourceSystemName = LoggingContextHolder.getLoggingContext().getSourceSystemName();

        LoggerHandler.LogOut("INFO", "3a", messageUUID, sourceSystemName, this.getClass().getName(),
                "Entering checkProducerAffln " + loggerUtils.writeAsJson(request));

        CallableStatement callableStatement = jdbcTemplate.getDataSource().getConnection().prepareCall("call PKG_LTC_CAPTIVATE.USP_PRODUCER_AFFLN(?,?,?,?,?,?,?,?,?,?)");


        callableStatement.setString("IN_PRDCR_ID_TYP", request.getInProducerIdTyp());
        callableStatement.setString("IN_PRDCR_ID_NO", request.getInProducerIdNo());

        callableStatement.registerOutParameter("OUT_PRDCR_ID_TYP", OracleTypes.NUMBER);
        callableStatement.registerOutParameter("OUT_PRDCR_ID_NO", OracleTypes.VARCHAR);
        callableStatement.registerOutParameter("OUT_PRDCR_FRST_NM", OracleTypes.VARCHAR);
        callableStatement.registerOutParameter("OUT_PRDCR_LAST_NM", OracleTypes.VARCHAR);
        callableStatement.registerOutParameter("OUT_PRDCR_TYP", OracleTypes.NUMBER);
        callableStatement.registerOutParameter("OUT_ERR_CD", OracleTypes.VARCHAR);
        callableStatement.registerOutParameter("OUT_ERR_MSG", OracleTypes.VARCHAR);
        callableStatement.registerOutParameter("OUT_AFFIL_CSR", OracleTypes.CURSOR);

        callableStatement.executeUpdate();

        reply = getProducerDataMapper.mapProducerAffln(callableStatement, reply);

        LoggerHandler.LogOut("INFO", "3", messageUUID, sourceSystemName, this.getClass().getName(),
                "Exiting checkProducerAffln " + loggerUtils.writeAsJson(reply));
        return reply;
    }


}
