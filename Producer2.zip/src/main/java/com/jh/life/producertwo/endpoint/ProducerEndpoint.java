package com.jh.life.producertwo.endpoint;

import com.jh.common.logging.LoggerHandler;
import com.jh.life.producertwo.exception.BadRequestException;
import com.jh.life.producertwo.model.CheckLicenseStatusResponseWrapper;
import com.jh.life.producertwo.model.GetProducerResponseWrapper;
import com.jh.life.producertwo.orchestration.ProducerOrchestration;
import com.jh.life.producertwo.utils.*;
import com.manulife.esb.wsdl.life.jh.producer.producer_2.GetProducerFault;
import com.manulife.esb.xsd.common.jh.header.JHHeader;
import com.manulife.esb.xsd.life.jh.producer.CheckLicenseStatusRequest;
import com.manulife.esb.xsd.life.jh.producer.CheckLicenseStatusResponse;
import com.manulife.esb.xsd.life.jh.producer.GetProducerRequest;
import com.manulife.esb.xsd.life.jh.producer.GetProducerResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ws.context.MessageContext;
import org.springframework.ws.server.endpoint.annotation.Endpoint;
import org.springframework.ws.server.endpoint.annotation.PayloadRoot;
import org.springframework.ws.server.endpoint.annotation.RequestPayload;
import org.springframework.ws.server.endpoint.annotation.ResponsePayload;
import org.springframework.ws.soap.SoapHeaderElement;
import org.springframework.ws.soap.server.endpoint.annotation.SoapHeader;

import java.sql.SQLException;

/**
 * Exposes Producer2Application Operations via SOAP.
 */
@Endpoint
public class ProducerEndpoint {
    private static final String NAMESPACE_URI = "http://www.esb.manulife.com/xsd/Life/jh/Producer";

    private static final String JH_HEADER_NS = "http://www.esb.manulife.com/xsd/common/jh/header";

    private final JHHeaderJaxbUtils jhHeaderJaxbUtils;
    private final LoggerUtils loggerUtils;
    /**
     * The Producer orchestration.
     */
    final ProducerOrchestration producerOrchestration;

    /**
     * Instantiates a new Producer endpoint.
     *
     * @param producerOrchestration the producer orchestration
     * @param jhHeaderJaxbUtils     the jh header jaxb utils
     * @param loggerUtils           the logger utils
     */
    @Autowired
    public ProducerEndpoint(final ProducerOrchestration producerOrchestration,
                            final JHHeaderJaxbUtils jhHeaderJaxbUtils, final LoggerUtils loggerUtils) {
        this.producerOrchestration = producerOrchestration;
        this.jhHeaderJaxbUtils = jhHeaderJaxbUtils;
        this.loggerUtils = loggerUtils;
    }

    /**
     * Check license status check license status response.
     *
     * @param request         the request
     * @param jhHeaderElement the jh header element
     * @param messageContext  the message context
     *
     * @return the check license status response
     *
     * @throws GetProducerFault the get producer fault
     * @throws Exception        the exception
     */
    @PayloadRoot(namespace = NAMESPACE_URI, localPart = "CheckLicenseStatus_request")
    @ResponsePayload
    public CheckLicenseStatusResponse checkLicenseStatus(final @RequestPayload CheckLicenseStatusRequest request,
                                                         final @SoapHeader("{" + JH_HEADER_NS + "}JHHeader") SoapHeaderElement jhHeaderElement,
                                                         final MessageContext messageContext) throws GetProducerFault,Exception {
        CheckLicenseStatusResponse reply = null;
        JHHeader header = parseHeader(jhHeaderElement);
        JHHeaderUtils.validateHeader(header);

        final String messageUUID = JHHeaderUtils.retrieveOrDefaultMessageUID(header, "CheckLicenseStatus");
        final String sourceSystemName = JHHeaderUtils.retrieveOrDefaultSourceSystemName(header);

        try {
            LoggingContextHolder.getLoggingContext().setContext(messageUUID, sourceSystemName);
            LoggerHandler.LogOut("INFO", "1", messageUUID, sourceSystemName, this.getClass().getName(),
                    "Entering checkLicenseStatus EndPoint " + loggerUtils.writeAsJson(request));

            CheckLicenseStatusResponseWrapper checkLicenseStatusResponseWrapper = producerOrchestration.checkLicenseStatus(header, request);

            reply = checkLicenseStatusResponseWrapper.getCheckLicenseStatusResponse();
            header = checkLicenseStatusResponseWrapper.getHeader();
            LoggerHandler.LogOut("INFO", "8", messageUUID, sourceSystemName, this.getClass().getName(),
                    "Exiting checkLicenseStatus EndPoint " + loggerUtils.writeAsJson(reply));

        } catch (final Exception e) {
            LoggerHandler.ErrorOut(e, messageUUID, sourceSystemName, this.getClass().getName(), e.getMessage());
            throw e;
        }

        // add response header as a property to be used by EndpointInterceptor
        // Current service does not modify header on response
        messageContext.setProperty(HeaderKey.JH_HEADER_KEY.getValue(), header);
        LoggingContextHolder.getLoggingContext().clear();

        return reply;
    }


    /**
     * Gets producer.
     *
     * @param request         the request
     * @param jhHeaderElement the jh header element
     * @param messageContext  the message context
     *
     * @return the producer
     *
     * @throws GetProducerFault the get producer fault
     * @throws Exception        the exception
     */
    @PayloadRoot(namespace = NAMESPACE_URI, localPart = "GetProducer_request")
    @ResponsePayload
    public GetProducerResponse getProducer(final @RequestPayload GetProducerRequest request,
                                           final @SoapHeader("{" + JH_HEADER_NS + "}JHHeader") SoapHeaderElement jhHeaderElement,
                                           final MessageContext messageContext) throws GetProducerFault, Exception {

        GetProducerResponse reply = null;
        JHHeader header = parseHeader(jhHeaderElement);
        JHHeaderUtils.validateHeader(header);

        final String messageUUID = JHHeaderUtils.retrieveOrDefaultMessageUID(header, "GetProducer");
        final String sourceSystemName = JHHeaderUtils.retrieveOrDefaultSourceSystemName(header);

        try {
            LoggingContextHolder.getLoggingContext().setContext(messageUUID, sourceSystemName);
            LoggerHandler.LogOut("INFO", "1", messageUUID, sourceSystemName, this.getClass().getName(),
                    "Entering getProducer EndPoint " + loggerUtils.writeAsJson(request));

            GetProducerResponseWrapper getProducerResponseWrapper = producerOrchestration.getProducer(header, request);

            reply = getProducerResponseWrapper.getGetProducerResponse();

            header = getProducerResponseWrapper.getHeader();

            LoggerHandler.LogOut("INFO", "5", messageUUID, sourceSystemName, this.getClass().getName(),
                    "Exiting getProducer EndPoint " + loggerUtils.writeAsJson(reply));
        } catch ( Exception e) {
            LoggerHandler.ErrorOut(e, messageUUID, sourceSystemName, this.getClass().getName(), e.getMessage());
            throw e;
        }

        // add response header as a property to be used by EndpointInterceptor
        // Current service does not modify header on response
        messageContext.setProperty(HeaderKey.JH_HEADER_KEY.getValue(), header);
        LoggingContextHolder.getLoggingContext().clear();

        return reply;
    }



    private JHHeader parseHeader(final SoapHeaderElement jhHeaderElement) {
        // parse JH Header if present
        JHHeader header = null;
        if (null != jhHeaderElement) {
            header = jhHeaderJaxbUtils.unmarshallJHHeader(jhHeaderElement);
        } else {
            throw new BadRequestException("Missing Header");
        }

        return header;
    }

}