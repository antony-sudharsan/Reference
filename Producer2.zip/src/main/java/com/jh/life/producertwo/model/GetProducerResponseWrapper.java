package com.jh.life.producertwo.model;

import com.manulife.esb.xsd.common.jh.header.JHHeader;
import com.manulife.esb.xsd.life.jh.producer.GetProducerResponse;

/**
 * The type Get producer response wrapper.
 */
public class GetProducerResponseWrapper {

    private JHHeader header;
    private GetProducerResponse getProducerResponse;

    private String errCode;

    /**
     * Gets err code.
     *
     * @return the err code
     */
    public String getErrCode() {
        return errCode;
    }

    /**
     * Sets err code.
     *
     * @param errCode the err code
     */
    public void setErrCode(String errCode) {
        this.errCode = errCode;
    }


    /**
     * Gets header.
     *
     * @return the header
     */
    public JHHeader getHeader() {
        return header;
    }

    /**
     * Sets header.
     *
     * @param header the header
     */
    public void setHeader(JHHeader header) {
        this.header = header;
    }

    /**
     * Gets get producer response.
     *
     * @return the get producer response
     */
    public GetProducerResponse getGetProducerResponse() {
        return getProducerResponse;
    }

    /**
     * Sets get producer response.
     *
     * @param getProducerResponse the get producer response
     */
    public void setGetProducerResponse(GetProducerResponse getProducerResponse) {
        this.getProducerResponse = getProducerResponse;
    }
}
