package com.jh.life.producertwo.constants;

public class ProducerConstants {

    // ####### Error Messages #####################

    public static String TECHNICAL_ERROR_REASON = "Technical Error";
    public static String INVALID_INPUT_ERROR_REASON = "Invalid Input";
    public static String TIMEOUT_ERROR_REASON = "Service Timedout";
    public static String NO_RECORD_FOUND_ERROR_REASON = "No Data Found";
    public static String MAX_RECORD_ERROR_REASON = "Max Result Limit Encountered";

    public static String LICENSE_SUCESS_MSG = "Success - Producer2Application Licensed to Sell";
    public static String LICENSE_NOT_FOUND = "Producer2Application not found in LARS";
    public static String LICENSE_ORG_NOT_FOUND =  "Organization ID not found in LARS";
    public static String LICENSE_ERROR = "LARS System error occurred";
    public static String LICENSE_INVALID_SYS = "Invalid Source System";
    public static String LICENSE_INVALID_REQ = "Invalid Request";
    public static String LICENSE_DISPUTE= "Producer2Application licence dispute";
    public static String PROD_NO_MATCH_FOUND = "No Match Found for Specific Identifier";
    public static String PROD_ORG_MULTIPLE_AGENCY = "Organization has multiple Agency codes";
    public static String PROD_ORG_NO_AGENCY = "Organization has no Agency code";
    public static String PROD_NO_AFILLATION = "No Affiliation found";
    public static String PROD_PAYROLL_NOT_ACTIVE = "Payroll number or Contract not active";
    public static String PROD_SUCCESS ="Success";
    // ####### Error Codes #####################

    public static String TECHNICAL_ERROR_CODE = "9999";
    public static String INVALID_INPUT_ERROR_CODE = "993";
    public static String TIMEOUT_ERROR_CODE = "99999";
    public static String NO_RECORD_FOUND_ERROR_CODE = "999";
    public static String MAX_RECORD_ERROR_CODE = "998";

    // ### Queries ##############################


    public ProducerConstants() {
    }
}
