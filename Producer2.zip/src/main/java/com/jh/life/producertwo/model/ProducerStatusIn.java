package com.jh.life.producertwo.model;

/**
 * The type Producer status in.
 */
public class ProducerStatusIn {

	/**
	 * The In producer id typ.
	 */
	String inProducerIdTyp =null;
	/**
	 * The In producer id no.
	 */
	String inProducerIdNo =null;

	/**
	 * Gets in producer id typ.
	 *
	 * @return the in producer id typ
	 */
	public String getInProducerIdTyp() {
		return inProducerIdTyp;
	}

	/**
	 * Sets in producer id typ.
	 *
	 * @param string the string
	 */
	public void setInProducerIdTyp(String string) {
		inProducerIdTyp = string;
	}

	/**
	 * Gets in producer id no.
	 *
	 * @return the in producer id no
	 */
	public String getInProducerIdNo() {
		return inProducerIdNo;
	}

	/**
	 * Sets in producer id no.
	 *
	 * @param iN_PRODUCER_ID_NO the n producer id no
	 */
	public void setInProducerIdNo(String iN_PRODUCER_ID_NO) {
		inProducerIdNo = iN_PRODUCER_ID_NO;
	}
	

}
