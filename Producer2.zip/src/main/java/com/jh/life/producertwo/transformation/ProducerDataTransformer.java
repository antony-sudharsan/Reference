package com.jh.life.producertwo.transformation;

import com.jh.common.utility.DataMappingCrossLookUp;
import com.jh.life.producertwo.model.LicenseCheckIn;
import com.jh.life.producertwo.model.ProducerStatusIn;
import com.jh.life.producertwo.utils.DataCrossLookUp;
import com.jh.life.producertwo.utils.ProducerUtils;
import com.manulife.esb.xsd.common.jh.header.JHHeader;
import com.manulife.esb.xsd.life.jh.producer.CheckLicenseStatusRequest;
import com.manulife.esb.xsd.life.jh.producer.GetProducerRequest;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.xml.datatype.XMLGregorianCalendar;
import java.math.BigInteger;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * The type Producer data transformer.
 */
@Component
public class ProducerDataTransformer {


    /**
     * The Producer utils.
     */
    @Autowired
    ProducerUtils producerUtils;

    /**
     * Gets license status request.
     *
     * @param request the request
     * @param header  the header
     *
     * @return the license status request
     */
    public LicenseCheckIn getLicenseStatusRequest( CheckLicenseStatusRequest request,  JHHeader header) {
        LicenseCheckIn licenseCheckIn = new LicenseCheckIn();

        if (StringUtils.length(request.getPartyIds().getGovtID())>0) {
            BigInteger TCCode1 = new BigInteger("1");
            BigInteger TCCode2 = new BigInteger("2");
            if ((request.getPartyIds().getGovtIDTC().getTc() == TCCode1) || (request.getPartyIds().getGovtIDTC().getTc() == TCCode2)) {
//                licenseCheckIn.setP1ProducerIdType(DataMappingCrossLookUp.getValue("PRODUCERIDNO", "87286"));
                licenseCheckIn.setP1ProducerIdType(DataMappingCrossLookUp.getValue("PRODUCERIDNO", "SSN"));
            } else {
                licenseCheckIn.setP1ProducerIdType("");
            }
            licenseCheckIn.setP1ProducerIdNo(request.getPartyIds().getGovtID());
        }

        if (StringUtils.length(request.getPartyIds().getGovtID()) ==0 && StringUtils.length(String.valueOf(request.getProducerIds2().getJHPayrollNumber()))  > 0) {
//            licenseCheckIn.setP1ProducerIdType(DataMappingCrossLookUp.getValue("PRODUCERIDNO", "87287"));
//            licenseCheckIn.setP1ProducerIdType("87287");
            licenseCheckIn.setP1ProducerIdType(DataMappingCrossLookUp.getValue("PRODUCERIDNO","PAYROLL"));
            licenseCheckIn.setP1ProducerIdNo(String.valueOf(request.getProducerIds2().getJHPayrollNumber()));
        }

        if (StringUtils.length(request.getPartyIds().getGovtID()) ==0 && StringUtils.length(String.valueOf(request.getProducerIds2().getJHPayrollNumber()))  ==0  && StringUtils.length(request.getProducerIds2().getAYProducerID()) > 0) {
//            licenseCheckIn.setP1ProducerIdType(DataMappingCrossLookUp.getValue("PRODUCERIDNO", "92854"));
//            licenseCheckIn.setP1ProducerIdType("92854");
            licenseCheckIn.setP1ProducerIdType(DataMappingCrossLookUp.getValue("PRODUCERIDNO","CODENUMBER"));
            licenseCheckIn.setP1ProducerIdNo(String.valueOf(request.getProducerIds2().getAYProducerID()));
        }

        licenseCheckIn.setP1OrgIdNo(request.getProducerIds2().getCompanyProducerID());


// CompanyProducerIDJHTC


        if (request.getProducerIds2().getCompanyProducerIDJHTC().intValue() ==1) {
            licenseCheckIn.setP1OrgIdTypCd(DataMappingCrossLookUp.getValue("ORGIDTYPCD", "AGENCYCODE"));
//            licenseCheckIn.setP1OrgIdTypCd("90302");

        } else if (request.getProducerIds2().getCompanyProducerIDJHTC().intValue() ==2) {
            licenseCheckIn.setP1OrgIdTypCd(DataMappingCrossLookUp.getValue("ORGIDTYPCD", "PARENTCODE"));
//            licenseCheckIn.setP1OrgIdTypCd("92855");
        } else if (request.getProducerIds2().getCompanyProducerIDJHTC().intValue() ==3) {
            licenseCheckIn.setP1OrgIdTypCd(DataMappingCrossLookUp.getValue("ORGIDTYPCD", "FASTRNUMBER"));
//            licenseCheckIn.setP1OrgIdTypCd( "90303");
        } else if (request.getProducerIds2().getCompanyProducerIDJHTC().intValue() ==4) {
            licenseCheckIn.setP1OrgIdTypCd(DataMappingCrossLookUp.getValue("ORGIDTYPCD", "SSN"));
//            licenseCheckIn.setP1OrgIdTypCd("92856");
        }else{
            licenseCheckIn.setP1OrgIdTypCd("");
        }

// CarrierCode
        if (request.getProducerIds2().getCarrierAppointment().getCarrierCode().equals("65099")) {

//            licenseCheckIn.setP1ManufInsCoCd(Integer.parseInt(DataMappingCrossLookUp.getValue("MANUFINSCOCD", "533110")));
            licenseCheckIn.setP1ManufInsCoCd(533110);
        } else if (request.getProducerIds2().getCarrierAppointment().getCarrierCode().equals("90204")) {
//            licenseCheckIn.setP1ManufInsCoCd(Integer.parseInt(DataMappingCrossLookUp.getValue("MANUFINSCOCD", "3916")));
            licenseCheckIn.setP1ManufInsCoCd(3916);
        } else if (request.getProducerIds2().getCarrierAppointment().getCarrierCode().equals("65838")) {
//            licenseCheckIn.setP1ManufInsCoCd(Integer.parseInt(DataMappingCrossLookUp.getValue("MANUFINSCOCD", "92817")));
            licenseCheckIn.setP1ManufInsCoCd(92817);
        } else if (request.getProducerIds2().getCarrierAppointment().getCarrierCode().equals("86375")) {
            // 92818
//            licenseCheckIn.setP1ManufInsCoCd(Integer.parseInt(DataCrossLookUp.getValue("MANUFINSCOCD", "JHNY")));
            licenseCheckIn.setP1ManufInsCoCd(92818);
        } else if (request.getProducerIds2().getCarrierAppointment().getCarrierCode().equals("93610")) {
//            licenseCheckIn.setP1ManufInsCoCd(Integer.parseInt(DataMappingCrossLookUp.getValue("MANUFINSCOCD", "94004")));
            licenseCheckIn.setP1ManufInsCoCd(94004);
        }

        // LineOfAuthorityType
        String lineOfAuthority = request.getProducerIds2().getCarrierAppointment().getLineOfAuthority().getLineOfAuthorityType().getTc();
        if (lineOfAuthority.equals("5")) {
            // 55788
//            licenseCheckIn.setP1PrdTypCd(Integer.parseInt(DataMappingCrossLookUp.getValue("PRDTYPCD", "55788")));
            licenseCheckIn.setP1PrdTypCd(55788);
        } else if (lineOfAuthority.equals("1")) {
// 55789
//            licenseCheckIn.setP1PrdTypCd(Integer.parseInt(DataMappingCrossLookUp.getValue("PRDTYPCD", "55789")));
            licenseCheckIn.setP1PrdTypCd(55788);
        } else if (lineOfAuthority.equals("2")) {
//55791
//            licenseCheckIn.setP1PrdTypCd(Integer.parseInt(DataMappingCrossLookUp.getValue("PRDTYPCD", "55791")));
            licenseCheckIn.setP1PrdTypCd(55791);
        } else if (lineOfAuthority.equals("6")) {
//55790
//            licenseCheckIn.setP1PrdTypCd(Integer.parseInt(DataMappingCrossLookUp.getValue("PRDTYPCD", "55790")));
            licenseCheckIn.setP1PrdTypCd(55790);
        } else if (lineOfAuthority.equals("4")) {
// 55792
//            licenseCheckIn.setP1PrdTypCd(Integer.parseInt(DataMappingCrossLookUp.getValue("PRDTYPCD", "55792")));
            licenseCheckIn.setP1PrdTypCd(55792);
        } else if (lineOfAuthority.equals("49")) {
//90326
//            licenseCheckIn.setP1PrdTypCd(Integer.parseInt(DataMappingCrossLookUp.getValue("PRDTYPCD", "90326")));
            licenseCheckIn.setP1PrdTypCd(55792);
        } else if (lineOfAuthority.equals("92816")) {
// 92816
//            licenseCheckIn.setP1PrdTypCd(Integer.parseInt(DataMappingCrossLookUp.getValue("PRDTYPCD", "92816")));
            licenseCheckIn.setP1PrdTypCd(92816);
        } else if (lineOfAuthority.equals("94763")) {
// 94763
//            licenseCheckIn.setP1PrdTypCd(Integer.parseInt(DataMappingCrossLookUp.getValue("PRDTYPCD", "94763")));
            licenseCheckIn.setP1PrdTypCd(94763);
        } else if (lineOfAuthority.equals("94764")) {
// 94764
//            licenseCheckIn.setP1PrdTypCd(Integer.parseInt(DataMappingCrossLookUp.getValue("PRDTYPCD", "94764")));
            licenseCheckIn.setP1PrdTypCd(94764);
        } else if (lineOfAuthority.equals("93927")) {
// 93927
//            licenseCheckIn.setP1PrdTypCd(Integer.parseInt(DataMappingCrossLookUp.getValue("PRDTYPCD", "93927")));
            licenseCheckIn.setP1PrdTypCd(93927);
        }


        // ResidenceJurisdictionAtIs
        HashMap<String, String> residenceJurisdictionMap = residenceJurisdictionMap();

//        System.out.println("1111>>"+request.getApplicationInfo().getApplicationJurisdiction().getTc());
        if (residenceJurisdictionMap.containsKey(String.valueOf(request.getApplicationInfo().getApplicationJurisdiction().getTc()))) {
            // residenceJurisdictionMap.get(request.getApplicationInfo().getApplicationJurisdiction().getTc()
//            licenseCheckIn.setP1PstlJursCdApp(DataMappingCrossLookUp.getValue("STATEOFSOLI", String.valueOf(residenceJurisdictionMap.get(request.getApplicationInfo().getApplicationJurisdiction().getTc()))));
            System.out.println("22222>>"+residenceJurisdictionMap.get(request.getApplicationInfo().getApplicationJurisdiction().getTc()));
            licenseCheckIn.setP1PstlJursCdApp(residenceJurisdictionMap.get(String.valueOf(request.getApplicationInfo().getApplicationJurisdiction().getTc())));
        }

        if (residenceJurisdictionMap.containsKey(String.valueOf(request.getApplicationInfo().getResidenceJurisdictionAtIssue().getTc()))) {
            // residenceJurisdictionMap.get(request.getApplicationInfo().getResidenceJurisdictionAtIssue().getTc()
//            licenseCheckIn.setP1PstlJursCdResi(Integer.parseInt(DataMappingCrossLookUp.getValue("STATEOFSOLI", String.valueOf(residenceJurisdictionMap.get(request.getApplicationInfo().getResidenceJurisdictionAtIssue().getTc())))));
            licenseCheckIn.setP1PstlJursCdResi(Integer.parseInt( residenceJurisdictionMap.get(String.valueOf(request.getApplicationInfo().getResidenceJurisdictionAtIssue().getTc()))));
        }


        XMLGregorianCalendar signedDate = request.getApplicationInfo().getSignedDate();

        XMLGregorianCalendar submissionDate = request.getApplicationInfo().getSubmissionDate();


        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
        String transactionDate = sdf.format(signedDate.toGregorianCalendar().getTime());


        licenseCheckIn.setP1TransactionDt(transactionDate);

        String strSubsissionDate = sdf.format(submissionDate.toGregorianCalendar().getTime());
        licenseCheckIn.setP1ApplSubDt(strSubsissionDate);

        licenseCheckIn.setP1SrcSystemIdNo(Integer.parseInt(header.getMessageSource().getApplicationName()));


        licenseCheckIn.setP1SubRefNo(header.getMessageSource().getProcessID());

        licenseCheckIn.setP1UserInfo(header.getMessageSource().getUserID());


        return licenseCheckIn;
    }

    /**
     * Gets producer status request.
     *
     * @param request the request
     * @param header  the header
     *
     * @return the producer status request
     */
    public ProducerStatusIn getProducerStatusRequest( GetProducerRequest request,  JHHeader header) {
        ProducerStatusIn producerStatusIn = new ProducerStatusIn();

        if (producerUtils.checkIsEqual("1", String.valueOf(request.getPartyIds().getGovtIDTC().getTc())) || producerUtils.checkIsEqual("2", String.valueOf(request.getPartyIds().getGovtIDTC().getTc()))) {
            producerStatusIn.setInProducerIdTyp("87286");
            producerStatusIn.setInProducerIdNo(request.getPartyIds().getGovtID());

        } else if (producerUtils.checkLenghtIsZero(request.getPartyIds().getGovtID())
                && producerUtils.checkLenghtIsZero(String.valueOf(request.getProducerIds().getJHPayrollNumber()))
                && (String.valueOf(request.getProducerIds().getNIPRNumber()).length() > 0)) {
            producerStatusIn.setInProducerIdTyp("94560");
            producerStatusIn.setInProducerIdNo(String.valueOf(request.getProducerIds().getNIPRNumber()));

        } else if (producerUtils.checkLenghtIsZero(request.getPartyIds().getGovtID())
                && producerUtils.checkLenghtIsZero(String.valueOf(request.getProducerIds().getJHPayrollNumber()))
                && producerUtils.checkLenghtIsZero(String.valueOf(request.getProducerIds().getNIPRNumber()))) {
            producerStatusIn.setInProducerIdTyp("87287");
            producerStatusIn.setInProducerIdNo(String.valueOf(request.getProducerIds().getJHPayrollNumber()));

        } else {
            producerStatusIn.setInProducerIdTyp("0");
            producerStatusIn.setInProducerIdNo("");
        }

        return producerStatusIn;
    }

    /**
     *
     * @return
     */
    private  HashMap<String, String> residenceJurisdictionMap () {
        // ResidenceJurisdictionAtIs
        HashMap<String, String> residenceJurisdictionMap = new HashMap<>();

        residenceJurisdictionMap.put("1", "1586");
        residenceJurisdictionMap.put("2", "1585");
        residenceJurisdictionMap.put("4", "1589");
        residenceJurisdictionMap.put("5", "1587");
        residenceJurisdictionMap.put("6", "1591");
        residenceJurisdictionMap.put("7", "1593");
        residenceJurisdictionMap.put("8", "1594");
        residenceJurisdictionMap.put("9", "1597");
        residenceJurisdictionMap.put("10", "1596");
        residenceJurisdictionMap.put("12", "1598");
        residenceJurisdictionMap.put("13", "1599");
        residenceJurisdictionMap.put("14", "1600");
        residenceJurisdictionMap.put("15", "1601");
        residenceJurisdictionMap.put("16", "1603");
        residenceJurisdictionMap.put("17", "1604");
        residenceJurisdictionMap.put("18", "1605");
        residenceJurisdictionMap.put("19", "1602");
        residenceJurisdictionMap.put("20", "1606");
        residenceJurisdictionMap.put("21", "1607");
        residenceJurisdictionMap.put("22", "1608");
        residenceJurisdictionMap.put("23", "1612");
        residenceJurisdictionMap.put("24", "50706");
        residenceJurisdictionMap.put("25", "1611");
        residenceJurisdictionMap.put("26", "1609");
        residenceJurisdictionMap.put("27", "1613");
        residenceJurisdictionMap.put("28", "1614");
        residenceJurisdictionMap.put("29", "1616");
        residenceJurisdictionMap.put("30", "1615");
        residenceJurisdictionMap.put("31", "1617");
        residenceJurisdictionMap.put("32", "1621");
        residenceJurisdictionMap.put("33", "1627");
        residenceJurisdictionMap.put("34", "1623");
        residenceJurisdictionMap.put("35", "1624");
        residenceJurisdictionMap.put("36", "1625");
        residenceJurisdictionMap.put("37", "1629");
        residenceJurisdictionMap.put("38", "1619");
        residenceJurisdictionMap.put("39", "1620");
        residenceJurisdictionMap.put("40", "1592");
        residenceJurisdictionMap.put("41", "1630");
        residenceJurisdictionMap.put("42", "1631");
        residenceJurisdictionMap.put("43", "1633");
        residenceJurisdictionMap.put("45", "1634");
        residenceJurisdictionMap.put("46", "1636");
        residenceJurisdictionMap.put("47", "1638");
        residenceJurisdictionMap.put("48", "1640");
        residenceJurisdictionMap.put("49", "1641");
        residenceJurisdictionMap.put("50", "1642");
        residenceJurisdictionMap.put("51", "1644");
        residenceJurisdictionMap.put("52", "1645");
        residenceJurisdictionMap.put("53", "1648");
        residenceJurisdictionMap.put("54", "1647");
        residenceJurisdictionMap.put("55", "1646");
        residenceJurisdictionMap.put("56", "1649");
        residenceJurisdictionMap.put("57", "1651");
        residenceJurisdictionMap.put("58", "1650");
        residenceJurisdictionMap.put("59", "1652");
        residenceJurisdictionMap.put("101", "4963");
        residenceJurisdictionMap.put("102", "1590");
        residenceJurisdictionMap.put("103", "4963");
        residenceJurisdictionMap.put("104", "4963");
        residenceJurisdictionMap.put("105", "4963");
        residenceJurisdictionMap.put("106", "4963");
        residenceJurisdictionMap.put("107", "4963");
        residenceJurisdictionMap.put("108", "4963");
        residenceJurisdictionMap.put("109", "4963");
        residenceJurisdictionMap.put("110", "4963");
        residenceJurisdictionMap.put("111", "4963");
        residenceJurisdictionMap.put("112", "4963");
        residenceJurisdictionMap.put("113", "4963");
        residenceJurisdictionMap.put("1000600004", "4964");

        return residenceJurisdictionMap;
    }
}
