package com.jh.life.producertwo;


import com.jh.common.logging.LoggerHandler;
import com.jh.common.utility.DataMappingCrossLookUp;
import com.jh.life.producertwo.utils.DataCrossLookUp;
import org.apache.cxf.helpers.IOUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.io.IOException;
import java.io.InputStream;


/**
 * The type On start up.
 */
@Component
public class OnStartUp {

    @Autowired
    private Environment env;

    @Value("${LookupXml}")
    private String lookupXML;


    /**
     * Init.
     *
     * @throws IOException the io exception
     */
    @PostConstruct
    public void init() throws IOException {

        try {
            //Initializing lookup xmls
            DataMappingCrossLookUp.init(lookupXML);
            LoggerHandler.getInstance(env.getProperty("log.appID"), env.getProperty("log.svcName"), env.getProperty("log.componentName"), env.getProperty("log.svcVersion"));
        }catch (Exception e){
            e.printStackTrace();
            throw e;
        }

        /*try (InputStream stream = new ClassPathResource("CrossLookup_Producer.xml").getInputStream()) {
            String text = IOUtils.toString(stream);
            System.out.println("%%%%IOUtils.toString(stream)%%%%>>" + text);
            DataCrossLookUp.init(text);
            System.out.println("After DataMapping");
            //Initializing Logger class
            LoggerHandler.getInstance(env.getProperty("log.appID"), env.getProperty("log.svcName"), env.getProperty("log.componentName"), env.getProperty("log.svcVersion"));

        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }*/


    }

}
