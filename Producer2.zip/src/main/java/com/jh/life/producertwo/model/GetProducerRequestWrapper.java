package com.jh.life.producertwo.model;

import com.manulife.esb.xsd.common.jh.header.JHHeader;
import com.manulife.esb.xsd.life.jh.producer.GetProducerRequest;

/**
 * The type Get producer request wrapper.
 */
public class GetProducerRequestWrapper {
    private JHHeader header;
    private GetProducerRequest getProducerRequest;

    /**
     * Gets header.
     *
     * @return the header
     */
    public JHHeader getHeader() {
        return header;
    }

    /**
     * Sets header.
     *
     * @param header the header
     */
    public void setHeader(JHHeader header) {
        this.header = header;
    }

    /**
     * Gets get producer request.
     *
     * @return the get producer request
     */
    public GetProducerRequest getGetProducerRequest() {
        return getProducerRequest;
    }

    /**
     * Sets get producer request.
     *
     * @param getProducerRequest the get producer request
     */
    public void setGetProducerRequest(GetProducerRequest getProducerRequest) {
        this.getProducerRequest = getProducerRequest;
    }


}
