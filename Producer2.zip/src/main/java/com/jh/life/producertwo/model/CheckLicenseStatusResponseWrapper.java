package com.jh.life.producertwo.model;

import com.manulife.esb.xsd.common.jh.header.JHHeader;
import com.manulife.esb.xsd.life.jh.producer.CheckLicenseStatusResponse;

/**
 * The type Check license status response wrapper.
 */
public class CheckLicenseStatusResponseWrapper {

    private JHHeader header;
    private CheckLicenseStatusResponse checkLicenseStatusResponse;

    /**
     * Gets header.
     *
     * @return the header
     */
    public JHHeader getHeader() {
        return header;
    }

    /**
     * Sets header.
     *
     * @param header the header
     */
    public void setHeader(JHHeader header) {
        this.header = header;
    }

    /**
     * Gets check license status response.
     *
     * @return the check license status response
     */
    public CheckLicenseStatusResponse getCheckLicenseStatusResponse() {
        return checkLicenseStatusResponse;
    }

    /**
     * Sets check license status response.
     *
     * @param checkLicenseStatusResponse the check license status response
     */
    public void setCheckLicenseStatusResponse(CheckLicenseStatusResponse checkLicenseStatusResponse) {
        this.checkLicenseStatusResponse = checkLicenseStatusResponse;
    }


}
