package com.jh.life.producertwo.utils;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import javax.xml.bind.JAXBElement;
import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;
import java.sql.Date;
import java.sql.Timestamp;
import java.util.GregorianCalendar;

/**
 * Utility class for Producer2Application operations.
 */
@Component
public class ProducerUtils {

    private static final Logger logger = LoggerFactory.getLogger(ProducerUtils.class);

    private static final String EMPTY_STRING = "";

    /**
     * Method to convert Timestamp to XMLGregorianCalendar
     *
     * @param inputDate
     *
     * @return
     */
    public static XMLGregorianCalendar convertTimestampToXmlGregorianCalendar(final Timestamp inputDate) {
        XMLGregorianCalendar xmlGregorianCalendar = null;
        if (inputDate != null) {
            final GregorianCalendar gregorianCalendar = new GregorianCalendar();

            gregorianCalendar.setTime(inputDate);
            try {
                xmlGregorianCalendar = DatatypeFactory.newInstance().newXMLGregorianCalendar(gregorianCalendar);
            } catch (final DatatypeConfigurationException e) {
                logger.error("Failed converting date to XMLGregorianCalendar", e);
            }
        }
        return xmlGregorianCalendar;
    }

    public XMLGregorianCalendar convertUtilDateToGregoerianCalendar(Date inputDate) {
        GregorianCalendar gregorianCalContactEffDate = new GregorianCalendar();
        gregorianCalContactEffDate.setTime(inputDate);
        XMLGregorianCalendar date2 = null;
        try {
            date2 = DatatypeFactory.newInstance().newXMLGregorianCalendar(gregorianCalContactEffDate);
        } catch (Exception e) {

        }
        return date2;
    }



    /**
     * Converts an XMLGregorianCalendar to a Timestamp
     *
     * @param xmlGregorianCalendar
     *
     * @return
     */
    public static Timestamp convertXmlGregorianCalendarToTimestamp(final XMLGregorianCalendar xmlGregorianCalendar) {
        Timestamp timestamp = null;
        if (xmlGregorianCalendar != null) {
            timestamp = new Timestamp(xmlGregorianCalendar.toGregorianCalendar().getTimeInMillis());
        }

        return timestamp;
    }

    /**
     * Converts an JAXBElement<XMLGregorianCalendar> to a Timestamp
     *
     * @param xmlGregorianCalendar
     *
     * @return
     */
    public static Timestamp convertXmlGregorianCalendarToTimestamp(
            final JAXBElement<XMLGregorianCalendar> xmlGregorianCalendar) {
        Timestamp timestamp = null;
        if ((xmlGregorianCalendar != null) && !xmlGregorianCalendar.isNil()) {
            timestamp = new Timestamp(xmlGregorianCalendar.getValue().toGregorianCalendar().getTimeInMillis());
        }

        return timestamp;
    }

    public static String ifNullReturnEmpty(final String value) {
        if (StringUtils.isNotEmpty(value)) {
            return value;
        }

        return EMPTY_STRING;
    }

    public String getStringShortValue(Object value) {

        if (value != null) {
            return String.valueOf(((short) value));
        } else {
            return EMPTY_STRING;
        }

    }

    public boolean checkIsEqual(String source,String target) {
        return source.equalsIgnoreCase(target);
    }

    public boolean checkLenghtIsZero(String source) {
        return (null == source || source.length() == 0);
    }

    public int getLARSProducerStatus(String status) {
        int statusOut = 0;
        switch (status) {
            case "Unknown":
                statusOut= 0;
                break;
            case "Active":
                statusOut= 1;
                break;
            case "Inactive":
                statusOut= 2;
                break;
            case "Pending":
                statusOut= 3;
                break;
            case "Producer2Application Ineligibal for rehire":
                statusOut= 1000000000;
                break;
        }

        return statusOut;
    }
}
