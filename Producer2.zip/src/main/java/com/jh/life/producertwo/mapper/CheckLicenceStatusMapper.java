package com.jh.life.producertwo.mapper;

import com.jh.common.logging.LoggerHandler;
import com.jh.life.producertwo.constants.ProducerConstants;
import com.jh.life.producertwo.model.CheckLicenseStatusResponseWrapper;
import com.jh.life.producertwo.utils.ProducerUtils;
import com.manulife.esb.xsd.common.jh.header.JHHeader;
import com.manulife.esb.xsd.common.jh.header.Status;
import com.manulife.esb.xsd.life.jh.producer.CheckLicenseStatusResponse;
import com.manulife.esb.xsd.life.jh.producer.License;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.sql.CallableStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * The type Check licence status mapper.
 */
@Component
public class CheckLicenceStatusMapper {

    /**
     * The Producer utils.
     */
    @Autowired
    ProducerUtils producerUtils;


    /**
     * Gets license status details.
     *
     * @param jhHeader         the jh header
     * @param messageUUID      the message uuid
     * @param sourceSystemName the source system name
     * @param licenseResultSet the license result set
     *
     * @return the license status details
     *
     * @throws SQLException the sql exception
     */
    public CheckLicenseStatusResponseWrapper getLicenseStatusDetails(JHHeader jhHeader, String messageUUID, String sourceSystemName, CallableStatement licenseResultSet) throws SQLException {
        LoggerHandler.LogOut("INFO", "4", messageUUID, sourceSystemName, this.getClass().getName(),
                "Mapping the Result Set");

        CheckLicenseStatusResponseWrapper checkLicenseStatusResponseWrapper = new CheckLicenseStatusResponseWrapper();
        CheckLicenseStatusResponse checkLicenseStatusResponse = new CheckLicenseStatusResponse();
        License license = new License();
        License.JHLARSLicenseStatusReason jhlarsLicenseStatusReason = new License.JHLARSLicenseStatusReason();
        ResultSet rs = null;

        String plLarsRetnCd = null;
        String p1Success = null;
        License.JHResponseType jhResponseType = null;

        try {
            plLarsRetnCd = licenseResultSet.getString("P1_LARS_RETN_CD");

            license.setJHLARSLicenseStatusCode(plLarsRetnCd);

            jhlarsLicenseStatusReason.setJHLARSLicenseErrorCode(licenseResultSet.getString("P1_LARS_ERR_CD"));
            jhlarsLicenseStatusReason.setJHLARSLicenseErrorMessage(licenseResultSet.getString("P1_LARS_ERR_MESG"));

            p1Success =licenseResultSet.getString("P1_SUCCESS");


            List<License.JHResponseType> reponseTypeList = new ArrayList<>();

            rs = (ResultSet) licenseResultSet.getObject("P1_CODE_VALUE_CSR");

            while (rs.next()) {

                jhResponseType = new License.JHResponseType();
                jhResponseType.setCode(rs.getString(1));

                jhResponseType.setValue(rs.getString(2));

                reponseTypeList.add(jhResponseType);
            }

            license.setJhResponseType(reponseTypeList);

            license.setJHLARSLicenseStatusReason(jhlarsLicenseStatusReason);

            checkLicenseStatusResponse.setLicense(license);

            checkLicenseStatusResponseWrapper.setCheckLicenseStatusResponse(checkLicenseStatusResponse);

            //########################### Mapping the Header Values ################################//

            checkLicenseStatusResponseWrapper.setHeader(mapLicenseStatusHeader(jhHeader, p1Success,plLarsRetnCd ));

            LoggerHandler.LogOut("INFO", "5", messageUUID, sourceSystemName, this.getClass().getName(), checkLicenseStatusResponseWrapper.toString());

        } catch (Exception e) {
            LoggerHandler.ErrorOut(e, messageUUID, sourceSystemName, this.getClass().getName(), checkLicenseStatusResponseWrapper.toString());
            throw e;
        } finally {
            licenseResultSet.close();
            if (rs != null)
                rs.close();
        }

        return checkLicenseStatusResponseWrapper;
    }

    /**
     *
     * @param jhHeader
     * @param p1Success
     * @param plLarsRetnCd
     * @return
     * @throws SQLException
     */
    private JHHeader mapLicenseStatusHeader(JHHeader jhHeader, String  p1Success, String plLarsRetnCd) throws SQLException {
        String statusCode = null;
        String statusDescription = null;
        Status status = jhHeader.getStatus();
        String[] statusCodeArray = {"69890", "70912", "70954", "573431", "70915", "70916"};
        List<String> statusCodeList = new ArrayList(Arrays.asList(statusCodeArray));


        if (p1Success.equals("0") && plLarsRetnCd.equals("69890")) {
            statusCode = "0000";
            statusDescription = ProducerConstants.LICENSE_SUCESS_MSG;
        } else if (p1Success.equals("0") && plLarsRetnCd.equals("70912")) {
            statusCode = "0100";
            statusDescription = ProducerConstants.LICENSE_NOT_FOUND;
        } else if (p1Success.equals("0") && plLarsRetnCd.equals("70954")) {
            statusCode = "0200";
            statusDescription = ProducerConstants.LICENSE_ORG_NOT_FOUND;
        } else if (p1Success.equals("0") && plLarsRetnCd.equals("573431")) {
            statusCode = "1111";
            statusDescription = ProducerConstants.LICENSE_ERROR;
        } else if (p1Success.equals("0") && plLarsRetnCd.equals("70915")) {
            statusCode = "1112";
            statusDescription = ProducerConstants.LICENSE_INVALID_SYS;
        } else if (p1Success.equals("0") && plLarsRetnCd.equals("70916")) {
            statusCode = "1113";
            statusDescription = ProducerConstants.LICENSE_INVALID_REQ;
        } else if (p1Success.equals("0") && !(statusCodeList.contains(plLarsRetnCd))) {
            statusCode = "0001";
            statusDescription = ProducerConstants.LICENSE_DISPUTE;
        }

        status.setStatusCode(statusCode);
        status.setStatusDescription(statusDescription);
        jhHeader.setStatus(status);
        return jhHeader;
    }



}
