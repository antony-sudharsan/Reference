package com.jh.life.producertwo.model;

/**
 * The type License check in.
 */
public class LicenseCheckIn {
    /**
     * The P 1 producer id typ.
     */
    String p1ProducerIdType = null;
    /**
     * The P 1 producer id no.
     */
    String p1ProducerIdNo = null;
    /**
     * The P 1 org id no.
     */
    String p1OrgIdNo;
    /**
     * The P 1 org id typ cd.
     */
    String p1OrgIdTypCd;
    /**
     * The P 1 pstl jurs cd app.
     */
    String p1PstlJursCdApp;
    /**
     * The P 1 pstl jurs cd resi.
     */
    int p1PstlJursCdResi;
    /**
     * The P 1 prd typ cd.
     */
    int p1PrdTypCd;
    /**
     * The P 1 manuf ins co cd.
     */
    int p1ManufInsCoCd;
    /**
     * The P 1 transaction dt.
     */
    String p1TransactionDt;
    /**
     * The P 1 appl sub dt.
     */
    String p1ApplSubDt;
    /**
     * The P 1 src system id no.
     */
    int p1SrcSystemIdNo;
    /**
     * The P 1 sub ref no.
     */
    String p1SubRefNo;
    /**
     * The P 1 user info.
     */
    String p1UserInfo;

    /**
     * Gets p 1 producer id typ.
     *
     * @return the p 1 producer id typ
     */
    public String getP1ProducerIdType() {
        return p1ProducerIdType;
    }

    /**
     * Sets p 1 producer id typ.
     *
     * @param p1ProducerIdType the p 1 producer id typ
     */
    public void setP1ProducerIdType(String p1ProducerIdType) {
        this.p1ProducerIdType = p1ProducerIdType;
    }

    /**
     * Gets p 1 producer id no.
     *
     * @return the p 1 producer id no
     */
    public String getP1ProducerIdNo() {
        return p1ProducerIdNo;
    }

    /**
     * Sets p 1 producer id no.
     *
     * @param p1ProducerIdNo the p 1 producer id no
     */
    public void setP1ProducerIdNo(String p1ProducerIdNo) {
        this.p1ProducerIdNo = p1ProducerIdNo;
    }

    /**
     * Gets p 1 org id no.
     *
     * @return the p 1 org id no
     */
    public String getP1OrgIdNo() {
        return p1OrgIdNo;
    }

    /**
     * Sets p 1 org id no.
     *
     * @param p1OrgIdNo the p 1 org id no
     */
    public void setP1OrgIdNo(String p1OrgIdNo) {
        this.p1OrgIdNo = p1OrgIdNo;
    }

    /**
     * Gets p 1 org id typ cd.
     *
     * @return the p 1 org id typ cd
     */
    public String getP1OrgIdTypCd() {
        return p1OrgIdTypCd;
    }

    /**
     * Sets p 1 org id typ cd.
     *
     * @param p1OrgIdTypCd the p 1 org id typ cd
     */
    public void setP1OrgIdTypCd(String p1OrgIdTypCd) {
        this.p1OrgIdTypCd = p1OrgIdTypCd;
    }

    /**
     * Gets p 1 pstl jurs cd app.
     *
     * @return the p 1 pstl jurs cd app
     */
    public String getP1PstlJursCdApp() {
        return p1PstlJursCdApp;
    }

    /**
     * Sets p 1 pstl jurs cd app.
     *
     * @param p1PstlJursCdApp the p 1 pstl jurs cd app
     */
    public void setP1PstlJursCdApp(String p1PstlJursCdApp) {
        this.p1PstlJursCdApp = p1PstlJursCdApp;
    }

    /**
     * Gets p 1 pstl jurs cd resi.
     *
     * @return the p 1 pstl jurs cd resi
     */
    public int getP1PstlJursCdResi() {
        return p1PstlJursCdResi;
    }

    /**
     * Sets p 1 pstl jurs cd resi.
     *
     * @param p1PstlJursCdResi the p 1 pstl jurs cd resi
     */
    public void setP1PstlJursCdResi(int p1PstlJursCdResi) {
        this.p1PstlJursCdResi = p1PstlJursCdResi;
    }

    /**
     * Gets p 1 prd typ cd.
     *
     * @return the p 1 prd typ cd
     */
    public int getP1PrdTypCd() {
        return p1PrdTypCd;
    }

    /**
     * Sets p 1 prd typ cd.
     *
     * @param p1PrdTypCd the p 1 prd typ cd
     */
    public void setP1PrdTypCd(int p1PrdTypCd) {
        this.p1PrdTypCd = p1PrdTypCd;
    }

    /**
     * Gets p 1 manuf ins co cd.
     *
     * @return the p 1 manuf ins co cd
     */
    public int getP1ManufInsCoCd() {
        return p1ManufInsCoCd;
    }

    /**
     * Sets p 1 manuf ins co cd.
     *
     * @param p1ManufInsCoCd the p 1 manuf ins co cd
     */
    public void setP1ManufInsCoCd(int p1ManufInsCoCd) {
        this.p1ManufInsCoCd = p1ManufInsCoCd;
    }

    /**
     * Gets p 1 transaction dt.
     *
     * @return the p 1 transaction dt
     */
    public String getP1TransactionDt() {
        return p1TransactionDt;
    }

    /**
     * Sets p 1 transaction dt.
     *
     * @param p1TransactionDt the p 1 transaction dt
     */
    public void setP1TransactionDt(String p1TransactionDt) {
        this.p1TransactionDt = p1TransactionDt;
    }

    /**
     * Gets p 1 appl sub dt.
     *
     * @return the p 1 appl sub dt
     */
    public String getP1ApplSubDt() {
        return p1ApplSubDt;
    }

    /**
     * Sets p 1 appl sub dt.
     *
     * @param p1ApplSubDt the p 1 appl sub dt
     */
    public void setP1ApplSubDt(String p1ApplSubDt) {
        this.p1ApplSubDt = p1ApplSubDt;
    }

    /**
     * Gets p 1 src system id no.
     *
     * @return the p 1 src system id no
     */
    public int getP1SrcSystemIdNo() {
        return p1SrcSystemIdNo;
    }

    /**
     * Sets p 1 src system id no.
     *
     * @param p1SrcSystemIdNo the p 1 src system id no
     */
    public void setP1SrcSystemIdNo(int p1SrcSystemIdNo) {
        this.p1SrcSystemIdNo = p1SrcSystemIdNo;
    }

    /**
     * Gets p 1 sub ref no.
     *
     * @return the p 1 sub ref no
     */
    public String getP1SubRefNo() {
        return p1SubRefNo;
    }

    /**
     * Sets p 1 sub ref no.
     *
     * @param p1SubRefNo the p 1 sub ref no
     */
    public void setP1SubRefNo(String p1SubRefNo) {
        this.p1SubRefNo = p1SubRefNo;
    }

    /**
     * Gets p 1 user info.
     *
     * @return the p 1 user info
     */
    public String getP1UserInfo() {
        return p1UserInfo;
    }

    /**
     * Sets p 1 user info.
     *
     * @param p1UserInfo the p 1 user info
     */
    public void setP1UserInfo(String p1UserInfo) {
        this.p1UserInfo = p1UserInfo;
    }

    @Override
    public String toString() {
        return "LicenseCheckIn{" +
                "p1ProducerIdType='" + p1ProducerIdType + '\'' +
                ", p1ProducerIdNo='" + p1ProducerIdNo + '\'' +
                ", p1OrgIdNo='" + p1OrgIdNo + '\'' +
                ", p1OrgIdTypCd='" + p1OrgIdTypCd + '\'' +
                ", p1PstlJursCdApp='" + p1PstlJursCdApp + '\'' +
                ", p1PstlJursCdResi=" + p1PstlJursCdResi +
                ", p1PrdTypCd=" + p1PrdTypCd +
                ", p1ManufInsCoCd=" + p1ManufInsCoCd +
                ", p1TransactionDt='" + p1TransactionDt + '\'' +
                ", p1ApplSubDt='" + p1ApplSubDt + '\'' +
                ", p1SrcSystemIdNo=" + p1SrcSystemIdNo +
                ", p1SubRefNo='" + p1SubRefNo + '\'' +
                ", p1UserInfo='" + p1UserInfo + '\'' +
                '}';
    }
}
