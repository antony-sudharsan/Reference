package com.jh.life.producertwo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * The type Producer 2 application.
 */
@SpringBootApplication
public class Producer2Application {


    /**
     * The entry point of application.
     *
     * @param args the input arguments
     */
    public static void main(String[] args) {
        SpringApplication.run(Producer2Application.class, args);
    }


}
