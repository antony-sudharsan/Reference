package com.jh.life.producertwo.model;

import com.manulife.esb.xsd.common.jh.header.JHHeader;
import com.manulife.esb.xsd.life.jh.producer.CheckLicenseStatusRequest;

/**
 * The type Check license status request wrapper.
 */
public class CheckLicenseStatusRequestWrapper {

    private JHHeader header;
    private CheckLicenseStatusRequest checkLicenseStatusRequest;

    /**
     * Gets header.
     *
     * @return the header
     */
    public JHHeader getHeader() {
        return header;
    }

    /**
     * Sets header.
     *
     * @param header the header
     */
    public void setHeader(JHHeader header) {
        this.header = header;
    }

    /**
     * Gets check license status request.
     *
     * @return the check license status request
     */
    public CheckLicenseStatusRequest getCheckLicenseStatusRequest() {
        return checkLicenseStatusRequest;
    }

    /**
     * Sets check license status request.
     *
     * @param checkLicenseStatusRequest the check license status request
     */
    public void setCheckLicenseStatusRequest(CheckLicenseStatusRequest checkLicenseStatusRequest) {
        this.checkLicenseStatusRequest = checkLicenseStatusRequest;
    }
}
