package com.jh.life.producertwo.orchestration;

import com.jh.common.logging.LoggerHandler;
import com.jh.life.producertwo.dao.ProducerDAO;
import com.jh.life.producertwo.exception.InvalidInputException;
import com.jh.life.producertwo.mapper.CheckLicenceStatusMapper;
import com.jh.life.producertwo.mapper.GetProducerDataMapper;
import com.jh.life.producertwo.model.CheckLicenseStatusResponseWrapper;
import com.jh.life.producertwo.model.GetProducerResponseWrapper;
import com.jh.life.producertwo.model.LicenseCheckIn;
import com.jh.life.producertwo.model.ProducerStatusIn;
import com.jh.life.producertwo.transformation.ProducerDataTransformer;
import com.jh.life.producertwo.utils.LoggerUtils;
import com.jh.life.producertwo.utils.LoggingContextHolder;
import com.jh.life.producertwo.utils.ProducerUtils;
import com.manulife.esb.xsd.common.jh.header.JHHeader;
import com.manulife.esb.xsd.life.jh.producer.CheckLicenseStatusRequest;
import com.manulife.esb.xsd.life.jh.producer.GetProducerRequest;
import com.manulife.esb.xsd.life.jh.producer.GetProducerResponse;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.sql.SQLException;

/**
 * The type Maintain policy orchestraion.
 */
@Component
public class ProducerOrchestration {

    @Autowired
    private LoggerUtils loggerUtils;

    @Autowired
    private ProducerUtils producerUtils;

    @Autowired
    private ProducerDAO producerDAO;

    @Autowired
     ProducerDataTransformer producerDataTransformer;


    /**
     * Check license status check license status response wrapper.
     *
     * @param header  the header
     * @param request the request
     *
     * @return the check license status response wrapper
     *
     * @throws Exception the exception
     */
    public CheckLicenseStatusResponseWrapper checkLicenseStatus(JHHeader header, final CheckLicenseStatusRequest request) throws Exception {

        final String messageUUID = LoggingContextHolder.getLoggingContext().getMessageUUID();
        final String sourceSystemName = LoggingContextHolder.getLoggingContext().getSourceSystemName();
        CheckLicenseStatusResponseWrapper reply = new CheckLicenseStatusResponseWrapper();

        LoggerHandler.LogOut("INFO", "2", messageUUID, sourceSystemName, this.getClass().getName(),
                "Entering checkLicenseStatus " + loggerUtils.writeAsJson(request));

//        final String user = retrieveAndValidateUser(header);

        LicenseCheckIn licenseCheckIn = producerDataTransformer.getLicenseStatusRequest(request, header);

        LoggerHandler.LogOut("INFO", "2a", messageUUID, sourceSystemName, this.getClass().getName(),
                "After Input Transformation " + loggerUtils.writeAsJson(licenseCheckIn));

        reply = producerDAO.getLicenseStatus(header,licenseCheckIn);

        LoggerHandler.LogOut("INFO", "7", messageUUID, sourceSystemName, this.getClass().getName(),
                "Exiting checkLicenseStatus " + loggerUtils.writeAsJson(reply));

        return reply;
    }


    /**
     * Gets producer.
     *
     * @param header  the header
     * @param request the request
     *
     * @return the producer
     *
     * @throws SQLException the sql exception
     */
    public GetProducerResponseWrapper getProducer( JHHeader header,  GetProducerRequest request) throws SQLException {

        final String messageUUID = LoggingContextHolder.getLoggingContext().getMessageUUID();
        final String sourceSystemName = LoggingContextHolder.getLoggingContext().getSourceSystemName();


        GetProducerResponseWrapper getProducerResponseWrapper = new GetProducerResponseWrapper();
        LoggerHandler.LogOut("INFO", "2", messageUUID, sourceSystemName, this.getClass().getName(),
                "Entering getProducer " + loggerUtils.writeAsJson(request));

        final String user = retrieveAndValidateUser(header);

        ProducerStatusIn producerStatusIn = producerDataTransformer.getProducerStatusRequest(request, header);

        LoggerHandler.LogOut("INFO", "2a", messageUUID, sourceSystemName, this.getClass().getName(),
                "After Input Transformation " + loggerUtils.writeAsJson(producerStatusIn));

        getProducerResponseWrapper = producerDAO.checkProducerStatus(header, producerStatusIn);

        GetProducerResponse getProducerResponse = getProducerResponseWrapper.getGetProducerResponse();

        String partyTypeCode = "";
        if(getProducerResponse.getParty() != null && getProducerResponse.getParty().getPartyTypeCode() != null ){
            partyTypeCode = getProducerResponse.getParty().getPartyTypeCode();
        }

        if((!getProducerResponseWrapper.getErrCode().equals("0100") ) && partyTypeCode.equals("1")){
            LoggerHandler.LogOut("INFO", "2b", messageUUID, sourceSystemName, this.getClass().getName(),
                    "Before Invoking the Producer Affln " + loggerUtils.writeAsJson(producerStatusIn));
            getProducerResponse = producerDAO.checkProducerAffln(producerStatusIn,getProducerResponse);

            LoggerHandler.LogOut("INFO", "2b", messageUUID, sourceSystemName, this.getClass().getName(),
                    "After Invoking the Producer Affln " + loggerUtils.writeAsJson(getProducerResponse));
            getProducerResponseWrapper.setGetProducerResponse(getProducerResponse);
        }

        LoggerHandler.LogOut("INFO", "4", messageUUID, sourceSystemName, this.getClass().getName(),
                "Exiting getProducer " + loggerUtils.writeAsJson(getProducerResponseWrapper));

        return getProducerResponseWrapper;
    }


    /**
     * Retrieve user from header, and if not found throw proper exception.
     *
     * @param header
     *
     * @return
     */
    private String retrieveAndValidateUser(final JHHeader header) {
        final String user = header.getMessageSource().getUserID();
        if (StringUtils.isEmpty(user)) {
            throw new InvalidInputException();
        }
        return user;
    }


}
