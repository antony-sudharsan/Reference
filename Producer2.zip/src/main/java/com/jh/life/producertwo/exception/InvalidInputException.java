package com.jh.life.producertwo.exception;

/**
 * Represents SoapFault for Invalid Input.
 */
public class InvalidInputException extends com.jh.life.producertwo.exception.BaseFaultException {
    private static final long serialVersionUID = -6016805724195451879L;

    private static final String DEFAULT_CODE = "993";
    private static final String DEFAULT_REASON = "Invalid Input";
    private static final String DEFAULT_DETAILS = "Invalid information entered for input.";
    private static final String FAULT_STRING = "Internal Error";

    public InvalidInputException() {
        super(DEFAULT_CODE, DEFAULT_REASON, DEFAULT_DETAILS, FAULT_STRING);
    }

}
