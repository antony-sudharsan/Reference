package com.jh.life.producertwo.exception;

/**
 * Represents SoapFault for Invalid Input.
 */
public class BadRequestException extends BaseFaultException {

    private static final long serialVersionUID = 1L;
    private static final String DEFAULT_CODE = "993";
    private static final String DEFAULT_REASON = "Invalid Input";
    private static final String DEFAULT_DETAILS = "Invalid information entered for input.";
    private static final String FAULT_STRING = "Internal Error";

    public BadRequestException() {
        super(DEFAULT_CODE, DEFAULT_REASON, DEFAULT_DETAILS, FAULT_STRING);
    }

    public BadRequestException(final String message) {
        super(DEFAULT_CODE, DEFAULT_REASON, message, FAULT_STRING);
    }

}
