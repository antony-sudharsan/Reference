package com.jh.life.producertwo.config;

import com.jh.life.producertwo.endpoint.ProducerEndpointInterceptor;
import com.jh.life.producertwo.exception.BaseFaultException;
import com.jh.life.producertwo.exception.DetailSoapFaultDefinitionExceptionResolver;
import com.jh.life.producertwo.utils.JHHeaderJaxbUtils;
import org.springframework.boot.web.servlet.ServletRegistrationBean;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;
import org.springframework.ws.config.annotation.EnableWs;
import org.springframework.ws.config.annotation.WsConfigurerAdapter;
import org.springframework.ws.server.EndpointInterceptor;
import org.springframework.ws.soap.server.endpoint.SoapFaultDefinition;
import org.springframework.ws.soap.server.endpoint.SoapFaultMappingExceptionResolver;
import org.springframework.ws.soap.server.endpoint.interceptor.PayloadValidatingInterceptor;
import org.springframework.ws.transport.http.MessageDispatcherServlet;
import org.springframework.ws.wsdl.wsdl11.SimpleWsdl11Definition;
import org.springframework.xml.xsd.SimpleXsdSchema;
import org.springframework.xml.xsd.XsdSchema;

import java.util.List;
import java.util.Properties;

/**
 * Configures Web Service Endpoint for Producer2Application Operations.
 */
@EnableWs
@Configuration
public class WebServiceConfig extends WsConfigurerAdapter {

    @Bean
    public ServletRegistrationBean messageDispatcherServlet(final ApplicationContext applicationContext) {
        final MessageDispatcherServlet servlet = new MessageDispatcherServlet();
        servlet.setApplicationContext(applicationContext);
        servlet.setTransformWsdlLocations(true);
        servlet.setTransformSchemaLocations(true);
        return new ServletRegistrationBean(servlet, "/Life/Producer_2/*");
    }

    // Note: Could use wsdl from TIBCO but it has embedded tibco namespaces
    // To retrieve wsdl
    // http://localhost:8080/Life/Producer_2/Producer_2.0.wsdl
    @Bean(name = "Producer_2.0")
    public SimpleWsdl11Definition producerWsdl11Definition() {
        final SimpleWsdl11Definition wsdl = new SimpleWsdl11Definition(
                new ClassPathResource("Producer_2.wsdl"));

        return wsdl;
    }

    @Bean
    public JHHeaderJaxbUtils jhHeaderJaxbUtils() {
        return new JHHeaderJaxbUtils();
    }

    // will expose imported schema
    // http://localhost:8080/MaintainProducerAgreement_1.0/JHFNMaintainProducerAgreement.xsd
    @Bean(name = "Producer2")
    public XsdSchema maintainProducerAgreementSchema() {
        return new SimpleXsdSchema(new ClassPathResource("Producer_2.xsd"));
    }

    // will expose imported schema
    // http://localhost:8080/MaintainProducerAgreement_1.0/JHHeader_0.5.0.xsd
    @Bean(name = "JHHeader_0.5.0")
    public XsdSchema headerSchema() {
        return new SimpleXsdSchema(new ClassPathResource("JHHeader_0.5.0.xsd"));
    }

    // will expose imported schema
    // http://localhost:8080/MaintainProducerAgreement_1.0/SOAPFault.xsd
    @Bean(name = "SOAPFault")
    public XsdSchema soapFaultSchema() {
        return new SimpleXsdSchema(new ClassPathResource("SOAPFault.xsd"));
    }

    @Bean
    public SoapFaultMappingExceptionResolver exceptionResolver() {
        final SoapFaultMappingExceptionResolver exceptionResolver = new DetailSoapFaultDefinitionExceptionResolver();

        final SoapFaultDefinition faultDefinition = new SoapFaultDefinition();
        faultDefinition.setFaultCode(SoapFaultDefinition.SERVER);
        faultDefinition.setFaultStringOrReason("Internal Error");
        exceptionResolver.setDefaultFault(faultDefinition);

        final Properties errorMappings = new Properties();
        errorMappings.setProperty(Exception.class.getName(), SoapFaultDefinition.SERVER.toString());
        errorMappings.setProperty(BaseFaultException.class.getName(), SoapFaultDefinition.SERVER.toString());
        exceptionResolver.setExceptionMappings(errorMappings);
        exceptionResolver.setOrder(1);
        return exceptionResolver;
    }

    @Override
    public void addInterceptors(final List<EndpointInterceptor> interceptors) {

        final PayloadValidatingInterceptor validatingInterceptor = new PayloadValidatingInterceptor();
        validatingInterceptor.setValidateRequest(true);
        validatingInterceptor.setValidateResponse(true);
        validatingInterceptor.setXsdSchema(maintainProducerAgreementSchema());
        interceptors.add(validatingInterceptor);

        // will handle adding soap response header
        interceptors.add(new ProducerEndpointInterceptor(jhHeaderJaxbUtils()));
    }

}
