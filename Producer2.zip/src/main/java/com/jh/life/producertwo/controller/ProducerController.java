package com.jh.life.producertwo.controller;

import com.jh.common.logging.LoggerHandler;
import com.jh.life.producertwo.model.CheckLicenseStatusRequestWrapper;
import com.jh.life.producertwo.model.CheckLicenseStatusResponseWrapper;
import com.jh.life.producertwo.model.GetProducerRequestWrapper;
import com.jh.life.producertwo.model.GetProducerResponseWrapper;
import com.jh.life.producertwo.orchestration.ProducerOrchestration;
import com.jh.life.producertwo.utils.JHHeaderUtils;
import com.jh.life.producertwo.utils.LoggerUtils;
import com.jh.life.producertwo.utils.LoggingContextHolder;
import com.manulife.esb.xsd.life.jh.producer.GetProducerResponse;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.DataBinder;
import org.springframework.web.bind.annotation.*;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

/**
 * The type Producer controller.
 */
@RestController
@EnableSwagger2
public class ProducerController {

    /**
     * The Log ret message.
     */
    String logRetMessage;
    /**
     * The Response headers.
     */
    HttpHeaders responseHeaders = new HttpHeaders();
    /**
     * The Producer orchestration.
     */
    @Autowired
    ProducerOrchestration producerOrchestration;

    private LoggerUtils loggerUtils;

    /**
     * Activate direct field access.
     *
     * @param dataBinder the data binder
     */
    @InitBinder
    public void activateDirectFieldAccess(final DataBinder dataBinder) {
        dataBinder.initDirectFieldAccess();
    }

    /**
     * Instantiates a new Producer controller.
     *
     * @param producerOrchestration the producer orchestration
     * @param loggerUtils           the logger utils
     */
    public ProducerController(ProducerOrchestration producerOrchestration, LoggerUtils loggerUtils) {
        this.producerOrchestration = producerOrchestration;
        this.loggerUtils = loggerUtils;
    }

    /**
     * Check license status response entity.
     *
     * @param request the request
     *
     * @return the response entity
     *
     * @throws Exception the exception
     */
    @ApiOperation(
            value = "Check License Status",
            notes = "Service will retrive License Status",
            response = CheckLicenseStatusResponseWrapper.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Success"),
            @ApiResponse(code = 406, message = "Service Processing Error"),
            @ApiResponse(code = 408, message = "Request Timeout"),
            @ApiResponse(code = 500, message = "SQL Server Backend returned an error"),
            @ApiResponse(code = 400, message = "Validation Failed"),
            @ApiResponse(code = 404, message = "Auth data Record not found "),
            @ApiResponse(code = 401, message = "Unauthorized to perform operation")
    })
    @RequestMapping(value = "/jh/common/producer/license/checkstatus", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CheckLicenseStatusResponseWrapper> checkLicenseStatus(@RequestBody CheckLicenseStatusRequestWrapper request) throws Exception {

        final String messageUUID = JHHeaderUtils.retrieveOrDefaultMessageUID(request.getHeader(),
                "checkLicenseStatus");
        final String sourceSystemName = JHHeaderUtils.retrieveOrDefaultSourceSystemName(request.getHeader());
        CheckLicenseStatusResponseWrapper checkLicenseStatusResponseWrapper = new CheckLicenseStatusResponseWrapper();

        try {
            LoggingContextHolder.getLoggingContext().setContext(messageUUID, sourceSystemName);

            JHHeaderUtils.validateHeader(request.getHeader());
            LoggerHandler.LogOut("INFO", "1", messageUUID, sourceSystemName, this.getClass().getName(), "Entering checkLicenseStatus Controller");
            checkLicenseStatusResponseWrapper = producerOrchestration.checkLicenseStatus(request.getHeader(), request.getCheckLicenseStatusRequest());

            LoggerHandler.LogOut("INFO", "6", messageUUID, sourceSystemName, this.getClass().getName(), "Exiting checkLicenseStatus Controller");
            LoggerHandler.LogOut("DEBUG", "6", messageUUID, sourceSystemName, this.getClass().getName(), "Controller Create Success");


        } catch (final Exception e) {
            LoggerHandler.ErrorOut(e, messageUUID, sourceSystemName, this.getClass().getName(), e.getMessage());
            throw e;
        }

        return new ResponseEntity(checkLicenseStatusResponseWrapper, new HttpHeaders(), HttpStatus.OK);
    }

    /**
     * Gets producer.
     *
     * @param request the request
     *
     * @return the producer
     *
     * @throws Exception the exception
     */
    @ApiOperation(
            value = "Producer2Application Status",
            notes = "Service will fetch and display Producer2Application Status Details",
            response = GetProducerResponse.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Success"),
            @ApiResponse(code = 500, message = "Internal Server Error"),
            @ApiResponse(code = 400, message = "Bad Request"),
            @ApiResponse(code = 404, message = "Not Found"),
            @ApiResponse(code = 401, message = "Unauthorized"),
            @ApiResponse(code = 408, message = "Request Timeout")
    })
    @RequestMapping(value = "/jh/common/producer/statusdetails", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<GetProducerResponseWrapper> getProducer(@RequestBody GetProducerRequestWrapper request) throws Exception {

        final String messageUUID = JHHeaderUtils.retrieveOrDefaultMessageUID(request.getHeader(),
                "checkLicenseStatus");
        final String sourceSystemName = JHHeaderUtils.retrieveOrDefaultSourceSystemName(request.getHeader());
        GetProducerResponseWrapper getProducerResponseWrapper = new GetProducerResponseWrapper();

        try {
            LoggingContextHolder.getLoggingContext().setContext(messageUUID, sourceSystemName);

            JHHeaderUtils.validateHeader(request.getHeader());
            LoggerHandler.LogOut("INFO", "1", messageUUID, sourceSystemName, this.getClass().getName(), "Entering produer status Controller");
            getProducerResponseWrapper = producerOrchestration.getProducer(request.getHeader(), request.getGetProducerRequest());

            LoggerHandler.LogOut("INFO", "6", messageUUID, sourceSystemName, this.getClass().getName(), "Exiting checkLicenseStatus Controller");
            LoggerHandler.LogOut("DEBUG", "6", messageUUID, sourceSystemName, this.getClass().getName(), "Controller Create Success");


        } catch (final Exception e) {
            LoggerHandler.ErrorOut(e, messageUUID, sourceSystemName, this.getClass().getName(), e.getMessage());
            throw e;
        }

        return new ResponseEntity(getProducerResponseWrapper, new HttpHeaders(), HttpStatus.OK);

    }

}
