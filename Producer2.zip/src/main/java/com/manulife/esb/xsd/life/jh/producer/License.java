
package com.manulife.esb.xsd.life.jh.producer;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="JHLARSLicenseStatusCode" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="JHLARSLicenseStatusReason" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="JHLARSLicenseErrorCode" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                   &lt;element name="JHLARSLicenseErrorMessage" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="JHResponseType" maxOccurs="unbounded" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="Code" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                   &lt;element name="Value" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "jhlarsLicenseStatusCode",
    "jhlarsLicenseStatusReason",
    "jhResponseType"
})
@XmlRootElement(name = "License")
public class License {

    @XmlElement(name = "JHLARSLicenseStatusCode", required = true)
    protected String jhlarsLicenseStatusCode;
    @XmlElement(name = "JHLARSLicenseStatusReason")
    protected License.JHLARSLicenseStatusReason jhlarsLicenseStatusReason;

    public void setJhResponseType(List<JHResponseType> jhResponseType) {
        this.jhResponseType = jhResponseType;
    }

    @XmlElement(name = "JHResponseType")
    protected List<License.JHResponseType> jhResponseType;

    /**
     * Gets the value of the jhlarsLicenseStatusCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getJHLARSLicenseStatusCode() {
        return jhlarsLicenseStatusCode;
    }

    /**
     * Sets the value of the jhlarsLicenseStatusCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setJHLARSLicenseStatusCode(String value) {
        this.jhlarsLicenseStatusCode = value;
    }

    /**
     * Gets the value of the jhlarsLicenseStatusReason property.
     * 
     * @return
     *     possible object is
     *     {@link License.JHLARSLicenseStatusReason }
     *     
     */
    public License.JHLARSLicenseStatusReason getJHLARSLicenseStatusReason() {
        return jhlarsLicenseStatusReason;
    }

    /**
     * Sets the value of the jhlarsLicenseStatusReason property.
     * 
     * @param value
     *     allowed object is
     *     {@link License.JHLARSLicenseStatusReason }
     *     
     */
    public void setJHLARSLicenseStatusReason(License.JHLARSLicenseStatusReason value) {
        this.jhlarsLicenseStatusReason = value;
    }

    /**
     * Gets the value of the jhResponseType property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the jhResponseType property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getJHResponseType().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link License.JHResponseType }
     * 
     * 
     */
    public List<License.JHResponseType> getJHResponseType() {
        if (jhResponseType == null) {
            jhResponseType = new ArrayList<License.JHResponseType>();
        }
        return this.jhResponseType;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="JHLARSLicenseErrorCode" type="{http://www.w3.org/2001/XMLSchema}string"/>
     *         &lt;element name="JHLARSLicenseErrorMessage" type="{http://www.w3.org/2001/XMLSchema}string"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "jhlarsLicenseErrorCode",
        "jhlarsLicenseErrorMessage"
    })
    public static class JHLARSLicenseStatusReason {

        @XmlElement(name = "JHLARSLicenseErrorCode", required = true)
        protected String jhlarsLicenseErrorCode;
        @XmlElement(name = "JHLARSLicenseErrorMessage", required = true)
        protected String jhlarsLicenseErrorMessage;

        /**
         * Gets the value of the jhlarsLicenseErrorCode property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getJHLARSLicenseErrorCode() {
            return jhlarsLicenseErrorCode;
        }

        /**
         * Sets the value of the jhlarsLicenseErrorCode property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setJHLARSLicenseErrorCode(String value) {
            this.jhlarsLicenseErrorCode = value;
        }

        /**
         * Gets the value of the jhlarsLicenseErrorMessage property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getJHLARSLicenseErrorMessage() {
            return jhlarsLicenseErrorMessage;
        }

        /**
         * Sets the value of the jhlarsLicenseErrorMessage property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setJHLARSLicenseErrorMessage(String value) {
            this.jhlarsLicenseErrorMessage = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="Code" type="{http://www.w3.org/2001/XMLSchema}string"/>
     *         &lt;element name="Value" type="{http://www.w3.org/2001/XMLSchema}string"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "code",
        "value"
    })
    public static class JHResponseType {

        @XmlElement(name = "Code", required = true)
        protected String code;
        @XmlElement(name = "Value", required = true)
        protected String value;

        /**
         * Gets the value of the code property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getCode() {
            return code;
        }

        /**
         * Sets the value of the code property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setCode(String value) {
            this.code = value;
        }

        /**
         * Gets the value of the value property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getValue() {
            return value;
        }

        /**
         * Sets the value of the value property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setValue(String value) {
            this.value = value;
        }

    }

}
