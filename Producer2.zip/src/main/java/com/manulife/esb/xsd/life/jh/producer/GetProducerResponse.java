
package com.manulife.esb.xsd.life.jh.producer;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Party">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="PartyTypeCode" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                   &lt;element name="FullName" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                   &lt;element name="GovtID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                   &lt;element name="GovtIDTC" minOccurs="0">
 *                     &lt;complexType>
 *                       &lt;complexContent>
 *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                           &lt;attribute name="tc" type="{http://www.w3.org/2001/XMLSchema}nonNegativeInteger" />
 *                         &lt;/restriction>
 *                       &lt;/complexContent>
 *                     &lt;/complexType>
 *                   &lt;/element>
 *                   &lt;element name="Person" minOccurs="0">
 *                     &lt;complexType>
 *                       &lt;complexContent>
 *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                           &lt;sequence>
 *                             &lt;element name="PersonId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                             &lt;element name="FirstName" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                             &lt;element name="MiddleName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                             &lt;element name="LastName" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                             &lt;element name="BirthDate" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                           &lt;/sequence>
 *                         &lt;/restriction>
 *                       &lt;/complexContent>
 *                     &lt;/complexType>
 *                   &lt;/element>
 *                   &lt;element name="Producer" minOccurs="0">
 *                     &lt;complexType>
 *                       &lt;complexContent>
 *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                           &lt;sequence>
 *                             &lt;element name="NIPRNumber" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *                             &lt;element name="JHPayrollNumber" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *                             &lt;element ref="{http://www.esb.manulife.com/xsd/Life/jh/Producer}JHAgencyNumber" minOccurs="0"/>
 *                             &lt;element ref="{http://www.esb.manulife.com/xsd/Life/jh/Producer}LARSProducerStatus"/>
 *                             &lt;element name="AgencyAffiliation" maxOccurs="unbounded" minOccurs="0">
 *                               &lt;complexType>
 *                                 &lt;complexContent>
 *                                   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                                     &lt;sequence>
 *                                       &lt;element name="FullName" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                                       &lt;element name="AbbrName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                                       &lt;element name="DBA" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                                       &lt;element ref="{http://www.esb.manulife.com/xsd/Life/jh/Producer}JHAgencyNumber" minOccurs="0"/>
 *                                       &lt;element name="ContractStatus" minOccurs="0">
 *                                         &lt;simpleType>
 *                                           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *                                             &lt;enumeration value="Active"/>
 *                                             &lt;enumeration value="Inactive"/>
 *                                           &lt;/restriction>
 *                                         &lt;/simpleType>
 *                                       &lt;/element>
 *                                     &lt;/sequence>
 *                                   &lt;/restriction>
 *                                 &lt;/complexContent>
 *                               &lt;/complexType>
 *                             &lt;/element>
 *                             &lt;element name="JITInd" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *                           &lt;/sequence>
 *                         &lt;/restriction>
 *                       &lt;/complexContent>
 *                     &lt;/complexType>
 *                   &lt;/element>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "party"
})
@XmlRootElement(name = "GetProducer_response")
public class GetProducerResponse {

    @XmlElement(name = "Party", required = true)
    protected GetProducerResponse.Party party;


    /**
     * Gets the value of the party property.
     * 
     * @return
     *     possible object is
     *     {@link GetProducerResponse.Party }
     *     
     */
    public GetProducerResponse.Party getParty() {
        return party;
    }

    /**
     * Sets the value of the party property.
     * 
     * @param value
     *     allowed object is
     *     {@link GetProducerResponse.Party }
     *     
     */
    public void setParty(GetProducerResponse.Party value) {
        this.party = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="PartyTypeCode" type="{http://www.w3.org/2001/XMLSchema}string"/>
     *         &lt;element name="FullName" type="{http://www.w3.org/2001/XMLSchema}string"/>
     *         &lt;element name="GovtID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *         &lt;element name="GovtIDTC" minOccurs="0">
     *           &lt;complexType>
     *             &lt;complexContent>
     *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *                 &lt;attribute name="tc" type="{http://www.w3.org/2001/XMLSchema}nonNegativeInteger" />
     *               &lt;/restriction>
     *             &lt;/complexContent>
     *           &lt;/complexType>
     *         &lt;/element>
     *         &lt;element name="Person" minOccurs="0">
     *           &lt;complexType>
     *             &lt;complexContent>
     *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *                 &lt;sequence>
     *                   &lt;element name="PersonId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *                   &lt;element name="FirstName" type="{http://www.w3.org/2001/XMLSchema}string"/>
     *                   &lt;element name="MiddleName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *                   &lt;element name="LastName" type="{http://www.w3.org/2001/XMLSchema}string"/>
     *                   &lt;element name="BirthDate" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *                 &lt;/sequence>
     *               &lt;/restriction>
     *             &lt;/complexContent>
     *           &lt;/complexType>
     *         &lt;/element>
     *         &lt;element name="Producer" minOccurs="0">
     *           &lt;complexType>
     *             &lt;complexContent>
     *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *                 &lt;sequence>
     *                   &lt;element name="NIPRNumber" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
     *                   &lt;element name="JHPayrollNumber" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
     *                   &lt;element ref="{http://www.esb.manulife.com/xsd/Life/jh/Producer}JHAgencyNumber" minOccurs="0"/>
     *                   &lt;element ref="{http://www.esb.manulife.com/xsd/Life/jh/Producer}LARSProducerStatus"/>
     *                   &lt;element name="AgencyAffiliation" maxOccurs="unbounded" minOccurs="0">
     *                     &lt;complexType>
     *                       &lt;complexContent>
     *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *                           &lt;sequence>
     *                             &lt;element name="FullName" type="{http://www.w3.org/2001/XMLSchema}string"/>
     *                             &lt;element name="AbbrName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *                             &lt;element name="DBA" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *                             &lt;element ref="{http://www.esb.manulife.com/xsd/Life/jh/Producer}JHAgencyNumber" minOccurs="0"/>
     *                             &lt;element name="ContractStatus" minOccurs="0">
     *                               &lt;simpleType>
     *                                 &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
     *                                   &lt;enumeration value="Active"/>
     *                                   &lt;enumeration value="Inactive"/>
     *                                 &lt;/restriction>
     *                               &lt;/simpleType>
     *                             &lt;/element>
     *                           &lt;/sequence>
     *                         &lt;/restriction>
     *                       &lt;/complexContent>
     *                     &lt;/complexType>
     *                   &lt;/element>
     *                   &lt;element name="JITInd" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
     *                 &lt;/sequence>
     *               &lt;/restriction>
     *             &lt;/complexContent>
     *           &lt;/complexType>
     *         &lt;/element>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "partyTypeCode",
        "fullName",
        "govtID",
        "govtIDTC",
        "person",
        "producer"
    })
    public static class Party {

        @XmlElement(name = "PartyTypeCode", required = true)
        protected String partyTypeCode;
        @XmlElement(name = "FullName", required = true)
        protected String fullName;
        @XmlElement(name = "GovtID")
        protected String govtID;
        @XmlElement(name = "GovtIDTC")
        protected GetProducerResponse.Party.GovtIDTC govtIDTC;
        @XmlElement(name = "Person")
        protected GetProducerResponse.Party.Person person;
        @XmlElement(name = "Producer")
        protected GetProducerResponse.Party.Producer producer;

        /**
         * Gets the value of the partyTypeCode property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getPartyTypeCode() {
            return partyTypeCode;
        }

        /**
         * Sets the value of the partyTypeCode property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setPartyTypeCode(String value) {
            this.partyTypeCode = value;
        }

        /**
         * Gets the value of the fullName property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getFullName() {
            return fullName;
        }

        /**
         * Sets the value of the fullName property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setFullName(String value) {
            this.fullName = value;
        }

        /**
         * Gets the value of the govtID property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getGovtID() {
            return govtID;
        }

        /**
         * Sets the value of the govtID property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setGovtID(String value) {
            this.govtID = value;
        }

        /**
         * Gets the value of the govtIDTC property.
         * 
         * @return
         *     possible object is
         *     {@link GetProducerResponse.Party.GovtIDTC }
         *     
         */
        public GetProducerResponse.Party.GovtIDTC getGovtIDTC() {
            return govtIDTC;
        }

        /**
         * Sets the value of the govtIDTC property.
         * 
         * @param value
         *     allowed object is
         *     {@link GetProducerResponse.Party.GovtIDTC }
         *     
         */
        public void setGovtIDTC(GetProducerResponse.Party.GovtIDTC value) {
            this.govtIDTC = value;
        }

        /**
         * Gets the value of the person property.
         * 
         * @return
         *     possible object is
         *     {@link GetProducerResponse.Party.Person }
         *     
         */
        public GetProducerResponse.Party.Person getPerson() {
            return person;
        }

        /**
         * Sets the value of the person property.
         * 
         * @param value
         *     allowed object is
         *     {@link GetProducerResponse.Party.Person }
         *     
         */
        public void setPerson(GetProducerResponse.Party.Person value) {
            this.person = value;
        }

        /**
         * Gets the value of the producer property.
         * 
         * @return
         *     possible object is
         *     {@link GetProducerResponse.Party.Producer }
         *     
         */
        public GetProducerResponse.Party.Producer getProducer() {
            return producer;
        }

        /**
         * Sets the value of the producer property.
         * 
         * @param value
         *     allowed object is
         *     {@link GetProducerResponse.Party.Producer }
         *     
         */
        public void setProducer(GetProducerResponse.Party.Producer value) {
            this.producer = value;
        }


        /**
         * <p>Java class for anonymous complex type.
         * 
         * <p>The following schema fragment specifies the expected content contained within this class.
         * 
         * <pre>
         * &lt;complexType>
         *   &lt;complexContent>
         *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
         *       &lt;attribute name="tc" type="{http://www.w3.org/2001/XMLSchema}nonNegativeInteger" />
         *     &lt;/restriction>
         *   &lt;/complexContent>
         * &lt;/complexType>
         * </pre>
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "")
        public static class GovtIDTC {

            @XmlAttribute(name = "tc")
            @XmlSchemaType(name = "nonNegativeInteger")
            protected BigInteger tc;

            /**
             * Gets the value of the tc property.
             * 
             * @return
             *     possible object is
             *     {@link BigInteger }
             *     
             */
            public BigInteger getTc() {
                return tc;
            }

            /**
             * Sets the value of the tc property.
             * 
             * @param value
             *     allowed object is
             *     {@link BigInteger }
             *     
             */
            public void setTc(BigInteger value) {
                this.tc = value;
            }

        }


        /**
         * <p>Java class for anonymous complex type.
         * 
         * <p>The following schema fragment specifies the expected content contained within this class.
         * 
         * <pre>
         * &lt;complexType>
         *   &lt;complexContent>
         *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
         *       &lt;sequence>
         *         &lt;element name="PersonId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
         *         &lt;element name="FirstName" type="{http://www.w3.org/2001/XMLSchema}string"/>
         *         &lt;element name="MiddleName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
         *         &lt;element name="LastName" type="{http://www.w3.org/2001/XMLSchema}string"/>
         *         &lt;element name="BirthDate" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
         *       &lt;/sequence>
         *     &lt;/restriction>
         *   &lt;/complexContent>
         * &lt;/complexType>
         * </pre>
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "", propOrder = {
            "personId",
            "firstName",
            "middleName",
            "lastName",
            "birthDate"
        })
        public static class Person {

            @XmlElement(name = "PersonId")
            protected String personId;
            @XmlElement(name = "FirstName", required = true)
            protected String firstName;
            @XmlElement(name = "MiddleName")
            protected String middleName;
            @XmlElement(name = "LastName", required = true)
            protected String lastName;
            @XmlElement(name = "BirthDate")
            protected String birthDate;

            /**
             * Gets the value of the personId property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getPersonId() {
                return personId;
            }

            /**
             * Sets the value of the personId property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setPersonId(String value) {
                this.personId = value;
            }

            /**
             * Gets the value of the firstName property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getFirstName() {
                return firstName;
            }

            /**
             * Sets the value of the firstName property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setFirstName(String value) {
                this.firstName = value;
            }

            /**
             * Gets the value of the middleName property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getMiddleName() {
                return middleName;
            }

            /**
             * Sets the value of the middleName property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setMiddleName(String value) {
                this.middleName = value;
            }

            /**
             * Gets the value of the lastName property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getLastName() {
                return lastName;
            }

            /**
             * Sets the value of the lastName property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setLastName(String value) {
                this.lastName = value;
            }

            /**
             * Gets the value of the birthDate property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getBirthDate() {
                return birthDate;
            }

            /**
             * Sets the value of the birthDate property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setBirthDate(String value) {
                this.birthDate = value;
            }

        }


        /**
         * <p>Java class for anonymous complex type.
         * 
         * <p>The following schema fragment specifies the expected content contained within this class.
         * 
         * <pre>
         * &lt;complexType>
         *   &lt;complexContent>
         *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
         *       &lt;sequence>
         *         &lt;element name="NIPRNumber" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
         *         &lt;element name="JHPayrollNumber" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
         *         &lt;element ref="{http://www.esb.manulife.com/xsd/Life/jh/Producer}JHAgencyNumber" minOccurs="0"/>
         *         &lt;element ref="{http://www.esb.manulife.com/xsd/Life/jh/Producer}LARSProducerStatus"/>
         *         &lt;element name="AgencyAffiliation" maxOccurs="unbounded" minOccurs="0">
         *           &lt;complexType>
         *             &lt;complexContent>
         *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
         *                 &lt;sequence>
         *                   &lt;element name="FullName" type="{http://www.w3.org/2001/XMLSchema}string"/>
         *                   &lt;element name="AbbrName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
         *                   &lt;element name="DBA" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
         *                   &lt;element ref="{http://www.esb.manulife.com/xsd/Life/jh/Producer}JHAgencyNumber" minOccurs="0"/>
         *                   &lt;element name="ContractStatus" minOccurs="0">
         *                     &lt;simpleType>
         *                       &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
         *                         &lt;enumeration value="Active"/>
         *                         &lt;enumeration value="Inactive"/>
         *                       &lt;/restriction>
         *                     &lt;/simpleType>
         *                   &lt;/element>
         *                 &lt;/sequence>
         *               &lt;/restriction>
         *             &lt;/complexContent>
         *           &lt;/complexType>
         *         &lt;/element>
         *         &lt;element name="JITInd" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
         *       &lt;/sequence>
         *     &lt;/restriction>
         *   &lt;/complexContent>
         * &lt;/complexType>
         * </pre>
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "", propOrder = {
            "niprNumber",
            "jhPayrollNumber",
            "jhAgencyNumber",
            "larsProducerStatus",
            "agencyAffiliation",
            "jitInd"
        })
        public static class Producer {

            @XmlElement(name = "NIPRNumber")
            protected Integer niprNumber;
            @XmlElement(name = "JHPayrollNumber")
            protected Integer jhPayrollNumber;
            @XmlElement(name = "JHAgencyNumber")
            protected BigInteger jhAgencyNumber;
            @XmlElement(name = "LARSProducerStatus", required = true)
            @XmlSchemaType(name = "nonNegativeInteger")
            protected BigInteger larsProducerStatus;

            public void setAgencyAffiliation(List<AgencyAffiliation> agencyAffiliation) {
                this.agencyAffiliation = agencyAffiliation;
            }

            @XmlElement(name = "AgencyAffiliation")
            protected List<GetProducerResponse.Party.Producer.AgencyAffiliation> agencyAffiliation;
            @XmlElement(name = "JITInd")
            protected Boolean jitInd;

            /**
             * Gets the value of the niprNumber property.
             * 
             * @return
             *     possible object is
             *     {@link Integer }
             *     
             */
            public Integer getNIPRNumber() {
                return niprNumber;
            }

            /**
             * Sets the value of the niprNumber property.
             * 
             * @param value
             *     allowed object is
             *     {@link Integer }
             *     
             */
            public void setNIPRNumber(Integer value) {
                this.niprNumber = value;
            }

            /**
             * Gets the value of the jhPayrollNumber property.
             * 
             * @return
             *     possible object is
             *     {@link Integer }
             *     
             */
            public Integer getJHPayrollNumber() {
                return jhPayrollNumber;
            }

            /**
             * Sets the value of the jhPayrollNumber property.
             * 
             * @param value
             *     allowed object is
             *     {@link Integer }
             *     
             */
            public void setJHPayrollNumber(Integer value) {
                this.jhPayrollNumber = value;
            }

            /**
             * Gets the value of the jhAgencyNumber property.
             * 
             * @return
             *     possible object is
             *     {@link BigInteger }
             *     
             */
            public BigInteger getJHAgencyNumber() {
                return jhAgencyNumber;
            }

            /**
             * Sets the value of the jhAgencyNumber property.
             * 
             * @param value
             *     allowed object is
             *     {@link BigInteger }
             *     
             */
            public void setJHAgencyNumber(BigInteger value) {
                this.jhAgencyNumber = value;
            }

            /**
             * Gets the value of the larsProducerStatus property.
             * 
             * @return
             *     possible object is
             *     {@link BigInteger }
             *     
             */
            public BigInteger getLARSProducerStatus() {
                return larsProducerStatus;
            }

            /**
             * Sets the value of the larsProducerStatus property.
             * 
             * @param value
             *     allowed object is
             *     {@link BigInteger }
             *     
             */
            public void setLARSProducerStatus(BigInteger value) {
                this.larsProducerStatus = value;
            }

            /**
             * Gets the value of the agencyAffiliation property.
             * 
             * <p>
             * This accessor method returns a reference to the live list,
             * not a snapshot. Therefore any modification you make to the
             * returned list will be present inside the JAXB object.
             * This is why there is not a <CODE>set</CODE> method for the agencyAffiliation property.
             * 
             * <p>
             * For example, to add a new item, do as follows:
             * <pre>
             *    getAgencyAffiliation().add(newItem);
             * </pre>
             * 
             * 
             * <p>
             * Objects of the following type(s) are allowed in the list
             * {@link GetProducerResponse.Party.Producer.AgencyAffiliation }
             * 
             * 
             */
            public List<GetProducerResponse.Party.Producer.AgencyAffiliation> getAgencyAffiliation() {
                if (agencyAffiliation == null) {
                    agencyAffiliation = new ArrayList<GetProducerResponse.Party.Producer.AgencyAffiliation>();
                }
                return this.agencyAffiliation;
            }

            /**
             * Gets the value of the jitInd property.
             * 
             * @return
             *     possible object is
             *     {@link Boolean }
             *     
             */
            public Boolean isJITInd() {
                return jitInd;
            }

            /**
             * Sets the value of the jitInd property.
             * 
             * @param value
             *     allowed object is
             *     {@link Boolean }
             *     
             */
            public void setJITInd(Boolean value) {
                this.jitInd = value;
            }


            /**
             * <p>Java class for anonymous complex type.
             * 
             * <p>The following schema fragment specifies the expected content contained within this class.
             * 
             * <pre>
             * &lt;complexType>
             *   &lt;complexContent>
             *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
             *       &lt;sequence>
             *         &lt;element name="FullName" type="{http://www.w3.org/2001/XMLSchema}string"/>
             *         &lt;element name="AbbrName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
             *         &lt;element name="DBA" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
             *         &lt;element ref="{http://www.esb.manulife.com/xsd/Life/jh/Producer}JHAgencyNumber" minOccurs="0"/>
             *         &lt;element name="ContractStatus" minOccurs="0">
             *           &lt;simpleType>
             *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
             *               &lt;enumeration value="Active"/>
             *               &lt;enumeration value="Inactive"/>
             *             &lt;/restriction>
             *           &lt;/simpleType>
             *         &lt;/element>
             *       &lt;/sequence>
             *     &lt;/restriction>
             *   &lt;/complexContent>
             * &lt;/complexType>
             * </pre>
             * 
             * 
             */
            @XmlAccessorType(XmlAccessType.FIELD)
            @XmlType(name = "", propOrder = {
                "fullName",
                "abbrName",
                "dba",
                "jhAgencyNumber",
                "contractStatus"
            })
            public static class AgencyAffiliation {

                @XmlElement(name = "FullName", required = true)
                protected String fullName;
                @XmlElement(name = "AbbrName")
                protected String abbrName;
                @XmlElement(name = "DBA")
                protected String dba;
                @XmlElement(name = "JHAgencyNumber")
                protected BigInteger jhAgencyNumber;
                @XmlElement(name = "ContractStatus")
                protected String contractStatus;

                /**
                 * Gets the value of the fullName property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getFullName() {
                    return fullName;
                }

                /**
                 * Sets the value of the fullName property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setFullName(String value) {
                    this.fullName = value;
                }

                /**
                 * Gets the value of the abbrName property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getAbbrName() {
                    return abbrName;
                }

                /**
                 * Sets the value of the abbrName property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setAbbrName(String value) {
                    this.abbrName = value;
                }

                /**
                 * Gets the value of the dba property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getDBA() {
                    return dba;
                }

                /**
                 * Sets the value of the dba property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setDBA(String value) {
                    this.dba = value;
                }

                /**
                 * Gets the value of the jhAgencyNumber property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link BigInteger }
                 *     
                 */
                public BigInteger getJHAgencyNumber() {
                    return jhAgencyNumber;
                }

                /**
                 * Sets the value of the jhAgencyNumber property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link BigInteger }
                 *     
                 */
                public void setJHAgencyNumber(BigInteger value) {
                    this.jhAgencyNumber = value;
                }

                /**
                 * Gets the value of the contractStatus property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getContractStatus() {
                    return contractStatus;
                }

                /**
                 * Sets the value of the contractStatus property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setContractStatus(String value) {
                    this.contractStatus = value;
                }

            }

        }

    }

}
