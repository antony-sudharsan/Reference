
package com.manulife.esb.xsd.life.jh.producer;

import java.math.BigInteger;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.manulife.esb.xsd.life.jh.producer package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _LARSProducerStatus_QNAME = new QName("http://www.esb.manulife.com/xsd/Life/jh/Producer", "LARSProducerStatus");
    private final static QName _JHAgencyNumber_QNAME = new QName("http://www.esb.manulife.com/xsd/Life/jh/Producer", "JHAgencyNumber");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.manulife.esb.xsd.life.jh.producer
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link License }
     * 
     */
    public License createLicense() {
        return new License();
    }

    /**
     * Create an instance of {@link PartyIds }
     * 
     */
    public PartyIds createPartyIds() {
        return new PartyIds();
    }

    /**
     * Create an instance of {@link ProducerIds2 }
     * 
     */
    public ProducerIds2 createProducerIds2() {
        return new ProducerIds2();
    }

    /**
     * Create an instance of {@link GetProducerResponse }
     * 
     */
    public GetProducerResponse createGetProducerResponse() {
        return new GetProducerResponse();
    }

    /**
     * Create an instance of {@link GetProducerResponse.Party }
     * 
     */
    public GetProducerResponse.Party createGetProducerResponseParty() {
        return new GetProducerResponse.Party();
    }

    /**
     * Create an instance of {@link GetProducerResponse.Party.Producer }
     * 
     */
    public GetProducerResponse.Party.Producer createGetProducerResponsePartyProducer() {
        return new GetProducerResponse.Party.Producer();
    }

    /**
     * Create an instance of {@link ProducerIds2 .CarrierAppointment }
     * 
     */
    public ProducerIds2 .CarrierAppointment createProducerIds2CarrierAppointment() {
        return new ProducerIds2 .CarrierAppointment();
    }

    /**
     * Create an instance of {@link ProducerIds2 .CarrierAppointment.LineOfAuthority }
     * 
     */
    public ProducerIds2 .CarrierAppointment.LineOfAuthority createProducerIds2CarrierAppointmentLineOfAuthority() {
        return new ProducerIds2 .CarrierAppointment.LineOfAuthority();
    }

    /**
     * Create an instance of {@link CheckLicenseStatusResponse }
     * 
     */
    public CheckLicenseStatusResponse createCheckLicenseStatusResponse() {
        return new CheckLicenseStatusResponse();
    }

    /**
     * Create an instance of {@link License.JHLARSLicenseStatusReason }
     * 
     */
    public License.JHLARSLicenseStatusReason createLicenseJHLARSLicenseStatusReason() {
        return new License.JHLARSLicenseStatusReason();
    }

    /**
     * Create an instance of {@link License.JHResponseType }
     * 
     */
    public License.JHResponseType createLicenseJHResponseType() {
        return new License.JHResponseType();
    }

    /**
     * Create an instance of {@link GetProducerRequest }
     * 
     */
    public GetProducerRequest createGetProducerRequest() {
        return new GetProducerRequest();
    }

    /**
     * Create an instance of {@link PartyIds.GovtIDTC }
     * 
     */
    public PartyIds.GovtIDTC createPartyIdsGovtIDTC() {
        return new PartyIds.GovtIDTC();
    }

    /**
     * Create an instance of {@link ProducerIds }
     * 
     */
    public ProducerIds createProducerIds() {
        return new ProducerIds();
    }

    /**
     * Create an instance of {@link ApplicationInfo }
     * 
     */
    public ApplicationInfo createApplicationInfo() {
        return new ApplicationInfo();
    }

    /**
     * Create an instance of {@link OLILUSTATE }
     * 
     */
    public OLILUSTATE createOLILUSTATE() {
        return new OLILUSTATE();
    }

    /**
     * Create an instance of {@link CheckLicenseStatusRequest }
     * 
     */
    public CheckLicenseStatusRequest createCheckLicenseStatusRequest() {
        return new CheckLicenseStatusRequest();
    }

    /**
     * Create an instance of {@link GetProducerResponse.Party.GovtIDTC }
     * 
     */
    public GetProducerResponse.Party.GovtIDTC createGetProducerResponsePartyGovtIDTC() {
        return new GetProducerResponse.Party.GovtIDTC();
    }

    /**
     * Create an instance of {@link GetProducerResponse.Party.Person }
     * 
     */
    public GetProducerResponse.Party.Person createGetProducerResponsePartyPerson() {
        return new GetProducerResponse.Party.Person();
    }

    /**
     * Create an instance of {@link GetProducerResponse.Party.Producer.AgencyAffiliation }
     * 
     */
    public GetProducerResponse.Party.Producer.AgencyAffiliation createGetProducerResponsePartyProducerAgencyAffiliation() {
        return new GetProducerResponse.Party.Producer.AgencyAffiliation();
    }

    /**
     * Create an instance of {@link ProducerIds2 .CarrierAppointment.LineOfAuthority.LineOfAuthorityType }
     * 
     */
    public ProducerIds2 .CarrierAppointment.LineOfAuthority.LineOfAuthorityType createProducerIds2CarrierAppointmentLineOfAuthorityLineOfAuthorityType() {
        return new ProducerIds2 .CarrierAppointment.LineOfAuthority.LineOfAuthorityType();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigInteger }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/Life/jh/Producer", name = "LARSProducerStatus")
    public JAXBElement<BigInteger> createLARSProducerStatus(BigInteger value) {
        return new JAXBElement<BigInteger>(_LARSProducerStatus_QNAME, BigInteger.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigInteger }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/Life/jh/Producer", name = "JHAgencyNumber")
    public JAXBElement<BigInteger> createJHAgencyNumber(BigInteger value) {
        return new JAXBElement<BigInteger>(_JHAgencyNumber_QNAME, BigInteger.class, null, value);
    }

}
