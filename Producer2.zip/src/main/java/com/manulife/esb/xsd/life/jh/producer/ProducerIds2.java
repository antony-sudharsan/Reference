
package com.manulife.esb.xsd.life.jh.producer;

import java.math.BigInteger;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="JHPayrollNumber" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="AYProducerID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CompanyProducerID" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="CompanyProducerIDJHTC">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}nonNegativeInteger">
 *               &lt;enumeration value="1"/>
 *               &lt;enumeration value="2"/>
 *               &lt;enumeration value="3"/>
 *               &lt;enumeration value="4"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CarrierAppointment">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="CarrierCode">
 *                     &lt;simpleType>
 *                       &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *                         &lt;enumeration value="65099"/>
 *                         &lt;enumeration value="90204"/>
 *                         &lt;enumeration value="65838"/>
 *                         &lt;enumeration value="86375"/>
 *                         &lt;enumeration value="93610"/>
 *                       &lt;/restriction>
 *                     &lt;/simpleType>
 *                   &lt;/element>
 *                   &lt;element name="LineOfAuthority">
 *                     &lt;complexType>
 *                       &lt;complexContent>
 *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                           &lt;sequence>
 *                             &lt;element name="LineOfAuthorityType">
 *                               &lt;complexType>
 *                                 &lt;complexContent>
 *                                   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                                     &lt;attribute name="tc">
 *                                       &lt;simpleType>
 *                                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *                                           &lt;enumeration value="1"/>
 *                                           &lt;enumeration value="2"/>
 *                                           &lt;enumeration value="4"/>
 *                                           &lt;enumeration value="5"/>
 *                                           &lt;enumeration value="6"/>
 *                                           &lt;enumeration value="49"/>
 *                                           &lt;enumeration value="92816"/>
 *                                           &lt;enumeration value="94763"/>
 *                                           &lt;enumeration value="94764"/>
 *                                           &lt;enumeration value="93927"/>
 *                                         &lt;/restriction>
 *                                       &lt;/simpleType>
 *                                     &lt;/attribute>
 *                                   &lt;/restriction>
 *                                 &lt;/complexContent>
 *                               &lt;/complexType>
 *                             &lt;/element>
 *                           &lt;/sequence>
 *                         &lt;/restriction>
 *                       &lt;/complexContent>
 *                     &lt;/complexType>
 *                   &lt;/element>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "jhPayrollNumber",
    "ayProducerID",
    "companyProducerID",
    "companyProducerIDJHTC",
    "carrierAppointment"
})
@XmlRootElement(name = "ProducerIds2")
public class ProducerIds2 {

    @XmlElement(name = "JHPayrollNumber")
    protected Integer jhPayrollNumber;
    @XmlElement(name = "AYProducerID")
    protected String ayProducerID;
    @XmlElement(name = "CompanyProducerID", required = true)
    protected String companyProducerID;
    @XmlElement(name = "CompanyProducerIDJHTC", required = true)
    protected BigInteger companyProducerIDJHTC;
    @XmlElement(name = "CarrierAppointment", required = true)
    protected ProducerIds2 .CarrierAppointment carrierAppointment;

    /**
     * Gets the value of the jhPayrollNumber property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getJHPayrollNumber() {
        return jhPayrollNumber;
    }

    /**
     * Sets the value of the jhPayrollNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setJHPayrollNumber(Integer value) {
        this.jhPayrollNumber = value;
    }

    /**
     * Gets the value of the ayProducerID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAYProducerID() {
        return ayProducerID;
    }

    /**
     * Sets the value of the ayProducerID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAYProducerID(String value) {
        this.ayProducerID = value;
    }

    /**
     * Gets the value of the companyProducerID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCompanyProducerID() {
        return companyProducerID;
    }

    /**
     * Sets the value of the companyProducerID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCompanyProducerID(String value) {
        this.companyProducerID = value;
    }

    /**
     * Gets the value of the companyProducerIDJHTC property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getCompanyProducerIDJHTC() {
        return companyProducerIDJHTC;
    }

    /**
     * Sets the value of the companyProducerIDJHTC property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setCompanyProducerIDJHTC(BigInteger value) {
        this.companyProducerIDJHTC = value;
    }

    /**
     * Gets the value of the carrierAppointment property.
     * 
     * @return
     *     possible object is
     *     {@link ProducerIds2 .CarrierAppointment }
     *     
     */
    public ProducerIds2 .CarrierAppointment getCarrierAppointment() {
        return carrierAppointment;
    }

    /**
     * Sets the value of the carrierAppointment property.
     * 
     * @param value
     *     allowed object is
     *     {@link ProducerIds2 .CarrierAppointment }
     *     
     */
    public void setCarrierAppointment(ProducerIds2 .CarrierAppointment value) {
        this.carrierAppointment = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="CarrierCode">
     *           &lt;simpleType>
     *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
     *               &lt;enumeration value="65099"/>
     *               &lt;enumeration value="90204"/>
     *               &lt;enumeration value="65838"/>
     *               &lt;enumeration value="86375"/>
     *               &lt;enumeration value="93610"/>
     *             &lt;/restriction>
     *           &lt;/simpleType>
     *         &lt;/element>
     *         &lt;element name="LineOfAuthority">
     *           &lt;complexType>
     *             &lt;complexContent>
     *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *                 &lt;sequence>
     *                   &lt;element name="LineOfAuthorityType">
     *                     &lt;complexType>
     *                       &lt;complexContent>
     *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *                           &lt;attribute name="tc">
     *                             &lt;simpleType>
     *                               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
     *                                 &lt;enumeration value="1"/>
     *                                 &lt;enumeration value="2"/>
     *                                 &lt;enumeration value="4"/>
     *                                 &lt;enumeration value="5"/>
     *                                 &lt;enumeration value="6"/>
     *                                 &lt;enumeration value="49"/>
     *                                 &lt;enumeration value="92816"/>
     *                                 &lt;enumeration value="94763"/>
     *                                 &lt;enumeration value="94764"/>
     *                                 &lt;enumeration value="93927"/>
     *                               &lt;/restriction>
     *                             &lt;/simpleType>
     *                           &lt;/attribute>
     *                         &lt;/restriction>
     *                       &lt;/complexContent>
     *                     &lt;/complexType>
     *                   &lt;/element>
     *                 &lt;/sequence>
     *               &lt;/restriction>
     *             &lt;/complexContent>
     *           &lt;/complexType>
     *         &lt;/element>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "carrierCode",
        "lineOfAuthority"
    })
    public static class CarrierAppointment {

        @XmlElement(name = "CarrierCode", required = true)
        protected String carrierCode;
        @XmlElement(name = "LineOfAuthority", required = true)
        protected ProducerIds2 .CarrierAppointment.LineOfAuthority lineOfAuthority;

        /**
         * Gets the value of the carrierCode property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getCarrierCode() {
            return carrierCode;
        }

        /**
         * Sets the value of the carrierCode property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setCarrierCode(String value) {
            this.carrierCode = value;
        }

        /**
         * Gets the value of the lineOfAuthority property.
         * 
         * @return
         *     possible object is
         *     {@link ProducerIds2 .CarrierAppointment.LineOfAuthority }
         *     
         */
        public ProducerIds2 .CarrierAppointment.LineOfAuthority getLineOfAuthority() {
            return lineOfAuthority;
        }

        /**
         * Sets the value of the lineOfAuthority property.
         * 
         * @param value
         *     allowed object is
         *     {@link ProducerIds2 .CarrierAppointment.LineOfAuthority }
         *     
         */
        public void setLineOfAuthority(ProducerIds2 .CarrierAppointment.LineOfAuthority value) {
            this.lineOfAuthority = value;
        }


        /**
         * <p>Java class for anonymous complex type.
         * 
         * <p>The following schema fragment specifies the expected content contained within this class.
         * 
         * <pre>
         * &lt;complexType>
         *   &lt;complexContent>
         *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
         *       &lt;sequence>
         *         &lt;element name="LineOfAuthorityType">
         *           &lt;complexType>
         *             &lt;complexContent>
         *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
         *                 &lt;attribute name="tc">
         *                   &lt;simpleType>
         *                     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
         *                       &lt;enumeration value="1"/>
         *                       &lt;enumeration value="2"/>
         *                       &lt;enumeration value="4"/>
         *                       &lt;enumeration value="5"/>
         *                       &lt;enumeration value="6"/>
         *                       &lt;enumeration value="49"/>
         *                       &lt;enumeration value="92816"/>
         *                       &lt;enumeration value="94763"/>
         *                       &lt;enumeration value="94764"/>
         *                       &lt;enumeration value="93927"/>
         *                     &lt;/restriction>
         *                   &lt;/simpleType>
         *                 &lt;/attribute>
         *               &lt;/restriction>
         *             &lt;/complexContent>
         *           &lt;/complexType>
         *         &lt;/element>
         *       &lt;/sequence>
         *     &lt;/restriction>
         *   &lt;/complexContent>
         * &lt;/complexType>
         * </pre>
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "", propOrder = {
            "lineOfAuthorityType"
        })
        public static class LineOfAuthority {

            @XmlElement(name = "LineOfAuthorityType", required = true)
            protected ProducerIds2 .CarrierAppointment.LineOfAuthority.LineOfAuthorityType lineOfAuthorityType;

            /**
             * Gets the value of the lineOfAuthorityType property.
             * 
             * @return
             *     possible object is
             *     {@link ProducerIds2 .CarrierAppointment.LineOfAuthority.LineOfAuthorityType }
             *     
             */
            public ProducerIds2 .CarrierAppointment.LineOfAuthority.LineOfAuthorityType getLineOfAuthorityType() {
                return lineOfAuthorityType;
            }

            /**
             * Sets the value of the lineOfAuthorityType property.
             * 
             * @param value
             *     allowed object is
             *     {@link ProducerIds2 .CarrierAppointment.LineOfAuthority.LineOfAuthorityType }
             *     
             */
            public void setLineOfAuthorityType(ProducerIds2 .CarrierAppointment.LineOfAuthority.LineOfAuthorityType value) {
                this.lineOfAuthorityType = value;
            }


            /**
             * <p>Java class for anonymous complex type.
             * 
             * <p>The following schema fragment specifies the expected content contained within this class.
             * 
             * <pre>
             * &lt;complexType>
             *   &lt;complexContent>
             *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
             *       &lt;attribute name="tc">
             *         &lt;simpleType>
             *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
             *             &lt;enumeration value="1"/>
             *             &lt;enumeration value="2"/>
             *             &lt;enumeration value="4"/>
             *             &lt;enumeration value="5"/>
             *             &lt;enumeration value="6"/>
             *             &lt;enumeration value="49"/>
             *             &lt;enumeration value="92816"/>
             *             &lt;enumeration value="94763"/>
             *             &lt;enumeration value="94764"/>
             *             &lt;enumeration value="93927"/>
             *           &lt;/restriction>
             *         &lt;/simpleType>
             *       &lt;/attribute>
             *     &lt;/restriction>
             *   &lt;/complexContent>
             * &lt;/complexType>
             * </pre>
             * 
             * 
             */
            @XmlAccessorType(XmlAccessType.FIELD)
            @XmlType(name = "")
            public static class LineOfAuthorityType {

                @XmlAttribute(name = "tc")
                protected String tc;

                /**
                 * Gets the value of the tc property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getTc() {
                    return tc;
                }

                /**
                 * Sets the value of the tc property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setTc(String value) {
                    this.tc = value;
                }

            }

        }

    }

}
