
package com.manulife.esb.xsd.life.jh.producer;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/Life/jh/Producer}PartyIds"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/Life/jh/Producer}ProducerIds2" minOccurs="0"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/Life/jh/Producer}ApplicationInfo"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "partyIds",
    "producerIds2",
    "applicationInfo"
})
@XmlRootElement(name = "CheckLicenseStatus_request")
public class CheckLicenseStatusRequest {

    @XmlElement(name = "PartyIds", required = true)
    protected PartyIds partyIds;
    @XmlElement(name = "ProducerIds2")
    protected ProducerIds2 producerIds2;
    @XmlElement(name = "ApplicationInfo", required = true)
    protected ApplicationInfo applicationInfo;

    /**
     * Gets the value of the partyIds property.
     * 
     * @return
     *     possible object is
     *     {@link PartyIds }
     *     
     */
    public PartyIds getPartyIds() {
        return partyIds;
    }

    /**
     * Sets the value of the partyIds property.
     * 
     * @param value
     *     allowed object is
     *     {@link PartyIds }
     *     
     */
    public void setPartyIds(PartyIds value) {
        this.partyIds = value;
    }

    /**
     * Gets the value of the producerIds2 property.
     * 
     * @return
     *     possible object is
     *     {@link ProducerIds2 }
     *     
     */
    public ProducerIds2 getProducerIds2() {
        return producerIds2;
    }

    /**
     * Sets the value of the producerIds2 property.
     * 
     * @param value
     *     allowed object is
     *     {@link ProducerIds2 }
     *     
     */
    public void setProducerIds2(ProducerIds2 value) {
        this.producerIds2 = value;
    }

    /**
     * Gets the value of the applicationInfo property.
     * 
     * @return
     *     possible object is
     *     {@link ApplicationInfo }
     *     
     */
    public ApplicationInfo getApplicationInfo() {
        return applicationInfo;
    }

    /**
     * Sets the value of the applicationInfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link ApplicationInfo }
     *     
     */
    public void setApplicationInfo(ApplicationInfo value) {
        this.applicationInfo = value;
    }

}
