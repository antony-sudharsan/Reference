
package com.manulife.esb.xsd.life.jh.producer;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="ApplicationJurisdiction" type="{http://www.esb.manulife.com/xsd/Life/jh/Producer}OLI_LU_STATE"/>
 *         &lt;element name="SignedDate" type="{http://www.w3.org/2001/XMLSchema}date"/>
 *         &lt;element name="SubmissionDate" type="{http://www.w3.org/2001/XMLSchema}date"/>
 *         &lt;element name="ResidenceJurisdictionAtIssue" type="{http://www.esb.manulife.com/xsd/Life/jh/Producer}OLI_LU_STATE"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "applicationJurisdiction",
    "signedDate",
    "submissionDate",
    "residenceJurisdictionAtIssue"
})
@XmlRootElement(name = "ApplicationInfo")
public class ApplicationInfo {

    @XmlElement(name = "ApplicationJurisdiction", required = true)
    protected OLILUSTATE applicationJurisdiction;
    @XmlElement(name = "SignedDate", required = true)
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar signedDate;
    @XmlElement(name = "SubmissionDate", required = true)
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar submissionDate;
    @XmlElement(name = "ResidenceJurisdictionAtIssue", required = true)
    protected OLILUSTATE residenceJurisdictionAtIssue;

    /**
     * Gets the value of the applicationJurisdiction property.
     * 
     * @return
     *     possible object is
     *     {@link OLILUSTATE }
     *     
     */
    public OLILUSTATE getApplicationJurisdiction() {
        return applicationJurisdiction;
    }

    /**
     * Sets the value of the applicationJurisdiction property.
     * 
     * @param value
     *     allowed object is
     *     {@link OLILUSTATE }
     *     
     */
    public void setApplicationJurisdiction(OLILUSTATE value) {
        this.applicationJurisdiction = value;
    }

    /**
     * Gets the value of the signedDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getSignedDate() {
        return signedDate;
    }

    /**
     * Sets the value of the signedDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setSignedDate(XMLGregorianCalendar value) {
        this.signedDate = value;
    }

    /**
     * Gets the value of the submissionDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getSubmissionDate() {
        return submissionDate;
    }

    /**
     * Sets the value of the submissionDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setSubmissionDate(XMLGregorianCalendar value) {
        this.submissionDate = value;
    }

    /**
     * Gets the value of the residenceJurisdictionAtIssue property.
     * 
     * @return
     *     possible object is
     *     {@link OLILUSTATE }
     *     
     */
    public OLILUSTATE getResidenceJurisdictionAtIssue() {
        return residenceJurisdictionAtIssue;
    }

    /**
     * Sets the value of the residenceJurisdictionAtIssue property.
     * 
     * @param value
     *     allowed object is
     *     {@link OLILUSTATE }
     *     
     */
    public void setResidenceJurisdictionAtIssue(OLILUSTATE value) {
        this.residenceJurisdictionAtIssue = value;
    }

}
