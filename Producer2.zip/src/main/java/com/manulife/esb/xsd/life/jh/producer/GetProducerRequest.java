
package com.manulife.esb.xsd.life.jh.producer;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/Life/jh/Producer}PartyIds"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/Life/jh/Producer}ProducerIds" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "partyIds",
    "producerIds"
})
@XmlRootElement(name = "GetProducer_request")
public class GetProducerRequest {

    @XmlElement(name = "PartyIds", required = true)
    protected PartyIds partyIds;
    @XmlElement(name = "ProducerIds")
    protected ProducerIds producerIds;

    /**
     * Gets the value of the partyIds property.
     * 
     * @return
     *     possible object is
     *     {@link PartyIds }
     *     
     */
    public PartyIds getPartyIds() {
        return partyIds;
    }

    /**
     * Sets the value of the partyIds property.
     * 
     * @param value
     *     allowed object is
     *     {@link PartyIds }
     *     
     */
    public void setPartyIds(PartyIds value) {
        this.partyIds = value;
    }

    /**
     * Gets the value of the producerIds property.
     * 
     * @return
     *     possible object is
     *     {@link ProducerIds }
     *     
     */
    public ProducerIds getProducerIds() {
        return producerIds;
    }

    /**
     * Sets the value of the producerIds property.
     * 
     * @param value
     *     allowed object is
     *     {@link ProducerIds }
     *     
     */
    public void setProducerIds(ProducerIds value) {
        this.producerIds = value;
    }

}
