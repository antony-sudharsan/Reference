@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.esb.manulife.com/xsd/Life/jh/Producer", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.manulife.esb.xsd.life.jh.producer;
