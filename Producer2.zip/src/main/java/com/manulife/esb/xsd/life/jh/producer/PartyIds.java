
package com.manulife.esb.xsd.life.jh.producer;

import java.math.BigInteger;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="PartyTypeCode" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="GovtID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="GovtIDTC" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;attribute name="tc" type="{http://www.w3.org/2001/XMLSchema}nonNegativeInteger" />
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "partyTypeCode",
    "govtID",
    "govtIDTC"
})
@XmlRootElement(name = "PartyIds")
public class PartyIds {

    @XmlElement(name = "PartyTypeCode", required = true)
    protected String partyTypeCode;
    @XmlElement(name = "GovtID")
    protected String govtID;
    @XmlElement(name = "GovtIDTC")
    protected PartyIds.GovtIDTC govtIDTC;

    /**
     * Gets the value of the partyTypeCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPartyTypeCode() {
        return partyTypeCode;
    }

    /**
     * Sets the value of the partyTypeCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPartyTypeCode(String value) {
        this.partyTypeCode = value;
    }

    /**
     * Gets the value of the govtID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGovtID() {
        return govtID;
    }

    /**
     * Sets the value of the govtID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGovtID(String value) {
        this.govtID = value;
    }

    /**
     * Gets the value of the govtIDTC property.
     * 
     * @return
     *     possible object is
     *     {@link PartyIds.GovtIDTC }
     *     
     */
    public PartyIds.GovtIDTC getGovtIDTC() {
        return govtIDTC;
    }

    /**
     * Sets the value of the govtIDTC property.
     * 
     * @param value
     *     allowed object is
     *     {@link PartyIds.GovtIDTC }
     *     
     */
    public void setGovtIDTC(PartyIds.GovtIDTC value) {
        this.govtIDTC = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;attribute name="tc" type="{http://www.w3.org/2001/XMLSchema}nonNegativeInteger" />
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "")
    public static class GovtIDTC {

        @XmlAttribute(name = "tc")
        @XmlSchemaType(name = "nonNegativeInteger")
        protected BigInteger tc;

        /**
         * Gets the value of the tc property.
         * 
         * @return
         *     possible object is
         *     {@link BigInteger }
         *     
         */
        public BigInteger getTc() {
            return tc;
        }

        /**
         * Sets the value of the tc property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigInteger }
         *     
         */
        public void setTc(BigInteger value) {
            this.tc = value;
        }

    }

}
