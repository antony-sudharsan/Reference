package com.jh.life.producertwo.orchestration;

import com.jh.common.logging.LoggerHandler;
import com.jh.life.producertwo.dao.ProducerDAO;
import com.jh.life.producertwo.model.*;
import com.jh.life.producertwo.transformation.ProducerDataTransformer;
import com.jh.life.producertwo.utils.LoggerUtils;
import com.jh.life.producertwo.utils.ProducerUtils;
import com.manulife.esb.xsd.common.jh.header.JHHeader;
import com.manulife.esb.xsd.common.jh.header.MessageSource;
import com.manulife.esb.xsd.common.jh.header.ServiceInfo;
import com.manulife.esb.xsd.life.jh.producer.*;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.junit4.SpringRunner;

import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;
import java.math.BigInteger;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.*;
import static org.mockito.Mockito.when;

/**
 * The type Producer orchestration test.
 */
@RunWith(SpringRunner.class)
public class ProducerOrchestrationTest {

    /**
     * The Producer dao.
     */
    @Mock
    ProducerDAO producerDAO;

    /**
     * The Producer orchestration.
     */
    @InjectMocks
    ProducerOrchestration producerOrchestration;

    /**
     * The Producer utils.
     */
    @Mock
    ProducerUtils producerUtils;

    @Mock
    private LoggerUtils loggerUtils;
    /**
     * The Producer data transformer.
     */
    @Mock
    ProducerDataTransformer producerDataTransformer;


    /**
     * The Check license status request.
     */
    CheckLicenseStatusRequest checkLicenseStatusRequest = null;
    /**
     * The Check license status response wrapper.
     */
    CheckLicenseStatusResponseWrapper checkLicenseStatusResponseWrapper = null;
    /**
     * The Header.
     */
    JHHeader header = null;
    /**
     * The Check license request wrapper.
     */
    CheckLicenseStatusRequestWrapper checkLicenseRequestWrapper = null;
    /**
     * The Get producer response wrapper.
     */
    GetProducerResponseWrapper getProducerResponseWrapper = null;
    /**
     * The Producer request.
     */
    GetProducerRequest producerRequest = null;
    /**
     * The Producer request wrapper.
     */
    GetProducerRequestWrapper producerRequestWrapper = null;

    /**
     * The License check in.
     */
    LicenseCheckIn licenseCheckIn = new LicenseCheckIn();

    /**
     * The Producer status in.
     */
    ProducerStatusIn producerStatusIn = new ProducerStatusIn();

    /**
     * Sets up.
     *
     * @throws Exception the exception
     */
    @Before
    public void setUp() throws Exception {

        MockitoAnnotations.initMocks(this);

        checkLicenseStatusResponseWrapper = populateCheckLicenseStatusResponse();
        checkLicenseRequestWrapper = populateCheckLicenseStatusRequest();
        getProducerResponseWrapper = populateGetProducerResponse();
        producerRequestWrapper = populateGetProducerRequest();

    }


    /**
     * Check license status.
     *
     * @throws Exception the exception
     */
    @Test
    public void checkLicenseStatus() throws Exception {
        when(producerDAO.getLicenseStatus(header,licenseCheckIn )).thenReturn(checkLicenseStatusResponseWrapper);
        producerOrchestration.checkLicenseStatus(header, checkLicenseRequestWrapper.getCheckLicenseStatusRequest());
        LoggerHandler.LogOut("INFO", "6", "", "", this.getClass().getName(),
                "checkLicenseStatusResponseWrapper >> " + loggerUtils.writeAsJson(checkLicenseStatusResponseWrapper));
        assertEquals("69890",checkLicenseStatusResponseWrapper.getCheckLicenseStatusResponse().getLicense().getJHLARSLicenseStatusCode());
        assertEquals("0",checkLicenseStatusResponseWrapper.getCheckLicenseStatusResponse().getLicense().getJHLARSLicenseStatusReason().getJHLARSLicenseErrorCode());
        assertEquals("Success - Producer Licensed to receive payment",checkLicenseStatusResponseWrapper.getCheckLicenseStatusResponse().getLicense().getJHLARSLicenseStatusReason().getJHLARSLicenseErrorMessage() );
    }

    /**
     * Gets producer.
     *
     * @throws Exception the exception
     */
    @Test
    public void getProducer() throws Exception {



    }

    /**
     *
     * @return
     */
    private GetProducerResponseWrapper populateGetProducerResponse() {
        GetProducerResponseWrapper producerResponseWrapper = new GetProducerResponseWrapper();

        GetProducerResponse getProducerResponse = new GetProducerResponse();
        GetProducerResponse.Party party = new GetProducerResponse.Party();

        MessageSource messageSource = new MessageSource();
        ServiceInfo serviceInfo = new ServiceInfo();

        header = new JHHeader();
        header.setMessageSource(messageSource);
        header.setServiceInfo(serviceInfo);
        header.setMessageUID("AAAA");

        messageSource.setUserID("CallidusCloud");
        messageSource.setApplicationName("575812");
        messageSource.setApplicationUserID("CallidusCloud");
        messageSource.setHostName("174.129.237.57");
        messageSource.setProcessID("1");

        serviceInfo.setServiceName("Producer");
        serviceInfo.setServiceOperation("CheckLicenseStatus");
        serviceInfo.setServiceVersion("1.0");

        party.setGovtID("1234");
        party.setFullName("Alex");
        party.setPartyTypeCode("AAA");
        getProducerResponse.setParty(party);

        producerResponseWrapper.setGetProducerResponse(getProducerResponse);
        producerResponseWrapper.setHeader(header);
        return producerResponseWrapper;
    }

    /**
     *
     * @return
     */
    private CheckLicenseStatusResponseWrapper populateCheckLicenseStatusResponse() {
        CheckLicenseStatusResponseWrapper reply = new CheckLicenseStatusResponseWrapper();
        CheckLicenseStatusResponse checkLicenseStatusResponse = new CheckLicenseStatusResponse();
        License license = new License();
        License.JHLARSLicenseStatusReason jhlarsLicenseStatusReason = new License.JHLARSLicenseStatusReason();

        MessageSource messageSource = new MessageSource();
        ServiceInfo serviceInfo = new ServiceInfo();

        header = new JHHeader();
        header.setMessageSource(messageSource);
        header.setServiceInfo(serviceInfo);
        header.setMessageUID("AAAA");

        messageSource.setUserID("CallidusCloud");
        messageSource.setApplicationName("575812");
        messageSource.setApplicationUserID("CallidusCloud");
        messageSource.setHostName("174.129.237.57");
        messageSource.setProcessID("1");

        serviceInfo.setServiceName("Producer");
        serviceInfo.setServiceOperation("CheckLicenseStatus");
        serviceInfo.setServiceVersion("1.0");


        license.setJHLARSLicenseStatusCode("69890");
        jhlarsLicenseStatusReason.setJHLARSLicenseErrorCode("0");
        jhlarsLicenseStatusReason.setJHLARSLicenseErrorMessage("Success - Producer Licensed to receive payment");
        List<License.JHResponseType> reponseTypeList = new ArrayList<>();
        License.JHResponseType jhResponseType = new License.JHResponseType();
        jhResponseType.setCode("72287");
        jhResponseType.setValue("041603777");

        reponseTypeList.add(jhResponseType);

        license.setJhResponseType(reponseTypeList);
        license.setJHLARSLicenseStatusReason(jhlarsLicenseStatusReason);
        checkLicenseStatusResponse.setLicense(license);

        reply.setHeader(header);
        reply.setCheckLicenseStatusResponse(checkLicenseStatusResponse);
        return reply;
    }

    /**
     *
     * @return
     * @throws Exception
     */
    private CheckLicenseStatusRequestWrapper populateCheckLicenseStatusRequest() throws Exception  {
        checkLicenseStatusRequest = new CheckLicenseStatusRequest();
        checkLicenseRequestWrapper = new CheckLicenseStatusRequestWrapper();
        PartyIds partyIds = new PartyIds();
        ProducerIds2 producerIds2 = new ProducerIds2();
        ApplicationInfo applicationInfo = new ApplicationInfo();
        MessageSource messageSource = new MessageSource();
        ServiceInfo serviceInfo = new ServiceInfo();
        OLILUSTATE applicationJurisdiction = new OLILUSTATE();
        OLILUSTATE residenceJurisdictionAtIssue = new OLILUSTATE();
        ProducerIds2.CarrierAppointment carrierAppointment = new ProducerIds2.CarrierAppointment();
        ProducerIds2.CarrierAppointment.LineOfAuthority lineOfAuthority = new ProducerIds2.CarrierAppointment.LineOfAuthority();
        ProducerIds2.CarrierAppointment.LineOfAuthority.LineOfAuthorityType lineOfAuthorityType = new ProducerIds2.CarrierAppointment.LineOfAuthority.LineOfAuthorityType();
        PartyIds.GovtIDTC govtIDTC = new PartyIds.GovtIDTC();

        carrierAppointment.setCarrierCode("65838");
        //  producerIds2.setAYProducerID();
        producerIds2.setCompanyProducerID("103");
        producerIds2.setCompanyProducerIDJHTC(BigInteger.valueOf(1));
        producerIds2.setJHPayrollNumber(159887);

        //partyIds.setGovtID("0");
        partyIds.setPartyTypeCode("1");
        govtIDTC.setTc(BigInteger.valueOf(1));
        lineOfAuthorityType.setTc("93927");

        applicationJurisdiction.setTc(BigInteger.valueOf(26));
        residenceJurisdictionAtIssue.setTc(BigInteger.valueOf(26));

        messageSource.setUserID("CallidusCloud");
        messageSource.setApplicationName("575812");
        messageSource.setApplicationUserID("CallidusCloud");
        messageSource.setHostName("174.129.237.57");
        messageSource.setProcessID("1");

        serviceInfo.setServiceName("Producer");
        serviceInfo.setServiceOperation("CheckLicenseStatus");
        serviceInfo.setServiceVersion("1.0");

        XMLGregorianCalendar result = DatatypeFactory.newInstance().newXMLGregorianCalendar("2013-05-06");
        applicationInfo.setSignedDate(result);
        applicationInfo.setSubmissionDate(result);

        header.setMessageSource(messageSource);
        header.setServiceInfo(serviceInfo);
        header.setMessageUID("AAAA");
        lineOfAuthority.setLineOfAuthorityType(lineOfAuthorityType);
        partyIds.setGovtIDTC(govtIDTC);
        carrierAppointment.setLineOfAuthority(lineOfAuthority);
        producerIds2.setCarrierAppointment(carrierAppointment);
        applicationInfo.setApplicationJurisdiction(applicationJurisdiction);
        applicationInfo.setResidenceJurisdictionAtIssue(residenceJurisdictionAtIssue);
        checkLicenseStatusRequest.setPartyIds(partyIds);
        checkLicenseStatusRequest.setApplicationInfo(applicationInfo);
        checkLicenseStatusRequest.setProducerIds2(producerIds2);

        checkLicenseRequestWrapper.setCheckLicenseStatusRequest(checkLicenseStatusRequest);
        checkLicenseRequestWrapper.setHeader(header);
        return checkLicenseRequestWrapper;
    }

    /**
     *
     * @return
     * @throws Exception
     */
    private GetProducerRequestWrapper populateGetProducerRequest() throws Exception  {
        producerRequestWrapper = new GetProducerRequestWrapper();

        MessageSource messageSource = new MessageSource();
        ServiceInfo serviceInfo = new ServiceInfo();

        header = new JHHeader();
        header.setMessageSource(messageSource);
        header.setServiceInfo(serviceInfo);
        header.setMessageUID("AAAA");

        messageSource.setUserID("CallidusCloud");
        messageSource.setApplicationName("575812");
        messageSource.setApplicationUserID("CallidusCloud");
        messageSource.setHostName("174.129.237.57");
        messageSource.setProcessID("1");

        serviceInfo.setServiceName("Producer");
        serviceInfo.setServiceOperation("CheckLicenseStatus");
        serviceInfo.setServiceVersion("1.0");

        producerRequest = new GetProducerRequest();

        producerRequestWrapper.setHeader(header);
        producerRequestWrapper.setGetProducerRequest(producerRequest);

        return producerRequestWrapper;
    }

}