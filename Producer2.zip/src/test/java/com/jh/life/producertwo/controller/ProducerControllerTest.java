package com.jh.life.producertwo.controller;

import com.jh.life.producertwo.model.CheckLicenseStatusRequestWrapper;
import com.jh.life.producertwo.model.CheckLicenseStatusResponseWrapper;
import com.jh.life.producertwo.model.GetProducerRequestWrapper;
import com.jh.life.producertwo.model.GetProducerResponseWrapper;
import com.jh.life.producertwo.orchestration.ProducerOrchestration;
import com.jh.life.producertwo.utils.JHHeaderUtils;
import com.jh.life.producertwo.utils.LoggerUtils;
import com.manulife.esb.xsd.common.jh.header.JHHeader;
import com.manulife.esb.xsd.common.jh.header.*;
import com.manulife.esb.xsd.life.jh.producer.CheckLicenseStatusRequest;
import com.manulife.esb.xsd.life.jh.producer.CheckLicenseStatusResponse;
import com.manulife.esb.xsd.life.jh.producer.License;
import com.manulife.esb.xsd.life.jh.producer.*;
import org.codehaus.jackson.map.ObjectMapper;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;

import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import static org.hamcrest.CoreMatchers.is;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;


/**
 * The type Producer controller test.
 */
@RunWith(SpringRunner.class)
/**
 * @WebMvcTest.
 * It will auto-configure the Spring MVC infrastructure for our unit tests.
 * Setting up WebMvc Context for the Controller which is under test("AnnuityController")
 */
@WebMvcTest(ProducerController.class)
public class ProducerControllerTest {

    /**
     * Initializing MockMvc
     */
    @Autowired
    private MockMvc mvc;
    /**
     * The Producer orchestration.
     *
     * @MockBean The class is included in the spring-boot-test library. It allows to add Mockito mocks in a Spring ApplicationContext. If a bean, compatible with the declared class exists in the context, it replaces it by the mock. If it is not the case, it adds the mock in the context as a bean.
     */
    @MockBean
    ProducerOrchestration producerOrchestration;

    /**
     * The Logger utils.
     */
    @MockBean
    LoggerUtils loggerUtils;

    /**
     * The Header utils.
     */
    @MockBean
    JHHeaderUtils headerUtils;

    /**
     * The Check license status request.
     */
    CheckLicenseStatusRequest checkLicenseStatusRequest = null;
    /**
     * The Check license status response wrapper.
     */
    CheckLicenseStatusResponseWrapper checkLicenseStatusResponseWrapper = null;
    /**
     * The Header.
     */
    JHHeader header = null;
    /**
     * The Check license request wrapper.
     */
    CheckLicenseStatusRequestWrapper checkLicenseRequestWrapper = null;
    /**
     * The Get producer response wrapper.
     */
    GetProducerResponseWrapper getProducerResponseWrapper = null;
    /**
     * The Producer request.
     */
    GetProducerRequest producerRequest = null;
    /**
     * The Producer request wrapper.
     */
    GetProducerRequestWrapper producerRequestWrapper = null;

    /**
     * Sets up.
     *
     * @throws Exception the exception
     */
    @Before
    public void setUp() throws Exception {

        checkLicenseStatusResponseWrapper = populateCheckLicenseStatusResponse();
        checkLicenseRequestWrapper = populateCheckLicenseStatusRequest();
        getProducerResponseWrapper = populateGetProducerResponse();
        producerRequestWrapper = populateGetProducerRequest();
    }


    /**
     * Check license status.
     *
     * @throws Exception the exception
     */
    @Test
    public void checkLicenseStatus() throws Exception {
        when(producerOrchestration.checkLicenseStatus(any(JHHeader.class), any(CheckLicenseStatusRequest.class))).thenReturn(checkLicenseStatusResponseWrapper);
        mvc.perform(post("/jh/common/producer/license/checkstatus")
                .content(asJsonString(checkLicenseRequestWrapper))
                .accept(MediaType.APPLICATION_JSON_VALUE)
                .contentType(MediaType.APPLICATION_JSON_VALUE)).andDo(print())
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.checkLicenseStatusResponse.license.jhlarslicenseStatusCode").value("69890"))
                .andExpect(jsonPath("$.checkLicenseStatusResponse.license.jhlarslicenseStatusReason.jhlarslicenseErrorCode").value("0"))
                .andExpect(jsonPath("$.checkLicenseStatusResponse.license.jhlarslicenseStatusReason.jhlarslicenseErrorMessage").value("Success - Producer Licensed to receive payment"));
    }

    /**
     * Gets producer.
     *
     * @throws Exception the exception
     */
    @Test
    public void getProducer() throws Exception {
        when(producerOrchestration.getProducer(any(JHHeader.class), any(GetProducerRequest.class))).thenReturn(getProducerResponseWrapper);
        mvc.perform(post("/jh/common/producer/statusdetails")
                .content(asJsonString(producerRequestWrapper))
                .accept(MediaType.APPLICATION_JSON_VALUE)
                .contentType(MediaType.APPLICATION_JSON_VALUE)).andDo(print())
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.getProducerResponse.party.partyTypeCode").value("AAA"))
                .andExpect(jsonPath("$.getProducerResponse.party.fullName").value("Alex"))
                .andExpect(jsonPath("$.getProducerResponse.party.govtID").value("1234"));
    }

    /**
     *
     * @return
     */
    private GetProducerResponseWrapper populateGetProducerResponse() {
        GetProducerResponseWrapper producerResponseWrapper = new GetProducerResponseWrapper();

        GetProducerResponse getProducerResponse = new GetProducerResponse();
        GetProducerResponse.Party party = new GetProducerResponse.Party();

        MessageSource messageSource = new MessageSource();
        ServiceInfo serviceInfo = new ServiceInfo();

        header = new JHHeader();
        header.setMessageSource(messageSource);
        header.setServiceInfo(serviceInfo);
        header.setMessageUID("AAAA");

        messageSource.setUserID("CallidusCloud");
        messageSource.setApplicationName("575812");
        messageSource.setApplicationUserID("CallidusCloud");
        messageSource.setHostName("174.129.237.57");
        messageSource.setProcessID("1");

        serviceInfo.setServiceName("Producer");
        serviceInfo.setServiceOperation("CheckLicenseStatus");
        serviceInfo.setServiceVersion("1.0");

        party.setGovtID("1234");
        party.setFullName("Alex");
        party.setPartyTypeCode("AAA");
        getProducerResponse.setParty(party);

        producerResponseWrapper.setGetProducerResponse(getProducerResponse);
        producerResponseWrapper.setHeader(header);
        return producerResponseWrapper;
    }

    /**
     *
     * @return
     */
    private CheckLicenseStatusResponseWrapper populateCheckLicenseStatusResponse() {
        CheckLicenseStatusResponseWrapper reply = new CheckLicenseStatusResponseWrapper();
        CheckLicenseStatusResponse checkLicenseStatusResponse = new CheckLicenseStatusResponse();
        License license = new License();
        License.JHLARSLicenseStatusReason jhlarsLicenseStatusReason = new License.JHLARSLicenseStatusReason();

        MessageSource messageSource = new MessageSource();
        ServiceInfo serviceInfo = new ServiceInfo();

        header = new JHHeader();
        header.setMessageSource(messageSource);
        header.setServiceInfo(serviceInfo);
        header.setMessageUID("AAAA");

        messageSource.setUserID("CallidusCloud");
        messageSource.setApplicationName("575812");
        messageSource.setApplicationUserID("CallidusCloud");
        messageSource.setHostName("174.129.237.57");
        messageSource.setProcessID("1");

        serviceInfo.setServiceName("Producer");
        serviceInfo.setServiceOperation("CheckLicenseStatus");
        serviceInfo.setServiceVersion("1.0");


        license.setJHLARSLicenseStatusCode("69890");
        jhlarsLicenseStatusReason.setJHLARSLicenseErrorCode("0");
        jhlarsLicenseStatusReason.setJHLARSLicenseErrorMessage("Success - Producer Licensed to receive payment");
        List<License.JHResponseType> reponseTypeList = new ArrayList<>();
        License.JHResponseType jhResponseType = new License.JHResponseType();
        jhResponseType.setCode("72287");
        jhResponseType.setValue("041603777");

        reponseTypeList.add(jhResponseType);

        license.setJhResponseType(reponseTypeList);
        license.setJHLARSLicenseStatusReason(jhlarsLicenseStatusReason);
        checkLicenseStatusResponse.setLicense(license);

        reply.setHeader(header);
        reply.setCheckLicenseStatusResponse(checkLicenseStatusResponse);
        return reply;
    }

    /**
     *
     * @return
     * @throws Exception
     */
    private CheckLicenseStatusRequestWrapper populateCheckLicenseStatusRequest() throws Exception  {
        checkLicenseStatusRequest = new CheckLicenseStatusRequest();
        checkLicenseRequestWrapper = new CheckLicenseStatusRequestWrapper();
        PartyIds partyIds = new PartyIds();
        ProducerIds2 producerIds2 = new ProducerIds2();
        ApplicationInfo applicationInfo = new ApplicationInfo();
        MessageSource messageSource = new MessageSource();
        ServiceInfo serviceInfo = new ServiceInfo();
        OLILUSTATE applicationJurisdiction = new OLILUSTATE();
        OLILUSTATE residenceJurisdictionAtIssue = new OLILUSTATE();
        ProducerIds2.CarrierAppointment carrierAppointment = new ProducerIds2.CarrierAppointment();
        ProducerIds2.CarrierAppointment.LineOfAuthority lineOfAuthority = new ProducerIds2.CarrierAppointment.LineOfAuthority();
        ProducerIds2.CarrierAppointment.LineOfAuthority.LineOfAuthorityType lineOfAuthorityType = new ProducerIds2.CarrierAppointment.LineOfAuthority.LineOfAuthorityType();
        PartyIds.GovtIDTC govtIDTC = new PartyIds.GovtIDTC();

        carrierAppointment.setCarrierCode("65838");
        //  producerIds2.setAYProducerID();
        producerIds2.setCompanyProducerID("103");
        producerIds2.setCompanyProducerIDJHTC(BigInteger.valueOf(1));
        producerIds2.setJHPayrollNumber(159887);

        //partyIds.setGovtID("0");
        partyIds.setPartyTypeCode("1");
        govtIDTC.setTc(BigInteger.valueOf(1));
        lineOfAuthorityType.setTc("93927");

        applicationJurisdiction.setTc(BigInteger.valueOf(26));
        residenceJurisdictionAtIssue.setTc(BigInteger.valueOf(26));

        messageSource.setUserID("CallidusCloud");
        messageSource.setApplicationName("575812");
        messageSource.setApplicationUserID("CallidusCloud");
        messageSource.setHostName("174.129.237.57");
        messageSource.setProcessID("1");

        serviceInfo.setServiceName("Producer");
        serviceInfo.setServiceOperation("CheckLicenseStatus");
        serviceInfo.setServiceVersion("1.0");

        XMLGregorianCalendar result = DatatypeFactory.newInstance().newXMLGregorianCalendar("2013-05-06");
        applicationInfo.setSignedDate(result);
        applicationInfo.setSubmissionDate(result);

        header.setMessageSource(messageSource);
        header.setServiceInfo(serviceInfo);
        header.setMessageUID("AAAA");
        lineOfAuthority.setLineOfAuthorityType(lineOfAuthorityType);
        partyIds.setGovtIDTC(govtIDTC);
        carrierAppointment.setLineOfAuthority(lineOfAuthority);
        producerIds2.setCarrierAppointment(carrierAppointment);
        applicationInfo.setApplicationJurisdiction(applicationJurisdiction);
        applicationInfo.setResidenceJurisdictionAtIssue(residenceJurisdictionAtIssue);
        checkLicenseStatusRequest.setPartyIds(partyIds);
        checkLicenseStatusRequest.setApplicationInfo(applicationInfo);
        checkLicenseStatusRequest.setProducerIds2(producerIds2);

        checkLicenseRequestWrapper.setCheckLicenseStatusRequest(checkLicenseStatusRequest);
        checkLicenseRequestWrapper.setHeader(header);
        return checkLicenseRequestWrapper;
    }

    private GetProducerRequestWrapper populateGetProducerRequest() throws Exception  {
        producerRequestWrapper = new GetProducerRequestWrapper();

        MessageSource messageSource = new MessageSource();
        ServiceInfo serviceInfo = new ServiceInfo();

        header = new JHHeader();
        header.setMessageSource(messageSource);
        header.setServiceInfo(serviceInfo);
        header.setMessageUID("AAAA");

        messageSource.setUserID("CallidusCloud");
        messageSource.setApplicationName("575812");
        messageSource.setApplicationUserID("CallidusCloud");
        messageSource.setHostName("174.129.237.57");
        messageSource.setProcessID("1");

        serviceInfo.setServiceName("Producer");
        serviceInfo.setServiceOperation("CheckLicenseStatus");
        serviceInfo.setServiceVersion("1.0");

        producerRequest = new GetProducerRequest();

        producerRequestWrapper.setHeader(header);
        producerRequestWrapper.setGetProducerRequest(producerRequest);

        return producerRequestWrapper;
    }

    /**
     * As json string string.
     *
     * @param obj the obj
     *
     * @return the string
     */
    /*
     * converts a Java object into JSON representation
     */
    public static String asJsonString(final Object obj) {
        try {
            String returnStr = new ObjectMapper().writeValueAsString(obj);
            return returnStr;

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

}