package com.jh.life.producertwo.transformation;

import com.jh.life.producertwo.model.LicenseCheckIn;
import com.manulife.esb.xsd.common.jh.header.JHHeader;
import com.manulife.esb.xsd.common.jh.header.MessageSource;
import com.manulife.esb.xsd.common.jh.header.ServiceInfo;
import com.manulife.esb.xsd.life.jh.producer.*;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.junit4.SpringRunner;

import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;
import java.math.BigInteger;

import static org.junit.Assert.*;

@RunWith(SpringRunner.class)
public class ProducerDataTransformerTest {

    CheckLicenseStatusRequest request = null;
    ProducerDataTransformer producerDataTransformer = null;
    JHHeader header = null;
    @Before
    public void setUp() throws Exception {
        producerDataTransformer = new ProducerDataTransformer();
        request = new CheckLicenseStatusRequest();
        header = new JHHeader();
        PartyIds partyIds = new PartyIds();
        ProducerIds2 producerIds2 = new ProducerIds2();
        ApplicationInfo applicationInfo = new ApplicationInfo();
        MessageSource messageSource = new MessageSource();
        ServiceInfo serviceInfo = new ServiceInfo();
        OLILUSTATE applicationJurisdiction = new OLILUSTATE();
        OLILUSTATE residenceJurisdictionAtIssue = new OLILUSTATE();
        ProducerIds2 .CarrierAppointment carrierAppointment = new ProducerIds2.CarrierAppointment();
        ProducerIds2 .CarrierAppointment.LineOfAuthority lineOfAuthority = new ProducerIds2.CarrierAppointment.LineOfAuthority();
        ProducerIds2 .CarrierAppointment.LineOfAuthority.LineOfAuthorityType lineOfAuthorityType = new ProducerIds2.CarrierAppointment.LineOfAuthority.LineOfAuthorityType();
        PartyIds.GovtIDTC govtIDTC = new PartyIds.GovtIDTC();

        carrierAppointment.setCarrierCode("65838");
      //  producerIds2.setAYProducerID();
        producerIds2.setCompanyProducerID("103");
        producerIds2.setCompanyProducerIDJHTC(BigInteger.valueOf(1));
        producerIds2.setJHPayrollNumber(159887);

        //partyIds.setGovtID("0");
        partyIds.setPartyTypeCode("1");
        govtIDTC.setTc(BigInteger.valueOf(1));
        lineOfAuthorityType.setTc("93927");

        applicationJurisdiction.setTc(BigInteger.valueOf(26));
        residenceJurisdictionAtIssue.setTc(BigInteger.valueOf(26));

        messageSource.setUserID("CallidusCloud");
        messageSource.setApplicationName("575812");
        messageSource.setApplicationUserID("CallidusCloud");
        messageSource.setHostName("174.129.237.57");
        messageSource.setProcessID("1");

        serviceInfo.setServiceName("Producer");
        serviceInfo.setServiceOperation("CheckLicenseStatus");
        serviceInfo.setServiceVersion("1.0");

        XMLGregorianCalendar result = DatatypeFactory.newInstance().newXMLGregorianCalendar("2013-05-06");
        System.out.print("DATE &&&&&&&&&&&&>"+result);
        applicationInfo.setSignedDate(result);
        applicationInfo.setSubmissionDate(result);

        header.setMessageSource(messageSource);
        header.setServiceInfo(serviceInfo);
        lineOfAuthority.setLineOfAuthorityType(lineOfAuthorityType);
        partyIds.setGovtIDTC(govtIDTC);
        carrierAppointment.setLineOfAuthority(lineOfAuthority);
        producerIds2.setCarrierAppointment(carrierAppointment);
        applicationInfo.setApplicationJurisdiction(applicationJurisdiction);
        applicationInfo.setResidenceJurisdictionAtIssue(residenceJurisdictionAtIssue);
        request.setPartyIds(partyIds);
        request.setApplicationInfo(applicationInfo);
        request.setProducerIds2(producerIds2);

    }

    @Test
    public void getLicenseStatusParty() {
        LicenseCheckIn licenseCheckIn =  producerDataTransformer.getLicenseStatusRequest(request,header);
//        assertEquals("87287", licenseCheckIn.getP1ProducerIdType());
        assertEquals("159887", licenseCheckIn.getP1ProducerIdNo());
        assertEquals("103", licenseCheckIn.getP1OrgIdNo());

    }

    @Test
    public void getLicenseStatusProducerId() {
        LicenseCheckIn licenseCheckIn =  producerDataTransformer.getLicenseStatusRequest(request,header);


        assertEquals(1609, licenseCheckIn.getP1PstlJursCdResi());
        assertEquals(93927, licenseCheckIn.getP1PrdTypCd());
        assertEquals(92817, licenseCheckIn.getP1ManufInsCoCd());
        assertEquals(575812, licenseCheckIn.getP1SrcSystemIdNo());


    }
    @Test
    public void getLicenseStatusApplicationInfo() {
        LicenseCheckIn licenseCheckIn =  producerDataTransformer.getLicenseStatusRequest(request,header);

        assertEquals("CallidusCloud", licenseCheckIn.getP1UserInfo());
        assertEquals("20130506", licenseCheckIn.getP1TransactionDt());
        assertEquals("20130506", licenseCheckIn.getP1ApplSubDt());

    }

}