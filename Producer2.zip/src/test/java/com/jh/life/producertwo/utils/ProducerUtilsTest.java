package com.jh.life.producertwo.utils;

import org.junit.Before;
import org.junit.Test;

import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;
import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.GregorianCalendar;

import static org.junit.Assert.*;

public class ProducerUtilsTest {

    XMLGregorianCalendar xmlGregCal;
    ProducerUtils producerUtils = null;
    Date oldDate;

    @Before
    public void setUp() throws Exception {
        producerUtils = new ProducerUtils();
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");

        oldDate = Date.valueOf("2011-12-25");

        GregorianCalendar cal = new GregorianCalendar();
        cal.setTime(oldDate);

        xmlGregCal = DatatypeFactory.newInstance().newXMLGregorianCalendar(cal);
    }


    @Test
    public void convertUtilDateToGregoerianCalendar() {
        assertEquals(xmlGregCal, producerUtils.convertUtilDateToGregoerianCalendar(oldDate));
    }


    @Test
    public void ifNullReturnEmptyNull() {
        assertEquals("", producerUtils.ifNullReturnEmpty(null));
    }

    @Test
    public void ifNullReturnEmpty() {
        assertEquals("ABC", producerUtils.ifNullReturnEmpty("ABC"));
    }
    @Test
    public void getStringShortNullValue() {
        assertEquals("", producerUtils.getStringShortValue(null));
    }

    @Test
    public void getStringShortNotNullValue() {
        short bar = (short) 0;
        assertEquals("0", producerUtils.getStringShortValue(bar));
    }
}