package com.jh.insurance.contactmanagement.controller;

import com.jh.insurance.contactmanagement.orchestration.ContactManagementOrchestration;
import com.manulife.esb.xsd.insurance.jh.contactmanagement.PINResetRequest;
import com.manulife.esb.xsd.insurance.jh.contactmanagement.PINResetResponse;
import com.manulife.esb.xsd.insurance.jh.contactmanagement.PartyIdGroupType;
import org.codehaus.jackson.map.ObjectMapper;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;

import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;


@RunWith(SpringRunner.class)
@WebMvcTest(ContactManagementController.class)
public class ContactManagementControllerTest {


    @Autowired
    private MockMvc mvc;

    @MockBean
    ContactManagementOrchestration contactManagementOrchestration = null;

    PINResetResponse pinResetResponse = null;
    PINResetRequest pinResetRequest = null;


    @Before
    public void setup() throws Exception{
        pinResetResponse = new PINResetResponse();
        pinResetRequest  = new PINResetRequest();
        PartyIdGroupType partyIdGroupType = new PartyIdGroupType();
        partyIdGroupType.setPartyId("152642793203280454");
        partyIdGroupType.setPartyIdSystemCode("LE");
        partyIdGroupType.setPartyIdTypeCode("2");
        pinResetRequest.setPartyIdGroup(partyIdGroupType);

        pinResetResponse.setStatusCode(0);
        pinResetResponse.setStatusMessage("LDAP_Success");
    }
    @Test
    public void resetCustomerPinStatusCode() throws Exception {

      /*  when(contactManagementOrchestration.resetCustomerPinDetails(anyString(),anyString(),any(PINResetRequest.class))).thenReturn(pinResetResponse);
        mvc.perform(post("/JH/Ins/Security/IAM/Pin/Reset")
                .content(asJsonString(pinResetResponse))
                .accept(MediaType.APPLICATION_JSON_VALUE)
                .contentType(MediaType.APPLICATION_JSON_VALUE)
                .header("MessageUUID", "1234")
                .header("sourceSystemName", "FNA"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("statusCode").value(0));*/
    }

    @Test
    public void resetCustomerPinStatusMessage() throws Exception {

        /*when(contactManagementOrchestration.resetCustomerPinDetails(anyString(),anyString(),any(PINResetRequest.class))).thenReturn(pinResetResponse);
        mvc.perform(post("/JH/Ins/Security/IAM/Pin/Reset")
                .content(asJsonString(pinResetResponse))
                .accept(MediaType.APPLICATION_JSON_VALUE)
                .contentType(MediaType.APPLICATION_JSON_VALUE)
                .header("MessageUUID", "1234")
                .header("sourceSystemName", "FNA"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("statusMessage").value("LDAP_Success"));*/
    }

    @After
    public void teardown(){

    }

    /*
     * converts a Java object into JSON representation
     */
    public static String asJsonString(final Object obj) {
        try {
            String returnStr = new ObjectMapper().writeValueAsString(obj);
            return returnStr;

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}