package com.jh.insurance.contactmanagement.orchestration;

import com.example.xmlns._1435354270716.contactmanagement.GetPINResetFault;
import com.jh.insurance.contactmanagement.constants.ContactManagementConstants;
import com.jh.insurance.contactmanagement.model.DocRoot;
import com.jh.insurance.contactmanagement.service.ContactManagementService;
import com.manulife.esb.xsd.insurance.jh.contactmanagement.PINResetRequest;
import com.manulife.esb.xsd.insurance.jh.contactmanagement.PINResetResponse;
import com.manulife.esb.xsd.insurance.jh.contactmanagement.PartyIdGroupType;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.test.context.junit4.SpringRunner;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;
import java.io.StringWriter;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

@RunWith(SpringRunner.class)
public class ContactManagementOrchestrationTest {

    @InjectMocks
    ContactManagementOrchestration contactManagementOrchestration;

    @Mock
    ContactManagementService contactManagementService;

    PINResetResponse pinResetResponse = null;
    PINResetRequest pinResetRequest = null;
    String xmlStringRequest = null;

    @Before
    public void setup() throws Exception{
        pinResetResponse = new PINResetResponse();
        pinResetRequest  = new PINResetRequest();
        PartyIdGroupType partyIdGroupType = new PartyIdGroupType();
        partyIdGroupType.setPartyId("152642793203280454");
        partyIdGroupType.setPartyIdSystemCode("LE");
        partyIdGroupType.setPartyIdTypeCode("2");
        pinResetRequest.setPartyIdGroup(partyIdGroupType);

        pinResetResponse.setStatusCode(0);
        pinResetResponse.setStatusMessage("LDAP_Success");

        DocRoot isamRequest = new DocRoot();
        DocRoot.Entry entry = new DocRoot.Entry();
        entry.setForcePINReset(new DocRoot.Entry.ForcePINReset(partyIdGroupType.getPartyId(), partyIdGroupType.getPartyId(), ContactManagementConstants.APPLID));
        isamRequest.setEntry(entry);

        JAXBContext jaxbContext = JAXBContext.newInstance(DocRoot.class);
        Marshaller jaxbMarshaller = jaxbContext.createMarshaller();
        StringWriter sw = new StringWriter();
        jaxbMarshaller.marshal(isamRequest, sw);
        xmlStringRequest = sw.toString();
    }


    @Test
    public void resetCustomerPinDetails() throws GetPINResetFault {
        when(contactManagementService.resetCustomerPin("FNA70053569", "1234", xmlStringRequest)).thenReturn(pinResetResponse);
        assertEquals(0,contactManagementOrchestration.resetCustomerPinDetails("FNA70053569", "1234",pinResetRequest).getStatusCode());
    }

    @Test
    public void resetCustomerPinDetailsMessage() throws GetPINResetFault {
        when(contactManagementService.resetCustomerPin("FNA70053569", "1234", xmlStringRequest)).thenReturn(pinResetResponse);
        assertEquals("LDAP_Success",contactManagementOrchestration.resetCustomerPinDetails("FNA70053569", "1234",pinResetRequest).getStatusMessage());
    }
}