package com.jh.insurance.contactmanagement.utility;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;

import static org.junit.Assert.assertEquals;

public class UtilityTest {

    @InjectMocks
    Utility utility;

    String inputStringAstrick = null;
    @Before
    public void setUp() throws Exception {
        inputStringAstrick = "Test*Astr";
    }

    @Test
    public void escapeMetaCharactersAstr() {
        assertEquals("Test\\*Astr",utility.escapeMetaCharacters(inputStringAstrick));
    }

    @Test
    public void escapeMetaCharactersBraces() {
        assertEquals("Test\\{Astr",utility.escapeMetaCharacters("Test{Astr"));
    }

    @After
    public void tearDown() throws Exception {
    }
}