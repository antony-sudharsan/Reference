
package com.manulife.esb.xsd.insurance.jh.contactmanagement;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for PartyIdGroup_Type complex type.
 *
 * <p>The following schema fragment specifies the expected content contained within this class.
 *
 * <pre>
 * &lt;complexType name="PartyIdGroup_Type">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/Insurance/jh/ContactManagement}PartyId"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/Insurance/jh/ContactManagement}PartyIdTypeCode"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/Insurance/jh/ContactManagement}PartyIdSystemCode" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "PartyIdGroup_Type", propOrder = {
        "partyId",
        "partyIdTypeCode",
        "partyIdSystemCode"
})
public class PartyIdGroupType {

    @XmlElement(name = "PartyId", required = true)
    protected String partyId;
    @XmlElement(name = "PartyIdTypeCode", required = true)
    protected String partyIdTypeCode;
    @XmlElement(name = "PartyIdSystemCode")
    protected String partyIdSystemCode;

    /**
     * Gets the value of the partyId property.
     *
     * @return possible object is
     * {@link String }
     */
    public String getPartyId() {
        return partyId;
    }

    /**
     * Sets the value of the partyId property.
     *
     * @param value allowed object is
     *              {@link String }
     */
    public void setPartyId(String value) {
        this.partyId = value;
    }

    /**
     * Gets the value of the partyIdTypeCode property.
     *
     * @return possible object is
     * {@link String }
     */
    public String getPartyIdTypeCode() {
        return partyIdTypeCode;
    }

    /**
     * Sets the value of the partyIdTypeCode property.
     *
     * @param value allowed object is
     *              {@link String }
     */
    public void setPartyIdTypeCode(String value) {
        this.partyIdTypeCode = value;
    }

    /**
     * Gets the value of the partyIdSystemCode property.
     *
     * @return possible object is
     * {@link String }
     */
    public String getPartyIdSystemCode() {
        return partyIdSystemCode;
    }

    /**
     * Sets the value of the partyIdSystemCode property.
     *
     * @param value allowed object is
     *              {@link String }
     */
    public void setPartyIdSystemCode(String value) {
        this.partyIdSystemCode = value;
    }

}
