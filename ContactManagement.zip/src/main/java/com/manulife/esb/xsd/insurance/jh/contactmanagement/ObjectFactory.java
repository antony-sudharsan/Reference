
package com.manulife.esb.xsd.insurance.jh.contactmanagement;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each
 * Java content interface and Java element interface
 * generated in the com.manulife.esb.xsd.insurance.jh.contactmanagement package.
 * <p>An ObjectFactory allows you to programatically
 * construct new instances of the Java representation
 * for XML content. The Java representation of XML
 * content can consist of schema derived interfaces
 * and classes representing the binding of schema
 * type definitions, element declarations and model
 * groups.  Factory methods for each of these are
 * provided in this class.
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _PartyId_QNAME = new QName("http://www.esb.manulife.com/xsd/Insurance/jh/ContactManagement", "PartyId");
    private final static QName _StatusMessage_QNAME = new QName("http://www.esb.manulife.com/xsd/Insurance/jh/ContactManagement", "StatusMessage");
    private final static QName _PartyIdTypeCode_QNAME = new QName("http://www.esb.manulife.com/xsd/Insurance/jh/ContactManagement", "PartyIdTypeCode");
    private final static QName _PartyIdGroup_QNAME = new QName("http://www.esb.manulife.com/xsd/Insurance/jh/ContactManagement", "PartyIdGroup");
    private final static QName _PartyIdSystemCode_QNAME = new QName("http://www.esb.manulife.com/xsd/Insurance/jh/ContactManagement", "PartyIdSystemCode");
    private final static QName _StatusCode_QNAME = new QName("http://www.esb.manulife.com/xsd/Insurance/jh/ContactManagement", "StatusCode");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.manulife.esb.xsd.insurance.jh.contactmanagement
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link PINResetRequest }
     */
    public PINResetRequest createPINResetRequest() {
        return new PINResetRequest();
    }

    /**
     * Create an instance of {@link PartyIdGroupType }
     */
    public PartyIdGroupType createPartyIdGroupType() {
        return new PartyIdGroupType();
    }

    /**
     * Create an instance of {@link PINResetResponse }
     */
    public PINResetResponse createPINResetResponse() {
        return new PINResetResponse();
    }

    /**
     * Create an instance of {@link PINResetFault }
     */
    public PINResetFault createPINResetFault() {
        return new PINResetFault();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/Insurance/jh/ContactManagement", name = "PartyId")
    public JAXBElement<String> createPartyId(String value) {
        return new JAXBElement<String>(_PartyId_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/Insurance/jh/ContactManagement", name = "StatusMessage")
    public JAXBElement<String> createStatusMessage(String value) {
        return new JAXBElement<String>(_StatusMessage_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/Insurance/jh/ContactManagement", name = "PartyIdTypeCode")
    public JAXBElement<String> createPartyIdTypeCode(String value) {
        return new JAXBElement<String>(_PartyIdTypeCode_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PartyIdGroupType }{@code >}}
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/Insurance/jh/ContactManagement", name = "PartyIdGroup")
    public JAXBElement<PartyIdGroupType> createPartyIdGroup(PartyIdGroupType value) {
        return new JAXBElement<PartyIdGroupType>(_PartyIdGroup_QNAME, PartyIdGroupType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/Insurance/jh/ContactManagement", name = "PartyIdSystemCode")
    public JAXBElement<String> createPartyIdSystemCode(String value) {
        return new JAXBElement<String>(_PartyIdSystemCode_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Integer }{@code >}}
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/Insurance/jh/ContactManagement", name = "StatusCode")
    public JAXBElement<Integer> createStatusCode(Integer value) {
        return new JAXBElement<Integer>(_StatusCode_QNAME, Integer.class, null, value);
    }

}
