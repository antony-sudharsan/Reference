
package com.manulife.esb.xsd.insurance.jh.contactmanagement;

import javax.xml.bind.annotation.*;


/**
 * <p>Java class for anonymous complex type.
 *
 * <p>The following schema fragment specifies the expected content contained within this class.
 *
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/Insurance/jh/ContactManagement}StatusCode"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/Insurance/jh/ContactManagement}StatusMessage"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
        "statusCode",
        "statusMessage"
})
@XmlRootElement(name = "PINReset_response")
public class PINResetResponse {

    @XmlElement(name = "StatusCode")
    protected int statusCode;
    @XmlElement(name = "StatusMessage", required = true)
    protected String statusMessage;

    /**
     * Gets the value of the statusCode property.
     */
    public int getStatusCode() {
        return statusCode;
    }

    /**
     * Sets the value of the statusCode property.
     */
    public void setStatusCode(int value) {
        this.statusCode = value;
    }

    /**
     * Gets the value of the statusMessage property.
     *
     * @return possible object is
     * {@link String }
     */
    public String getStatusMessage() {
        return statusMessage;
    }

    /**
     * Sets the value of the statusMessage property.
     *
     * @param value allowed object is
     *              {@link String }
     */
    public void setStatusMessage(String value) {
        this.statusMessage = value;
    }

}
