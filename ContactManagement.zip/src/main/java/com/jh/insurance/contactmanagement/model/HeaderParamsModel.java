package com.jh.insurance.contactmanagement.model;

import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@ToString
public class HeaderParamsModel {

    @Getter
    @Setter
    @ApiModelProperty(value = "EFSAuth")
    private String EFSAuth;

    @Getter
    @Setter
    @ApiModelProperty(value = "EFSKey")
    private String EFSKey;

    @Getter
    @Setter
    @ApiModelProperty(value = "EFSDate")
    private String EFSDate;

    @Getter
    @Setter
    @ApiModelProperty(value = "EFSSign")
    private String EFSSign;
}
