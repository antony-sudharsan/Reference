package com.jh.insurance.contactmanagement.utility;

import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Component;
import org.w3c.dom.Document;
import org.xml.sax.InputSource;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamReader;
import java.io.*;

@Component
public class Utility {

    public static String escapeMetaCharacters(String inputString) {
        final String[] metaCharacters = {"\\", "^", "$", "{", "}", "[", "]", "(", ")", ".", "*", "+", "?", "|", "<", ">", "-", "&"};
        String outputString = "";
        for (int i = 0; i < metaCharacters.length; i++) {
            if (inputString.contains(metaCharacters[i])) {
                outputString = inputString.replace(metaCharacters[i], "\\" + metaCharacters[i]);
                inputString = outputString;
            }
        }
        return outputString;
    }


    public static XMLStreamReader ParseToBody(Reader reader, String elemName) throws Exception {
        XMLInputFactory factory = XMLInputFactory.newInstance(); // Or newFactory()
        XMLStreamReader xsr = factory.createXMLStreamReader(reader);

        int i = 0;
        while (xsr.hasNext()) {
            int eventType = xsr.next();

            switch (eventType) {
                case XMLStreamReader.START_ELEMENT:

                    String elementName = xsr.getLocalName();
                    if (elementName.equals(elemName)) {
                        i++;
                    }

                    break;

                case XMLStreamReader.END_ELEMENT:
                    break;
            }
            if (i == 2) break;
        }

        return xsr;


    }


    public static Document loadXML(String fileName) throws Exception {
        Resource resource = new ClassPathResource(fileName);
        BufferedReader br = new BufferedReader(new InputStreamReader(resource.getInputStream()));
        StringBuilder stringBuilder = new StringBuilder();
        String line;
        while ((line = br.readLine()) != null) {
            stringBuilder.append(line).append('\n');
        }
        br.close();

        //	File fXmlFile = new File(fileName);
        DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
        InputSource is = new InputSource(new StringReader(stringBuilder.toString()));
        Document doc = dBuilder.parse(is);
        doc.getDocumentElement().normalize();

        return doc;

    }


    public static String getStackTrace(Throwable t) {
        StringWriter sw = new StringWriter();
        t.printStackTrace(new PrintWriter(sw));
        return sw.toString();
    }

}
