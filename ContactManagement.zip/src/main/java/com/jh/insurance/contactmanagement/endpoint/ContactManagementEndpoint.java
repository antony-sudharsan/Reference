package com.jh.insurance.contactmanagement.endpoint;

import com.example.xmlns._1435354270716.contactmanagement.GetPINResetFault;
import com.jh.common.logging.LoggerHandler;
import com.jh.insurance.contactmanagement.constants.ContactManagementConstants;
import com.jh.insurance.contactmanagement.orchestration.ContactManagementOrchestration;
import com.jh.insurance.contactmanagement.utility.HeaderKey;
import com.jh.insurance.contactmanagement.utility.JHHeaderJaxbUtils;
import com.jh.insurance.contactmanagement.utility.LoggerUtils;
import com.jh.insurance.contactmanagement.utility.LoggingContextHolder;
import com.manulife.esb.xsd.common.jh.commonmessage.FaultType;
import com.manulife.esb.xsd.common.jh.header.JHHeader;
import com.manulife.esb.xsd.insurance.jh.contactmanagement.PINResetFault;
import com.manulife.esb.xsd.insurance.jh.contactmanagement.PINResetRequest;
import com.manulife.esb.xsd.insurance.jh.contactmanagement.PINResetResponse;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ws.context.MessageContext;
import org.springframework.ws.server.endpoint.annotation.Endpoint;
import org.springframework.ws.server.endpoint.annotation.PayloadRoot;
import org.springframework.ws.server.endpoint.annotation.RequestPayload;
import org.springframework.ws.server.endpoint.annotation.ResponsePayload;
import org.springframework.ws.soap.SoapHeaderElement;
import org.springframework.ws.soap.server.endpoint.annotation.SoapHeader;

import javax.ws.rs.BadRequestException;

@Endpoint
public class ContactManagementEndpoint {

    private static final String NAMESPACE_URI = "http://www.esb.manulife.com/xsd/Insurance/jh/ContactManagement";

    private static final String JH_HEADER_NS = "http://www.esb.manulife.com/xsd/common/jh/header";


    @Autowired
    private ContactManagementOrchestration contactManagementOrchestration;
    @Autowired
    private JHHeaderJaxbUtils jhHeaderJaxbUtils;
    @Autowired
    private LoggerUtils loggerUtils;


    @Autowired
    public ContactManagementEndpoint(ContactManagementOrchestration contactManagementOrchestration, JHHeaderJaxbUtils jhHeaderJaxbUtils, LoggerUtils loggerUtils) {
        this.contactManagementOrchestration = contactManagementOrchestration;
        this.jhHeaderJaxbUtils = jhHeaderJaxbUtils;
        this.loggerUtils = loggerUtils;
    }

    /**
     * @param request
     * @param jhHeaderElement
     * @param messageContext
     * @return
     * @throws Exception
     */
    @PayloadRoot(namespace = NAMESPACE_URI, localPart = "PINReset_request")
    @ResponsePayload
    public PINResetResponse resetCustomerPinDetails(
            @RequestPayload PINResetRequest request,
            @SoapHeader("{" + JH_HEADER_NS + "}JHHeader") SoapHeaderElement jhHeaderElement,
            MessageContext messageContext) throws Exception {

        PINResetResponse reply = null;
        JHHeader header = parseHeader(jhHeaderElement);
        validateHeader(header);

        String messageUUID = header.getMessageUID();
        String sourceSystemName = header.getMessageSource().getApplicationName();
        String userId = header.getMessageSource().getUserID();

        try {

            LoggerHandler.LogOut("INFO", "1", messageUUID, sourceSystemName, this.getClass().getName(),
                    "Entering IAM PIN REST EndPoint " + loggerUtils.writeAsJson(request));

            reply = contactManagementOrchestration.resetCustomerPinDetails(messageUUID, sourceSystemName, request);

            LoggerHandler.LogOut("INFO", "6", messageUUID, sourceSystemName, this.getClass().getName(),
                    "Exiting IAM PIN REST EndPoint " + loggerUtils.writeAsJson(reply));

        } catch (GetPINResetFault getPINResetFault) {
            throw getPINResetFault;
        } catch (final Exception e) {
            LoggerHandler.ErrorOut(e, messageUUID, sourceSystemName, this.getClass().getName(), e.getMessage());
            FaultType faultType = new FaultType(ContactManagementConstants.TECHNICAL_ERROR_CODE, e.getMessage());
            PINResetFault pinResetFault = new PINResetFault(faultType);

            GetPINResetFault getPINResetFault = new GetPINResetFault("", pinResetFault, e);
            throw getPINResetFault;
        }
        // add response header as a property to be used by EndpointInterceptor
        // Current service does not modify header on response
        messageContext.setProperty(HeaderKey.JH_HEADER_KEY.getValue(), header);
        LoggingContextHolder.getLoggingContext().clear();

        return reply;
    }


    /**
     * @param jhHeaderElement
     * @return
     */
    private JHHeader parseHeader(final SoapHeaderElement jhHeaderElement) {
        // parse JH Header if present
        JHHeader header = null;
        if (null != jhHeaderElement) {
            header = jhHeaderJaxbUtils.unmarshallJHHeader(jhHeaderElement);
        } else {
            throw new BadRequestException("Missing Header");
        }

        return header;
    }

    /**
     * @param header
     */
    private void validateHeader(final JHHeader header) {
        if ((header == null) || (header.getMessageSource() == null)
                || StringUtils.isEmpty(header.getMessageSource().getApplicationName())) {
            throw new BadRequestException("Invalid Header Sent");
        }
    }
}
