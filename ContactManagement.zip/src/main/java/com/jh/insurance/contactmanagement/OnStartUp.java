/**
 * 
 */
package com.jh.insurance.contactmanagement;

import com.jh.common.logging.LoggerHandler;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;



/**
 * @author deepain
 *
 */
@Component
public class OnStartUp {
				
	@Autowired
	private Environment env;
	
	@PostConstruct
	public void init() {
		try {	
			
			//Initializing Logger class
			LoggerHandler.getInstance(env.getProperty("log.appID"), env.getProperty("log.svcName"), env.getProperty("log.componentName"), env.getProperty("log.svcVersion"));			
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
}
