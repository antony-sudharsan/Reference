package com.jh.insurance.contactmanagement.model;

import com.manulife.esb.xsd.common.jh.header.JHHeader;
import com.manulife.esb.xsd.insurance.jh.contactmanagement.PINResetRequest;

public class PINResetRequestWrapper {

    private JHHeader header;
    private PINResetRequest pinResetRequest;

    public JHHeader getHeader() {
        return header;
    }

    public void setHeader(JHHeader header) {
        this.header = header;
    }

    public PINResetRequest getPinResetRequest() {
        return pinResetRequest;
    }

    public void setPinResetRequest(PINResetRequest pinResetRequest) {
        this.pinResetRequest = pinResetRequest;
    }
}
