/**
 *
 */
package com.jh.insurance.contactmanagement.exception;

import com.jh.insurance.contactmanagement.model.ErrorResponse;
import org.springframework.http.HttpStatus;

/**
 * @author deepain
 */


public class IamPinResetImplException extends RuntimeException {
    private Exception e;
    private HttpStatus httpStatusCode;
    private ErrorResponse errorResp;


    public IamPinResetImplException(Exception e, HttpStatus notFound, ErrorResponse errorResponse) {
        this.e = e;
        this.httpStatusCode = httpStatusCode;
        this.errorResp = errorResp;
    }

    public Exception getE() {
        return e;
    }

    public void setE(Exception e) {
        this.e = e;
    }

    public HttpStatus getHttpStatusCode() {
        return httpStatusCode;
    }

    public void setHttpStatusCode(HttpStatus httpStatusCode) {
        this.httpStatusCode = httpStatusCode;
    }

    public ErrorResponse getErrorResp() {
        return errorResp;
    }

    public void setErrorResp(ErrorResponse errorResp) {
        this.errorResp = errorResp;
    }
}
