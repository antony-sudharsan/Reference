
package com.jh.insurance.contactmanagement.utility;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.jh.insurance.contactmanagement.model.CustomerPinReset;
import com.jh.insurance.contactmanagement.model.DocRoot;
import com.jh.insurance.contactmanagement.model.DocRoot.Entry.ForcePINReset;
import org.apache.http.ssl.SSLContextBuilder;
import org.springframework.util.ResourceUtils;

import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.File;
import java.io.InputStreamReader;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Base64;



/**
* @author deepain
*
*/
public class ISAMConnectivity {

      /**
       * @param args
       */
       @SuppressWarnings("null")
       public static void main(String[] args) {
              // TODO Auto-generated method stub
              String password = "changeit";
              try {
	            	  /**
            	  	  {	
		            		JSONParser parser = new JSONParser();
                       Object request = parser.parse(new FileReader(".\\src\\main\\resources\\testdata\\SuccessRequest.json"));
                       Object response = parser.parse(new FileReader("C:\\SpringBootWorkspace\\ContactManagement_Gradle-JAX-RS\\src\\main\\resources\\testdata\\SuccessResponse.json"));
		            		JSONObject jobj = (JSONObject) request;
		            		String str1 = (String) jobj.get("partyId");
		            		String str2 = (String) jobj.get("partyIdTypeCode");
		            		String str3 = (String) jobj.get("partyIdSystemCode");
		            		CustomerPinReset pin = new CustomerPinReset((String) jobj.get("partyId"),(String) jobj.get("partyIdTypeCode"),(String) jobj.get("partyIdSystemCode"));;
		            		System.out.println(pin.getPartyId());
		            		System.out.println(pin.getPartyIdSystemCode());
		            		System.out.println(pin.getPartyIdTypeCode());	            		
		            		
	            	  }  */
            	  
	            	  {	
	            		  	ObjectMapper mapper = new ObjectMapper();
                          CustomerPinReset pin = mapper.readValue(new File(".\\src\\main\\resources\\testdata\\SuccessRequest.json"), CustomerPinReset.class);
		            		//CustomerPinReset pin = new CustomerPinReset((String) jobj.get("partyId"),(String) jobj.get("partyIdTypeCode"),(String) jobj.get("partyIdSystemCode"));;
	            		  	System.out.println("Modified values");
		            		System.out.println(pin.getPartyId());
		            		System.out.println(pin.getPartyIdSystemCode());
		            		System.out.println(pin.getPartyIdTypeCode());	            		
		            		
	            	  }
            	  	 System.out.println("Working Directory : "+System.getProperty("user.dir"));	
                     SSLContext sslContext = SSLContextBuilder
                             .create()
                             .loadKeyMaterial(ResourceUtils.getFile("C:\\Users\\deepain\\OneDrive - Manulife\\Attachments\\Certificates\\ContactManagement\\CACerts.jks"), password.toCharArray(), password.toCharArray())
                             .loadTrustMaterial(ResourceUtils.getFile("C:\\Users\\deepain\\OneDrive - Manulife\\Attachments\\Certificates\\ContactManagement\\CACerts.jks"), password.toCharArray())
                             .build();
                     DocRoot.Entry.ForcePINReset pinReset = new ForcePINReset("167644765912133246", "167644765912133246", "LE");  
                     DocRoot isamRequest = new DocRoot();
                     DocRoot.Entry entry = new DocRoot.Entry();
                     entry.setForcePINReset(pinReset);
                     isamRequest.setEntry(entry);
/*                  

                     SSLConnectionSocketFactory csf = new SSLConnectionSocketFactory(sslContext);
                     MultiValueMap<String, String> headers = new LinkedMultiValueMap<String, String>();*/
                     
/*                  Map map = new HashMap<String, String>();
               map.put("Content-Type", "text/xml");
               map.put("Accept-Encoding", "gzip,deflate");
               
               headers.clear();
               headers.setAll(map);*/

/*                  CloseableHttpClient httpClient = HttpClients.custom().setSSLSocketFactory(csf).build();

                     HttpComponentsClientHttpRequestFactory requestFactory = new HttpComponentsClientHttpRequestFactory();

                     requestFactory.setHttpClient(httpClient);

                     RestTemplate restTemplate = new RestTemplate(requestFactory);
                                  
                     RestTemplateBuilder builder = new RestTemplateBuilder();*/

                     String URI = "https://jhsdsm.mod.manulifeusa.com:8080/";
                     String username = "uid=tibcoesbsvc,ou=service accounts,o=jhancock.com";
                     String pswd = "T1bc0SVC@dm1n";
                     
                     //builder.basicAuthorization(username, pswd);
                     
                     //restTemplate = builder.build();
                     
                     //builder.rootUri("http://jhsdsm.mod.manulifeusa.com:8080");
                     
                     //RestTemplate restTemplate = builder.build();
                     
                     //ResponseEntity response = null;
                     
                     //HttpEntity<?> request = new HttpEntity<>(isamRequest, headers); 
                     //ResponseEntity<?> response = new RestTemplate().postForEntity(URI, request, String.class);
              
                     //HttpResponse response = restTemplate.postForObject(URI, isamRequest , HttpResponse.class);
                     
                     HttpsURLConnection connection = null;
                     HttpsURLConnection.setDefaultSSLSocketFactory(sslContext.getSocketFactory());               
                     connection = (HttpsURLConnection) new URL(URI).openConnection();
                     String encoded = Base64.getEncoder().encodeToString((username+":"+pswd).getBytes(StandardCharsets.UTF_8));  //Java 8
                     connection.setRequestProperty("Authorization", "Basic "+encoded);              
                     connection.setRequestProperty("Accept-Language", "en-US,en;q=0.5");
                     connection.setRequestProperty("Content-Type", "text/xml;charset=utf-8");
                     connection.setRequestProperty("Accept-Encoding", "gzip,deflate");
                     connection.setRequestProperty("Accept-Language", "en-US,en;q=0.5");
                     connection.setRequestMethod("POST");
                     connection.setDoInput(true);
                     connection.setDoOutput(true);
                     //OutputStream os = connection.getOutputStream();
                     DataOutputStream wr = new DataOutputStream(connection.getOutputStream());
                     String XMLSRequest = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><DocRoot><Entry><ForcePINReset><UID>1234</UID><GUID>1234</GUID><APPLID>LE</APPLID></ForcePINReset></Entry></DocRoot>";
                     //os.write(XMLSRequest.getBytes());
                     wr.writeBytes(XMLSRequest);
                     wr.flush();
                     wr.close();
                     
                     int responseCode = connection.getResponseCode();
                     System.out.println("\n"+connection.getHeaderFields());
                     System.out.println("\n"+connection.getHeaderField("Header"));
                     
                     System.out.println("\nSending 'POST' request to URL : " + URI);
                     System.out.println("Post Data : " + XMLSRequest);
                     System.out.println("Response Code : " + responseCode);

                     BufferedReader in = new BufferedReader(
                             new InputStreamReader(connection.getInputStream()));
                     String inputLine;
                     StringBuffer response = new StringBuffer();

                     while ((inputLine = in.readLine()) != null) {
                           response.append(inputLine);
                     }
                     in.close();

                     //print result
                     System.out.println(response.toString());

                     
              
              } catch (Exception e) {
                     // TODO Auto-generated catch block
                     e.printStackTrace();
              }
              


       }

}
