package com.jh.insurance.contactmanagement.service;

import com.example.xmlns._1435354270716.contactmanagement.GetPINResetFault;
import com.jh.common.logging.LoggerHandler;
import com.jh.insurance.contactmanagement.constants.ContactManagementConstants;
import com.jh.insurance.contactmanagement.exception.IamPinResetImplException;
import com.jh.insurance.contactmanagement.model.DocRoot;
import com.jh.insurance.contactmanagement.model.ErrorResponse;
import com.jh.insurance.contactmanagement.model.PINResetResponseWrapper;
import com.jh.insurance.contactmanagement.resources.HttpsConnectionAuthEnabledWithSSLSuppression;
import com.jh.insurance.contactmanagement.utility.LoggingContextHolder;
import com.manulife.esb.xsd.common.jh.commonmessage.FaultType;
import com.manulife.esb.xsd.common.jh.header.JHHeader;
import com.manulife.esb.xsd.insurance.jh.contactmanagement.PINResetFault;
import com.manulife.esb.xsd.insurance.jh.contactmanagement.PINResetResponse;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.conn.ssl.TrustStrategy;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.client.ClientHttpRequestFactory;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.security.cert.X509Certificate;
import java.util.Base64;

@Component
public class ContactManagementService {

    @Autowired
    RestTemplate restTemplate;
    @Value("${url}")
    private String url;
    @Value("${tibcouser}")
    private String tibcouser;
    @Value("${password}")
    private String password;

    @Autowired
    HttpsConnectionAuthEnabledWithSSLSuppression httpsConnectionAuthEnabledWithSSLSuppression;

    @Bean
    public RestTemplate restTemplate() throws GetPINResetFault {
        return new RestTemplate(clientHttpRequestFactory());
    }

    private ClientHttpRequestFactory clientHttpRequestFactory() throws GetPINResetFault {

        HttpComponentsClientHttpRequestFactory requestFactory = new HttpComponentsClientHttpRequestFactory();

        try {
            HttpComponentsClientHttpRequestFactory factory = new HttpComponentsClientHttpRequestFactory();
            TrustStrategy acceptingTrustStrategy = (X509Certificate[] chain, String authType) -> true;

            SSLContext sslContext = org.apache.http.ssl.SSLContexts.custom()
                    .loadTrustMaterial(null, acceptingTrustStrategy)
                    .build();

            SSLConnectionSocketFactory csf = new SSLConnectionSocketFactory(sslContext);

            CloseableHttpClient httpClient = HttpClients.custom()
                    .setSSLSocketFactory(csf)
                    .build();


            requestFactory.setHttpClient(httpClient);
            requestFactory.setReadTimeout(9000);
            requestFactory.setConnectTimeout(9000);

        } catch (Exception e) {
            e.printStackTrace();
            FaultType faultType = new FaultType(ContactManagementConstants.TECHNICAL_ERROR_CODE, "IAM Service call responded with error");
            PINResetFault pinResetFault = new PINResetFault(faultType);
            GetPINResetFault getPINResetFault = new GetPINResetFault("IAM Service call responded with error", pinResetFault);
            throw getPINResetFault;
        }
        return requestFactory;
    }


    /**
     * @param messageUUID
     * @param sourceSystemName
     * @param docRoot
     * @return
     * @throws Exception
     */

    public PINResetResponse resetCustomerPinService(String messageUUID, String sourceSystemName, DocRoot docRoot) throws Exception {
        PINResetResponse pinResetResponse = null;
        try {

            LoggerHandler.LogOut("INFO", "2", messageUUID, sourceSystemName, this.getClass().getName(), docRoot.toString());

            HttpHeaders requestHeaders = new HttpHeaders();
            String encoded = Base64.getEncoder().encodeToString((tibcouser + ":" + password).getBytes(StandardCharsets.UTF_8));

            requestHeaders.set("Authorization", "Basic " + encoded);
            requestHeaders.set("Accept-Language", "en-US,en;q=0.5");
            requestHeaders.set("Content-Type", "text/xml;charset=utf-8");
            requestHeaders.set("Accept-Encoding", "gzip,deflate");
            requestHeaders.set("Accept-Language", "en-US,en;q=0.5");

            restTemplate.exchange(url, HttpMethod.POST, new HttpEntity<byte[]>(requestHeaders), DocRoot.class);

        } catch (Exception e) {
            e.printStackTrace();
            FaultType faultType = new FaultType(ContactManagementConstants.TECHNICAL_ERROR_CODE, "IAM Service call responded with error");
            PINResetFault pinResetFault = new PINResetFault(faultType);
            GetPINResetFault getPINResetFault = new GetPINResetFault("IAM Service call responded with error", pinResetFault);
            throw getPINResetFault;
        }
        return pinResetResponse;
    }


    public PINResetResponseWrapper resetCustomerPin(JHHeader header, String xmlStringRequest) throws GetPINResetFault {
        final String messageUUID = LoggingContextHolder.getLoggingContext().getMessageUUID();
        final String sourceSystemName = LoggingContextHolder.getLoggingContext().getSourceSystemName();
        LoggerHandler.LogOut("INFO", "3", messageUUID, sourceSystemName, this.getClass().getName(), xmlStringRequest);

        PINResetResponseWrapper pinResetResponseWrapper = new PINResetResponseWrapper();
        PINResetResponse pinResetResponse = new PINResetResponse();


        try {
            LoggerHandler.LogOut("INFO", "2", messageUUID, sourceSystemName, this.getClass().getName(), xmlStringRequest);

            HttpsURLConnection connection = httpsConnectionAuthEnabledWithSSLSuppression.getHttpsConnectionWithNoAuth(messageUUID, sourceSystemName, url, tibcouser, password);
            if (connection != null) {

                DataOutputStream wr = new DataOutputStream(connection.getOutputStream());
                wr.writeBytes(xmlStringRequest);
                wr.flush();
                wr.close();

                //Checking for success response
                if (connection.getResponseCode() == 0) {
                    //print result
                    BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                    String inputLine;
                    StringBuffer response = new StringBuffer();

                    while ((inputLine = in.readLine()) != null) {
                        response.append(inputLine);
                    }
                    in.close();
                    pinResetResponse.setStatusCode(0);
                    pinResetResponse.setStatusMessage("LDAP_Success");
                } else if (connection.getResponseCode() == 404) {

                    LoggerHandler.ErrorOut(new Exception("User Record Not Found"), messageUUID, sourceSystemName, this.getClass().getName(), "IAM Service connection failed : " + new ErrorResponse("404", "Connection Error", "User Record Not Found for the partyID").toString());

                    FaultType faultType = new FaultType(ContactManagementConstants.TECHNICAL_ERROR_CODE, "User Record Not Found");
                    PINResetFault pinResetFault = new PINResetFault(faultType);
                    GetPINResetFault getPINResetFault = new GetPINResetFault("User Record Not Found", pinResetFault);
                    throw getPINResetFault;

                } else {

                    LoggerHandler.ErrorOut(new Exception("IAM Service call responded with error"), messageUUID, sourceSystemName, this.getClass().getName(), "IAM Service invocation failed with error response : " + new ErrorResponse("422", "IAM service returned an error response", "Error Response Code received from IAM" + connection.getResponseCode()).toString());

                    FaultType faultType = new FaultType(ContactManagementConstants.TECHNICAL_ERROR_CODE, "IAM Service call responded with error");
                    PINResetFault pinResetFault = new PINResetFault(faultType);
                    GetPINResetFault getPINResetFault = new GetPINResetFault("IAM Service call responded with error", pinResetFault);
                    throw getPINResetFault;

                }
            } else {

                LoggerHandler.ErrorOut(new Exception("Unable to create connection to IAM"), messageUUID, sourceSystemName, this.getClass().getName(), "IAM Service Invocation failed : " + new ErrorResponse("404", "Connection Error", "Connection couldnot be created").toString());

                FaultType faultType = new FaultType(ContactManagementConstants.TECHNICAL_ERROR_CODE, "Unable to create connection to IAM");
                PINResetFault pinResetFault = new PINResetFault(faultType);
                GetPINResetFault getPINResetFault = new GetPINResetFault("Unable to create connection to IAM", pinResetFault);
                throw getPINResetFault;
            }

            pinResetResponseWrapper.setHeader(header);
            pinResetResponseWrapper.setPinResetResponse(pinResetResponse);
            LoggerHandler.LogOut("INFO", "4", messageUUID, sourceSystemName, this.getClass().getName(), pinResetResponse.toString());

            return pinResetResponseWrapper;
        } catch (IamPinResetImplException implEx) {
            throw implEx;
        } catch (Exception e) {
            e.printStackTrace();
            LoggerHandler.ErrorOut(e, messageUUID, sourceSystemName, this.getClass().getName(), "IAM Service Invocation failed : " + e.toString());

            FaultType faultType = new FaultType(ContactManagementConstants.TECHNICAL_ERROR_CODE, e.getMessage());
            PINResetFault pinResetFault = new PINResetFault(faultType);
            GetPINResetFault getPINResetFault = new GetPINResetFault("DST Service not available", pinResetFault, e);
            throw getPINResetFault;
        }
        //End of try-catch block
    }
    //End of resetCustomerPin Method implementation
}
