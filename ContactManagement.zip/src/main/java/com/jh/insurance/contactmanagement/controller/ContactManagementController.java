package com.jh.insurance.contactmanagement.controller;

import com.example.xmlns._1435354270716.contactmanagement.GetPINResetFault;
import com.jh.common.logging.LoggerHandler;
import com.jh.insurance.contactmanagement.constants.ContactManagementConstants;
import com.jh.insurance.contactmanagement.exception.IamPinResetImplException;
import com.jh.insurance.contactmanagement.model.PINResetRequestWrapper;
import com.jh.insurance.contactmanagement.model.PINResetResponseWrapper;
import com.jh.insurance.contactmanagement.orchestration.ContactManagementOrchestration;
import com.jh.insurance.contactmanagement.utility.JHHeaderUtils;
import com.jh.insurance.contactmanagement.utility.LoggingContextHolder;
import com.manulife.esb.xsd.common.jh.commonmessage.FaultType;
import com.manulife.esb.xsd.insurance.jh.contactmanagement.PINResetFault;
import com.manulife.esb.xsd.insurance.jh.contactmanagement.PINResetRequest;
import com.manulife.esb.xsd.insurance.jh.contactmanagement.PINResetResponse;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

/**
 *
 */

@RestController
@EnableSwagger2
public class ContactManagementController {

    @Autowired
    private ContactManagementOrchestration contactManagementOrchestration;


    private HttpHeaders responseHeaders = new HttpHeaders();
    private ResponseEntity<PINResetResponseWrapper> responseEntity;

    @ApiOperation(httpMethod = "POST", value = "Reset the Contact Details", notes = "Reset the Contact Pin ")
    @ApiResponses(value = {@ApiResponse(code = 200, message = "Success"), @ApiResponse(code = 400, message = "Validation Error: Invalid Request"),
            @ApiResponse(code = 404, message = "The downstream resource not reacheable"), @ApiResponse(code = 500, message = "Internal Service Error")})
    @RequestMapping(value = "/JH/Ins/Security/IAM/Pin/Reset", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<PINResetResponseWrapper> ResetCustomerPin(@RequestBody PINResetRequestWrapper request) throws Exception {

        final String messageUUID = JHHeaderUtils.retrieveOrDefaultMessageUID(request.getHeader(),
                "checkLicenseStatus");
        final String sourceSystemName = JHHeaderUtils.retrieveOrDefaultSourceSystemName(request.getHeader());
        PINResetResponseWrapper pinResetResponseWrapper = new PINResetResponseWrapper();

        try {
            LoggingContextHolder.getLoggingContext().setContext(messageUUID, sourceSystemName);

            JHHeaderUtils.validateHeader(request.getHeader());
            LoggerHandler.LogOut("INFO", "1", messageUUID, sourceSystemName, this.getClass().getName(), "Entering checkLicenseStatus Controller");

            pinResetResponseWrapper = contactManagementOrchestration.resetCustomerPinDetails(request.getHeader(), request.getPinResetRequest());
            responseHeaders.clear();
            responseHeaders.add("MessageID", messageUUID);
            responseHeaders.add("SourceName", sourceSystemName);
            responseEntity = new ResponseEntity<>(pinResetResponseWrapper, responseHeaders, HttpStatus.OK);

            LoggerHandler.LogOut("INFO", "6", messageUUID, sourceSystemName, this.getClass().getName(), pinResetResponseWrapper.toString());

            return responseEntity;

        } catch (final Exception e) {
            LoggerHandler.ErrorOut(e, messageUUID, sourceSystemName, this.getClass().getName(), e.getMessage());
            throw e;
        }

    }

}
