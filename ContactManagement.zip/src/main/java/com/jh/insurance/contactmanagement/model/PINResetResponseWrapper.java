package com.jh.insurance.contactmanagement.model;

import com.manulife.esb.xsd.common.jh.header.JHHeader;
import com.manulife.esb.xsd.insurance.jh.contactmanagement.PINResetRequest;
import com.manulife.esb.xsd.insurance.jh.contactmanagement.PINResetResponse;

public class PINResetResponseWrapper {

    private JHHeader header;

    private PINResetResponse pinResetResponse;

    public JHHeader getHeader() {
        return header;
    }

    public void setHeader(JHHeader header) {
        this.header = header;
    }

    public PINResetResponse getPinResetResponse() {
        return pinResetResponse;
    }

    public void setPinResetResponse(PINResetResponse pinResetResponse) {
        this.pinResetResponse = pinResetResponse;
    }
}
