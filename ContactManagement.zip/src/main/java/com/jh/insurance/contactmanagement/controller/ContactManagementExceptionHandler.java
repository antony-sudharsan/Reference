/**
 * 
 */
package com.jh.insurance.contactmanagement.controller;

import com.jh.insurance.contactmanagement.exception.IamPinResetImplException;
import com.jh.insurance.contactmanagement.model.ErrorResponse;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;


/**
 * @author deepain
 *
 */

@ControllerAdvice
@RestController
public class ContactManagementExceptionHandler extends ResponseEntityExceptionHandler {
	
	@ExceptionHandler(Exception.class)
	public final ResponseEntity<Object> handleAllExceptions(Exception ex, WebRequest request) {
		ErrorResponse exceptionResponse = new ErrorResponse("500", ex.getMessage(), request.getDescription(false));
		return new ResponseEntity<Object>(exceptionResponse, HttpStatus.INTERNAL_SERVER_ERROR);
	}

	@ExceptionHandler(IamPinResetImplException.class)
	public final ResponseEntity<Object> IamPinResetException(IamPinResetImplException ex, WebRequest request) {
		ErrorResponse exceptionResponse = ex.getErrorResp();
		return new ResponseEntity<Object>(exceptionResponse, ex.getHttpStatusCode());
	}

}
