package com.jh.insurance.contactmanagement.utility;

public final class LoggingContextHolder {

    private static ThreadLocal<LoggingContext> holder = new ThreadLocal<LoggingContext>() {
        @Override
        public LoggingContext initialValue() {
            return new LoggingContext();
        }
    };

    private LoggingContextHolder() {

    }

    public static LoggingContext getLoggingContext() {
        return holder.get();
    }
}
