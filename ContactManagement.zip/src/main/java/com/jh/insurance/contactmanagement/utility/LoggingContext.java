package com.jh.insurance.contactmanagement.utility;

public class LoggingContext {

    private String messageUUID;
    private String sourceSystemName;

    public void setContext(final String messageUUID, final String sourceSystemName) {
        this.messageUUID = messageUUID;
        this.sourceSystemName = sourceSystemName;
    }

    public String getMessageUUID() {
        return messageUUID;
    }

    public void setMessageUUID(final String messageUUID) {
        this.messageUUID = messageUUID;
    }

    public String getSourceSystemName() {
        return sourceSystemName;
    }

    public void setSourceSystemName(final String sourceSystemName) {
        this.sourceSystemName = sourceSystemName;
    }

    public void clear() {
        this.messageUUID = null;
        this.sourceSystemName = null;
    }
}
