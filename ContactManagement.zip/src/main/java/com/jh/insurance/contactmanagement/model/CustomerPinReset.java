/**
 * 
 */
package com.jh.insurance.contactmanagement.model;

/**
 * @author Iniyan Deepak
 *
 */


import javax.xml.bind.annotation.*;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "partyId",
	"partyIdTypeCode",
	"partyIdSystemCode"
})
@XmlRootElement(name = "CustomerPinReset")	
public class CustomerPinReset {
	@XmlElement(name = "partyId", required = false)
	private String partyId;
	
	@XmlElement(name = "partyIdTypeCode", required = false)
	private String partyIdTypeCode;
	
	@XmlElement(name = "partyIdSystemCode", required = false)
	private String partyIdSystemCode;
	
	public CustomerPinReset() {
		super();
	}

	public CustomerPinReset(String partyId, String partyIdTypeCode, String partyIdSystemCode) {
		super();
		this.partyId = partyId;
		this.partyIdTypeCode = partyIdTypeCode;
		this.partyIdSystemCode = partyIdSystemCode;
	}

	public String getPartyId() {
		return partyId;
	}
	
	public void setPartyId(String partyId) {
		this.partyId = partyId;
	}
	
	public String getPartyIdTypeCode() {
		return partyIdTypeCode;
	}

	public void setPartyIdTypeCode(String partyIdTypeCode) {
		this.partyIdTypeCode = partyIdTypeCode;
	}

	public String getPartyIdSystemCode() {
		return partyIdSystemCode;
	}

	public void setPartyIdSystemCode(String partyIdSystemCode) {
		this.partyIdSystemCode = partyIdSystemCode;
	}	
	
}
