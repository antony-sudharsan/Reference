/**
 * 
 */
package com.jh.insurance.contactmanagement.model;

import org.springframework.stereotype.Component;

import javax.xml.bind.annotation.*;
/**
 * @author Iniyan Deepak
 *
 */

@Component
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
	    "statusCode",
		"statusMessage"
})
@XmlRootElement(name="Status")
public class Status {
	
	@XmlElement(name = "statusCode", required = false)
	protected String statusCode;
	
	@XmlElement(name = "statusMessage", required = false)
	protected String statusMessage;
	
	public Status(String statusCode, String statusMessage) {
		super();
		this.statusCode = statusCode;
		this.statusMessage = statusMessage;
	}

	public Status() {
		// TODO Auto-generated constructor stub
	}

	public String getStatusCode() {
		return statusCode;
	}
		
	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}
	
	public String getStatusMessage() {
		return statusMessage;
	}
	
	public void setStatusMessage(String statusMessage) {
		this.statusMessage = statusMessage;
	}
	
}
