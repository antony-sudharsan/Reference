package com.jh.insurance.contactmanagement.exception;


public class SQLServerErrorException extends RuntimeException {


    /**
     *
     */
    private static final long serialVersionUID = 1L;
    private String details;

    public SQLServerErrorException(String message, String details) {
        super(message);
        this.details = details;
    }

    public String getDetails() {
        return details;
    }

    public void setDetails(String details) {
        this.details = details;
    }


}


