/**
 *
 */
package com.jh.insurance.contactmanagement.resources;

import com.example.xmlns._1435354270716.contactmanagement.GetPINResetFault;
import com.jh.common.logging.LoggerHandler;
import com.jh.insurance.contactmanagement.constants.ContactManagementConstants;
import com.manulife.esb.xsd.common.jh.commonmessage.FaultType;
import com.manulife.esb.xsd.insurance.jh.contactmanagement.PINResetFault;
import org.springframework.stereotype.Component;

import javax.net.ssl.*;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.cert.X509Certificate;
import java.util.Base64;


/**
 * @author deepain
 */
@Component
public class HttpsConnectionAuthEnabledWithSSLSuppression {

    public HttpsConnectionAuthEnabledWithSSLSuppression() {
        super();
    }

    /**
     * @param messageUUID
     * @param sourceSystemName
     * @param url
     * @param authenticationUsername
     * @param authenticationPassword
     * @return
     * @throws GetPINResetFault
     */
    public HttpsURLConnection getHttpsConnectionWithNoAuth(String messageUUID, String sourceSystemName, String url, String authenticationUsername, String authenticationPassword) throws GetPINResetFault {


        try {
            TrustManager[] trustAllCerts = new TrustManager[]{new X509TrustManager() {
                public java.security.cert.X509Certificate[] getAcceptedIssuers() {
                    return null;
                }

                public void checkClientTrusted(X509Certificate[] certs, String authType) {
                }

                public void checkServerTrusted(X509Certificate[] certs, String authType) {
                }
            }
            };

            SSLContext sslContext = SSLContext.getInstance("SSL");
            sslContext.init(null, trustAllCerts, new java.security.SecureRandom());
            HttpsURLConnection.setDefaultSSLSocketFactory(sslContext.getSocketFactory());

            HostnameVerifier allHostsValid = new HostnameVerifier() {
                public boolean verify(String hostname, SSLSession session) {
                    return true;
                }
            };

            HttpsURLConnection.setDefaultHostnameVerifier(allHostsValid);

            HttpsURLConnection connection = null;
            HttpsURLConnection.setDefaultSSLSocketFactory(sslContext.getSocketFactory());
            connection = (HttpsURLConnection) new URL(url).openConnection();
            String encoded = Base64.getEncoder().encodeToString((authenticationUsername + ":" + authenticationPassword).getBytes(StandardCharsets.UTF_8));
            connection.setRequestProperty("Authorization", "Basic " + encoded);
            connection.setRequestProperty("Accept-Language", "en-US,en;q=0.5");
            connection.setRequestProperty("Content-Type", "text/xml;charset=utf-8");
            connection.setRequestProperty("Accept-Encoding", "gzip,deflate");
            connection.setRequestProperty("Accept-Language", "en-US,en;q=0.5");
            connection.setRequestMethod("POST");
            connection.setDoInput(true);
            connection.setDoOutput(true);
            return connection;

        } catch (Exception e) {
            e.printStackTrace();
            LoggerHandler.ErrorOut(e, messageUUID, sourceSystemName, this.getClass().getName(), "IAM Connectivity failed : " + e.toString());
            FaultType faultType = new FaultType(ContactManagementConstants.TECHNICAL_ERROR_CODE, e.getMessage());
            PINResetFault pinResetFault = new PINResetFault(faultType);
            GetPINResetFault getPINResetFault = new GetPINResetFault("IAM.Pinreset Service connection failed", pinResetFault, e);
            throw getPINResetFault;
        }
    }
}
