package com.jh.insurance.contactmanagement.orchestration;

import com.example.xmlns._1435354270716.contactmanagement.GetPINResetFault;
import com.jh.common.logging.LoggerHandler;
import com.jh.insurance.contactmanagement.constants.ContactManagementConstants;
import com.jh.insurance.contactmanagement.exception.IamPinResetImplException;
import com.jh.insurance.contactmanagement.model.DocRoot;
import com.jh.insurance.contactmanagement.model.ErrorResponse;
import com.jh.insurance.contactmanagement.model.PINResetResponseWrapper;
import com.jh.insurance.contactmanagement.service.ContactManagementService;
import com.jh.insurance.contactmanagement.utility.LoggingContextHolder;
import com.manulife.esb.xsd.common.jh.commonmessage.FaultType;
import com.manulife.esb.xsd.common.jh.header.JHHeader;
import com.manulife.esb.xsd.insurance.jh.contactmanagement.PINResetFault;
import com.manulife.esb.xsd.insurance.jh.contactmanagement.PINResetRequest;
import com.manulife.esb.xsd.insurance.jh.contactmanagement.PINResetResponse;
import com.manulife.esb.xsd.insurance.jh.contactmanagement.PartyIdGroupType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;
import java.io.StringWriter;

@Component
public class ContactManagementOrchestration {
    @Autowired
    ContactManagementService contactManagementService;


    public PINResetResponseWrapper resetCustomerPinDetails(JHHeader header, PINResetRequest request) throws Exception {
        final String messageUUID = LoggingContextHolder.getLoggingContext().getMessageUUID();
        final String sourceSystemName = LoggingContextHolder.getLoggingContext().getSourceSystemName();

        LoggerHandler.LogOut("INFO", "2a", messageUUID, sourceSystemName, this.getClass().getName(), request.toString());
        PartyIdGroupType partyIdGroupType = request.getPartyIdGroup();
        PINResetResponseWrapper pinResetResponse = resetCustomerPin(header, partyIdGroupType);
        LoggerHandler.LogOut("INFO", "5b", messageUUID, sourceSystemName, this.getClass().getName(), pinResetResponse.toString());
        return pinResetResponse;
    }


    private PINResetResponseWrapper resetCustomerPin(JHHeader header, PartyIdGroupType partyIdGroupType) throws Exception {
        final String messageUUID = LoggingContextHolder.getLoggingContext().getMessageUUID();
        final String sourceSystemName = LoggingContextHolder.getLoggingContext().getSourceSystemName();

        LoggerHandler.LogOut("INFO", "2b", messageUUID, sourceSystemName, this.getClass().getName(), partyIdGroupType.toString());
        PINResetResponseWrapper pinResetResponseWrapper = null;
        try {
            if (partyIdGroupType.getPartyId().length() > 0) {

                //Creating ISAM Request object
                DocRoot isamRequest = new DocRoot();
                DocRoot.Entry entry = new DocRoot.Entry();
                entry.setForcePINReset(new DocRoot.Entry.ForcePINReset(partyIdGroupType.getPartyId(), partyIdGroupType.getPartyId(), ContactManagementConstants.APPLID));
                isamRequest.setEntry(entry);

                JAXBContext jaxbContext = JAXBContext.newInstance(DocRoot.class);
                Marshaller jaxbMarshaller = jaxbContext.createMarshaller();
                StringWriter sw = new StringWriter();
                jaxbMarshaller.marshal(isamRequest, sw);
                String xmlStringRequest = sw.toString();
                pinResetResponseWrapper = contactManagementService.resetCustomerPin(header, xmlStringRequest);
                //    pinResetResponse = contactManagementService.resetCustomerPinService(messageUUID, sourceSystemName, isamRequest);

                pinResetResponseWrapper.
            } else {
                throw new IamPinResetImplException(new Exception("Invalid request : PartyID not present in the request"), HttpStatus.BAD_REQUEST, new ErrorResponse("400", "PartyID not present in the request", "Invalid request : PartyID not present in the request"));
            }

            LoggerHandler.LogOut("INFO", "5a", messageUUID, sourceSystemName, this.getClass().getName(), pinResetResponseWrapper.toString());

        } catch (GetPINResetFault getPINResetFault) {
            throw getPINResetFault;
        } catch (Exception e) {
            e.printStackTrace();
            FaultType faultType = new FaultType(ContactManagementConstants.TECHNICAL_ERROR_CODE, e.getMessage());
            PINResetFault pinResetFault = new PINResetFault(faultType);
            GetPINResetFault getPINResetFault = new GetPINResetFault("DST Service not available", pinResetFault, e);
            throw getPINResetFault;
        }
        return pinResetResponseWrapper;
    }
}
