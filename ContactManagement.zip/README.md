# ContactManagement  Design Document
## Introduction
    This document defines the service specification for SOA components making up the Contact Management service for John Hancock LTC.
    This service supports operations related to Contact Management. The operations currently specified are:

1. ResetPIN

## REST Operations
|Operation|URI|Method|
|---|:---:|---:|
|ResetCustomerPin|/JH/Ins/Security/IAM/Pin/Reset|POST|

# SOAP Endpoint URL
Operation|URI|Local Part|
---|---|---|
ResetCustomerPin|https://contactmanagement-dev.apps.cac.preview.pcf.manulife.com/insurance/ContactManagement1.0/|PINReset_request|

## Swagger URL
https://contactmanagement-dev.apps.cac.preview.pcf.manulife.com/swagger-ui.html

## Audit Point
No|Reference Interpretation
---|---
1|Data received From Input
2|Data Sent to End System
3|Data Output received from End System
4|Data sent back to Output

## HTTP Error Codes
# For REST Service
Error Code|Error Description
---|---
200|Success
408|Request Timeout
417|Max Records (Search only)
500|Technical Error
400|Invalid Input, Bad Request of Validation Failed.
404|Record not found

# For SOAP Service
Code|Reason|Detail
---|---|---
999|No Data Found|No Data Found based on criteria
993|Invalid Input|Invalid information entered for input.
998|[] records found, refine search criteria|[] records found, it is greater than user maximum input of []
9999|Technical Error|Stacktrace Message
99999|Service Timed Out|Service Timed Out


## Notes
To run locally, set profile to **local** and ensure the following environment variables are defined:
- url
- username
- password
